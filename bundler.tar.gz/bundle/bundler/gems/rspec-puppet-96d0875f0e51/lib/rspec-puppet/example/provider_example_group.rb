module RSpec::Puppet
  module ProviderExampleGroup
  end
end
