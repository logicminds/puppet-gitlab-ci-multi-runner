require 'spec_helper'

describe 'cycle::bad' do
  it { should_not compile }
end
