Puppet::Parser::Functions.newfunction(:nasty, :type => :rvalue) do |arguments|
  arguments.shift
end
