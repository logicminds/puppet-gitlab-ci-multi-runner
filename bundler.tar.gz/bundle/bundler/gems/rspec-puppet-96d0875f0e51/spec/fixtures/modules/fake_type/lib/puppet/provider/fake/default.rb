Puppet::Type.type(:fake).provide(:default) do

end
