require 'mock_function'
require 'mock_resource'
require 'template_harness'
require 'hieradata/validator'
require 'hieradata/yaml_validator'

include RSpecPuppetUtils
