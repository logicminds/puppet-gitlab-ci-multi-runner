#Beaker for Modules
##Read the Beaker Docs

[Beaker How To](How-To-Beaker.md)
[Beaker DSL API](http://rubydoc.info/github/puppetlabs/beaker/frames)

##Understand the Difference Between beaker and beaker-rspec
[beaker vs. beaker-rspec](beaker-vs.-beaker-rspec.md)

##beaker-rspec Details
See the [beaker-rspec README](https://github.com/puppetlabs/beaker-rspec/blob/master/README.md) for details on how to use beaker-rspec with modules.
