# Reviewers/Maintainers For Beaker
For the majority of Beaker new code will be reviewed and merged by these owners.

|Owners|
|:------:|
|[Alice Nodelman (anodelman)](https://github.com/anodelman)|
|[Kevin Imber (kevpl)](https://github.com/kevpl)|

# Reviewers/Maintainers For Specific Areas of Beaker
For code to land in these specific areas of Beaker the following owners must provide review and :+1:

 Code | Owners
:-------:|:----------:
Beaker::Hypervisor::Docker | [Richard Pijnenburg (electrical)](https://github.com/electrical)
FreeBSD | [Peter Souter (petems)](https://github.com/petems)
OpenBSD | [Matt Dainty (bodgit)](https://github.com/bodgit)
