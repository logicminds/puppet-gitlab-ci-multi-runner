# Beaker Acceptance Tests: fixtures

Any files needed to execute Beaker acceptance tests.
