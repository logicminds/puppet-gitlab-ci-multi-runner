{
  :load_path => File.join('acceptance', 'lib')
}
