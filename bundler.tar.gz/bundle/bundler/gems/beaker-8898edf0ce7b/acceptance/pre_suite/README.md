# Beaker Acceptance Tests: pre-suite

Collection of pre-suites for SUT configuration before test execution.

Options:
* install PE
* install FOSS Puppet
