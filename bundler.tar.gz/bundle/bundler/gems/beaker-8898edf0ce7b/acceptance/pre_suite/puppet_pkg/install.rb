# the version is required on windows
# all versions are required for osx
install_puppet({
  :version        => '3.8.1',
  :facter_version => '2.1.0',
  :hiera_version  => '1.3.4',
})