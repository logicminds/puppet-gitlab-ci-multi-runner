# Beaker Acceptance Tests: base

Tests that do not depend upon Puppet being installed on the SUTs.

