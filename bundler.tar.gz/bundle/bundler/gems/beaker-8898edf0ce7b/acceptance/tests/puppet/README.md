# Beaker Acceptance Tests: puppet

Tests that depend upon Puppet being installed on the SUTs.
