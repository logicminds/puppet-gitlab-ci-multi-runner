module Beaker
  module Version
    STRING = '2.31.0'
  end
end
