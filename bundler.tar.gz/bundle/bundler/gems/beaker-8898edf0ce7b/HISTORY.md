# default - History
## Tags
* [LATEST - 16 Dec, 2015 (da1729b0)](#LATEST)
* [2.30.1 - 3 Dec, 2015 (9f1376ef)](#2.30.1)
* [2.30.0 - 2 Dec, 2015 (dbb72630)](#2.30.0)
* [2.29.1 - 23 Nov, 2015 (5d824690)](#2.29.1)
* [2.29.0 - 18 Nov, 2015 (33fd2399)](#2.29.0)
* [2.28.0 - 4 Nov, 2015 (89829551)](#2.28.0)
* [2.27.0 - 21 Oct, 2015 (0378d13a)](#2.27.0)
* [2.26.0 - 13 Oct, 2015 (427a512b)](#2.26.0)
* [2.25.0 - 1 Oct, 2015 (51d4cb1a)](#2.25.0)
* [2.24.0 - 15 Sep, 2015 (c12e9054)](#2.24.0)
* [2.23.0 - 9 Sep, 2015 (2532324a)](#2.23.0)
* [2.22.0 - 1 Sep, 2015 (96ec20a7)](#2.22.0)
* [2.21.0 - 26 Aug, 2015 (40281eb2)](#2.21.0)
* [2.20.0 - 17 Aug, 2015 (8a419e98)](#2.20.0)
* [2.19.0 - 13 Aug, 2015 (80897129)](#2.19.0)
* [2.18.3 - 28 Jul, 2015 (d9a02474)](#2.18.3)
* [2.18.2 - 27 Jul, 2015 (c84f6f23)](#2.18.2)
* [2.18.1 - 14 Jul, 2015 (6a82f99f)](#2.18.1)
* [2.18.0 - 13 Jul, 2015 (e018f2fc)](#2.18.0)
* [2.17.0 - 10 Jul, 2015 (aaac4771)](#2.17.0)
* [2.16.0 - 6 Jul, 2015 (b3e76227)](#2.16.0)
* [2.15.1 - 1 Jul, 2015 (cd6f0bab)](#2.15.1)
* [2.15.0 - 1 Jul, 2015 (07c416fb)](#2.15.0)
* [2.14.1 - 5 Jun, 2015 (35026603)](#2.14.1)
* [2.14.0 - 4 Jun, 2015 (c0ebcd16)](#2.14.0)
* [2.13.0 - 29 May, 2015 (dd70aa66)](#2.13.0)
* [2.12.0 - 20 May, 2015 (62845ce9)](#2.12.0)
* [2.11.0 - 6 May, 2015 (b775cc73)](#2.11.0)
* [2.10.0 - 22 Apr, 2015 (c4f37479)](#2.10.0)
* [2.9.0 - 9 Apr, 2015 (b161d325)](#2.9.0)
* [beaker2.8.0 - 26 Mar, 2015 (2d25d06d)](#beaker2.8.0)
* [beaker2.7.1 - 19 Mar, 2015 (45b2bf10)](#beaker2.7.1)
* [beaker2.7.0 - 19 Mar, 2015 (38b14ef8)](#beaker2.7.0)
* [beaker2.6.0 - 12 Mar, 2015 (d4e731ab)](#beaker2.6.0)
* [beaker2.5.1 - 4 Mar, 2015 (009c2c63)](#beaker2.5.1)
* [beaker2.5.0 - 23 Feb, 2015 (c421cf95)](#beaker2.5.0)
* [beaker2.4.1 - 13 Feb, 2015 (84400ed1)](#beaker2.4.1)
* [beaker2.4.0 - 13 Feb, 2015 (bc5a6676)](#beaker2.4.0)
* [beaker2.3.0 - 29 Jan, 2015 (3d185da0)](#beaker2.3.0)
* [beaker2.2.0 - 8 Jan, 2015 (cba5f7ed)](#beaker2.2.0)
* [beaker2.1.0 - 17 Dec, 2014 (ec089b1a)](#beaker2.1.0)
* [beaker2.0.0 - 5 Dec, 2014 (fb4b620b)](#beaker2.0.0)
* [beaker1.20.1 - 17 Oct, 2014 (be250ad6)](#beaker1.20.1)
* [beaker1.20.0 - 17 Oct, 2014 (24acc2d3)](#beaker1.20.0)
* [beaker1.19.1 - 19 Sep, 2014 (3aafc71d)](#beaker1.19.1)
* [beaker1.19.0 - 19 Sep, 2014 (6a56cc90)](#beaker1.19.0)
* [beaker1.18.0 - 18 Sep, 2014 (b9171d9c)](#beaker1.18.0)
* [beaker1.17.7 - 2 Sep, 2014 (e47881f0)](#beaker1.17.7)
* [beaker1.17.6 - 27 Aug, 2014 (bfb257bf)](#beaker1.17.6)
* [beaker1.17.5 - 22 Aug, 2014 (7e553089)](#beaker1.17.5)
* [beaker1.17.4 - 21 Aug, 2014 (8e6d070f)](#beaker1.17.4)
* [beaker1.17.3 - 20 Aug, 2014 (f8a536c1)](#beaker1.17.3)
* [beaker1.17.2 - 15 Aug, 2014 (c6f1f64a)](#beaker1.17.2)
* [beaker1.17.1 - 12 Aug, 2014 (72e60299)](#beaker1.17.1)
* [beaker1.17.0 - 12 Aug, 2014 (fb482b56)](#beaker1.17.0)
* [beaker1.16.0 - 17 Jul, 2014 (c1267696)](#beaker1.16.0)
* [beaker1.15.0 - 8 Jul, 2014 (82bb4ef9)](#beaker1.15.0)
* [beaker1.14.1 - 3 Jul, 2014 (d2e750d5)](#beaker1.14.1)
* [beaker1.14.0 - 3 Jul, 2014 (cf8ea838)](#beaker1.14.0)
* [beaker1.13.1 - 23 Jun, 2014 (aa09552d)](#beaker1.13.1)
* [beaker1.13.0 - 20 Jun, 2014 (5e80c638)](#beaker1.13.0)
* [beaker1.12.2 - 12 Jun, 2014 (a31ba183)](#beaker1.12.2)
* [beaker1.12.1 - 30 May, 2014 (36b14dc7)](#beaker1.12.1)
* [beaker1.12.0 - 21 May, 2014 (591d3595)](#beaker1.12.0)
* [beaker1.11.2 - 16 May, 2014 (f28c387b)](#beaker1.11.2)
* [beaker1.11.1 - 15 May, 2014 (f684a724)](#beaker1.11.1)
* [beaker1.11.0 - 8 May, 2014 (a389e3d1)](#beaker1.11.0)
* [beaker1.10.0 - 22 Apr, 2014 (fbef5d2b)](#beaker1.10.0)
* [beaker1.9.1 - 27 Mar, 2014 (747ee73e)](#beaker1.9.1)
* [beaker1.9.0 - 26 Mar, 2014 (7feb8327)](#beaker1.9.0)
* [beaker1.8.2 - 21 Mar, 2014 (0f848be8)](#beaker1.8.2)
* [beaker1.8.1 - 19 Mar, 2014 (4de3450e)](#beaker1.8.1)
* [beaker1.8.0 - 17 Mar, 2014 (0cea9162)](#beaker1.8.0)
* [beaker1.7.0 - 19 Feb, 2014 (0ad045fe)](#beaker1.7.0)
* [beaker1.6.2 - 31 Jan, 2014 (ed048e29)](#beaker1.6.2)
* [beaker1.6.1 - 30 Jan, 2014 (468bbb6f)](#beaker1.6.1)
* [beaker1.6.0 - 30 Jan, 2014 (3787bdb8)](#beaker1.6.0)
* [beaker1.5.0 - 29 Jan, 2014 (78db5afb)](#beaker1.5.0)
* [beaker1.4.1 - 27 Jan, 2014 (bc6a7d32)](#beaker1.4.1)
* [beaker1.4.0 - 24 Jan, 2014 (c24f0194)](#beaker1.4.0)
* [beaker1.3.2 - 23 Jan, 2014 (39bbbf0c)](#beaker1.3.2)
* [beaker1.3.1 - 18 Dec, 2013 (08b59809)](#beaker1.3.1)
* [beaker1.3.0 - 13 Dec, 2013 (5815f829)](#beaker1.3.0)
* [beaker1.2.0 - 5 Dec, 2013 (59070752)](#beaker1.2.0)
* [beaker1.0.1 - 25 Nov, 2013 (70f55b11)](#beaker1.0.1)
* [beaker1.0.1pre - 20 Nov, 2013 (8cffaf28)](#beaker1.0.1pre)
* [beaker1.0.0 - 8 Nov, 2013 (c85186b7)](#beaker1.0.0)
* [beaker0.0.0 - 20 Aug, 2013 (c49dc525)](#beaker0.0.0)
* [pe3.0 - 6 Jun, 2013 (0b52d9c5)](#pe3.0)
* [pe2.8.1 - 15 Apr, 2013 (7f527ff2)](#pe2.8.1)
* [pe2.8.0 - 26 Mar, 2013 (6b79859e)](#pe2.8.0)
* [pe2.7.1 - 8 Feb, 2013 (9826e1ca)](#pe2.7.1)
* [pe2.7.0 - 16 Nov, 2012 (08c2bd19)](#pe2.7.0)
* [pe2.6.1 - 9 Oct, 2012 (58edb963)](#pe2.6.1)
* [pe2.6.0 - 17 Sep, 2012 (592ad45d)](#pe2.6.0)
* [pe2.5.3 - 23 Jul, 2012 (0eb96550)](#pe2.5.3)
* [pe2.5.2 - 9 Jul, 2012 (eaa93833)](#pe2.5.2)
* [pe2.5.0 - 27 Mar, 2012 (232e21a5)](#pe2.5.0)
* [pe2.0.3 - 21 Feb, 2012 (492ff756)](#pe2.0.3)
* [pe2.0.2 - 3 Feb, 2012 (e36f0d22)](#pe2.0.2)
* [pe2.0.1 - 31 Jan, 2012 (3a118201)](#pe2.0.1)
* [pe2.0 - 11 Nov, 2011 (4d7b65b6)](#pe2.0)
* [pe1.2 - 6 Sep, 2011 (ba3dadd2)](#pe1.2)

## Details
### <a name = "LATEST">LATEST - 16 Dec, 2015 (da1729b0)

* (GEM) update beaker version to 2.31.0 (da1729b0)

* Revert "Added netscaler platform" (112ef320)


```
Revert "Added netscaler platform"

This reverts commit 6a2abd36fe5b36db163582b12dca11b5cd018c7f.
```
* Added netscaler platform (6a2abd36)

* Merge pull request #1034 from erikPrime/(BKR-237)_disable_updates.puppetlabs.com (23bc8f94)


```
Merge pull request #1034 from erikPrime/(BKR-237)_disable_updates.puppetlabs.com

(BKR-237) disable updates.puppetlabs.com
```
* (BKR-237) fixed option & updated tests (85a99ef8)

* Merge pull request #1033 from kevpl/bkr647_windows_pkgcygwin (e0d06f7f)


```
Merge pull request #1033 from kevpl/bkr647_windows_pkgcygwin

(BKR-647) windows.install_package now uses SSL cygwin URL with fallback
```
* (BKR-237) mods in response to review (af321acf)

* (MAINT) fix spec test for set_etc_hosts (cf6dc589)

* (MAINT) makes set_etc_hosts APPEND instead of REPLACE (09cbdf77)

* (BKR-237) updates.puppetlabs.com resolves to 127.0.0.1 (a78ee042)

* Merge pull request #1031 from kevpl/bkr642_aix_fix (ab4ebd1d)


```
Merge pull request #1031 from kevpl/bkr642_aix_fix

(BKR-642) include aix exec, error checking to unix exec
```
* Merge pull request #1032 from kevpl/bkr628_mac_group (2c79ac19)


```
Merge pull request #1032 from kevpl/bkr628_mac_group

(BKR-628) fixed mac group_present check
```
* (BKR-647) windows.install_package now uses SSL cygwin URL with fallback (95bf615b)

* Merge pull request #1025 from ody/add_privatebindir_to_path (6e7333f5)


```
Merge pull request #1025 from ody/add_privatebindir_to_path

Add privatebindir to PATH
```
* (BKR-628) fixed mac group_present check (35b12e53)

* Merge pull request #1029 from kevpl/bkr569_fetch_nocache (3ffd8b42)


```
Merge pull request #1029 from kevpl/bkr569_fetch_nocache

(BKR-569) added caching disable option
```
* (BKR-642) include aix exec, error checking to unix exec (7ba2bf64)

* Merge pull request #1026 from ody/reorder_permiteuserenv (77581a29)


```
Merge pull request #1026 from ody/reorder_permiteuserenv

Swap the placement of PermiteUserEnvironment
```
* Merge pull request #1030 from kevpl/bkr626_puppetagent_docs (7173bd15)


```
Merge pull request #1030 from kevpl/bkr626_puppetagent_docs

(BKR-626) added puppet-agent doc links
```
* Merge pull request #1018 from sathlan/feature/add_memory_option_to_vagrant_libvirt (91621239)


```
Merge pull request #1018 from sathlan/feature/add_memory_option_to_vagrant_libvirt

(BKR-631) Add memory option to vagrant libvirt.
```
* (BKR-626) added puppet-agent doc links (dee654e4)

* (BKR-569) added caching disable option (1cf628e4)

* Merge pull request #1028 from joshcooper/ticket/master/BKR-644-fedora-puppet-agent-dev-repo (a6e41cc1)


```
Merge pull request #1028 from joshcooper/ticket/master/BKR-644-fedora-puppet-agent-dev-repo

(BKR-644) Prepend 'f' to the fedora version
```
* Merge pull request #1027 from bmjen/fix-solaris (3df53898)


```
Merge pull request #1027 from bmjen/fix-solaris

(maint) Fix typo in solaris install_pe util function.
```
* (BKR-644) Prepend 'f' to the fedora version (1b15425d)


```
(BKR-644) Prepend 'f' to the fedora version

Previously, install_puppet_agent_dev_repo_on did not work for fedora,
because we were constructing a URL of the form:

    http://<host>/puppet-agent/<sha>/repos/fedora/22/PC1/x86_64/puppet-agent-1.3.2-1.fedora22.x86_64.rpm

However, we unfortunately prepend 'f' to the version string when
publishing the package, see RE-4191.

This commit prepends an 'f' to the version string for fedora-only, so
the new URL is:

    http://<host>/puppet-agent/<sha>/repos/fedora/f22/PC1/x86_64/puppet-agent-1.3.2-1.fedoraf22.x86_64.rpm

Note f22 appears in two places, "fedora/f22" and
"puppet-agent...-fedoraf22.x86_64.rpm"
```
* (maint) Fix typo in solaris install_pe util function. (3e68260a)

* (MAINT) Swap placement of PermitUserEnvironment (2cb7f6d6)


```
(MAINT) Swap placement of PermitUserEnvironment

  This commit will rework the way PermiteUserEnvironment is added to
  sshd_config by putting it at the top of the file.

  Without this commit you will create a bad sshd_config if your sut's
  base image containes matching blocks the end of its sshd_config
  because the PermitUserEnvironment option is not allowed there.  This
  ordering is likely perferred since it is generally the norm to put
  matching blocks at the end of the sshd_config.
```
* (MAINT) Add privatebindir to PATH (5e45c1f1)


```
(MAINT) Add privatebindir to PATH

  This commit will add privatebindir to the list of paths added to the
  PATH variable stored in ~/.ssh/environment.

  This needs to happen so that the gem command and any excutables
  installed using that gem command are available for use during a suite.
  A requirement if your suite deploys dependencies with r10k on both aio
  and foss agent types.
```
* (BKR-631) Add memory option to vagrant libvirt. (349501e0)


```
(BKR-631) Add memory option to vagrant libvirt.

This add the possibility to specify the memory for each host separately
or for every host.
```
### <a name = "2.30.1">2.30.1 - 3 Dec, 2015 (9f1376ef)

* (HISTORY) update beaker history for gem release 2.30.1 (9f1376ef)

* (GEM) update beaker version to 2.30.1 (a1ee5206)

* Merge pull request #1024 from puppetlabs/revert-1013-bkr-623/test-runner-reorganization (18307e09)


```
Merge pull request #1024 from puppetlabs/revert-1013-bkr-623/test-runner-reorganization

Revert "[BKR-623] Reorganize Beaker test runner classes for introduction of minitest runner"
```
* Revert "[BKR-623] Reorganize Beaker test runner classes for introduction of minitest runner" (979a329e)

### <a name = "2.30.0">2.30.0 - 2 Dec, 2015 (dbb72630)

* (HISTORY) update beaker history for gem release 2.30.0 (dbb72630)

* (GEM) update beaker version to 2.30.0 (bc912e78)

* Merge pull request #1013 from puppetlabs/bkr-623/test-runner-reorganization (6c613051)


```
Merge pull request #1013 from puppetlabs/bkr-623/test-runner-reorganization

[BKR-623] Reorganize Beaker test runner classes for introduction of minitest runner
```
* Merge pull request #1021 from kevpl/yard_gen_fix (5fcdb777)


```
Merge pull request #1021 from kevpl/yard_gen_fix

(MAINT) updated yard doc location
```
* Merge pull request #1016 from hunner/add_solaris (1245f155)


```
Merge pull request #1016 from hunner/add_solaris

(BKR-472) (BKR-475) Fix solaris for install_pe_on with 2015.2
```
* Merge pull request #1017 from adrienthebo/ruby-193-p194-platform-yaml-deserialize (d4854de2)


```
Merge pull request #1017 from adrienthebo/ruby-193-p194-platform-yaml-deserialize

(BKR-634) Fix YAML deserialization for Beaker::Platform
```
* Merge pull request #1008 from developerinlondon/master (6bdb61bc)


```
Merge pull request #1008 from developerinlondon/master

(BKR-622) Fix Regular Expression to give correct Host IP Address
```
* Merge pull request #1022 from bleach/fix_module_howto (125fd861)


```
Merge pull request #1022 from bleach/fix_module_howto

(BKR-636) Fix module howto
```
* (BKR-623) Make native runner name consistent (fdd904eb)


```
(BKR-623) Make native runner name consistent

Prior to this we ended up in a state where the beaker native runner
was in the Beaker::Runner::Native module namespace, but textual and
--runner references to the runner used the name 'beaker'. This makes
them consistently 'native'.
```
* (BKR-623) Stop advertising minitest runner in --help (1164b15c)


```
(BKR-623) Stop advertising minitest runner in --help

We will wait until this is ready for prime time to mention it.
```
* Merge pull request #1012 from kevpl/bkr609_pever_empty (bff4d847)


```
Merge pull request #1012 from kevpl/bkr609_pever_empty

(BKR-609) added checks to make aio_version? more robust
```
* (BKR-636) Specify module directory in spec helper (3635726c)


```
(BKR-636) Specify module directory in spec helper

Unless this is specified, the module seems to be installed in
/etc/puppetlabs/puppet/modules, where it is not found by puppet.
```
* (BKR-636) Tell the user to install pry (151d72fe)


```
(BKR-636) Tell the user to install pry

The sample spec_helper requires pry, so we now tell the user to install it.
```
* Merge pull request #1014 from heathseals/extraConfig (1317b33b)


```
Merge pull request #1014 from heathseals/extraConfig

(BKR-635) Add VM hostname to VMX data during cloning operations
```
* (MAINT) updated yard doc location (1c51fdee)


```
(MAINT) updated yard doc location

Since moving the wiki docs into the repo itself, there's been
an issue where if you ran the yard rake tasks, you'd blow away
the in-repo docs, because the default yard doc location is the
same as the in-repo docs location: . This change makes
yard create the  folder, and use it for local doc
generation
```
* (BKR-634) Fix YAML deserialization for Beaker::Platform (2ddd8881)


```
(BKR-634) Fix YAML deserialization for Beaker::Platform

The version of Psych shipped with Ruby 1.9.3-p194 did not support
subclasses of String that added additional ivars to the String class.
The Beaker::Platform class does just that - subclassing String and
additional ivars - which meant that round tripping a Beaker::Platform
object would create an object with improperly initialized instance
variables. Psych commit e2fcf9af9e95535401f816bc893839b9ad743a9e
resolved that issue but we still use platforms that have the old version
of psych.

To resolve this issue, this commit implements a custom #init_with method
that explicitly sets all instance variables on the Beaker object that
were defined inside of the YAML map instance, and then reconstructs the
string value based on those fields.
```
* (BKR-472) (BKR-475) Fix solaris for install_pe_on with 2015.2 (e27613e1)


```
(BKR-472) (BKR-475) Fix solaris for install_pe_on with 2015.2

When trying to install puppet-agent collection packages through
`install_pe_on`, eventually `install_puppet_agent_pe_promoted_repo_on`
gets called but has no entry for where the solaris packages are kept.
This commit adds the ability for solaris to install PC puppet-agent
packages.
```
* (BKR-623) Remove inheritance from Beaker::TestSuite (c8610167)

* (BKR-623) migrate TestCase tests into native runner (afc9546a)

* (BKR-632) Include 'minitest' in --runner options list (e84a4059)

* (BKR-623) Add barebones minitest test suite class (a33c5ec5)

* (BKR-623) Migrate TestSuite tests to the native runner (43c7ac77)

* (BKR-635) Add VM hostname to VMX data during cloning operations (55fb8447)


```
(BKR-635) Add VM hostname to VMX data during cloning operations

This commit adds a custom guestinfo keyword and hostname variable
that allows the VMware Tools to query the hostname.
```
* (BKR-623) Rename runner/beaker to runner/native, ... (7d13665e)


```
(BKR-623) Rename runner/beaker to runner/native, ...

... and bring `Beaker::TestCase` into the fold.

Prior to this, `Beaker::TestCase` was still global. In moving it to a nested
`Beaker::Runner::Beaker::TestCase` I found that a few tests were starting to
fail. Further investigation showed that references to `Beaker::*` classes
inside tests were being resolved as `Beaker::Runner::Beaker::*`, and throwing
constant missing exceptions. Moving `Beaker::Runner::Beaker` to
`Beaker::Runner::Native` allows ruby's nested class resolution algorithm
to find `::Beaker` instead of a nested `Beaker` module constant.
```
* (BKR-623) Use --runner to choose test suite (f1aace6b)

* (BKR-623) Adjust const_set hack names (06469668)


```
(BKR-623) Adjust const_set hack names

Prior to this, old tests which relied on Beaker::Log being set to
@logger, would break under our refactorings. For example:
https://github.com/puppetlabs/puppet/blob/3.8.3/acceptance/tests/security/cve-2013-1653_puppet_kick.rb#L66

This should continue the duct-taping of constant names, kicking the can that much further
down the road.
```
* (BKR-623) Add `--runner` option, defaulting to "beaker" (f392f2a3)


```
(BKR-623) Add `--runner` option, defaulting to "beaker"

Note, we are generally not testing our command-line behavior, our presets, etc.
This adds a spec that shows how to easily test these sorts of things.
```
* (BKR-623) Specialize Beaker::TestSuite (1bf1ed77)


```
(BKR-623) Specialize Beaker::TestSuite

This creates a `lib/beaker/runnner` path, a `Beaker::Runner` module namespace,
and moves the `Beaker::TestSuite` there, leaving a wrapper subclass behind.

This allows us to treat the current Beaker test runner as a special case, making
space to add support for other test runners. Everything should continue working
as before, allowing us to move on to next steps.
```
* (BKR-609) added checks to make aio_version? more robust (54f79440)

* {BKR-622} Fix Regular Expression to give correct Host IP Address (5c3331b4)


```
{BKR-622} Fix Regular Expression to give correct Host IP Address

Without this patch applied the hostname can sometimes be incorrectly picked up and this
creates problem with all the hostnames getting the same IP addresses on a multi-node setup.

Example Nodeset that can cause this problem:
HOSTS:
  staging:
    roles:
      - sta
      - master
    platform: el-6-x86_64
    box: puppetlabs/centos-6.6-64-puppet
    box_url: https://vagrantcloud.com/puppetlabs/boxes/centos-6.6-64-puppet
    hypervisor: vagrant
    shared_folder: abc
    NetworkSettings:
      IPAddress: 10.255.50.100
  etl:
    roles:
      - etl
    platform: el-6-x86_64
    box: puppetlabs/centos-6.6-64-puppet
    box_url: https://vagrantcloud.com/puppetlabs/boxes/centos-6.6-64-puppet
    hypervisor: vagrant
    NetworkSettings:
      IPAddress: 10.255.50.120
CONFIG:
  type: git
  destroy: no

In the above scenario, the hostname 'etl' is also available when you search 'puppetlabs'.

The patch fixes this by changing the regular expression to look for the string 'etl' (including
the quote marks).
```
### <a name = "2.29.1">2.29.1 - 23 Nov, 2015 (5d824690)

* (HISTORY) update beaker history for gem release 2.29.1 (5d824690)

* (GEM) update beaker version to 2.29.1 (5781838d)

* Merge pull request #1019 from ody/bkr633_lesser_ruby (41647b80)


```
Merge pull request #1019 from ody/bkr633_lesser_ruby

(BKR-633) Explicitly depend on mime-types.
```
* (BKR-633) Explicitly depend on mime-types. (99fb8b11)


```
(BKR-633) Explicitly depend on mime-types.

  This commit will add an explicit dependency on the mime-types gem to
  beaker's gemspec that installs versions less than 3.0 on systems with
  a Ruby version less than 2.0.

  This has to be done in order for beaker to install freshly on systems
  where it hasn't been installed before.  The mime-types gem dropped
  ruby 1.9.2 support with 3.0 and one of beaker's dependency, fog
  depends on any version of mime-types greater than 0.
```
* Merge pull request #1009 from kevpl/bkr499_solaris10_fixups (22fe3324)


```
Merge pull request #1009 from kevpl/bkr499_solaris10_fixups

(BKR-499) solaris10 fixups
```
* (BKR-499) refactoring set_env into host logic (a661dfe0)

* (BKR-499) Solaris 10 Fixes (ba1289ca)

### <a name = "2.29.0">2.29.0 - 18 Nov, 2015 (33fd2399)

* (HISTORY) update beaker history for gem release 2.29.0 (33fd2399)

* (GEM) update beaker version to 2.29.0 (5ae7782f)

* Merge pull request #1011 from developerinlondon/feature/BKR-625-add-mounting-folder-option (4bc5750e)


```
Merge pull request #1011 from developerinlondon/feature/BKR-625-add-mounting-folder-option

(BKR-625) Added ability to mount a folder.
```
* Merge pull request #1010 from dylanratcliffe/bkr-624/fix-line_prefix_length (e48e8752)


```
Merge pull request #1010 from dylanratcliffe/bkr-624/fix-line_prefix_length

(BKR-624) Added a setter for line_prefix
```
* (BKR-624) Modified `step_in` and `step_out` methods so that you can set (e72689b5)


```
(BKR-624) Modified `step_in` and `step_out` methods so that you can set
`line_prefix` explicitly and they will still work.
```
* BKR-625: Added ability to mount a folder. (e047bd84)


```
BKR-625: Added ability to mount a folder.

Without this patch there is no way to mount a local folder inside the beaker nodes.

With this patch folders can be mounted similar to below:


    HOSTS:
      ubuntu-1404-x64-master:
        roles:
          - master
          - agent
          - dashboard
          - database
        platform: ubuntu-1404-x86_64
        hypervisor: vagrant
        box: puppetlabs/ubuntu-14.04-64-nocm
        box_url: https://vagrantcloud.com/puppetlabs/boxes/ubuntu-14.04-64-nocm
        mount_folders:
          folder1:
            from: ./
            to: /vagrant/folder1
          tmp:
            from: /tmp
            to: /vagrant/tmp
        ip: 192.168.20.20
      ubuntu-1404-x64-agent:
        roles:
          - agent
        platform: ubuntu-1404-x86_64
        hypervisor: vagrant
        box: puppetlabs/ubuntu-14.04-64-nocm
        box_url: https://vagrantcloud.com/puppetlabs/boxes/ubuntu-14.04-64-nocm
        ip: 192.168.21.21
    CONFIG:
      nfs_server: none
      consoleport: 443



In the above beaker will mount the folders ./ to /vagrant/folder1 and the folder /tmp to /vagrant/tmp

This relates to the new feature ticket opened on puppetlab here: https://tickets.puppetlabs.com/browse/BKR-625
```
* Merge pull request #1007 from adrienthebo/bkr-517-print-exception-class-message (5780f563)


```
Merge pull request #1007 from adrienthebo/bkr-517-print-exception-class-message

(BRK-617) Print exception message for test cases
```
* (BRK-617) Print exception message for test cases (788b9cda)


```
(BRK-617) Print exception message for test cases

Some exceptions implement the `#inspect` method to only print the class
name or otherwise change the output to not include the error message in
question, which makes such exceptions very challenging to deubg. This
commit changes the test case exception printing method to explicitly
print the exception class and message so that there's always relevant
context available when an exception is raised.
```
### <a name = "2.28.0">2.28.0 - 4 Nov, 2015 (89829551)

* (HISTORY) update beaker history for gem release 2.28.0 (89829551)

* (GEM) update beaker version to 2.28.0 (aadc0fcc)

* Merge pull request #1006 from puppetlabs/qeng-3063/flush-output-to-prevent-reboot-timeout-problems (7a273b77)


```
Merge pull request #1006 from puppetlabs/qeng-3063/flush-output-to-prevent-reboot-timeout-problems

[QENG-3063] Fix reboot test timeout issues on jenkins
```
* (QENG-3063/BKR-612) Wrap rsync tests in `fails_intermittently` (666e7944)


```
(QENG-3063/BKR-612) Wrap rsync tests in `fails_intermittently`

These tests are failing intermittently under very similar conditions as the
failure being addressed in QENG-3063: when a host obtains a new IP address after
a `host.reboot`, calls to `host.create_remote_file` using the rsync protocol,
and `host.rsync_to` fail, apparently due to SSH host keys having changed and
causing an error that is also not properly reported, but also due to another
root cause which is potentially related to stale IP addresses being used for
rsync-ssh connections.

Wrapping these testshere to get the QENG-3063 tests to land green. Separately
work for BKR-612 will address the rsync issue.
```
* (QENG-3063) Use `StringIO` instead of `MockIO` in logger specs (74f97eb1)


```
(QENG-3063) Use `StringIO` instead of `MockIO` in logger specs

Prior to this, attempting to use `.flush` on our logger instance (which is
necessary) would cause the various logger-related spec tests to fail. These
tests are overly mockist, but are also unnecessarily using a home-grown
under-featured `MockIO` class that provides less functionality than just using
the standard `StringIO` class, as normal IO testers are wont to do.
```
* (QENG-3063) Fix reboot test timeout issues on jenkins (98cd7785)


```
(QENG-3063) Fix reboot test timeout issues on jenkins

Prior to this change, the `host_test.rb` check for rebooting systems could
sometimes fail, only on our Beaker acceptance jenkins, but in such a way that
it was clear that something was happening after the attempt to reboot started,
but no further output was available.

Exploratory work showed that when a rebooted host changes IP address, it is
possible for not only the normal long sequence of Fibonacci-fallback connect
retries to happen, but for also various low-level TCP connection failures (with
their own long timeouts) to occur.

Since output was being buffered, and not flushed, and neither of these phases
was generating a lot of output (enough to trigger a buffer flush on its own),
it was possible for more than our 10 minute jenkins output timeout to pass
without effectively changing the output buffer.

Flushing our log output overcomes the jenkins timeout problem. We do not here
address questions of long IP-address change timeouts.
```
* Merge pull request #990 from petems/BKR-583-version_bug_fix (d5a7c089)


```
Merge pull request #990 from petems/BKR-583-version_bug_fix

(BKR-583) Fixes incorrect error when MSI missing
```
* Merge pull request #989 from petems/BKR-584-fix_mkdir_on_windows (4ad80330)


```
Merge pull request #989 from petems/BKR-584-fix_mkdir_on_windows

(BKR-584) Change to use mkdir_p helper command
```
* Merge pull request #1003 from GeoffWilliams/rublib_reset (1a854bc3)


```
Merge pull request #1003 from GeoffWilliams/rublib_reset

(BKR-511) Beaker fails to launch Vagrant VMs when run within Bundler
```
* Merge pull request #1004 from puppetlabs/bkr-358/land-host-helpers-acceptance-tests (b3fa28fe)


```
Merge pull request #1004 from puppetlabs/bkr-358/land-host-helpers-acceptance-tests

[BKR-358] Add acceptance tests for host helpers
```
* (BKR-358) Add acceptance tests for host helpers (7473e353)


```
(BKR-358) Add acceptance tests for host helpers

This adds acceptance tests, along with a configuration file suitable for running
these tests in our jenkins instance, for the Beaker host helpers.

This also temporarily disables the "reboot" host acceptance test, which has been
intermittently failing, and will be re-enabled via closure of QENG-3063.

This work is detailed in the GitHub Pull Request at:

  https://github.com/puppetlabs/beaker/pull/930
```
* (BKR-511) Beaker fails to launch Vagrant VMs when run within Bundler (e479c7cd)


```
(BKR-511) Beaker fails to launch Vagrant VMs when run within Bundler

Unset the RUBYLIB variable before shelling out to run vagrant.  Fixes dependency on outdated version of bundler
```
* Merge pull request #998 from kevpl/bkr598_aws_keymod (18c39ce1)


```
Merge pull request #998 from kevpl/bkr598_aws_keymod

(BKR-598) made AWS EC2 key name collision impractical
```
* Merge pull request #1001 from johnduarte/remove-aix-tar (97692dca)


```
Merge pull request #1001 from johnduarte/remove-aix-tar

(BKR-607) Remove tar dependency for AIX
```
* (BKR-607) Remove tar dependency for AIX (ce1e169f)


```
(BKR-607) Remove tar dependency for AIX

Prior to this commit, Beaker installed -- and removed -- tar as
a dependency of the puppet-agent package on AIX. This dependency
has been removed from puppet-agent.

This commit removes the logic to install and remove the tar rpm
from AIX. It also updates the rpec test for `remove_puppet_on`
on AIX to remove the expectation that `tar` would a dependency.
```
* Merge pull request #995 from kevpl/bkr588_eos_update (4d692e26)


```
Merge pull request #995 from kevpl/bkr588_eos_update

(BKR-588) updated eos install support
```
* Merge pull request #991 from kevpl/bkr590_ports_parameterize (1a9784e9)


```
Merge pull request #991 from kevpl/bkr590_ports_parameterize

(BKR-590) parameterized ports in helpers
```
* Merge pull request #994 from johnduarte/cumulus-remove (8d9cd4e1)


```
Merge pull request #994 from johnduarte/cumulus-remove

(BKR-597) Add cumulus logic to remove_puppet_on
```
* Merge pull request #992 from bkero/master (9e80a972)


```
Merge pull request #992 from bkero/master

(BKR-592) Add < 1.35.0 dep constraint to fog
```
* Merge pull request #999 from puppetlabs/maint/fix-readme-docs-link (261a920e)


```
Merge pull request #999 from puppetlabs/maint/fix-readme-docs-link

(MAINT) Update main README.md docs link
```
* (MAINT) Update main README.md docs link (8c979e91)


```
(MAINT) Update main README.md docs link

This was missed in the final change-over from Home.md during BKR-602, updating so that
this points to the new right place.
```
* Merge pull request #983 from alexharv074/BKR-579 (3558e0bf)


```
Merge pull request #983 from alexharv074/BKR-579

(BKR-579) rpm calls to respect package_proxy opt
```
* (BKR-598) made AWS EC2 key name collision impractical (1ba4ae60)


```
(BKR-598) made AWS EC2 key name collision impractical

Added the `:aws_keyname_modifier` property, randomly set to a string of
10 digits by default, will be used to make the AWS EC2 key name unique
to a Beaker run. The nanosecond time has been added to the key name as
well to make the chance for collisions even harder.
```
* Merge pull request #997 from puppetlabs/maint/ongoing-wiki-import-docs-tweaks (f188e7f5)


```
Merge pull request #997 from puppetlabs/maint/ongoing-wiki-import-docs-tweaks

(MAINT) Move docs to README.md, rename some files
```
* (BKR-588) added EOS docs (7b298942)

* (MAINT) Move docs to README.md, rename some files (d4a0dbdb)


```
(MAINT) Move docs to README.md, rename some files

Prior to this we were using Home.md as the root for documentation in docs/
(as a direct import from the wiki). A few files also picked up strange names at
some point in the automated cleanup process, so this fixes those, and normalizes
some file names with punctuation, etc.
```
* Merge pull request #993 from cowofevil/maint/master/BKR-596/fix_windows_path_support (6975e329)


```
Merge pull request #993 from cowofevil/maint/master/BKR-596/fix_windows_path_support

(BKR-596) Fix Windows Path Support
```
* Merge pull request #996 from puppetlabs/bkr-xxx/move-wiki-to-in-repo-docs (5709ac2b)


```
Merge pull request #996 from puppetlabs/bkr-xxx/move-wiki-to-in-repo-docs

(BKR-600) Import wiki docs, relativize markdown links
```
* (BKR-600) Import wiki docs, relative markdown links (09f2d189)


```
(BKR-600) Import wiki docs, relative markdown links

Import was via:

git subtree add --prefix docs https://github.com/puppetlabs/beaker.wiki.git master --squash

Cleanup was via:

perl -p -i -e "s|https://github\.com/puppetlabs/beaker/wiki/([^.)#]+)([#)])|\1.md\2|g" docs/*

Additionally did some manual whitespace cleanup, edited README.md.

Notes:

git-subtree-dir: doc
git-subtree-split: 750f8dec7b5d453bcc567dec14b43b5d1f319447
```
* Merge pull request #986 from kevpl/bkr587_applymanifeston_docs2 (2fd10105)


```
Merge pull request #986 from kevpl/bkr587_applymanifeston_docs2

(BKR-587) added nil as a result to apply_manifest_on docs
```
* (BKR-588) updated eos install support (4f9d11d9)

* (BKR-596) Fix Broken Spec Test (c8f66627)


```
(BKR-596) Fix Broken Spec Test

Should have fixed this in the first place!
```
* (BKR-596) Fix Windows Path Support (867141f9)


```
(BKR-596) Fix Windows Path Support

The "copy_module_to" method does not detect if the target machine is Windows
after SCP copy of the module. It attempts to move the directory because path
joining does not account for "/" separators in the path.
```
* (BKR-597) Add cumulus logic to remove_puppet_on (a697937e)


```
(BKR-597) Add cumulus logic to remove_puppet_on

This commit adds logic for gathering installed puppet packages
on cumulus for removal in the `remove_puppet_on` method
```
* (BKR-592) Add < 1.35.0 dep constraint to fog (3625c573)


```
(BKR-592) Add < 1.35.0 dep constraint to fog

This commit adds a < 1.35.0 dependency constraint to the fog entry in
beaker's gemspec file. This fixes a problem introduced in fog 1.35.0
where it starts depending on a newer version of fog-google than beaker
currently allows.
```
* (BKR-579) rpm calls to respect package_proxy opt (6b9aeab0)


```
(BKR-579) rpm calls to respect package_proxy opt

Without this patch applied, the call to rpm in Beaker::DSL::InstallUtils
ignores the package_proxy option.

We add two new methods, extract_rpm_proxy_options and
install_package_with_rpm.

The extract_rpm_proxy_options method is needed as the rpm command
expects command line options --httpproxy and --httpport.

The install_package_with_rpm method is needed in order to install rpms
from a remote URL address.  The existing install_package method uses yum
and yum can't install an rpm from a remote URL.

Spec tests are provided for the new methods and one redundant spec test
is deleted.
```
* (BKR-590) parameterized ports in helpers (b26470f8)

* (BKR-584) Change to use mkdir_p helper command (6f1deef2)


```
(BKR-584) Change to use mkdir_p helper command

Makes command cross-compatible for PSWindows
```
* (BKR-587) added nil as a result to apply_manifest_on docs (be3fb7dd)

* (BKR-583) Fixes incorrect error when MSI missing (2f117f1a)


```
(BKR-583) Fixes incorrect error when MSI missing

`version` variable missing, so get error:

`<NameError: undefined local variable or method 'version'>`

Rather than correct error:

`<RuntimeError: Puppet MSI at /puppet-agent-VERSION-x86.msi does not exist!>`
```
### <a name = "2.27.0">2.27.0 - 21 Oct, 2015 (0378d13a)

* (HISTORY) update beaker history for gem release 2.27.0 (0378d13a)

* (GEM) update beaker version to 2.27.0 (90fddaf4)

* Merge pull request #961 from GeoffWilliams/dockerfile_externalise (f4a90933)


```
Merge pull request #961 from GeoffWilliams/dockerfile_externalise

(BKR-539) simplified Dockerfile support
```
* Merge pull request #987 from johnduarte/remove_puppet_patch (2cdcb71e)


```
Merge pull request #987 from johnduarte/remove_puppet_patch

(BKR-573) Add publisher for solaris package removal
```
* Merge pull request #977 from colinPL/qeng2604_add_tags (e79b4b17)


```
Merge pull request #977 from colinPL/qeng2604_add_tags

(QENG-2604) Add Host Tags
```
* Merge pull request #962 from pondohva/decrease_spamlog_level (a7630b05)


```
Merge pull request #962 from pondohva/decrease_spamlog_level

(BKR-542) remove hosts object from log about execution against empty …
```
* (QENG-2604) More vmpooler spec changes (dec9511c)


```
(QENG-2604) More vmpooler spec changes

Remove some key:value checks from spec test. Override a used @option
value and ensure it passes through add_tags.
```
* (QENG-2604) Fix vmpooler specs (8d71a905)


```
(QENG-2604) Fix vmpooler specs

Fix vmpooler spec tests for tags that were hard-coded but checking
against environment variables.
```
* (QENG-2604) Add More host_tag specs (f6fe7d5a)


```
(QENG-2604) Add More host_tag specs

Add spec tests for aws_sdk and vmpooler hypervisors targetting
host_tags behavior.
```
* (QENG-2604) Break add_tags in vmpooler (93d44425)


```
(QENG-2604) Break add_tags in vmpooler

Move the merging of host tags with pre-defined tags to its own method
to emulate how it behaves in aws_sdk.
```
* Merge pull request #988 from joshcooper/ticket/master/BKR-574-allow-no-restart (bfb6b356)


```
Merge pull request #988 from joshcooper/ticket/master/BKR-574-allow-no-restart

(BKR-574) Allow global restart_when_done => false
```
* (BKR-574) Allow global restart_when_done => false (8d6742ef)


```
(BKR-574) Allow global restart_when_done => false

Previously, setting `:restart_when_done` to false on the master host, or
globally in options, did not work, because the `with_puppet_running_on`
method was checking for a truthy value.

This commit checks if the key is in the hash instead. It also preserves
the behavior where the options passed in by the test case take
precedence over the host's value.
```
* (BKR-573) Add publisher for solaris package removal (e90918c9)

* Merge pull request #984 from ferventcoder/ticket/master/BKR-582 (45cca4e8)


```
Merge pull request #984 from ferventcoder/ticket/master/BKR-582

(BKR-582) Colorization adjustments / CI Build / Allow overriding log colors
```
* Merge pull request #976 from johnduarte/remove_puppet_on (92a5309b)


```
Merge pull request #976 from johnduarte/remove_puppet_on

(BKR-573) Add remove_puppet_on
```
* Merge pull request #982 from kevpl/bkr571_applymanifeston_docs (2a9b0a32)


```
Merge pull request #982 from kevpl/bkr571_applymanifeston_docs

(BKR-571) updated documentation on return types
```
* Merge pull request #972 from azhurbilo/patch-1 (26c8c8bb)


```
Merge pull request #972 from azhurbilo/patch-1

(BKR-380) Fix '3389' (host port) is declared multiple times
```
* (BKR-582) Colorization adjustments / CI Build (c2dc9fd7)


```
(BKR-582) Colorization adjustments / CI Build

When beaker detects it is being run by Jenkins, it should adjust output
colors so that they are better handled in console output. This is done
by detecting BUILD_NUMBER environment variable, a variable that is
known to be present on Jenkins build slaves.

Adjust colorization to colors that come out better during runs. The
colors that should come up to the front are shown better when running
in the console. Additionally make it easier to see logs coming back
from the SUT with an explicit color instead of NORMAL (which is the
same setting as the current GREY).

Allow overriding log colors by passing in log_colors in options.
If a user has overridden the default colors, don't override the
colors in CI.
```
* (BKR-582) Info on begin test file (239ab2d1)


```
(BKR-582) Info on begin test file

When a test file is found, log it at the info level. This allows a bit
more trackability in finding the location of tests.
```
* (BKR-582) Warn on skipped tests (8745c061)


```
(BKR-582) Warn on skipped tests

If a test is skipped, it should show up as a warning. Adjust beaker to
warn when tests are skipped.
```
* (BKR-571) updated documentation on return types (9d98dec1)

* (QENG-2604) Empty host_tags in Presets (df0abb97)


```
(QENG-2604) Empty host_tags in Presets

The host_tags value in presets is now an empty hash and
department, project, and created_by are returned to the
root of the @options hash. This resolves an issue with
environment vars not being properly merged into the new
host_tags hash.
```
* (BKR-542) change logger level to info for "empty array of hosts" (b056ef83)

* (BKR-573) Add spec tests for remove_puppet_on (8e04650b)


```
(BKR-573) Add spec tests for remove_puppet_on

This commit adds spec tests for the  `remove_puppet_on` method.
```
* (QENG-2604) Add Host Tags (03fd8ca7)


```
(QENG-2604) Add Host Tags

This commit adds the ability to specify arbitrary tags and have them
applied to AWS or vmpooler instances. The configuration parameter is
called "host_tags" to avoid confusion with test tagging. Host tags can
be specified at the host or CONFIG level.

The presets have been modified to pre-populate "host_tags" with:
project, department, and created_by.

Example:
HOSTS:
  'agent1':
    roles:
      - agent
    host_tags:
      created_by: 'me'
      some_key: 'yes it is'
CONFIG:
    host_tags:
      project: 'beaker'
```
* (BKR-573) Add remove_puppet_on (3c1f5daf)


```
(BKR-573) Add remove_puppet_on

This commit adds a `remove_puppet_on` method that can be used to
ensure that puppet packages have been expunged from hosts.

This method is intended to be used in a pre-suite. It is currently
limited to the AIX and Solaris platforms.
```
* (BKR-380) beaker vagrant windows box support issues (c3379726)


```
(BKR-380) beaker vagrant windows box support issues
Fix '3389' (host port) is declared multiple times

Without "auto_correct" we got error if source Vagrantfile of box already contains this port forwarding.



Error:
vm:
* Forwarded port '3389' (host port) is declared multiple times
with the protocol 'tcp'.



I think we need add this change as most part of Windows boxes in Vagrant Atlas already have this port forwarding:
- https://github.com/joefitzgerald/packer-windows/blob/master/vagrantfile-windows_2012_r2.template
- https://github.com/boxcutter/windows/blob/master/tpl/vagrantfile-eval-win2012r2-standard.tpl

change spec for 3389 rdp port
```
* (BKR-539) simplified Dockerfile support (63268b8f)


```
(BKR-539) simplified Dockerfile support

Allow user to override the automatically generated Dockerfile
```
### <a name = "2.26.0">2.26.0 - 13 Oct, 2015 (427a512b)

* (HISTORY) update beaker history for gem release 2.26.0 (427a512b)

* (GEM) update beaker version to 2.26.0 (d581b613)

* Merge pull request #971 from sschneid/sysprofile (e2c5f6fc)


```
Merge pull request #971 from sschneid/sysprofile

(BKR-580) --collect-perf-data enhancements
```
* Merge pull request #980 from johnduarte/patch-sol-pkg-names (4ef4ba07)


```
Merge pull request #980 from johnduarte/patch-sol-pkg-names

(maint) Fix Solaris 11 package name logic
```
* Merge pull request #975 from anodelman/win-fix (6a1e14a9)


```
Merge pull request #975 from anodelman/win-fix

(BKR-275) PowerShell Wrapper Does not Handle Quoting
```
* (BKR-275) PowerShell Wrapper Does not Handle Quoting (5bffbaa0)


```
(BKR-275) PowerShell Wrapper Does not Handle Quoting

- add spec test coverage for EncodedCommand support in powershell
  wrapper
```
* (maint) Fix Solaris 11 package name logic (fcbd6018)


```
(maint) Fix Solaris 11 package name logic

This commit fixes a bug in the Solaris 11 package naming logic
that dropped the SHA suffix entirely from the final package name.
The SHA should be incorporated into the package name.

An additional spec test has been added for the expected package
name in this circumstance.
```
* (BKR-275) PowerShell Wrapper Does not Handle Quoting (d364123b)


```
(BKR-275) PowerShell Wrapper Does not Handle Quoting

- add unicode support
```
* Merge pull request #968 from anodelman/new-platform (ad037a82)


```
Merge pull request #968 from anodelman/new-platform

(BKR-488) Add support for Windows 10 (x86, x64)
```
* (BKR-275) PowerShell Wrapper Does not Handle Quoting (c530b8c5)


```
(BKR-275) PowerShell Wrapper Does not Handle Quoting

- create new powershell dsl helper:
  execute_powershell_script_on
  * takes as input a string representing a powershell script
  * create a file on the host containing the script
  * executes the script using powershell -File
- add the ability to execute an encoded powershell string
  powershell("Set Content -path 'fu.txt', -value 'fu'", {'EncodedCommand => true})
  * the command will be Base64 encoded for you
  * bypasses quoting sadness
```
* Merge pull request #907 from hamidnazari/master (a28c8cf1)


```
Merge pull request #907 from hamidnazari/master

(BKR-427) Support for Docker Container Names and Container Reuse
```
* (BKR-580) Different Debian vs EL crontab differences (a4c78dac)

* (BKR-580) Fix spec tests broken in 9b16bef (3ec3fad0)

* (BKR-580) --collect-perf-data enhancements (c57d4d44)


```
(BKR-580) --collect-perf-data enhancements

* allow --collect-perf-data modes:

'aggressive' (poll every minute)
'normal' (poll every 10 minutes)
'none' (do not collect perf data)

If a mode is unspecified, --collect-perf-data will default to 'normal',
which mimics past behavior.

* allow metric exporting to Graphite:

Set via the HOSTS file, eg:


`json
graphite_server: graphite.example.com
graphite_perf_data: beaker.perf

`
```
* (BKR-427) Added support for Docker container names and container reuse (e8a65c67)

* (BKR-488) Add support for Windows 10 (x86, x64) (5b2918db)


```
(BKR-488) Add support for Windows 10 (x86, x64)

- improve the 'wait_for_connection_failure' ssh connection method
  * increase the timeouts
  * send actual data down the pipe, seems to improve the function of
    the test
  * remove 'abort' calls from the code, we can recover and retry
  * added yard docs
- add /f to the windows reboot call
  * forces closure of any open applications
```
### <a name = "2.25.0">2.25.0 - 1 Oct, 2015 (51d4cb1a)

* (HISTORY) update beaker history for gem release 2.25.0 (51d4cb1a)

* (GEM) update beaker version to 2.25.0 (e21f5581)

* Merge pull request #974 from anodelman/maint (65664e45)


```
Merge pull request #974 from anodelman/maint

(BKR-568) no longer accept PRs marked as "(MAINT)"
```
* Merge pull request #964 from kevpl/bkr522_ec2_nocachedkeys (3ec3e14d)


```
Merge pull request #964 from kevpl/bkr522_ec2_nocachedkeys

(BKR-522) now creates new ec2 keys per run
```
* (BKR-568) no longer accept PRs marked as "(MAINT)" (47d9d1ba)


```
(BKR-568) no longer accept PRs marked as "(MAINT)"

- update CONTRIBUTING.md to indicate change in policy
```
* Merge pull request #973 from anodelman/ruby-test (9b52fe4e)


```
Merge pull request #973 from anodelman/ruby-test

(BKR-564) beaker no longer works on ruby 1.9.3
```
* (BKR-564) beaker no longer works on ruby 1.9.3 (4f94d048)


```
(BKR-564) beaker no longer works on ruby 1.9.3

- pin fog-google to 0.0.9, 0.1 release removed ruby 1.9 support
```
* Merge pull request #970 from johnduarte/bkr-545-frozen-string (deb4377f)


```
Merge pull request #970 from johnduarte/bkr-545-frozen-string

(BKR-545) Dup solaris puppet_agent_version
```
* (BKR-545) Dup solaris puppet_agent_version (f1d2068b)


```
(BKR-545) Dup solaris puppet_agent_version

This commit dups the `opts[:puppet_agent_version]` in the foss_utils to
prevent a `RuntimeError: can't modify frozen String` error
```
* Merge pull request #963 from johnduarte/p5p-for-sol11 (b9e6a23e)


```
Merge pull request #963 from johnduarte/p5p-for-sol11

(BKR-545) Use p5p for Solaris 11 puppet-agent pkgs
```
* Merge pull request #969 from johnduarte/aix-repo-install (a7280515)


```
Merge pull request #969 from johnduarte/aix-repo-install

(BKR-554) Install AIX packages via install repo
```
* (BKR-554) Install AIX packages via install repo (973ff502)


```
(BKR-554) Install AIX packages via install repo

This commit adds support for installing AIX 'packages' via the
install repo logic. AIX does not support repository management
and can only install 'RPM' files directly. Since this logic
is contained in the install repo logic in Beaker, we can use
this to install a package that has been mirrored to the standard
repo location.

This assumes that the package is mirrored to the repo location.
In other words, that the following files are the same.
  * http://builds.delivery.puppetlabs.net/puppet-agent/1214e51d63b84a82df0c55cab99abc2a3f90a597/artifacts/aix/7.1/PC1/ppc/puppet-agent-1.2.5.49.g1214e51-1.aix7.1.ppc.rpm
  * http://builds.delivery.puppetlabs.net/puppet-agent/1214e51d63b84a82df0c55cab99abc2a3f90a597/repos/aix/7.1/PC1/ppc/puppet-agent-1.2.5.49.g1214e51-1.aix7.1.ppc.rpm

It also assumes that the desired package is not defined for AIX
in the acceptance pre-suite for the project.
```
* Merge pull request #967 from bkero/master (7852e6b3)


```
Merge pull request #967 from bkero/master

(BKR-327) Add support for EL7 to epel_info_for and add_el_extras method
```
* fix spec tests to match ArgumentError for epel_info_for (d78a8de4)

* Raise ArgumentErrors instead of generic errors (839b75e4)

* (BKR-327) add epel7 support to get_el_info and el_install (0e5a0257)


```
(BKR-327) add epel7 support to get_el_info and el_install

Base work courtesy of Andrew Stangl <andrewstangl@gmail.com>
```
* (BKR-327) add epel_7_pkg preset (0e9485d3)

* (BKR-327) add tests for retrieving epel el7 url (41730085)

* Merge pull request #960 from kevpl/bkr351_indent_add (7e91e61e)


```
Merge pull request #960 from kevpl/bkr351_indent_add

(BKR-351) added indentation based on test/step nesting level
```
* Merge pull request #959 from anodelman/subset-hosts (1810fae0)


```
Merge pull request #959 from anodelman/subset-hosts

(BKR-535) Regression: confine_block does not skip tests...
```
* Merge pull request #957 from anodelman/confine (8de4ee64)


```
Merge pull request #957 from anodelman/confine

(BKR-533) Beaker's `confine` overwrites the array of all hosts
```
* (BKR-522) now creates new ec2 keys per run (07bb7405)


```
(BKR-522) now creates new ec2 keys per run

Before, ec2 keys would only be created if this was the first run for
a particular user/coordinator. This is a problem for F5 testing, in
which F5 hosts needed to be created with a particular key. We were
using cached keys, which weren't the ones being used in ec2.

The original solution was to delete the keys in ec2, so that they'd
be recreated as if this was the first run by a user. @justinstoller
brought up the good point that if this were to happen, certain
Beaker runs would have their keys deleted from a new F5 run. The
solution became that each Beaker run would generate its own key,
deleting it on cleanup.
```
* (BKR-545) Use p5p for Solaris 11 puppet-agent pkgs (831b0bb5)


```
(BKR-545) Use p5p for Solaris 11 puppet-agent pkgs

This commit updates install_utils/foss_utils to use `p5p` as
the expected package suffix for puppet-agent when the platform
is Solaris 11. Solaris 10 will continue to use `pkg.gz` as its
expected suffix.

The `p5p` package naming format is much more stringent. See
http://www.oracle.com/technetwork/articles/servers-storage-admin/ips-package-versioning-2232906.html
for details.
```
* Merge pull request #955 from kevpl/bkr532_beakerhiera_merge (b181c059)


```
Merge pull request #955 from kevpl/bkr532_beakerhiera_merge

(BKR-532) added beaker-hiera library usage
```
* (BKR-535) Regression: confine_block does not skip tests... (72955d58)


```
(BKR-535) Regression: confine_block does not skip tests...

...with beaker 2.24.0

- allow users to include skip_test in block parameter for confine_block
- added acceptance test to ensure correct behavior
```
* (BKR-533) Beaker's `confine` overwrites the array of all hosts (be1cc5dc)


```
(BKR-533) Beaker's `confine` overwrites the array of all hosts

- make it possible to confine to a subset of hosts + all hosts not in
  the subset.

  To confine to only windows agents + any non-agent hosts

    confine :to, { :platform => 'windows' }, agents

  To confine to non-windows agents + any non-agent hosts

    confine :except, { :platform => 'windows' }, agent

- Useful for cases where you want to use your master, but only operate
  on a subset of agents
```
* (BKR-351) added indentation based on test/step nesting level (cec66d21)


```
(BKR-351) added indentation based on test/step nesting level

This will only affect tests where `test_name` or `step` has
been passed a block to execute.

The only exception to that statement is `host.exec`'s
logic, as it's more presentable to nest command output one
level under the command itself.
```
* (BKR-532) added beaker-hiera library usage (127aa3de)

### <a name = "2.24.0">2.24.0 - 15 Sep, 2015 (c12e9054)

* (HISTORY) update beaker history for gem release 2.24.0 (c12e9054)

* (GEM) update beaker version to 2.24.0 (96d9104d)

* Merge pull request #956 from kevpl/bkr531_osx_update (ca365d15)


```
Merge pull request #956 from kevpl/bkr531_osx_update

(BKR-531) updated osx name structure to match RE changes
```
* (BKR-531) review clarifications & clean-up (308815d7)

* Merge pull request #950 from anodelman/timeout (1a528f21)


```
Merge pull request #950 from anodelman/timeout

(BKR-514) increase polling timeout when requesting vpool instances
```
* (BKR-531) updated osx name structure to match RE changes (f4512f99)

* Merge pull request #949 from cybercom-finland/bkr-516/more-openstack-credentials-from-env (11243052)


```
Merge pull request #949 from cybercom-finland/bkr-516/more-openstack-credentials-from-env

(BKR-516) Lookup more openstack credentials from ENV
```
* Merge pull request #953 from GeoffWilliams/docker_error_catch (5d79e90a)


```
Merge pull request #953 from GeoffWilliams/docker_error_catch

(BKR-523) Beaker prints error message on exit when using docker containers
```
* Merge pull request #952 from GeoffWilliams/no_more_grey (c13914a0)


```
Merge pull request #952 from GeoffWilliams/no_more_grey

(BKR-519) Beaker prints invisible messages in debug mode (black-on-bl…
```
* (BKR-523) Beaker prints error message on exit when using docker containers (ddd05816)


```
(BKR-523) Beaker prints error message on exit when using docker containers

Capture the strange error message from docker (and all other internal docker errors) and display the message as a logged warning instead of a stack trace.  This will preven the message from causing a CI test failure as the exit status is now zero
```
* (BKR-519) Beaker prints invisible messages in debug mode (black-on-black) (20cfbdd2)


```
(BKR-519) Beaker prints invisible messages in debug mode (black-on-black)
Use normal colour instead of bold as some terminals (mac) can't handle the grey without additional configuration
```
* Merge pull request #951 from johnduarte/aix-curl-opts (3b1fd835)


```
Merge pull request #951 from johnduarte/aix-curl-opts

(BKR-520) Add curl options for AIX
```
* Merge pull request #945 from mcanevet/fix/BKR-506 (673ac239)


```
Merge pull request #945 from mcanevet/fix/BKR-506

(BKR-506) Fix FQDN
```
* Merge pull request #915 from jstremick/feature/aws_credential_sources (e643f054)


```
Merge pull request #915 from jstremick/feature/aws_credential_sources

BRK-431: Find AWS credentials from environment variables
```
* Merge pull request #946 from kevpl/bkr455_exitcodes_logging (b19d1238)


```
Merge pull request #946 from kevpl/bkr455_exitcodes_logging

(BKR-455) added warning message for conflicting exit code handling
```
* Merge pull request #948 from cybercom-finland/bkr-515/host_name_prefix (8b8b2cc2)


```
Merge pull request #948 from cybercom-finland/bkr-515/host_name_prefix

(BKR-515) add config option host_name_prefix
```
* (BKR-520) Add curl options for AIX (f6438338)


```
(BKR-520) Add curl options for AIX

The curl command on AIX does not support the `-k flag`. This commit
creates condition statements to replace the `-k` flag in the curl
options with `--tlsv1` when the platform is AIX.
```
* (BKR-514) increase polling timeout when requesting vpool instances (05fa681e)


```
(BKR-514) increase polling timeout when requesting vpool instances

- increase timeout to 15 minutes
- write out failure message to get more information about why the pool
  request failed
```
* Merge pull request #947 from anodelman/osx (9258e8ec)


```
Merge pull request #947 from anodelman/osx

(BKR-482) Add support for OSX 10.11 El Capitan (x86_64)
```
* (BKR-482) Add support for OSX 10.11 El Capitan (x86_64) (439568c4)


```
(BKR-482) Add support for OSX 10.11 El Capitan (x86_64)

- correctly turn on ssh user environment support
- update platform list
```
* (BKR-455) added warning message for conflicting exit code handling (44f55339)

* Merge pull request #944 from puppetlabs/bkr-505/fix-broken-confine_block-behavior (a5cd36a1)


```
Merge pull request #944 from puppetlabs/bkr-505/fix-broken-confine_block-behavior

(BKR-505) rescue `SkipTest` in `confine_block`
```
* (BKR-505) Add acceptance tests for #confine_block (0d73ff10)


```
(BKR-505) Add acceptance tests for #confine_block

These tests fail when the code patch in this PR is not present, and
succeed when the patch is present.
```
* (BKR-515) Add config option host_name_prefix (66cbd292)


```
(BKR-515) Add config option host_name_prefix

This helps to identify hosts if you do not destroy them.

If defined, hostname is prefixed.
```
* (BKR-516) Lookup more openstack credentials from ENV (34b4054a)


```
(BKR-516) Lookup more openstack credentials from ENV

Add support to configure openstack via these environment
variables (environment variable name, configuration option)
- OS_KEYNAME openstack_keyname
- OS_NETWORK openstack_network
- OS_REGION  openstack_region
```
* (BKR-506) Fix FQDN (ab283113)

* (BKR-505) rescue SkipTest in confine_block (efd0c3e3)


```
(BKR-505) rescue SkipTest in confine_block

Prior to this, use of confine_block would result in all following code in the
test case being skipped in situations where the host list had no matches for
the confine_block.  The entire purpose of confine_block is to limit the scope
of the confine to the passed block.

Also, ensure and rescue at the method level do not require an additional
wrapping begin..end block.
```
* BRK-431: Correct env variable names and prefix (3026cd88)

* BRK-431: Corrected AWS keys used in .fog file (f43460e6)

* BRK-431: Find AWS credentials from environment variables (5e085999)

### <a name = "2.23.0">2.23.0 - 9 Sep, 2015 (2532324a)

* (HISTORY) update beaker history for gem release 2.23.0 (2532324a)

* (GEM) update beaker version to 2.23.0 (db33f827)

* Merge pull request #943 from MikaelSmith/imp/master/BKR-504 (e10c5491)


```
Merge pull request #943 from MikaelSmith/imp/master/BKR-504

(BKR-504) Update Solaris package name for release version
```
* (BKR-504) Update Solaris package name for release version (44602018)


```
(BKR-504) Update Solaris package name for release version

The planned Solaris package names for the puppet-agent package were
changed to incorporate a release version, as already handled for other
platforms. Update the Solaris package name to include the hard-coded
release `1` naming.
```
* Merge pull request #942 from kevpl/bkr497_f5_skipconfigure (5a783a91)


```
Merge pull request #942 from kevpl/bkr497_f5_skipconfigure

(BKR-497) skip configuration for f5 hosts
```
* Merge pull request #940 from anodelman/preserved-hosts (fe8df0b0)


```
Merge pull request #940 from anodelman/preserved-hosts

(BKR-440) host_preserved.yml file should disable the pre_suite
```
* (BKR-497) fixed set_env to skip f5 platforms (a6301f24)

* (BKR-497) skip configuration for f5 hosts (87bdf9b7)

* Merge pull request #941 from kevpl/bkr469_ec2_keys (d16fef00)


```
Merge pull request #941 from kevpl/bkr469_ec2_keys

(BKR-469) added f5 wait checks
```
* (BKR-469) added f5 platform specific provisioning wait checks (8f5a9464)

* (BKR-440) host_preserved.yml file should disable the pre_suite (1b6e0bec)


```
(BKR-440) host_preserved.yml file should disable the pre_suite

- instead of just removing the pre_suite/post_suite/tests from
the options, explicitly set it to be []
- this means that you don't end up accidentally running a pre-suite
  defined in a secondary options file
```
* (BKR-469) added options_hash-provided keys to aws public_key check (274d5df9)

* Merge pull request #937 from puppetlabs/maint/constrain-add_system32_hosts_entry-to-pswindows (a7857fab)


```
Merge pull request #937 from puppetlabs/maint/constrain-add_system32_hosts_entry-to-pswindows

(MAINT) constrain `add_system32_hosts_entry`
```
* (MAINT) remove spec tests for add_system32_hosts_entry (bd76ee56)


```
(MAINT) remove spec tests for add_system32_hosts_entry

These tests do not actually exercise the code path in question -- had they
exercised that code path, we would have known earlier that this helper only
works on powershell systems.

We have replacement tests coming in BKR-358 which will exercise this code path
more fully (they are what exposed this problem), so removing these tests in
favor landing those.
```
* (MAINT) constrain `add_system32_hosts_entry` (88e86059)


```
(MAINT) constrain `add_system32_hosts_entry`

Prior to this commit, this method was available to any windows platform,
including cygwin-enabled windows installed. This method only actually works
on non-cygwin windows platforms, and this discrepancy was uncovered during
work for BKR-358, where we are adding acceptance tests for the host helper
methods.
```
### <a name = "2.22.0">2.22.0 - 1 Sep, 2015 (96ec20a7)

* (HISTORY) update beaker history for gem release 2.22.0 (96ec20a7)

* (GEM) update beaker version to 2.22.0 (e693a4e7)

* Merge pull request #935 from MikaelSmith/feat/master/BKR-470 (9a96c210)


```
Merge pull request #935 from MikaelSmith/feat/master/BKR-470

(BKR-470) Add Solaris to install_puppet_agent_dev_repo_on
```
* Merge pull request #938 from anodelman/none-hypervisor (c5ae989f)


```
Merge pull request #938 from anodelman/none-hypervisor

(BKR-458) add beaker notouch hypervisor
```
* Merge pull request #934 from anodelman/puppet-agent (8a495267)


```
Merge pull request #934 from anodelman/puppet-agent

(BKR-459) update osx package name and directory to correspond...
```
* (BKR-458) add beaker notouch hypervisor (f31ba283)


```
(BKR-458) add beaker notouch hypervisor

- support for a 'noop' hypervisor that does no
  configuration/validation/provision/cleanup/proxy-ing
```
* (maint) Add spec test for install_puppet_agent_dev_repo_on (0a6eb377)

* (BKR-472) Add Solaris 11 support for installing puppet-agent (6960c09b)


```
(BKR-472) Add Solaris 11 support for installing puppet-agent

Solaris 11 re-uses most of the setup for Solaris 10, but the root user's
home directory on Solaris 10 is special. Fix up the configuration to
special-case Solaris 10.
```
* (BKR-470) Add Solaris to install_puppet_agent_dev_repo_on (265f6ec3)


```
(BKR-470) Add Solaris to install_puppet_agent_dev_repo_on

Adds Solaris support for installing packages in the
install_puppet_agent_dev_repo_on helper.
```
* (MAINT) fix ability to set external file dir through opts (65d2bbb7)


```
(MAINT) fix ability to set external file dir through opts

- we were overriding for windows/mac hosts to a different default, so
  anything passed in by the user was ignored
```
* (BKR-459) update osx package name and directory to correspond... (db9090ef)


```
(BKR-459) update osx package name and directory to correspond...

... to RE changes

- updated install_puppet_agent_dev_repo_on to handle new directory
  structure and name change
- backwards compatible, handles both old and new
```
### <a name = "2.21.0">2.21.0 - 26 Aug, 2015 (40281eb2)

* (HISTORY) update beaker history for gem release 2.21.0 (40281eb2)

* (GEM) update beaker version to 2.21.0 (a6ef010f)

* Merge pull request #933 from sschneid/license_update (978b2ede)


```
Merge pull request #933 from sschneid/license_update

(maint) Update license copyright
```
* Merge pull request #932 from anodelman/win-fix (a5b8f291)


```
Merge pull request #932 from anodelman/win-fix

(BKR-293) PowerShell Hangs on Windows 2008 R2 WMF 5.0 Beta
```
* Merge pull request #919 from colinPL/pkg_acceptance (cb6fa705)


```
Merge pull request #919 from colinPL/pkg_acceptance

(maint) Add Package Acceptance Tests
```
* (maint) Update license copyright (ed0a84ec)

* Merge pull request #926 from anodelman/aio-paths (dce6c683)


```
Merge pull request #926 from anodelman/aio-paths

(BKR-395) Calling `remove_defaults_on` twice with `type: aio` in...
```
* Merge pull request #931 from colinPL/bkr452_deb_code (9885aab1)


```
Merge pull request #931 from colinPL/bkr452_deb_code

(BRK-452) Use Platform To Get Code Name
```
* (BKR-293) PowerShell Hangs on Windows 2008 R2 WMF 5.0 Beta (0d99ed70)


```
(BKR-293) PowerShell Hangs on Windows 2008 R2 WMF 5.0 Beta

- beaker powershell regressions discovered while working on this bug,
  mostly around ensuring that we are using the correct path separator on
  pswindowns machines
```
* Merge pull request #929 from puppetlabs/maint/fix-git-install-load-path-issue (f1e1ef00)


```
Merge pull request #929 from puppetlabs/maint/fix-git-install-load-path-issue

(MAINT) Fix acceptance puppet_git load path
```
* Merge pull request #927 from anodelman/maint (87b094d1)


```
Merge pull request #927 from anodelman/maint

(BKR-449) beaker acceptance base smoketest intermittant failure...
```
* (maint) fix old issue with clone_git_repo_on test (27bae4b5)


```
(maint) fix old issue with clone_git_repo_on test

Prior to this change clone_git_repo_on acceptance test would fail as we
reverted the method's behavior to be backwards compatible.  it appears
this tests is not getting run in CI. Also add install_utils to the
load_path so the user doesn't have to.
```
* (BRK-452) Use Platform To Get Code Name (518f25ae)


```
(BRK-452) Use Platform To Get Code Name

The unix/pkg.rb had its own mapping of platform to debian code name.
However, this is available through the Platform class. This commit
removes the duplicate data in pkg.rb and uses self['platform'].codename
in its place.
```
* (maint) Add vivid Repo Fixture (fc5afde6)


```
(maint) Add vivid Repo Fixture

Add repo fixture for Ubuntu 15.04 (vivid).
```
* (MAINT) Fix acceptance puppet_git load path (efa36129)


```
(MAINT) Fix acceptance puppet_git load path

Prior to this commit, running the acceptance tests locally without specifying a
specific load path would result in a require failure if attempting to test against
puppet installed via git.

This updates the load path to fix the problem.
```
* (maint) Add trusty Repo Template (c5ed7a0d)


```
(maint) Add trusty Repo Template

Add repo fixture for trusty instances.
```
* (BKR-449) beaker acceptance base smoketest intermittant failure... (f626b057)


```
(BKR-449) beaker acceptance base smoketest intermittant failure...

...on ubuntu 1504

- when attempting to reconnect post reboot we are getting into a
  blocking state, most likely an issue with the Net::SSH gem
- just give some breathing room before moving on from a reboot and
  everything is okay
```
* (maint) Add Missing Fedora Templates (485dcefa)


```
(maint) Add Missing Fedora Templates

Add missing fedora rpm repo templates for packaging tests.
```
* Merge pull request #921 from mcanevet/fix/hack_etc_host_on_openstack (cf09c58b)


```
Merge pull request #921 from mcanevet/fix/hack_etc_host_on_openstack

(BKR-443) Hack /etc/hosts when using openstack
```
* Merge pull request #893 from biemond/solaris-fixes (b402911a)


```
Merge pull request #893 from biemond/solaris-fixes

BKR-408 Supporting solaris as a beakernode
```
* (BKR-395) Calling `remove_defaults_on` twice with `type: aio` in... (97cbc1a9)


```
(BKR-395) Calling `remove_defaults_on` twice with `type: aio` in...

...config file throws exception

- ensure that we don't blow away the PATH and break the world
```
* (BKR-443) Hack /etc/hosts when using openstack (a701c7cc)

* (maint) Exclude OS X From Most Things (c9c224aa)


```
(maint) Exclude OS X From Most Things

Exclude OS X systems from running the generic and unix-specific package
tests. A special test suite will need to be created for these systems.
```
* (maint) Change assert Method; Workaround debian Check for Package (09b7c9fb)


```
(maint) Change assert Method; Workaround debian Check for Package

assert_equal(true,...) is the same as just assert(...). Change all
of those matching calls to just assert.

beaker can incorrectly report a package as being installed when in fact it is not. This is specific to debian systems. As a work around to the above, debian systems will use check_for_command to determine whether the specific package is installed.
```
* (maint) Add Package Acceptance Tests (a9919557)


```
(maint) Add Package Acceptance Tests

Add acceptance tests that exercise the host packages functionality. There are two files: one for all hosts and one targeting unix hosts specifically.

This includes fixtures for support the deploy_*_repo methods.
```
* BKR-408 Supporting solaris as a beakernode #893 (45f1f6c5)


```
BKR-408 Supporting solaris as a beakernode #893

- copy certs to solaris root home folder  /
- gsed of CSW to allow ssh root login
- restart sshd daemon

solaris 11 fixes

- root home is /root and not /
- PermitRootLogin in solaris 11 is not in comment
- change security of the user root for solaris else no ssh login without
password
```
### <a name = "2.20.0">2.20.0 - 17 Aug, 2015 (8a419e98)

* (HISTORY) update beaker history for gem release 2.20.0 (8a419e98)

* (GEM) update beaker version to 2.20.0 (1d735a7a)

* Merge pull request #925 from objectverbobject/BKR-448 (d76d2a4a)


```
Merge pull request #925 from objectverbobject/BKR-448

(BKR-448) Check for connection object during host.close
```
* Merge pull request #924 from anodelman/puppet-agent (ba4b3d4e)


```
Merge pull request #924 from anodelman/puppet-agent

(BKR-447) Ubuntu PE puppet-agent urls not being generated correctly
```
* Merge pull request #904 from dylanratcliffe/add-per-node-memory (cc3d716a)


```
Merge pull request #904 from dylanratcliffe/add-per-node-memory

(BKR-423) Added the ability to set CPUs and memory per node
```
* Merge pull request #923 from puppetlabs/bkr-428/change-assertion-in-teardown-behavior (5f60c353)


```
Merge pull request #923 from puppetlabs/bkr-428/change-assertion-in-teardown-behavior

[BKR-428] gracefully handle assert failure in teardown
```
* (BKR-448) Check for connection object during host.close (255f43f6)


```
(BKR-448) Check for connection object during host.close

The close method for hosts assumed the connection object existed when
trying to set the hostname; this fix checks to ensure the connection
object exists prior to calling any methods on it.
```
* (BKR-447) Ubuntu PE puppet-agent urls not being generated correctly (bb71b7ba)


```
(BKR-447) Ubuntu PE puppet-agent urls not being generated correctly

- incorrectly adding additional '.' to ubuntu version strings that were
  already correct
- added spec test to ensure correct behavior
- passed local testing
```
* Merge pull request #922 from anodelman/many-names (334d63a8)


```
Merge pull request #922 from anodelman/many-names

(BKR-446) add ability to identify a host by vmhostname/ip
```
* (BKR-428) gracefully handle assert failure in teardown (f8b97d7b)


```
(BKR-428) gracefully handle assert failure in teardown

Prior to this commit, if a teardown method ran code which contained assertions,
and an assertion failed, the exception raised by the assertion failure was
uncaught and beaker would crash.

This change treats the assertion failure as a test failure and allows beaker
to continue running.
```
* (BKR-446) add ability to identify a host by vmhostname/ip (24ecdf4b)


```
(BKR-446) add ability to identify a host by vmhostname/ip

- make it possible to run commands like:

on 'vmhostname', "command"
on '0.0.0.0', "command"
```
* (BKR-423) Added the ability to set CPUs and memory per node (132b6b7e)

### <a name = "2.19.0">2.19.0 - 13 Aug, 2015 (80897129)

* (HISTORY) update beaker history for gem release 2.19.0 (80897129)

* (GEM) update beaker version to 2.19.0 (821aefba)

* Merge pull request #918 from johnduarte/dnf_fed22 (d9a52536)


```
Merge pull request #918 from johnduarte/dnf_fed22

(BKR-439) Add DNF for fedora-22
```
* (BKR-439) Add DNF for fedora-22 (f13a1e3c)


```
(BKR-439) Add DNF for fedora-22

This commit adds a case condition for fedora-22 to use the 'dnf'
command where the 'yum' command would previously have been executed.
```
* Merge pull request #917 from kevpl/bkr346_hostspreserved_multiple (fbeaf7fc)


```
Merge pull request #917 from kevpl/bkr346_hostspreserved_multiple

(BKR-346) fixed repeat hosts_preserved issue
```
* Merge pull request #868 from er0ck/improvement/master/BKR-366-merge_up_install_from_git_changes_from_deployer_puppet (0029295b)


```
Merge pull request #868 from er0ck/improvement/master/BKR-366-merge_up_install_from_git_changes_from_deployer_puppet

(BKR-366) merge-up install_from_git changes from deployer and puppet
```
* Merge pull request #906 from Iristyle/ticket/master/BKR-421-refactor-msi-installation (d7ae5ea7)


```
Merge pull request #906 from Iristyle/ticket/master/BKR-421-refactor-msi-installation

(BKR-421) Refactor MSI installation
```
* (BKR-346) fixed repeat hosts_preserved issue (c2f713cc)

* Merge pull request #916 from sschneid/use_token_during_cleanup (8b500667)


```
Merge pull request #916 from sschneid/use_token_during_cleanup

(maint) Supply token (if exists) during VM cleanup
```
* Merge pull request #902 from anodelman/type (4737c014)


```
Merge pull request #902 from anodelman/type

(BKR-412) clarify 'types' in beaker
```
* Merge pull request #914 from anodelman/answers (4d462c12)


```
Merge pull request #914 from anodelman/answers

(BKR-340) separate answer file generation into a library
```
* Merge pull request #911 from anodelman/deb7 (b573ed80)


```
Merge pull request #911 from anodelman/deb7

(BKR-422) debian7 fails to reboot during smoketest
```
* (maint) Supply token (if exists) during VM cleanup (2e1b91ae)

* Merge pull request #865 from madAndroid/BKR-208-preserve-SUT-host-output (1d267e8a)


```
Merge pull request #865 from madAndroid/BKR-208-preserve-SUT-host-output

(BKR-208) Preserve SUT host output
```
* Merge pull request #913 from kevpl/bkr389_upgradepe_agentupgrades (e3784f1a)


```
Merge pull request #913 from kevpl/bkr389_upgradepe_agentupgrades

(BKR-389) fixed upgrade_pe issues for agent upgrade module
```
* (BKR-389) fixed upgrade_pe issues for agent upgrade module (c5d10577)

* Merge pull request #912 from anodelman/new-platform (b611d502)


```
Merge pull request #912 from anodelman/new-platform

(BKR-372) add support for ubuntu 15.04, Vivid, amd64 & i386
```
* Merge pull request #886 from kevpl/bkr393_pm_ubuntu_fix (a7395ce7)


```
Merge pull request #886 from kevpl/bkr393_pm_ubuntu_fix

(BKR-393) fixed ubuntu PM URLs, didn't match package versions
```
* Merge pull request #870 from vindir/feature/aws-specs (41568f1f)


```
Merge pull request #870 from vindir/feature/aws-specs

(BKR-349) AwsSdk Hypervisor Specs (for review <3)
```
* Merge pull request #885 from mcanevet/fix/fqdn (3a9d36f1)


```
Merge pull request #885 from mcanevet/fix/fqdn

(BKR-391) Add fqdn to /etc/hosts
```
* (BKR-372) add support for ubuntu 15.04, Vivid, amd64 & i386 (f9a2e1ef)


```
(BKR-372) add support for ubuntu 15.04, Vivid, amd64 & i386

- not quite sure what is going on here, but removing the timeout and
  using the Net::SSH default allows ubuntu15.04 to reboot successfully
  (was stuck on a blocking call to Net::SSH.start)
```
* Merge pull request #910 from kevpl/bkr426_fetchhttpfile_longersolution (2b252ce0)


```
Merge pull request #910 from kevpl/bkr426_fetchhttpfile_longersolution

(BKR-426) long-term fix to end '/' issue in fetch_http_file
```
* Merge pull request #895 from anodelman/maint (7467e09c)


```
Merge pull request #895 from anodelman/maint

(BKR-410) `confine :except, {}, [host1,host2]` does not work as expected
```
* (BKR-422) debian7 fails to reboot during smoketest (f96a15aa)


```
(BKR-422) debian7 fails to reboot during smoketest

- to fix current smoketest redness change how we connect to beaker boxes
- do three separate connection attempts (with retries)
  * first with ip
  * then the virtual hostname (vmhostname)
  * then the name of the box provided by the user (hostname)
- Only when all three fail do we fail out
- decrease the Net::SSH timeout so that we can move through the various
  attempts in a reasonable amount of time
- add a sleep post windows reboot, getting reds here because windows
  takes so long to come back up
```
* Merge pull request #899 from anodelman/install (f4cc4c9b)


```
Merge pull request #899 from anodelman/install

(BKR-414) install_pe_on assumes hosts will be an array
```
* (BKR-426) long-term fix to end '/' issue in fetch_http_file (013a7e3c)

* (BKR-421) Windows installs with service Disabled (4eae7d02)


```
(BKR-421) Windows installs with service Disabled

 - Modify the default behavior to install Puppet with a disabled service
   instead of Automatic
 - Modify do_install so that on a Windows MSI install the method
   setup_defaults_and_config_helper_on is called.  This replaces the
   existing configure_pe_defaults_on behavior and augments it with an
   additional `puppet agent -t` run that generates certificates.  Since
   it calls puppet commands for configuring the server and certname,
   additionally remove the redundant passing of these values to the
   Windows installer.
```
* (BKR-421) Verify Windows puppet service status (5c70e60c)


```
(BKR-421) Verify Windows puppet service status

 - After completing an MSI install, verify the service status of the
   puppet service.
```
* (BKR-421) Refactor foss_utils to use WindowsUtils (9b37abb5)


```
(BKR-421) Refactor foss_utils to use WindowsUtils

 - There are 4 separate points in the code where an MSI installation can
   be launched from, that all differ.  Unify all entry points to use the
   helper install_msi_on from WindowUtils.

   Simplify the logic in the foss_utils install_a_puppet_msi_on and
   instead of verifying which command Beaker sends (since the actual
   code execution is thorougly tested for install_msi_on), simply
   verify that the proper method is being called
```
* (BKR-421) Add WindowsUtils with MSI helper (49920a8b)


```
(BKR-421) Add WindowsUtils with MSI helper

 - Refactor the do_install portion of pe_utils so that it no longer uses
   the installer_cmd helper when on Windows.  Instead, extract out a new
   MSI installation helper to WindowsUtils called install_msi_on.

 - install_msi_on expects 4 parameters
     hosts - to run the installer on
     msi_path - can be a local path on disk or uri
     msi_opts - options passed to the installer to configure behavior
     opts - additional options, currently only :debug to emit the log
        after installation

 - install_msi_on will generate a batch file and SCP it to the host
   to avoid any potential command line quoting issues with Cygwin
   and will properly propagate the msiexec exit code

 - MSI exit codes 0, 1641 and 3010 are acceptable since they may
   simply indicate a reboot is required
   install_msi_on will automatically dump the MSI log to the output
   when a different failure code is encountered
```
* (maint) remove errant pe_utils docs for installer_cmd (cae4fc68)

* (BKR-412) clarify 'types' in beaker (72e82f58)


```
(BKR-412) clarify 'types' in beaker

- having made 'aio' a type meant that we were losing pe/foss specific
  information (like the puppet service)
- make 'aio' a role that a host can have, meaning that the aio defaults
  will be installed overtop of any foss/pe defaults
- stay backwards compatible with some of our weirder test types occuring
  in the wild (like git-package)
```
* (BKR-413) beaker incorrectly reading preview 'LATEST' file (81077e35)


```
(BKR-413) beaker incorrectly reading preview 'LATEST' file

- unable to reproduce bug as reported, but found errors in spec test
  coverage while poking around.
```
* (BKR-414) install_pe_on assumes hosts will be an array (7ac2ca96)


```
(BKR-414) install_pe_on assumes hosts will be an array

- ensure that we only confine to an array of hosts
```
* (BKR-410) `confine :except, {}, [host1,host2]` does not work as expected (3a27e489)


```
(BKR-410) `confine :except, {}, [host1,host2]` does not work as expected

- add support to confine to all hosts *except* those in provided host
  array
```
* (BKR-208) - add commandline option, as requested by @anodelman (81139678)

* (BKR-340) separate answer file generation into a library (2a3d9dc5)


```
(BKR-340) separate answer file generation into a library

- remove answer file generation from beaker
- add dependencies to new beaker-answers gem and stringify-hash
```
* (BKR-393) fixed ubuntu PM URLs, didn't match package versions (2b820611)

* (BKR-391) Add fqdn to /etc/hosts (033dc9a8)

* (BKR-349) awsSdk pass-through to make specs more idiomatic and DRY things up (a3e1fa83)

* (BKR-349) Revert "(BKR-349) Clean out unused methods AwsSdk#kill_zombies and AwsSdk#kill_zombie_volumes" (76969db6)


```
(BKR-349) Revert "(BKR-349) Clean out unused methods AwsSdk#kill_zombies and AwsSdk#kill_zombie_volumes"

This reverts commit e2da888de350d9c9f98e0bb20533d61a35ad419e.
```
* (BKR-349) Revert "(BKR-349) Remove unused AWS hypervisor method for log_instances" (bc6535ac)


```
(BKR-349) Revert "(BKR-349) Remove unused AWS hypervisor method for log_instances"

This reverts commit b33ae4b49175dc30da71dcdff56045aed9ca7c49.
```
* (BKR-208) - Rename option and method to color_host_output, as per suggestion fron @anodelman (02223524)

* (BKR-349) Add specs to test out configuration of /etc/hosts for new instances (ebe312d0)


```
(BKR-349) Add specs to test out configuration of /etc/hosts for new instances

Includes tests for AwsSdk#configure_hosts and AwsSdk#etc_hosts_entry
```
* (BKR-349) Add Host#dns_name to spec/helpers.rb host defaults. (b586da67)

* (BKR-349) AwsSdk#configure_hosts now returns nil as api docs indicate (433b9033)

* (BKR-349) Remove redundant entry in spec/helpers.rb host defaults (974bd4a3)

* (BKR-349) Refactor AwsSdk#configure_hosts for improved testability (0b28c5d2)

* (BKR-349) Update yard doc for create_instance to the proper @return type. (1d2b5322)

* (BKR-349) Add specs to test AwsSdk#load_fog_credentials (1d3545d4)

* (BKR-349) Specs added for AwsSdk#create_group (99470010)

* (BKR-349) Specs added for AwsSdk#ensure_group (66eb22fb)

* (BKR-349) Add private ip to host creation in the spec helpers (2b1a1fb8)

* (BKR-349) Stub out remaining simple methods for AwsSdk spec testing (0eb22705)

* (BKR-349) Add new specs for AwsSdk#ensure_key_pair (82231282)

* (BKR-366) merge up install from git changes from deployer and puppet (953423ce)


```
(BKR-366) merge up install from git changes from deployer and puppet

This change merges changes to install_from_git that were overloaded into
puppet and other repos' acceptance libraries.
We also split the cloning portion of install_from_git into its own
method, added options that are passed through to on() and moved a method
to beaker's acceptance library that needs to be shared across tests
(install_packages_on).
This addition of an acceptance library for beaker may require changes to
the jenkins CI configuration, to add the library to the test-runner's
load-path.
The merge-up also brought in helpers for install_from_git,
build_git_url() and lookup_in_env().
This change also adds a few more features to build_git_url that were required
for deployer, including giturl protocol.
```
* (BKR-349) Add new specs for AwsSdk#local_user (a280d073)

* (BKR-349) Add new specs for AwsSdk#set_hostnames (1ae376a2)

* (BKR-349) Add new specs for AwsSdk#add_tags (0ee05d39)

* (BKR-349) Add new specs for AwsSdk#wait_for_status (8d331dfc)

* (BKR-349) Clean out unused methods AwsSdk#kill_zombies and AwsSdk#kill_zombie_volumes (e60692eb)

* (BKR-349) Update yard docs with actual return type for AwsSdk#security_groups (dc7401cd)

* (BKR-349) New spec test for AwsSdk#security_groups (bd40500f)

* (BKR-349) Add specs to test AwsSdk#security_group_by_id (5509c3fc)

* (BKR-349) Update yard docs with actual return type for AwsSdk#vpcs (e016a375)

* (BKR-349) New spec test for AwsSdk#vpcs (0c800e52)

* (BKR-349) Add specs to test AwsSdk#vpc_by_id (e13d7e18)

* (BKR-208) - Add spec for preserving SUT host output (97a9a1df)

* (BKR-208) - Add preserve_host_output method, to set allow us to not strip colour for beaker runs (07f06d7b)

* (BKR-349) Add specs to test AwsSdk#instances (b28c39ed)

* (BKR-349) Update yard docs with actual return type for AwsSdk#instances (ce44abac)

* (BKR-349) Add specs to test AwsSdk#instance_by_id (538458a3)

* (BKR-349) Improved specs for AwsSdk#cleanup (68f8a5d4)

* (BKR-349) Fix incorrect key name for access credentials in spec helper for fog creds (90b88e57)


```
(BKR-349) Fix incorrect key name for access credentials in spec helper for fog creds

PS: This still doesn't appear to play nicely when attempting to work with
resulting instance objects. Seems like it has to be mocked any time it digs
into the aws lib.
```
* (BKR-349) Remove unused AWS hypervisor method for log_instances (16d506ef)

* (BKR-349) Add spec tests for AWS hypervisor cleanup method (6f3c8fa8)

* (BKR-349) Add spec tests for AwsSdk#kill_instances (72c53781)

* (BKR-349) Add tests for AwsSdk#provision (3fbb8a3e)

* (BKR-349) Stub out describes for missing method tests (784102ff)

* (BKR-349) Clean up describe/context naming for existing tests (147e78aa)

* (BKR-349) Sort tests based on method appearance (e1920ade)

### <a name = "2.18.3">2.18.3 - 28 Jul, 2015 (d9a02474)

* (HISTORY) update beaker history for gem release 2.18.3 (d9a02474)

* (GEM) update beaker version to 2.18.3 (c0553c0c)

* Merge pull request #908 from kevpl/bkr424_windows_doubleslash (cec8965d)


```
Merge pull request #908 from kevpl/bkr424_windows_doubleslash

(BKR-424) eliminated extra '/' on windows download URL
```
* (BKR-424) eliminated extra '/' on windows download URL (6b9735e0)

### <a name = "2.18.2">2.18.2 - 27 Jul, 2015 (c84f6f23)

* (HISTORY) update beaker history for gem release 2.18.2 (c84f6f23)

* (GEM) update beaker version to 2.18.2 (15c0496b)

* Merge pull request #894 from anodelman/shallow (d2860c7a)


```
Merge pull request #894 from anodelman/shallow

(BKR-405) The "install_pe" DSL Method Fails to Install SG...
```
* Merge pull request #880 from petems/BKR-326-fix_freebsd_install (6383f3d6)


```
Merge pull request #880 from petems/BKR-326-fix_freebsd_install

(BKR-326) Fixes FreeBSD install to use ports
```
* Merge pull request #896 from bstopp/master (35f8e63e)


```
Merge pull request #896 from bstopp/master

(BKR-417) Add support for specifying # of CPUs in VirtualBox
```
* Merge pull request #900 from ferventcoder/maint/issue/start-wait-winrm (f8f01651)


```
Merge pull request #900 from ferventcoder/maint/issue/start-wait-winrm

(maint) Always wait for Windows agent installs
```
* Merge pull request #901 from justinstoller/bug/master/bkr-420_no-more-latest (282371b4)


```
Merge pull request #901 from justinstoller/bug/master/bkr-420_no-more-latest

(BKR-420) Allow easily installing latest puppet-agent
```
* (BKR-420) Allow easily installing latest puppet-agent (460a6247)


```
(BKR-420) Allow easily installing latest puppet-agent

Prior to this we were over eagerly failing if there was no puppet-agent
version explicitly set.  Having install_puppet_agent install the latest
released version of puppet-agent is a desired and common workflow.

This patch removes the aggressive failing on non-specified puppet-agent
versions in `install_puppet_agent_on`
```
* (maint) use type over cat in pure Windows (f53a9f6d)


```
(maint) use type over cat in pure Windows

If the host is not a cygwin environment, prefer `type` to produce the
contents of the log file over `cat`. `type` is built-in, where `cat` is
only available if someone has put *nix tools on the path, whether
through a git install (MinGW tools), installing GnuWin utils or some
other method.
```
* (maint) Always wait for Windows agent installs (c8cb9384)


```
(maint) Always wait for Windows agent installs

When installing Windows agents with cygwin or any other means, always
prefer `start /w` over just calling msiexec.

This adds to what was first introduced in 9c32cac7a7a5bf.
```
* Merge branch 'master' of github.com:bstopp/beaker (4452e5a9)

* Merge pull request #889 from spjmurray/bkr_401_os_volume_races (5c17bca4)


```
Merge pull request #889 from spjmurray/bkr_401_os_volume_races

(BKR-401) fix race in OpenStack volume deletion
```
* Merge pull request #892 from petems/maint_move_vb_vagrant_out_of_disk_path (17fe242f)


```
Merge pull request #892 from petems/maint_move_vb_vagrant_out_of_disk_path

(maint) Moves various VB options out of `disk_path` logic
```
* Merge pull request #812 from bodgit/openbsd (e37685d0)


```
Merge pull request #812 from bodgit/openbsd

(BKR-249) Add OpenBSD support
```
* Merge pull request #898 from kevpl/bkr415_acceptance_fix (888788a9)


```
Merge pull request #898 from kevpl/bkr415_acceptance_fix

(BKR-415) re-targeted puppet_pkg acceptance from 3.7.5 -> 3.8.1
```
* (BKR-415) re-targeted puppet_pkg acceptance from 3.7.5 -> 3.8.1 (c37cc8d7)

* This patch adds support for configuring the number of CPUs for (c3fae736)


```
This patch adds support for configuring the number of CPUs for
vagrant VirtualBox instances. The `vagrant_cpus` config option is
used to set the value.
```
* (BKR-417) This patch adds support for configuring the number of CPUs for (837fe37e)


```
(BKR-417) This patch adds support for configuring the number of CPUs for
vagrant VirtualBox instances. The `vagrant_cpus` config option is
used to set the value.
```
* (BKR-405) The "install_pe" DSL Method Fails to Install SG... (c31f2d9d)


```
(BKR-405) The "install_pe" DSL Method Fails to Install SG...

...if "Latest-win" Version File is Missing

- do not attempt to determine windows pe_ver if master version is
  greater than 3.99, just inherit from the master (if it exists)
- there's probably more edge cases here, but I don't believe that
  install_pe can handle every combinations of platforms/versions
```
* (maint) Moves out of `disk_path` logic... (c8f98aa6)


```
(maint) Moves out of `disk_path` logic...

Looks like these got moved into the `if` logic for `disk_path` accidentally around v2.8. This means that you can no longer use these options without adding disk_path logic in later versions of Beaker. This moves them back into their own section.
```
* (BKR-401) fix race in OpenStack volume deletion (b93046ed)


```
(BKR-401) fix race in OpenStack volume deletion

There is a delay between a volume being detached from a virtual machine and
when it is ready to be deleted.  The code as it stands is likely to hit a 400
error as the volume is still in the 'detaching' state.  Add in a wait_for
statement to allow the volume to get back into the 'available' state before
deleting
```
* (BKR-326) Fixes FreeBSD install to use ports (a0d47d14)


```
(BKR-326) Fixes FreeBSD install to use ports

* Adds helper method to `FreeBSD:Pkg` to install packages on FreeBSD using ports with sensible default arguments
```
* (BKR-249) Add OpenBSD support (3f72ecfc)


```
(BKR-249) Add OpenBSD support

Add install method to prefer installing the OpenBSD-maintained Puppet package
which tends to work better than vanilla gem versions. Also add enough smarts
to be able to do gem installations. The shell is not a login shell therefore
it doesn't pick up the .profile that contains the PKG_PATH variable so pkg_add
doesn't automatically install from the network so add the PKG_PATH to the
.ssh/environment too.

The packaging support handles the case when there are multiple rubies
available. Currently it will install the newest in the list that is older than
2.2.x as that doesn't work with all versions of Puppet. Also, if installing the
package advises to create symlinks to make this package the default, perform
this step automatically. This handles for example when installing ruby-1.9.3
and all the commands have a 19 suffix, etc.
```
### <a name = "2.18.1">2.18.1 - 14 Jul, 2015 (6a82f99f)

* (HISTORY) update beaker history for gem release 2.18.1 (6a82f99f)

* (GEM) update beaker version to 2.18.1 (f9939536)

* Merge pull request #891 from anodelman/shallow (c4b30018)


```
Merge pull request #891 from anodelman/shallow

(BKR-402) Regression in Beaker 2.18.0 AIO testing for PuppetDB usage
```
* Merge pull request #890 from justinstoller/bug/master/BKR-403_sless (e52b0af4)


```
Merge pull request #890 from justinstoller/bug/master/BKR-403_sless

(BKR-403) Use rpm on sles for pe puppet-agent
```
* (BKR-402) Regression in Beaker 2.18.0 AIO testing for PuppetDB usage (8c262979)


```
(BKR-402) Regression in Beaker 2.18.0 AIO testing for PuppetDB usage

- provide a sane default for puppetservice for aio defaults, but allow
  override with a user setting
```
* (BKR-403) Use rpm on sles for pe puppet-agent (6acd9938)


```
(BKR-403) Use rpm on sles for pe puppet-agent

In BKR-397 we updated rpm using platforms to use yum instead of rpm in
the install_puppet_agent_pe_promoted_repo, however it wasn't noticed
that SLES was also an rpm using platform in the match that doesn't also
include yum.

This patch moves SLES platforms into their own branch of logic that uses
the old rpm installation method while retaining the yum based
installation for other platforms.
```
### <a name = "2.18.0">2.18.0 - 13 Jul, 2015 (e018f2fc)

* (HISTORY) update beaker history for gem release 2.18.0 (e018f2fc)

* (GEM) update beaker version to 2.18.0 (268ce21e)

* Merge pull request #887 from kevpl/bkr394_aio_mixedinstall (28f9d26d)


```
Merge pull request #887 from kevpl/bkr394_aio_mixedinstall

(BKR-394) added support for 3.8/AIO mixed installations
```
* Merge pull request #888 from justinstoller/maint/master/BKR-397_use_yum (a76abdd9)


```
Merge pull request #888 from justinstoller/maint/master/BKR-397_use_yum

(BKR-397) Use yum for installing pe promoted puppet-agent
```
* (BKR-397) Use yum for installing pe promoted puppet-agent (d6d37145)


```
(BKR-397) Use yum for installing pe promoted puppet-agent

Previously we used the rpm command to install a local rpm file. However
puppet-agent requires dmidecode for EL platforms and this dependency
won't be resolved by using rpm.

This commit uses yum's localinstal command to install the local rpm file
so that dependencies are resolved.
```
* Merge pull request #858 from spjmurray/openstack_cinder_volumes (f5ecb177)


```
Merge pull request #858 from spjmurray/openstack_cinder_volumes

(BKR-347) Openstack: Add support for cinder attached volumes
```
* (BKR-394) added support for 3.8/AIO mixed installations (d715cb1d)

* Merge pull request #881 from anodelman/env-support (788aae5c)


```
Merge pull request #881 from anodelman/env-support

(BKR-387) environment not being preserved between ssh connections...
```
* (BKR-387) environment not being preserved between ssh connections... (41e64c50)


```
(BKR-387) environment not being preserved between ssh connections...

... on debian

- mirror the env to /etc/profile.d/beaker_env.sh
- add and acceptance test to ensure that environment variables are
  preserved between ssh connections for a SUT
```
* (BKR-347) Openstack: Add support for cinder attached volumes (4c2c5f23)


```
(BKR-347) Openstack: Add support for cinder attached volumes

Implement the storage array feature introduced for vagrant virtual box
to OpenStack users.  Unlike virtual box the bus type is outside of our
control.  If you need SCSI support this must be attached to the image
in glance.  How to do this is in the method documentation
```
### <a name = "2.17.0">2.17.0 - 10 Jul, 2015 (aaac4771)

* (HISTORY) update beaker history for gem release 2.17.0 (aaac4771)

* (GEM) update beaker version to 2.17.0 (745d9116)

* Merge pull request #884 from justinstoller/maint/master/moar-puppet-agent (7ba09f8f)


```
Merge pull request #884 from justinstoller/maint/master/moar-puppet-agent

(maint) Allow PE puppet-agent installs on custom roles
```
* (maint) Allow PE puppet-agent installs on custom roles (cfe9c834)


```
(maint) Allow PE puppet-agent installs on custom roles

Previously we installed puppet-agent on a host if there was the agent
role and no other role assigned to it. This prevents assigning a
puppet-agent node the "default" role to be used as the default test
target, or allow any other custom roles.

To allow assigning the "default" or custom roles to a puppet-agent node
we list the non-puppet-agnet roles we know how to generate installation answers
for and use that list to determine what nodes are puppet-agent or not.
```
* Merge pull request #883 from anodelman/puppetservice (2822e415)


```
Merge pull request #883 from anodelman/puppetservice

(BKR-390) Scooter pipeline is using pe-httpd instead of pe-puppetserver
```
* Merge pull request #882 from anodelman/osx (b64ee262)


```
Merge pull request #882 from anodelman/osx

(BKR-388) Beaker::Host::Mac#touch returns non-existent path
```
* Merge pull request #879 from anodelman/maint (df169767)


```
Merge pull request #879 from anodelman/maint

(BKR-386) beaker does not work with host_preserved.yaml file anymore
```
* (BKR-390) Scooter pipeline is using pe-httpd instead of pe-puppetserver (3a7830cc)


```
(BKR-390) Scooter pipeline is using pe-httpd instead of pe-puppetserver

- only use aio defaults on agents that are not master, database or
  dashboard (was previously using aio defaults/paths on all hosts
  identified as being >= 4.0)
```
* (BKR-388) Beaker::Host::Mac#touch returns non-existent path (21e885e0)


```
(BKR-388) Beaker::Host::Mac#touch returns non-existent path

- ensure that the mac host.touch method returns a correct, absolute
  path to the touch command
```
* Merge pull request #859 from vindir/feature/instancestores (a3429c39)


```
Merge pull request #859 from vindir/feature/instancestores

(BKR-348) AWS: Adding instance storage support
```
* (BKR-386) beaker does not work with host_preserved.yaml file anymore (c1b471fc)


```
(BKR-386) beaker does not work with host_preserved.yaml file anymore

- puppet-agent installation was causing a 'version' argument to be added
  to the preserved host file, causing beaker to output --version
  information upon re-use of that file
- fix is just renaming --version to use beaker_version instead of
  version as a flag
```
* (BKR-348) instance storage now supported (e607b2d5)


```
(BKR-348) instance storage now supported

AMIs using the instance storage root device type are now supported
allowing users who don't want/need EBS backed AMIs to add nodesets
more easily.
```
### <a name = "2.16.0">2.16.0 - 6 Jul, 2015 (b3e76227)

* (HISTORY) update beaker history for gem release 2.16.0 (b3e76227)

* (GEM) update beaker version to 2.16.0 (6b0a9ca2)

* Merge pull request #876 from anodelman/shallow (6edc61fe)


```
Merge pull request #876 from anodelman/shallow

(BKR-383) puppet-agent dmg installation doesn't work for anything...
```
* Merge pull request #877 from anodelman/osx (35d266b0)


```
Merge pull request #877 from anodelman/osx

(BKR-384) & (BKR-385) support for dev puppet-agent installation on osx
```
* Merge pull request #878 from anodelman/maint (c011ff05)


```
Merge pull request #878 from anodelman/maint

(MAINT) bad hardcoded 'debian' in puppet-agent promoted installation
```
* Merge pull request #856 from kevpl/bkr336_executiontime_add (fbe5b300)


```
Merge pull request #856 from kevpl/bkr336_executiontime_add

(BKR-336) added command-line arg to get test results in timing order
```
* (MAINT) bad hardcoded 'debian' in puppet-agent promoted installation (441de9ea)


```
(MAINT) bad hardcoded 'debian' in puppet-agent promoted installation

- should use #{variant} and not hardcoded debian, otherwise pukes on
  ubuntu
```
* (BKR-384) install_puppet_agent_dev_repo needs to support osx (9772fcfb)


```
(BKR-384) install_puppet_agent_dev_repo needs to support osx

- able to install dev puppet-agent on osx

example:

install_puppet_agent_dev_repo_on(host,
   { :puppet_agent_sha => 'c2946821d1bcd7e43a34bd1f9cd2f86160ca4fe0',
     :puppet_agent_version => '1.2.1.23.gc294682'    })
```
* (BKR-385) beaker needs to be able to convert mac codename to... (dee9b7c6)


```
(BKR-385) beaker needs to be able to convert mac codename to...

...version number

- add support to the platform object to handle yosemite -> 10.10 and
  mavericks -> 10.9 conversions for osx variant
```
* Merge pull request #875 from anodelman/puppet-agent (0a4318a2)


```
Merge pull request #875 from anodelman/puppet-agent

(BKR-377) Installing the Latest Puppet Agent Package
```
* (BKR-383) puppet-agent dmg installation doesn't work for anything... (6361cd78)


```
(BKR-383) puppet-agent dmg installation doesn't work for anything...

... other than 'latest'

- fix up the url construction for downloading a release mac puppet-agent
- tested locally
- there currently is not puppet-agent-latest.dmg file, so that won't
  work until that is posted
```
* Merge pull request #861 from logicminds/BKR-365 (c6bcdc9c)


```
Merge pull request #861 from logicminds/BKR-365

BKR-365 - allow beaker to use ssh config with rsync
```
* Merge pull request #867 from anodelman/hypervisor-acceptance (20e12ca7)


```
Merge pull request #867 from anodelman/hypervisor-acceptance

(BKR-367) create beaker ec2 smoketest
```
* Merge pull request #866 from kevpl/bkr318_f5_added (2cedf59a)


```
Merge pull request #866 from kevpl/bkr318_f5_added

(BKR-318) added platform support for f5
```
* Merge pull request #871 from anodelman/answers (66b3d8e1)


```
Merge pull request #871 from anodelman/answers

(BKR-370) beaker doesn't use answers set as env vars
```
* (BKR-377) Installing the Latest Puppet Agent Package (ffaada1e)


```
(BKR-377) Installing the Latest Puppet Agent Package

- support 'latest' as puppet_agent_version in
  install_puppet_agent_pe_promoted_on
- default to 'latest' for
  install_puppet_agent_pe_promoted_on::puppet_agent_version
```
* Merge pull request #873 from anodelman/shallow (a14f1624)


```
Merge pull request #873 from anodelman/shallow

(BKR-376) better interface to install puppet-agent through install_pe
```
* Merge pull request #874 from anodelman/maint (a0959a20)


```
Merge pull request #874 from anodelman/maint

(BKR-378) RHEL4 runs fail due to the absence of yum
```
* (BKR-378) RHEL4 runs fail due to the absence of yum (e7276d32)


```
(BKR-378) RHEL4 runs fail due to the absence of yum

- regression: accidentally changed as a ride along to puppet-agent installation
  work, return to correct state
```
* (BKR-376) better interface to install puppet-agent through install_pe (bfb9f006)


```
(BKR-376) better interface to install puppet-agent through install_pe

- standardize on parameter names puppet_agent_version, puppet_agent_sha
- if no puppet_agent_sha is provided default to puppet_agent_version
- support new env vars
  * BEAKER_PUPPET_AGENT_VERSION
  * BEAKER_PUPPET_AGENT_SHA
  * BEAKER_PUPPET_COLLECTION

- examples (puppet-agent installation):
  install_puppet_agent_on(host, { :version => '1.1.0', :default_action => 'gem_install'})
  install_puppet_agent_dev_repo_on(host, { :puppet_agent_sha => 'd3377feaeac173aada3a2c2cedd141eb610960a7', :puppet_agent_version => '1.1.1.225.gd3
377fe'  })
  install_puppet_agent_pe_promoted_repo_on(host, { :puppet_agent_sha => '1.1.0.227', :puppet_agent_version => '1.1.0.227.g1d8334c', :pe_ver => '4.0
.0-rc1'})

- using install_pe/install_pe_on (for versions of PE > 4.0)
set the puppet-agent version through an env var:
  export BEAKER_PUPPET_AGENT_VERSION=1.2.0
can then just call:
  install_pe or install_pe_on(hosts, options)

set the puppet-agent version through the options hash
  options[:puppet_agent_version] = '1.2.0'
  install_pe
```
* (BKR-370) beaker doesn't use answers set as env vars (521780ec)


```
(BKR-370) beaker doesn't use answers set as env vars

- not correctly using 'answer_for' to determine if there is a provided
  value for all questions
- fixed up some variable naming for clarity
```
* (BKR-367) create beaker ec2 smoketest (56aa9438)


```
(BKR-367) create beaker ec2 smoketest

- add acceptance/tests/hypervisor/communication.rb, checks to ensure
  that hosts can ping each other
- enable ping for aws ec2 instances created by beaker
- create host.ping method to ping from host to a second host, return
  'true' when ping is successful, 'false' otherwise
```
* (BKR-318) added platform support for f5 (308cb672)

* BKR-365 - allow beaker to use ssh config with rsync (691823fc)


```
BKR-365 - allow beaker to use ssh config with rsync

   * fixes a bug that vagrant introduced when using dynamic ssh configs
```
* (BKR-336) added command-line arg to get test results in timing order (806ff012)


```
(BKR-336) added command-line arg to get test results in timing order

The new argument will allow a second beaker_*.xml file to be
created next to the first one in timing order.

Conflicts:
	lib/beaker/options/command_line_parser.rb
```
### <a name = "2.15.1">2.15.1 - 1 Jul, 2015 (cd6f0bab)

* (HISTORY) update beaker history for gem release 2.15.1 (cd6f0bab)

* (GEM) update beaker version to 2.15.1 (eb1f373a)

* Merge pull request #872 from anodelman/maint (3c2a8179)


```
Merge pull request #872 from anodelman/maint

(BKR-374) apt/yum.puppetlabs use 'pc1' not 'PC1'
```
* (BKR-374) apt/yum.puppetlabs use 'pc1' not 'PC1' (358fcad4)

### <a name = "2.15.0">2.15.0 - 1 Jul, 2015 (07c416fb)

* (HISTORY) update beaker history for gem release 2.15.0 (07c416fb)

* (GEM) update beaker version to 2.15.0 (4b71df0e)

* Merge pull request #869 from kevpl/bkr253_installpe_pe_aio_url (b243648e)


```
Merge pull request #869 from kevpl/bkr253_installpe_pe_aio_url

(BKR-253) install_pe_on uses pe_promoted puppet-agent for 4.0+
```
* (BKR-253) install_pe_on uses pe_promoted puppet-agent for 4.0+ (c0d47643)

* Merge pull request #860 from anodelman/shallow (11f9a9ba)


```
Merge pull request #860 from anodelman/shallow

(BKR-323) Allow install_puppet_agent_on to support "pe only" platforms
```
* Merge pull request #862 from anodelman/support-date-version (dbc4b535)


```
Merge pull request #862 from anodelman/support-date-version

(BKR-344) Support year.release versioning (e.g. 2015.2)
```
* Merge pull request #863 from anodelman/maint (b444c507)


```
Merge pull request #863 from anodelman/maint

(MAINT) add spec testing to option parsing prioritization
```
* (BKR-352) Beaker install_puppet_agent_on helper does not... (521e4791)


```
(BKR-352) Beaker install_puppet_agent_on helper does not...

...respect the host install_32 or ruby_arch setting on Windows

- install x86 msi when
  * host['install_32'] == true
  * opts['install_32'] == true
  * host['ruby_arch'] == 'x86'
  * host.is_x86_64? == false
- install x64 msi when
  * (host.is_x86_64? == true) && !host['install_32'] &&
      !opts['install_32'] && !(host['ruby_arch'] == 'x86')
```
* (MAINT) add spec testing to option parsing prioritization (701c5aed)


```
(MAINT) add spec testing to option parsing prioritization

- make sure that we are sorting through env variables, command line
  arguments, host file options, options file argument and presets
  correctly
```
* (BKR-344) Support year.release versioning (e.g. 2015.2) (048e6708)


```
(BKR-344) Support year.release versioning (e.g. 2015.2)

- update semver matching to understand that 3.0.0 < 2015.3.0.0
- update answer file generation to provide 4.0 answers for version 2015+
```
* Merge pull request #855 from bstopp/bug/copy_module_to_mv_fix (9631b55a)


```
Merge pull request #855 from bstopp/bug/copy_module_to_mv_fix

(BKR-339) Remove the target module directory on host during copy_module_to
```
* Merge pull request #853 from kevpl/bkr319_installpe_puppetagent (6ddec170)


```
Merge pull request #853 from kevpl/bkr319_installpe_puppetagent

(BKR-319) added puppet-agent install for install_pe for versions over 4.0
```
* Merge pull request #851 from madAndroid/BKR-314-idempotent-EL-install-release-repo (d7fccf8f)


```
Merge pull request #851 from madAndroid/BKR-314-idempotent-EL-install-release-repo

(BKR-314) Ensure install_puppetlabs_release_repo is idempotent for EL
```
* (BKR-319) review feedback refactor (4b7235ec)

* (BKR-323) Allow install_puppet_agent_on to support "pe only" platforms (cc906f1d)


```
(BKR-323) Allow install_puppet_agent_on to support "pe only" platforms

- support both pm.puppetlabs.com and builds.puppetlabs.com for
  downloading puppet-agent
- use install_puppet_agent_on for yum|apt.puppetlabs.com
- use install_puppet_agent_dev_repo_on for builds.puppetlabs.com
- use install_puppet_agent_pe_promoted_repo_on for pm.puppetlabs.com

example usage:
  install_puppet_agent_on(host, { :version => '1.1.0', :default_action => 'gem_install'})
  install_puppet_agent_dev_repo_on(host, { :sha => 'd3377feaeac173aada3a2c2cedd141eb610960a7', :version => '1.1.1.225.gd3377fe'  })
  install_puppet_agent_pe_promoted_repo_on(host, { :sha => '1.1.0.227', :version => '1.1.0.227.g1d8334c', :pe_ver => '4.0.0-rc1'})
```
* Merge pull request #844 from kevpl/bkr53_withpuppetrunningon_restart (36c9ae20)


```
Merge pull request #844 from kevpl/bkr53_withpuppetrunningon_restart

(BKR-53) with_puppet_running_on only restarts before yielding
```
* (BKR-339) Remove the target module directory on host during copy_module_to (1d1d7eb6)


```
(BKR-339) Remove the target module directory on host during copy_module_to

Without this patch, the copy_module_to function will not work correctly to copy updated module files into the target directory on the hosts. Instead accpetance test spec files can be updated, but not module sources. Additionally the module copy will fail on the second non-provisioning run.

The patch simply executes a delete of the target directory on the host, ensuring it does not exist prior to the mv command.
```
* Merge pull request #847 from anodelman/fail-fast (923c7857)


```
Merge pull request #847 from anodelman/fail-fast

(BKR-322) --fail-mode fast doesn't seem to be failing fast
```
* (BKR-319) added puppet-agent install for install_pe for versions over 4.0 (2749c051)

* Merge pull request #850 from anodelman/aio-paths (19511298)


```
Merge pull request #850 from anodelman/aio-paths

(BKR-325) AIO detection for install_puppet() and install_pe()
```
* Merge pull request #846 from anodelman/shallow (b00942f0)


```
Merge pull request #846 from anodelman/shallow

(BKR-317) More usable configure_foss_defaults_on
```
* Merge pull request #848 from petems/BKR-326-fix_freebsd_ssh_root_setup (3491f13d)


```
Merge pull request #848 from petems/BKR-326-fix_freebsd_ssh_root_setup

(BKR-326) Fixes enabling user environments
```
* Merge pull request #839 from vindir/feature/aws_ip_failover (837b2673)


```
Merge pull request #839 from vindir/feature/aws_ip_failover

(BKR-311) Allow AWS IP Fallback
```
* (BKR-326) Adds requirement of perl for FreeBSD (476b3860)


```
(BKR-326) Adds requirement of perl for FreeBSD

Makes regex sed replacement easier
```
* BKR-314 - expect more explicit rpm command - with --replacepkgs (cca0046e)

* BKR-314 - Use --replacepkgs to ensure repo install is idempotent (dd73ca21)

* (BKR-325) AIO detection for install_puppet() and install_pe() (8e6347ab)


```
(BKR-325) AIO detection for install_puppet() and install_pe()

- check the pe_ver/version to see if aio pathing should be installed
  instead of foss/pe
```
* (BKR-326) Adds FreeBSD specs for root login enable (a8ffadbe)

* (BKR-326) Fixes enabling user environments (e5bc2451)


```
(BKR-326) Fixes enabling user environments

Currently this step uses `echo_to_file`, which actually overwrites the file with the one line. This changes it to use the perl regex instead.
```
* (BKR-322) --fail-mode fast doesn't seem to be failing fast (7dfb56e0)


```
(BKR-322) --fail-mode fast doesn't seem to be failing fast

- was using the default value instead of the setting value
```
* (BKR-317) More usable configure_foss_defaults_on (74df91d1)


```
(BKR-317) More usable configure_foss_defaults_on

- add support for remove_defaults_on
- add some spec test coverage
```
* Merge pull request #828 from kevpl/bkr220_tagging_add (5f71cdb3)


```
Merge pull request #828 from kevpl/bkr220_tagging_add

(BKR-220) test tagging implemented
```
* (BKR-317) More usable configure_foss_defaults_on (12c51454)


```
(BKR-317) More usable configure_foss_defaults_on

- create configure_defaults_on that provided a type sets the correct
  defaults per-host, will also remove any existing defaults
```
* Merge pull request #845 from kevpl/bkr320_answers_40nilproblems (56fbc872)


```
Merge pull request #845 from kevpl/bkr320_answers_40nilproblems

(BKR-320) added nil-check so we don't call methods on empty answer maps
```
* (BKR-320) added nil-check so we don't call methods on empty answer maps (2d38a720)

* (BKR-53) with_puppet_running_on can not restart after yielding (9da3b99f)


```
(BKR-53) with_puppet_running_on can not restart after yielding

Before, with_puppet_running_on bounced the puppet service before and after runs.
This was causing us a lot of pain as the last restart proved unnecessary for the
most part, and added 30 seconds to each test run on avg in our CI.

We've decided to improve this by adding the ability to remove the second bounce.
Mosts tests use `with_puppet_running_on`, so they'll be setup accordingly before
yielding, so that second one is unnecessary.
```
* (BKR-311) Allow AWS IP Fallback (098daef0)


```
(BKR-311) Allow AWS IP Fallback

When bringing up an instance in a VPC there won't always be a public address.
This allows the AWS hypervisor to fallback and assign an instance's private
ip to host['ip'] for new instances without a public address.

This PR includes tests for the .AwsSdk#populate_dns method to verify this new
behavior persists in the future.
```
* (BKR-220) test tagging implemented (f41c29f9)

### <a name = "2.14.1">2.14.1 - 5 Jun, 2015 (35026603)

* (HISTORY) update beaker history for gem release 2.14.1 (35026603)

* (GEM) update beaker version to 2.14.1 (8539687f)

* Merge pull request #842 from anodelman/fix-puppetservice-default (28a4ef9c)


```
Merge pull request #842 from anodelman/fix-puppetservice-default

(BKR-313) Beaker is using pe-httpd as the puppet master service...
```
* Merge pull request #841 from kevpl/bkr295_ubuntu_stopagenton_fix (eb8cc39c)


```
Merge pull request #841 from kevpl/bkr295_ubuntu_stopagenton_fix

(BKR-295) use 'puppet' in stop_agent_on for 4.0+
```
* (BKR-313) Beaker is using pe-httpd as the puppet master service... (a27eb5ae)


```
(BKR-313) Beaker is using pe-httpd as the puppet master service...

... in method 'with_puppet_running_on'

- use pe-httpd pre 3.4, pe-puppetserver post 3.4
```
* (BKR-295) use 'puppet' in stop_agent_on for 4.0+ (9604315c)

### <a name = "2.14.0">2.14.0 - 4 Jun, 2015 (c0ebcd16)

* (HISTORY) update beaker history for gem release 2.14.0 (c0ebcd16)

* (GEM) update beaker version to 2.14.0 (656f30be)

* Merge pull request #837 from justinstoller/maint/master/bkrsomethingsomething (0d0ceab9)


```
Merge pull request #837 from justinstoller/maint/master/bkrsomethingsomething

[WIP] add install_puppet_agent_on method to install_utils
```
* Merge pull request #836 from rick/bkr-301/add-warning-when-empty-fog-file-is-encountered (0d102203)


```
Merge pull request #836 from rick/bkr-301/add-warning-when-empty-fog-file-is-encountered

[BKR-301] add warning when empty fog file is encountered
```
* Merge pull request #838 from thallgren/master (4e8be4e2)


```
Merge pull request #838 from thallgren/master

(maint) Fix typo Error -> Errno
```
* (maint) Fix typo Error -> Errno (670b1509)

* (BKR-195) Simplified install of released puppet-agent (fcac8e03)


```
(BKR-195) Simplified install of released puppet-agent

Previously installing the puppet-agent package required writing a
pre-suite to manually install the correct dev repositories and
installing a dev build of puppet-agent.

This is problematic for downstream consumers that do not want to test
puppet-agent or the code in it, but want to test that their code works
with puppet-agent (eg module authors).

This commit creates the DSL method `install_puppet_agent_on()`, an
analog to the `install_puppet_on()` method that allows installing
puppet-agent.

It also allows the `install_puppet()` method to install puppet-agent if
given a version of Puppet greater than 4.0.0 (by delegating to
`install_puppet_agent_on()`).

Errata:
 * Follows the pattern of naming helpers `*_on` and
   normalizes the helpers it touches to follow the same pattern.
 * Updates the MSI and DMG methods to allow for latest builds
   (prior to this they required explicit versions and so were rarely
   used even by our internal teams).
 * Also updates legacy puppet MSI and DMG install helpers to
   delegate to newer install puppet-agent helpers using the same
   criteria as used in `install_puppet_on()` (despite being marked as
   api private they are used internally).
 * Uses newer `install_puppetlabs_release_repo_on` and
   `Host#install_package` and updates old helpers to do the same
```
* Merge pull request #833 from thallgren/issue/bkr-304/redundant-scp-copying (adb9c37a)


```
Merge pull request #833 from thallgren/issue/bkr-304/redundant-scp-copying

(BKR-304) Prevent redundant copying when doing scp
```
* Merge pull request #796 from fiddyspence/bug/rsync_fails_with_docker (82286b54)


```
Merge pull request #796 from fiddyspence/bug/rsync_fails_with_docker

(BKR-226) - rsync fails because of NATted ports
```
* (BKR-301) Add "happy path" tests for credential loading (22c39286)


```
(BKR-301) Add "happy path" tests for credential loading

Since we've tested that `#load_credentials` behaves ok during hard times, let's
actually test that it does what it's supposed to do.
```
* (BKR-301) Tests and code for empty fog file case (d33ac6d6)


```
(BKR-301) Tests and code for empty fog file case

Numerous small refactorings in `#load_credentials` after getting the test green.
```
* (BKR-301) New test and testing seams (bf8a9a26)


```
(BKR-301) New test and testing seams

This splits off tests for #load_credentials, as we have untested
behavior there, and the point of this work is to fix a mis-feature
in that area (not catching the hard-to-decipher exception when
an empty fog file is presented).  The main tests all stub out the
fog file loading, so here we introduce a different stub.

This also modifies the `Vmpooler` class to split out a testing seam:
the `#read_fog_file` method can be stubbed now independently of the
`#load_credentials method`, so we can feed in post-YAML output to
the `#load_credentials` under test.

Since `#load_credentials` is called as part of the constructor (a mild
anti-pattern, but lazy loading can be cumbersome), we need to validate
its results via testing post-constructed object state.  Unfortunately,
we can't get the resultant credentials state without piercing the
instance-variable boundary of the `Vmpooler` object, so we added another
seam: the `attr_reader` for `:credentials`.

While we're there, we added the reader for the remainder of the
options handed into the constructor, as it makes sense to at least
be uniform in the library, even if it is under-tested.
```
* (MAINT) clean up whitespace in spec file (98631575)

* Merge pull request #835 from waynr/bkr-307 (5c17aaec)


```
Merge pull request #835 from waynr/bkr-307

(BKR-307) Add Beaker::Platform support for debian jessie (aka 8)
```
* Merge pull request #832 from anodelman/login-as-user (33f4d6b7)


```
Merge pull request #832 from anodelman/login-as-user

(BKR-248) support connecting to SUTs with user/password
```
* (BKR-307) Add Beaker::Platform support for debian jessie (aka 8) (f87fc3fe)

* Merge pull request #826 from anodelman/cisco (a7c0cce2)


```
Merge pull request #826 from anodelman/cisco

(BKR-292) Cisco platform changes + prepend command functionality
```
* Merge pull request #831 from anodelman/remove-rake-task (ddf4a989)


```
Merge pull request #831 from anodelman/remove-rake-task

(BKR-239) Remove dependency on puppet-dashboard rake tasks for...
```
* Merge pull request #821 from anodelman/shallow (a22c86f1)


```
Merge pull request #821 from anodelman/shallow

(BKR-273) Allow Setting Type by Host
```
* (BKR-304) Prevent redundant copying when doing scp (7db1d724)


```
(BKR-304) Prevent redundant copying when doing scp

Before this commit, the method Beaker::Host.do_scp_to would request
copying of both directories and files from the underlying scp
connection. This resulted in a lot of redundant copying since the
scp connection, when handed a directory, would copy it recursively.

This commit ensures that only the files are copied. This is safe
because all remote directories are already created in a preceding
step.
```
* (BKR-248) support connecting to SUTs with user/password (4da57c9f)


```
(BKR-248) support connecting to SUTs with user/password

- check to see if a custom ssh user has been defined, if so then use
  that instead of the default user per-OS type
```
* Merge pull request #830 from kevpl/puppet_git_branch_change (cc52b1e4)


```
Merge pull request #830 from kevpl/puppet_git_branch_change

(MAINT) moving from stable to a release for facter & hiera
```
* Merge pull request #829 from kevpl/bkr231_answers_update (4975d36f)


```
Merge pull request #829 from kevpl/bkr231_answers_update

(BKR-231) updated answers to use v4 answers for puppet 4
```
* (MAINT) moving from stable to a release for facter & hiera in puppet_git acceptance testing (89d6f425)

* Merge pull request #823 from anodelman/subset-hosts (e62404db)


```
Merge pull request #823 from anodelman/subset-hosts

(BKR-280) ability to install pe/foss on subset of hosts
```
* Merge pull request #813 from electrical/docker_swarm (b5818852)


```
Merge pull request #813 from electrical/docker_swarm

(BKR-242) Docker swarm
```
* (BKR-231) updated answers to use v4 answers for puppet 4 (49eed580)

* (BKR-239) Remove dependency on puppet-dashboard rake tasks for... (ce9aa43c)


```
(BKR-239) Remove dependency on puppet-dashboard rake tasks for...

... shallow gravy.

- wrap rake test call in version check, only run if pre 3.99
- use scooter for new frictionless workflow
```
* (BKR-292) Cisco platform changes + prepend command functionality (685e43aa)


```
(BKR-292) Cisco platform changes + prepend command functionality

- add cisco to supported platforms
- add ability to send a prepend_cmd string to a command object
```
* Merge pull request #822 from justinstoller/maint/master/remove-step (b7915485)


```
Merge pull request #822 from justinstoller/maint/master/remove-step

(maint) Remove step dsl usage from inside Beaker
```
* Merge pull request #825 from mcanevet/dev/user_data (98453297)


```
Merge pull request #825 from mcanevet/dev/user_data

(BKR-300) Always manage_etc_hosts in cloud-init
```
* (BKR-300) Always manage_etc_hosts in cloud-init (b5a0885b)

* (BKR-280) ability to install pe/foss on subset of hosts (83accb53)


```
(BKR-280) ability to install pe/foss on subset of hosts

- created install_pe_on, upgrade_pe_on, install_puppet_on that accept a
  first argument of a host array and then correctly install pe/puppet on
  provided hosts
```
* (maint) Remove step dsl usage from inside Beaker (5d1cf55a)


```
(maint) Remove step dsl usage from inside Beaker

Prior to this we would use the `step` DSL method in a couple of places
inside Beaker.  This can be problematic when using Beaker as a library
and requires loading more of Beaker than is necessary for executing
certain helper methods.  This commit removes the internal usage of step
and replaces it with calls to the the logger that will output the same
style of notification that calling step does.
```
* (BKR-273) Allow Setting Type by Host (5c40b0d7)


```
(BKR-273) Allow Setting Type by Host

- no longer use 'type' to control path/default host settings
- set environment and defaults post pe/foss installation
- dump more information post testing so that you can correctly pick up
  the host again
```
* (BKR-242) Add Swarm support to docker run (7d447a46)


```
(BKR-242) Add Swarm support to docker run

To distribute the same built image between all swarm slaves we need to
push the image to a private registry.
If the image does not exist yet ( first build ) we tag + push it.
If it does exist we will re-use it.
If we built the image on Node A but then the run command is executed on
node B we will pull the image automatically and run it.

The only downside is that we will always build the image since we need
to know the resulting image ID.
Hopefully this can be improved in the future.
```
* (BKR-242) Add logic to support swarm (917a2306)


```
(BKR-242) Add logic to support swarm

When we want the IP address of the container with running swarm we have
to fetch the IP of the swarm slave it self.
```
* (BKR-226) - rsync fails because of NATted ports fix (89c4d6ab)

### <a name = "2.13.0">2.13.0 - 29 May, 2015 (dd70aa66)

* (HISTORY) update beaker history for gem release 2.13.0 (dd70aa66)

* (GEM) update beaker version to 2.13.0 (c801d4c8)

* Merge pull request #824 from anodelman/remove-rake-task (32d49e16)


```
Merge pull request #824 from anodelman/remove-rake-task

(BKR-239) Remove dependency on puppet-dashboard rake tasks...
```
* (BKR-239) Remove dependency on puppet-dashboard rake tasks... (a334fe40)


```
(BKR-239) Remove dependency on puppet-dashboard rake tasks...

... for shallow gravy.

- do that
```
* Merge pull request #817 from justinstoller/maint/master/hocon-update (ddc7d948)


```
Merge pull request #817 from justinstoller/maint/master/hocon-update

(maint) Relax constraint on hocon
```
* Merge pull request #820 from anodelman/fix-accessors (aeedd651)


```
Merge pull request #820 from anodelman/fix-accessors

(BKR-283)/(BKR-262) missing @metadata/@logger accessors for beaker-rspec
```
* Merge pull request #819 from spjmurray/virtualbox_volumes (85bbc4dd)


```
Merge pull request #819 from spjmurray/virtualbox_volumes

(BKR-281) VirtualBox: Add support for storage arrays
```
* (BKR-283)/(BKR-262) missing @metadata/@logger accessors for beaker-rspec (d230c2cc)


```
(BKR-283)/(BKR-262) missing @metadata/@logger accessors for beaker-rspec

- beaker-rspec needs access to @metadata, broken with beaker 2.12.0
- Beaker-rspec missing @logger accessor

Added both logger and metadata accessors so that beaker-rspec can be
repaired to work with latest beaker releases.
```
* (BKR-287) Relax constraint on hocon (f8f44deb)


```
(BKR-287) Relax constraint on hocon

Prior to this we were using the hocon gem and pinning to a z release.

This commit relaxes the version dependency to pull in an pre-1.0 hocon
release.

This is necessary for testing the hocon module itself.
```
* (BKR-281) VirtualBox: Add support for storage arrays (3b0b2443)


```
(BKR-281) VirtualBox: Add support for storage arrays

Extends the Vagrant VirtualBox hypervisor to allow per host definitions
of storage volumes, for testing things like ceph and other storage
technologies.

An example nodeset provisions the VM with 3 attached storage volumes
available as sdb, sdc, sdd (on linux systems) at at SCSI addresses
2:0:0:0, 3:0:0:0, 4:0:0:0.  Sizes are specified in MB.

  HOSTS:
    osd0:
      hypervisor: vagrant
      volumes:
        osd0_0:
          size: 10000
        osd0_1:
          size: 10000
        journal:
          size: 1000
```
### <a name = "2.12.0">2.12.0 - 20 May, 2015 (62845ce9)

* (HISTORY) update beaker history for gem release 2.12.0 (62845ce9)

* (GEM) update beaker version to 2.12.0 (88efb0d6)

* Merge pull request #790 from kevpl/bkr76_acceptance_addpresuite (4d43e91d)


```
Merge pull request #790 from kevpl/bkr76_acceptance_addpresuite

(BKR-76) created first pre-suite acceptance tests
```
* Merge pull request #814 from kevpl/bkr186_test_addaccessors2 (121ee9f8)


```
Merge pull request #814 from kevpl/bkr186_test_addaccessors2

(BKR-186) added current test info accessors to DSL
```
* Merge pull request #815 from kevpl/bkr232_option_noprovision_implies_no_configure_validate (f60724a6)


```
Merge pull request #815 from kevpl/bkr232_option_noprovision_implies_no_configure_validate

(BKR-232) --no-provision now implies --no-configure & --no-validate
```
* Merge pull request #816 from petems/BKR-276-fix_freebsd_file_making (158273ef)


```
Merge pull request #816 from petems/BKR-276-fix_freebsd_file_making

(BKR-276) Fixes `#echo_to_file` for FreeBSD
```
* (BKR-276) Fixes `#echo_to_file` for FreeBSD (d1e36080)


```
(BKR-276) Fixes `#echo_to_file` for FreeBSD

Previous command didn't wrap printf string in `"`
Stops command working:




freebsd-9-x64 executed in 0.04 seconds
Warning: ssh connection to 10.255.52.108 has been terminated

freebsd-9-x64 20:12:47$ printf 127.0.0.1\tlocalhost localhost.localdomain\n10.255.52.108\tfreebsd-9-x64\n > /etc/hosts
Attempting ssh connection to 10.255.52.108, user: root, opts: {:config=>"/var/folders/nn/408ddhln26s1b356ry19q6yr0000gp/T/freebsd-9-x6420150518-65951-3jag0b"}
printf: missing format character


```
* (BKR-232) --no-provision now implies --no-configure & --no-validate (e2200d2e)

* (BKR-76) sles: fixed git & gem install issues (d0d0b95d)

* (BKR-76) fixed solaris 11 issues with git install (8909ff3b)

* Merge pull request #799 from sschneid/vmpooler_tokens (3e545182)


```
Merge pull request #799 from sschneid/vmpooler_tokens

(BKR-218) Support using vmpooler API tokens
```
* (BKR-76) added windows ruby setup steps (1f45fc57)

* (BKR-186) added current test info accessors to DSL (76b07a5a)

* (BKR-218) Support using vmpooler API tokens (4c860f93)

* (BKR-76) created first pre-suite acceptance tests (b5d1dd1f)

### <a name = "2.11.0">2.11.0 - 6 May, 2015 (b775cc73)

* (HISTORY) update beaker history for gem release 2.11.0 (b775cc73)

* (GEM) update beaker version to 2.11.0 (50128ac0)

* Merge pull request #806 from kevpl/bkr240_windows_rebootfix (7455593a)


```
Merge pull request #806 from kevpl/bkr240_windows_rebootfix

(BKR-240) added a reason code on reboot for windows
```
* Merge pull request #803 from puppetlabs/fix/qeng-2009_3.99_windows_msi_name (4098e30c)


```
Merge pull request #803 from puppetlabs/fix/qeng-2009_3.99_windows_msi_name

(QENG-2009) Fix windows MSI name for 3.99
```
* Merge pull request #804 from davemcdonnell/fix_pty_typo_el7 (0de90408)


```
Merge pull request #804 from davemcdonnell/fix_pty_typo_el7

Fix typo ptry => pty, sudo failing on el7
```
* Merge pull request #802 from anodelman/win-fix (d17a309e)


```
Merge pull request #802 from anodelman/win-fix

(BKR-191) replace is_cygwin? with a more understandable name
```
* Merge pull request #808 from kevpl/bkr235_answers_puppetdbcustomize (441bf997)


```
Merge pull request #808 from kevpl/bkr235_answers_puppetdbcustomize

(BKR-235) Added Customization for External Postgres
```
* Merge pull request #807 from kevpl/bkr241_windows_install32bitpuppetagent (cacb37e0)


```
Merge pull request #807 from kevpl/bkr241_windows_install32bitpuppetagent

Bkr241 windows install32bitpuppetagent
```
* Merge pull request #809 from kevpl/bkr243_preservedhosts_v2 (5d74773c)


```
Merge pull request #809 from kevpl/bkr243_preservedhosts_v2

(BKR-243) improved preserved-hosts file saving
```
* (BKR-243) improved preserved-hosts file saving (282bb9e4)

* (BKR-240) added a reason code on reboot for windows (24fc8038)

* Merge pull request #791 from rbrw/ticket/master/bkr-217-rotate-ec2-subnets (61b3b1bd)


```
Merge pull request #791 from rbrw/ticket/master/bkr-217-rotate-ec2-subnets

(BKR-217) aws_sdk: given CONFIG subnet_ids, try each in turn
```
* Merge pull request #793 from kevpl/bkr180_install_middleman (90eb818e)


```
Merge pull request #793 from kevpl/bkr180_install_middleman

(BKR-180) added ability to use Beaker machine as scp middle-man for PE
```
* Merge pull request #797 from anodelman/sweep (f40ed598)


```
Merge pull request #797 from anodelman/sweep

(BKR-224) on(node, 'puppet agent -t') raises no warning when node = []
```
* Merge pull request #798 from fiddyspence/bug/move_round_openstack_address_assignments (30019ce0)


```
Merge pull request #798 from fiddyspence/bug/move_round_openstack_address_assignments

(BKR-223) Change order of how we assign IPs to openstack instances
```
* Merge pull request #801 from anodelman/maint (40b18ed0)


```
Merge pull request #801 from anodelman/maint

(BKR-215) Document all of the options to #on and friends
```
* BKR-245 Fix typo ptry => pty, restart sshd failing on el7 when running sudo (07f69955)

* (QENG-2009) Update beaker specs for 3.99 windows msi fix (8b5401f7)

* (QENG-2009) Fix windows MSI name for 3.99 (cd07eb83)


```
(QENG-2009) Fix windows MSI name for 3.99

We were only using puppet-agent for 4.0, this
commit bumps that down to 3.99.
```
* (BKR-235) all necessary answers to use an external postgres host are now customizable (493fea00)

* (BKR-191) replace is_cygwin? with a more understandable name (2c67d735)


```
(BKR-191) replace is_cygwin? with a more understandable name

- create is_powershell?, update usages of is_cygwin as appropriate
- move powershell only code into pswindows host object
- fixes related to breakages discovered when this code was moved
```
* (BKR-215) Document all of the options to #on and friends (1dda76e3)


```
(BKR-215) Document all of the options to #on and friends

- updates shared options to be current (with info for
  accept_all_exit_codes and friends)
- yard doc does a single pass and you can't guarantee file ordering, so
  you have to have the common options macro in each file that needs it -
  duplication yay!
```
* (MAINT) update acceptable_exit_codes usage to accept_all_exit_codes (402b4d85)


```
(MAINT) update acceptable_exit_codes usage to accept_all_exit_codes

- we are abusing acceptable_exit_codes all over the place by giving it a
  mega-array, basically recreating the functionality of
  accept_all_exit_codes
```
* (BKR-235) added ability to customize puppetdb_hostname answer (3d5d5b64)

* (BKR-223) Change order of how we assign IPs to openstack instances (f6d2c521)

* (BKR-224) on(node, 'puppet agent -t') raises no warning when node = [] (69315874)


```
(BKR-224) on(node, 'puppet agent -t') raises no warning when node = []

- if a logger is defined then send a warning message if attempting to
  run a command against an array of 0 nodes
```
* Merge pull request #794 from kevpl/bkr199_cumulus_packageupdate (4e556c5b)


```
Merge pull request #794 from kevpl/bkr199_cumulus_packageupdate

(BKR-199) updated cumulus packages required to reflect current package structure
```
* Merge pull request #795 from fiddyspence/bug/rsync_source_always_nil (7bc2c62e)


```
Merge pull request #795 from fiddyspence/bug/rsync_source_always_nil

(BKR-225) rsync module_utils method source is always nil
```
* Merge pull request #788 from fiddyspence/feature/do_you_want_openstack_region_support_this_time (c35ec983)


```
Merge pull request #788 from fiddyspence/feature/do_you_want_openstack_region_support_this_time

[openstack] enable support for multiple regions
```
* (BKR-225) rsync module_utils method source is always nil (e3db6871)


```
(BKR-225) rsync module_utils method source is always nil

sadfs
```
* (BKR-199) updated cumulus packages required to reflect current package structure (790c5d44)

* (BKR-180) added ability to use Beaker machine as scp middle-man for PE (b97640c0)

* (BKR-217) aws_sdk: given CONFIG subnet_ids, try each in turn (08e4f79d)


```
(BKR-217) aws_sdk: given CONFIG subnet_ids, try each in turn

This should help alleviate the EC2 InsufficientInstanceCapacity.

The new policy will only be applied to a host if there isn't a CONFIG
subnet_id and there isn't a host-specific subnet_id.  When it does
apply, try each subnet in subnet_ids once for each relevant host.

The new option can be used like this:

  CONFIG
    vpc_id: foo
    subnet_ids:
      - x
      - y
      - z
```
* (BKR-27)[openstack] enable support for multiple regions (e32e0b54)

* (BKR-217) aws_sdk: Kill EC2 instances on exception (6b0cf490)


```
(BKR-217) aws_sdk: Kill EC2 instances on exception

Move EC2 cleanup code to kill_instances() and call that from cleanup(),
and from a new exception handler in launch_all_nodes(), to be sure we
don't leave instances running when something goes wrong.

Adjust wait_for_status() to handle a specific list of hosts rather than
just @hosts.
```
* (BKR-217) aws_sdk: add create_instance() (d4d6521d)


```
(BKR-217) aws_sdk: add create_instance()

Move the per-host core of launch_all_nodes() to create_instance() to
prepare for the addition of launch exception
handlers (InsufficientCapacity, etc.).
```
* (BKR-217) aws_sdk: move wait_for_status() to launch_all_nodes() (023437e1)

* (maint) Allow :ruby_arch to select Windows builds (a0d76866)


```
(maint) Allow :ruby_arch to select Windows builds

 - Puppet puppetlabs/puppet@92c539f8626467690321c875d5f2746f56fec6ac
   added :ruby_arch to support the notion of choosing a Windows
   installer architecture.  A node could set :ruby_arch to either
   x64 or x86 to choose to install a 64-bit or 32-bit Ruby MSI on a
   64-bit version of Windows.

   When similar behavior was introduced to Beaker, it didn't follow
   prior art, and a new setting called :install_32 was introduced to
   manage this functionality in 6f8deb7dbc7bc75b8624df754c261f4d2b58b999

   This commit adds in :ruby_arch, with the hope that :install_32 will
   be deprecated on a future major version boundary to simplify the
   logic around settings evaluation here.
```
* (maint) Allow installing 32-bit Puppet Agent (23c06fa9)


```
(maint) Allow installing 32-bit Puppet Agent

 - Previously, install_utils was modified to be able to install PE
   based on a configuration switch called `install_32` in
   6f8deb7dbc7bc75b8624df754c261f4d2b58b999

   This allows a 64-bit Windows OS to ask to install a 32-bit Ruby /
   Puppet version.  This is important given 64-bit support wasn't
   added to Puppet or PE until 3.7.

   When installing the puppet-agent through install_puppetagent_dev_repo
   helper, allow for selecting the build in a similar fashion.
```
### <a name = "2.10.0">2.10.0 - 22 Apr, 2015 (c4f37479)

* (HISTORY) update beaker history for gem release 2.10.0 (c4f37479)

* (GEM) update beaker version to 2.10.0 (2f834676)

* Merge pull request #777 from kevpl/bkr184_repos_addoption (c68967e3)


```
Merge pull request #777 from kevpl/bkr184_repos_addoption

(BKR-184) generalized repo selection code for install_puppetlabs_dev_repo
```
* Merge pull request #775 from kevpl/bkr4_hostsfile_reuse (433d7ccd)


```
Merge pull request #775 from kevpl/bkr4_hostsfile_reuse

(BKR-4) Beaker now dumps re-usable hosts file when SUTs are preserved
```
* Merge pull request #787 from er0ck/fix/master/BKR-209-check_for_package_and_host_prebuild_sles10 (c256ebd7)


```
Merge pull request #787 from er0ck/fix/master/BKR-209-check_for_package_and_host_prebuild_sles10

(BKR-209) check for package and host prebuild sles10
```
* (BKR-209) check for package and host prebuild sles10 (f21ad513)


```
(BKR-209) check for package and host prebuild sles10

this change fixes check_for_package on sles10 in which zypper always
returns 0, even if a package is not found.
This change also removes ntp package from the host pre-build steps.
sles10 comes with ntp_command installed.
```
* Merge pull request #785 from anodelman/cherry (8eb9a543)


```
Merge pull request #785 from anodelman/cherry

(BKR-196) add 'reboot' host method
```
* (BKR-196) add 'reboot' host method (53cd051b)


```
(BKR-196) add 'reboot' host method

- added host.reboot method
- added acceptance test to ensure functionality
```
* Merge pull request #733 from fiddyspence/feature/better_openstack_ip_assignment_handling (d854fcae)


```
Merge pull request #733 from fiddyspence/feature/better_openstack_ip_assignment_handling

(gh-732) Better Openstack IP address assignment
```
* Merge pull request #752 from petems/MAINT-fix_install_puppet_from_msi_on_cygwin (1333f9bd)


```
Merge pull request #752 from petems/MAINT-fix_install_puppet_from_msi_on_cygwin

(MAINT) Fix install_puppet_from msi_on non-cygwin
```
* Merge pull request #765 from petems/BKR-113-add_freesbd_vagrant_options (6bec19f7)


```
Merge pull request #765 from petems/BKR-113-add_freesbd_vagrant_options

(BKR-113) Adds FreeBSD Vagrantfile logic
```
* Merge pull request #766 from petems/BKR-113-host_prebuild_steps_for_freebsd (59873206)


```
Merge pull request #766 from petems/BKR-113-host_prebuild_steps_for_freebsd

(BKR-113) Host Prebuilt commands for FreeBSD
```
* Merge pull request #774 from electrical/centos7 (00434a4f)


```
Merge pull request #774 from electrical/centos7

modifications for CentOS-7
```
* Merge pull request #779 from kevpl/bkr150_sut_changename (85e45d64)


```
Merge pull request #779 from kevpl/bkr150_sut_changename

(BKR-150) changed host name to host.log_prefix for extra context in sut.log
```
* Merge pull request #683 from fiddyspence/bug/openstack_multi_host_blurn (57e398a5)


```
Merge pull request #683 from fiddyspence/bug/openstack_multi_host_blurn

(gh-687) [openstack] multi node root user enable
```
* Merge pull request #784 from anodelman/answers (35632798)


```
Merge pull request #784 from anodelman/answers

(BKR-182) Disable check_for_updates by default with beaker
```
* (BKR-182) Disable check_for_updates by default with beaker (75384994)


```
(BKR-182) Disable check_for_updates by default with beaker

- added to version 3.2+
```
* (BKR-150) changed host name to host.log_prefix for extra context in sut.log (7ec8d8e8)

* (BKR-184) generalized repo selection code for install_puppetlabs_dev_repo (b3b519ea)

* (BKR-4) Beaker now dumps re-usable hosts file when SUTs are preserved (03f7262f)

* (BKR-116) modifications for CentOS-7 (1d961ccc)

* (BKR-113) Host Prebuilt commands for FreeBSD (39038ad3)


```
(BKR-113) Host Prebuilt commands for FreeBSD

Since FreeBSD echo is different from Linux-y echo, it's much easier to just use printf and escape the strings using gsub.
```
* (BKR-113) Adds FreeBSD Vagrantfile logic (95429ad7)


```
(BKR-113) Adds FreeBSD Vagrantfile logic

With Vagrant we use rsync for folder sync, as nfs has a character restriction of 88 characters. So depending on the module name and where it's being stored, it can error out:



==> default: Mounting NFS shared folders...
The following SSH command responded with a non-zero exit status.
Vagrant assumes that this means the command failed!

mount -t nfs '10.0.1.1:/Users/petersouter/projects/reallylongpathnameover88characterssothatmountfswillfail12345678910111213141516' '/vagrant'

Stdout from the command:

Stderr from the command:

mount_nfs: 10.0.1.1:/Users/petersouter/projects/reallylongpathnameover88characterssothatmountfswillfail12345678910111213141516: File name too long



Further reading if interested:
http://www.secnetix.de/olli/FreeBSD/mnamelen.hawk
https://bugs.freebsd.org/bugzilla/show_bug.cgi?id=167105
```
* (MAINT) Changes msi install commands ran... (effcde41)


```
(MAINT) Changes msi install commands ran...

When on non-cygwin Windows, use `start` not cmd
```
* (MAINT) Changes msi install commands run when on non-cygwin (89dabc69)

* (gh-732) Better Openstack IP address assignment (e1fcd580)

* (gh-687) [openstack] Previously, the method attemped to set root on all nodes, even if the node was not up yet (802db0e9)

### <a name = "2.9.0">2.9.0 - 9 Apr, 2015 (b161d325)

* (HISTORY) update beaker history for gem release 2.9.0 (b161d325)

* (GEM) update beaker version to 2.9.0 (901c4a94)

* Merge pull request #783 from anodelman/maint (62b5ac60)


```
Merge pull request #783 from anodelman/maint

(BKR-70) Make SshConnection.close more robust...
```
* (BKR-70) Make SshConnection.close more robust... (3bb4f7ca)


```
(BKR-70) Make SshConnection.close more robust...

...(so that on(host, "reboot") works correctly)

- catch IOErrors
- added additional execution option ':expect_connection_failure' for
  operations that you believe should result in the connection to the
  host being dropped or broken
- tested with rebooting centos7 box, successfully rebuilds connection
  and continues test execution
```
* Merge pull request #781 from anodelman/zombie (959952a7)


```
Merge pull request #781 from anodelman/zombie

(BKR-192) can't run beaker without a host file specified
```
* (BKR-192) can't run beaker without a host file specified (5cf28b4c)


```
(BKR-192) can't run beaker without a host file specified

- the hosts file was being defaulted to to provide a log name prefix -
  it needs a default value for when there is no user provided value plus
  no hosts file
```
* Merge pull request #778 from anodelman/maint (e2d23066)


```
Merge pull request #778 from anodelman/maint

(BKR-188) have beaker support a 'test' raketask.
```
* Merge pull request #780 from anodelman/spec-tests (a64a3a10)


```
Merge pull request #780 from anodelman/spec-tests

(BKR-183) simplecov busted in beaker
```
* (BKR-183) simplecov busted in beaker (3ae9cd7f)


```
(BKR-183) simplecov busted in beaker

- accidentally busted when we dropped ruby 1.8 support
- updated to look nice with the current beaker directory structure
- updated env var to meet beaker standards
```
* (BKR-188) have beaker support a 'test' raketask. (93faeffa)


```
(BKR-188) have beaker support a 'test' raketask.

- meets our gem standards
```
* Merge pull request #767 from petems/BKR-113-freebsd_pkg_commands (a18ff029)


```
Merge pull request #767 from petems/BKR-113-freebsd_pkg_commands

(BKR-113) Add pkg commands for FreeBSD
```
* Merge pull request #764 from petems/BKR-113-add_freebsd_host_class (cc6b606e)


```
Merge pull request #764 from petems/BKR-113-add_freebsd_host_class

(BKR-113) Add FreeBSD host class
```
* Merge pull request #768 from anodelman/maint (5a8d8b0c)


```
Merge pull request #768 from anodelman/maint

(QENG-2083) share out beaker's history file generation tool
```
* Merge pull request #770 from madAndroid/BKR-165-hack_etc_hosts_docker (bfd12ca9)


```
Merge pull request #770 from madAndroid/BKR-165-hack_etc_hosts_docker

(BKR-165) hack_etc_hosts method doesn't work for Docker provider
```
* Merge pull request #773 from liamjbennett/install_windows_cert (3aa42917)


```
Merge pull request #773 from liamjbennett/install_windows_cert

(gh-691) Add function to install certs on windows agents
```
* Merge pull request #771 from justinstoller/maint/master/pc1 (8909e35a)


```
Merge pull request #771 from justinstoller/maint/master/pc1

(QENG-2096) Update dev repo for new AIO repo name
```
* Merge pull request #762 from sschneid/bkr-161_tagging (084ee947)


```
Merge pull request #762 from sschneid/bkr-161_tagging

(BKR-161) Beaker tagging improvements
```
* (gh-691) Add function to install certs on windows agents (ccf0bb7e)


```
(gh-691) Add function to install certs on windows agents

This fixes the issue raised in PUP-2365
```
* BKR-165 - Add spec test to check for presence of /etc/hosts for docker provider (d5da2ee2)

* BKR-165 - Amend hack_etc_hosts to set host file entry to host['vm_ip'], if present; add comments to that affect (9c8874b8)

* BKR-165 - add hack_etc_hosts method to beaker hypervisor, and set host['vm_ip'] to correct container IP (b324abe7)

* (QENG-2096) Update dev repo for new AIO repo name (06e3da46)


```
(QENG-2096) Update dev repo for new AIO repo name

Soon AIO builds will only be published to the repo "PC1" (not
products/devel or main as previously). This allows Beaker to install
from both new AIO repos or legacy repos.
```
* (QENG-2083) share out beaker's history file generation tool (afe0d24c)


```
(QENG-2083) share out beaker's history file generation tool

- remove the history file generator used exclusively by beaker in favor of the
  new, general use tool
```
* Merge pull request #763 from mullr/fix-ezbake-package-version (3e2e1e6d)


```
Merge pull request #763 from mullr/fix-ezbake-package-version

Fix ezbake version string extraction
```
* Merge pull request #753 from petems/MAINT-fix_copy_module_to_on_non_cygwin (30a9ee04)


```
Merge pull request #753 from petems/MAINT-fix_copy_module_to_on_non_cygwin

(MAINT) Fix copy module to on non-cygwin
```
* Merge pull request #761 from petems/MAINT-show_error_from_docker (a6198bb4)


```
Merge pull request #761 from petems/MAINT-show_error_from_docker

(MAINT) Show error from docker
```
* (BKR-113) Add pkg commands for FreeBSD (efb39f8e)

* (BKR-113) Add FreeBSD host class (e288f713)


```
(BKR-113) Add FreeBSD host class

* Also add to supported platforms
* Main change is location of Puppet data under `/usr/local/etc` rather than `/etc/`
```
* (BKR-162) Fix ezbake version string extraction (3b1bf59b)


```
(BKR-162) Fix ezbake version string extraction

This previously used 'echo -n', which is not a universally available
feature of echo. When running with an OS X host, this caused the string
to look like "-n PACKAGE-1.2.3\n", which caused cascading failures in
the code that uses this data. printf is a more portable replacement.
```
* (BKR-161) Beaker tagging improvements (da9fe1ed)


```
(BKR-161) Beaker tagging improvements

- Use JOB_NAME for 'project' tag default if it exists
- Set 'beaker_version' tag in vmpooler hypervisor
```
* (MAINT) Updates spec to detect error string (58d7a031)

* (MAINT) Changes error message to help debugging (2d9bc305)


```
(MAINT) Changes error message to help debugging

* Changes the wording to say it was not connectable rather than found
* Adds error string to help debugging the issue
```
* (MAINT) Adds non-cygwin block for copy_module_to (8e5cdd0c)

### <a name = "beaker2.8.0">beaker2.8.0 - 26 Mar, 2015 (2d25d06d)

* (HISTORY) update beaker history for gem release 2.8.0 (2d25d06d)

* (GEM) update beaker version to 2.8.0 (f320c276)

* Merge pull request #759 from sschneid/vmpooler_tagging (97052ab4)


```
Merge pull request #759 from sschneid/vmpooler_tagging

(BKR-155) Add simple tagging to vmpooler hosts
```
* Merge pull request #755 from anodelman/acceptance (0ac1460d)


```
Merge pull request #755 from anodelman/acceptance

(BKR-77) breakup dsl/helpers and dsl/install_utils
```
* Merge pull request #754 from anodelman/win-fix (f426a7cf)


```
Merge pull request #754 from anodelman/win-fix

(BKR-151) periodic failure to restart ssh on windows
```
* Merge pull request #734 from kevpl/bkr5_log_prefix (4aaedb45)


```
Merge pull request #734 from kevpl/bkr5_log_prefix

(BKR-5) added a default log_prefix of the hostfile name, and the --log-p...
```
* Wrap tagging attempt in a begin/rescue/end block (66f4629f)

* Merge pull request #745 from puppetlabs/fix_vagrant_insecure (77c14f7b)


```
Merge pull request #745 from puppetlabs/fix_vagrant_insecure

(BKR-148) Stop vagrant from generating ssh key
```
* Merge pull request #749 from kevpl/bkr79_deprecate_hostproperties (c7a6ef03)


```
Merge pull request #749 from kevpl/bkr79_deprecate_hostproperties

(BKR-79) added deprecated warning to host defaults
```
* Merge pull request #751 from petems/MAINT-fix-non-cygwin-root-enable (47a942ae)


```
Merge pull request #751 from petems/MAINT-fix-non-cygwin-root-enable

(MAINT) Fix enable root login on non-cygwin
```
* (BKR-155) Add simple tagging to vmpooler hosts (90d4e088)

* (BKR-151) periodic failure to restart ssh on windows (beec5281)


```
(BKR-151) periodic failure to restart ssh on windows

- wrap ssh stop/start in a repeat loop
```
* (BKR-77) breakup dsl/helpers and dsl/install_utils (73931bf3)


```
(BKR-77) breakup dsl/helpers and dsl/install_utils

- dsl/helpers.rb and dsl/install_utils.rb have grown too large and no
  longer make sense as discreet units
- divide install_utils into modules with methods associated with
  different applications (pe, puppet, modules)
- divide helpers into modules with methods exercising different areas of
  functionality (facter, hiera, host, puppet, web, trapperkeeper)
- update spec testing stucture to reflect new install_utils/helpers
  stucture
```
* (MAINT) Changes default to show warning (e17321ec)


```
(MAINT) Changes default to show warning

This means that we won't try to run the sed command on Windows boxes if they have false for cygwin
```
* (MAINT) Adds spec for `enable_root_login` method (1f666bef)

* (BKR-79) added deprecated warning to host defaults (f654a4f0)

* (BRK-148) Stop vagrant from generating ssh key (d7470ed9)


```
(BRK-148) Stop vagrant from generating ssh key

Hashicorp added new behavior that generates a new SSH key
when generating a box, and will remove any existing "insecure"
key found on a box. See https://github.com/mitchellh/vagrant/pull/4707

This has the unfortunate side effect of breaking the automation
used in Beaker to setup SSH keys, since it relied on the default
"insecure" vagrant keys being used. Current workaround is to disable
the new Vagrant behavior with a configuration option.
```
* (BKR-5) added a default log_prefix of the hostfile name, and the --log-prefix CLI option (6ce6cbd4)

### <a name = "beaker2.7.1">beaker2.7.1 - 19 Mar, 2015 (45b2bf10)

* (HISTORY) update beaker history for gem release 2.7.1 (45b2bf10)

* (GEM) update beaker version to 2.7.1 (2bf87b79)

* Merge pull request #758 from anodelman/answers (ffbeacf5)


```
Merge pull request #758 from anodelman/answers

(BKR-156) Error generating answer file for Windows agent install
```
* (BKR-156) Error generating answer file for Windows agent install (5f0be5ca)


```
(BKR-156) Error generating answer file for Windows agent install

- was attempting to add answers for a windows host, when we don't pass
  answers to windows hosts
- updated spec test to include a windows style host to confirm that this
  works
```
### <a name = "beaker2.7.0">beaker2.7.0 - 19 Mar, 2015 (38b14ef8)

* (GEM) update beaker version to 2.7.0 (38b14ef8)

* Merge pull request #756 from anodelman/answers (d2c0e2be)


```
Merge pull request #756 from anodelman/answers

(BKR-154) missing q_enable_future_parser in answer file generated...
```
* (BKR-154) missing q_enable_future_parser in answer file generated... (bc7ee68e)


```
(BKR-154) missing q_enable_future_parser in answer file generated...

...by beaker

- add missing answer
- update specs to ensure that 3.8 answers are correctly generated
```
* Merge pull request #750 from MosesMendoza/PE-8260/master/add_38_answer (c3c688e4)


```
Merge pull request #750 from MosesMendoza/PE-8260/master/add_38_answer

(PE-8260) add answer for new NC migrate question
```
* (PE-8260) add answer for new NC migrate question (2b620f64)


```
(PE-8260) add answer for new NC migrate question

This commit adds a 38-specific answer file to beaker, which introduces an
answer for whether to stop the upgrade and proceed to do the NC database
migration. It defaults to 'n' to enable upgrades to continue.

Signed-off-by: Moses Mendoza <moses@puppetlabs.com>
```
* Merge pull request #743 from anodelman/maint (957d763f)


```
Merge pull request #743 from anodelman/maint

(BKR-81) start using new public beaker jira project
```
* Merge pull request #746 from kevpl/bkr6_aio_privatebindirwindows (3ae5a02d)


```
Merge pull request #746 from kevpl/bkr6_aio_privatebindirwindows

(BKR-6) added privatebindir for windows' old PE and FOSS types
```
* Merge pull request #747 from anodelman/gem-source (7204b3da)


```
Merge pull request #747 from anodelman/gem-source

(BKR-60) failures caused by rubygems timeouts
```
* (BKR-60) failures caused by rubygems timeouts (db418b14)


```
(BKR-60) failures caused by rubygems timeouts

- add ability to set GEM_SOURCE to internal rubygems mirror
```
* Merge pull request #744 from anodelman/win-fix (a2ab4bca)


```
Merge pull request #744 from anodelman/win-fix

(BKR-7) beaker's prebuild_steps corrupts PATH on windows+cygwin
```
* (BKR-6) added privatebindir for windows' old PE and FOSS types (f0d8cdf3)

* (BKR-7) beaker's prebuild_steps corrupts PATH on windows+cygwin (003688b8)


```
(BKR-7) beaker's prebuild_steps corrupts PATH on windows+cygwin

- remove un-used RUBYLIB env var
- no dependencies on this anywhere, might as well pull it out
```
* (BKR-7) beaker's prebuild_steps corrupts PATH on windows+cygwin (054f7849)


```
(BKR-7) beaker's prebuild_steps corrupts PATH on windows+cygwin

- use correct path separator for cygwin vs. correct separator for
  non-cygwin windows
```
* (BKR-81) start using new public beaker jira project (a45a045c)


```
(BKR-81) start using new public beaker jira project

- update contributor and readme doc to point to correct ticket tracker
  information
```
### <a name = "beaker2.6.0">beaker2.6.0 - 12 Mar, 2015 (d4e731ab)

* (HISTORY) update beaker history for gem release 2.6.0 (d4e731ab)

* (GEM) update beaker version to 2.6.0 (b63d3d11)

* Merge pull request #741 from anodelman/maint (d797fe23)


```
Merge pull request #741 from anodelman/maint

 (BKR-8) PE 3.8 on Sles11 can't find puppet in path after install...
```
* (BKR-8) PE 3.8 on Sles11 can't find puppet in path after install... (d53d1db9)


```
(BKR-8) PE 3.8 on Sles11 can't find puppet in path after install...

... completes successfully.

- add the ~/.ssh/environment to a /etc/profile.d/beaker_env.sh script
- ensure that beaker_env.sh is kept up to date and correct with state of
  current env
```
* Merge pull request #666 from petems/MAINT-fix_mkdir_bug (9d59deab)


```
Merge pull request #666 from petems/MAINT-fix_mkdir_bug

(MAINT) Fix mkdir bug on PSWindows and fix test
```
* Merge pull request #738 from demophoon/fix/master/qeng-1970-custom-answers-windows-guard (80de6cbe)


```
Merge pull request #738 from demophoon/fix/master/qeng-1970-custom-answers-windows-guard

(QENG-1970) Guard against merging custom answers on Windows
```
* Merge pull request #739 from kevpl/qeng1969_aio_pathsupdate (c066aef1)


```
Merge pull request #739 from kevpl/qeng1969_aio_pathsupdate

(QENG-1969) fixed PE privatebindir default
```
* Merge pull request #730 from anodelman/acceptance (2ba9cd51)


```
Merge pull request #730 from anodelman/acceptance

(QENG-1869) create beaker host.rb acceptance tests
```
* Merge pull request #740 from anodelman/maint (24c90744)


```
Merge pull request #740 from anodelman/maint

(gh-702) sshd restart doesn't work with some el6...
```
* (gh-702) sshd restart doesn't work with some el6... (f3b9035f)


```
(gh-702) sshd restart doesn't work with some el6...

... variants especially centos - with vagrant provisioner

For centos6 & vagrant, this pull fixed it: https://github.com/puppetlabs/beaker/pull/545
& fixing https://github.com/puppetlabs/beaker/issues/656 re-broke it by undoing pull 545

- Instead of service sshd restart, service sshd reload fixes the issue.
  Even systemctl takes reload.
```
* (QENG-1969) fixed PE privatebindir default (768b1ed0)

* (QENG-1970) Guard against merging custom answers on Windows (5c7e31c2)


```
(QENG-1970) Guard against merging custom answers on Windows

Before this commit Beaker would attempt to merge custom answers on
platforms where answers are not used. This commit guards against merging
custom answers unless there are already answers specified.
```
* Merge pull request #736 from kevpl/qeng1946_aio_pathsupdate (7d0cccf2)


```
Merge pull request #736 from kevpl/qeng1946_aio_pathsupdate

(QENG-1946) removed paths from AIO host defaults in windows & unix
```
* Merge pull request #735 from Iristyle/ticket/master/QENG-1955-Windows-File-exist-failures-on-Windows-2003 (a42d8ab5)


```
Merge pull request #735 from Iristyle/ticket/master/QENG-1955-Windows-File-exist-failures-on-Windows-2003

(QENG-1955) Windows::File.file_exist? fails on 2003
```
* (QENG-1955) Windows::File.file_exist? fails on 2003 (f21d2226)


```
(QENG-1955) Windows::File.file_exist? fails on 2003

 - In 9c32cac7a7a5bf52f21b628b14ddba9bfc44510c a change was
   introduced to add a new Windows::File.file_exist? method
   that relied on using test -e.  The code assumes that the
   path does not contain spaces and does not need to be
   quoted.

   Unfortunately, this assumption is incorrect and causes
   pre-suites to fail because this test is performed on
   Puppets :vardir.  On Windows, Puppets :vardir is always
   rooted at %ALLUSERSPROFILE%\PuppetLabs

   When running on Windows 2008 or higher, the
   %ALLUSERSPROFILE% directory is C:\ProgramData\

   However, on Windows 2003, the path structure is different
   and that directory is located at
   C:\Documents and Settings\All Users\Application Data

   With an unquoted path passed to test -e a failure is
   generated, which breaks Windows pre-suites on 2003.
```
* (QENG-1946) removed paths from AIO host defaults in windows & unix (0b7afd49)

* Merge pull request #729 from sschneid/rename_vcloudpooled_vmpooler (6cd29bbf)


```
Merge pull request #729 from sschneid/rename_vcloudpooled_vmpooler

(maint) VcloudPooled -> Vmpooler
```
* (maint) VcloudPooled -> Vmpooler (e1723437)


```
(maint) VcloudPooled -> Vmpooler

This PR renames the 'VcloudPooled' hypervisor to 'Vmpooler', and
includes a few fixups as ride-alongs:

  - resourcepool, folder, datastore not needed for Vmpooler
  - small syntax/wording changes
```
* (QENG-1869) create beaker host.rb acceptance tests (3474a114)


```
(QENG-1869) create beaker host.rb acceptance tests

- tests that exercise basic host.rb functionality
```
* (MAINT) Fixing mkdir_p POSH command (f57354de)


```
(MAINT) Fixing mkdir_p POSH command

Test was set to test for the wrong command:


ruby
.with("if not exist test\\test\\test (md )")



So the directory would never get made, as the `md` bit was empty. Fixed spec and code to create command
```
### <a name = "beaker2.5.1">beaker2.5.1 - 4 Mar, 2015 (009c2c63)

* (HISTORY) update beaker history for gem release 2.5.1 (009c2c63)

* (GEM) update beaker version to 2.5.1 (958ab02d)

* Merge pull request #719 from kevpl/qeng1841_aio_pathsupdate (c6a15c8f)


```
Merge pull request #719 from kevpl/qeng1841_aio_pathsupdate

(QENG-1841) updated AIO pathing for linux & windows
```
* Merge pull request #726 from anodelman/maint (a23acbf2)


```
Merge pull request #726 from anodelman/maint

(maint) Upgrade google-api-client dependency to fix Ruby 1.9.x...
```
* (maint) Upgrade google-api-client dependency to fix Ruby 1.9.x... (d5301654)


```
(maint) Upgrade google-api-client dependency to fix Ruby 1.9.x...

- compatibility

- for puppetdb project:

"
Retriable was upgraded today (Jan 30th) and they shipped a version 2.0.0
that
requires Ruby >=2.0.0.

In google-api-client 0.7.1, we were pulling in version >= 1.4 of
retriable. In 0.8.2
they have a fix that pulls in ~> 1.4 version of retriable, thus pinning
the ceiling
on the upgrade to retriable 2.0.0.
"
```
* Merge pull request #626 from carlossg/ssh-restart (31bc7aa4)


```
Merge pull request #626 from carlossg/ssh-restart

[docker] No need to restart sshd
```
* Merge pull request #721 from kevpl/qeng1913_aio_pullback (69130a54)


```
Merge pull request #721 from kevpl/qeng1913_aio_pullback

(QENG-1913) rolling back the name change for pe-puppet that was made for AIO
```
* Merge pull request #722 from puppetlabs/revert-715-acceptance (fdf906b8)


```
Merge pull request #722 from puppetlabs/revert-715-acceptance

Revert "(QENG-1869) create beaker host.rb acceptance tests"
```
* Revert "(QENG-1869) create beaker host.rb acceptance tests" (d7e2c7c3)

* (QENG-1913) rolling back the name change for pe-puppet that was made for AIO (d68fe7d7)

* Merge pull request #716 from anodelman/maint (6e420185)


```
Merge pull request #716 from anodelman/maint

(QENG-1681) upgrade_pe method is generating errors when attempted...
```
* (QENG-1841) updated AIO pathing for linux & windows (fdfa69be)

* Merge pull request #715 from anodelman/acceptance (c6c377c8)


```
Merge pull request #715 from anodelman/acceptance

(QENG-1869) create beaker host.rb acceptance tests
```
* Merge pull request #714 from kevpl/qeng1721_aio_windowsinstall (14f2239d)


```
Merge pull request #714 from kevpl/qeng1721_aio_windowsinstall

(QENG-1721) added installation support of dev versions of windows puppet...
```
* (QENG-1681) upgrade_pe method is generating errors when attempted... (ae0d7333)


```
(QENG-1681) upgrade_pe method is generating errors when attempted...

...on PE 3.7.0 and later

- do pe version comparison in the upgrader method, not the answer file
  generator
- use proper semvar dot comparison of versions, not just string compare
- handle not knowing what the pe_ver is currently installed
- unrelated nit: remove duplicate key entries in answer file generation
```
* Merge pull request #647 from mcanevet/feature/openstack/generate_key_pair (32e123e9)


```
Merge pull request #647 from mcanevet/feature/openstack/generate_key_pair

(gh-646) Create random keypair
```
* Merge pull request #699 from kevpl/qeng1429_should_fail_not_error (b757a552)


```
Merge pull request #699 from kevpl/qeng1429_should_fail_not_error

(QENG-1429) added clause to catch Beaker & Minitest assertions
```
* Merge pull request #708 from kevpl/qeng1847_aio_hostparams (a321d264)


```
Merge pull request #708 from kevpl/qeng1847_aio_hostparams

(QENG-1847) changed internal host path attribute usage to host.puppet me...
```
* Merge pull request #686 from mcanevet/fix/openstack/use_openstack_tenant (0aa7d5e6)


```
Merge pull request #686 from mcanevet/fix/openstack/use_openstack_tenant

(gh-685) Add openstack_tenant to network_client init
```
* Merge pull request #697 from anodelman/cygwin-less (ebda7a6d)


```
Merge pull request #697 from anodelman/cygwin-less

(QENG-1735) set up local windows vm without cygwin and get it working
```
* (QENG-1721) added installation support of dev versions of windows puppet-agent (45f92543)

* Merge pull request #670 from petems/MAINT-ps_windows_reindent (1f3034c5)


```
Merge pull request #670 from petems/MAINT-ps_windows_reindent

(MAINT) Fix indentation
```
* Merge pull request #711 from jonnytpuppet/rsync_support (27672383)


```
Merge pull request #711 from jonnytpuppet/rsync_support

Added support for rsync
```
* Merge pull request #713 from anodelman/maint (539f176d)


```
Merge pull request #713 from anodelman/maint

(MAINT) fix broken spec tests
```
* (MAINT) fix broken spec tests (76e06a75)


```
(MAINT) fix broken spec tests

- accidental breakage of spec tests
- also removed deprecated rspec method call
```
* Merge pull request #634 from liamjbennett/puppet_conf (baeee93d)


```
Merge pull request #634 from liamjbennett/puppet_conf

(gh-474) Adding a utility method for puppet.conf file
```
* Merge pull request #689 from liamjbennett/powershell_fix (854d0aa0)


```
Merge pull request #689 from liamjbennett/powershell_fix

(gh-688) Fixing the powershell wrapper to use an array of arguments
```
* QENG-1878 Added support for rsync (d2076dec)

* (QENG-1869) create beaker host.rb acceptance tests (e4c0fcf9)


```
(QENG-1869) create beaker host.rb acceptance tests

- tests that exercise basic host.rb functionality
```
* (QENG-1847) changed internal host path attribute usage to host.puppet method calls where possible (0179294e)

* (QENG-1380) design beaker DSL based acceptance tests (8341e56d)


```
(QENG-1380) design beaker DSL based acceptance tests

- initial directory hierarchy for beaker acceptance testing
```
* (QENG-1429) added clause to catch Beaker & Minitest assertions (d91692dd)

* (gh-688) Fixing the powershell wrapper to use an array of arguments (b5ebc137)

* (gh-685) Add openstack_tenant to network_client init (58c6eca1)

* (MAINT) Fix indentation (62c23595)

* (QENG-1735) set up local windows vm without cygwin and get it working (9c32cac7)


```
(QENG-1735) set up local windows vm without cygwin and get it working

- ensure that you can install PE
- deal with setting PATH/RUBY env vars
- update DSL methods to work on windows without bash
```
* (gh-646) Create random keypair (7b660047)

* (gh-474) Adding a utility method for puppet.conf file (8965fec0)

* (gh-626) [docker] Ensure that the ssh server can be restarted and container keeps running (85123f12)


```
(gh-626) [docker] Ensure that the ssh server can be restarted and container keeps running

If the sshd process dies then the container stops
Allow configuring the execution or not of set_env
Fix #611
```
### <a name = "beaker2.5.0">beaker2.5.0 - 23 Feb, 2015 (c421cf95)

* (HISTORY) update beaker history for gem release 2.5.0 (c421cf95)

* (GEM) update beaker version to 2.5.0 (9ad8bd4c)

* Merge pull request #701 from anodelman/win-fix (de652599)


```
Merge pull request #701 from anodelman/win-fix

(QENG-1852) install_puppet unable to install windows msi (regression)
```
* Merge pull request #677 from kevpl/qeng1721_aio_windowsadd (566600ba)


```
Merge pull request #677 from kevpl/qeng1721_aio_windowsadd

qeng1721: added AIO windows support
```
* Merge pull request #695 from liamjbennett/vagrant_windows_fix (a7a85f72)


```
Merge pull request #695 from liamjbennett/vagrant_windows_fix

(MAINT) Rolling back change for windows in the vagrant hypervisor
```
* Merge pull request #706 from madAndroid/GH-700-add-docker-options (8e0a7e7d)


```
Merge pull request #706 from madAndroid/GH-700-add-docker-options

GH-700 - Allow Docker::options to be set from config hash
```
* Merge pull request #709 from kevpl/qeng1868_3.8_answers (cd980c9e)


```
Merge pull request #709 from kevpl/qeng1868_3.8_answers

(QENG-1868) added 3.8 answers file, based on 3.7
```
* (QENG-1868) added 3.8 answers file, based on 3.7 (5ee004d4)

* Merge pull request #707 from johnduarte/QENG-1867 (badb17a0)


```
Merge pull request #707 from johnduarte/QENG-1867

(QENG-1867) Add ETIMEDOUT rescue to host.rb
```
* (QENG-1867) Add ETIMEDOUT rescue to host.rb (e7a2ed2d)


```
(QENG-1867) Add ETIMEDOUT rescue to host.rb

This commit adds `Errno::ETIMEDOUT` to the rescue logic of the
port_open? method in lib/beaker/host.rb.

Adding this this rescue prevents the ETIMEDOUT error from short circuiting of
the logical intention of the port_open? method.
```
* GH-700 - amend merge as per suggestion in #706 (6d56290a)

* GH-700 - amend comments to be more appropriate (02591293)

* GH-700 - handle the use case where ::Docker.options is nil (81836988)

* Merge pull request #703 from sschneid/pooling_api_syntax_fixup (041f04ad)


```
Merge pull request #703 from sschneid/pooling_api_syntax_fixup

(MAINT) use implicit trailing '/' for pooling_api URI
```
* (MAINT) use implicit trailing '/' for pooling_api URI (4d2e6f32)

* (QENG-1852) install_puppet unable to install windows msi (regression) (76aba308)


```
(QENG-1852) install_puppet unable to install windows msi (regression)

- busted curl command on windows
- busted msiexec command for installation
- i cry myself to sleep every night
```
* Merge pull request #698 from sschneid/batch_vm_checkout (b8a64f74)


```
Merge pull request #698 from sschneid/batch_vm_checkout

(QENG-780) request sets of VMs instead of one VM at a time
```
* GH-700 - set ::Docker.options from docker_options in options hash, if it's not set via ::Docker.options already (7db8b636)

* (QENG-780) Updating MockNet::HTTP::Post methods (72a07bd2)

* (QENG-780) request sets of VMs instead of one VM at a time (9e82d9b6)


```
(QENG-780) request sets of VMs instead of one VM at a time

This PR facilitates use of vmpooler's batch-request POST API
(https://github.com/puppetlabs/vmpooler#post-vm) within beaker.
```
* Merge pull request #696 from kevpl/qeng1721_aio_quickadd (831a6c4e)


```
Merge pull request #696 from kevpl/qeng1721_aio_quickadd

(QENG-1721) added a quick AIO override for windows to unblock testing
```
* (QENG-1721) added a quick AIO override for windows to unblock testing (ba6ba605)

* (MAINT) Rolling back change for windows in the vagrant hypervisor (16741375)


```
(MAINT) Rolling back change for windows in the vagrant hypervisor

Rolling back the change made in bf353c1 as it is no longer required.

The subsequent change in 3aa080c for vagrant 1.7 properly fixed the issue
and so the work around can now be removed.
```
* qeng1721: added AIO windows support (6f8deb7d)

### <a name = "beaker2.4.1">beaker2.4.1 - 13 Feb, 2015 (84400ed1)

* (HISTORY) update beaker history for gem release 2.4.1 (84400ed1)

* (GEM) update beaker version to 2.4.1 (c3cffad8)

* Merge pull request #684 from anodelman/maint (7ff40a47)


```
Merge pull request #684 from anodelman/maint

(QENG-1834) Regression in Beaker 2.4.0 using do_scp_to
```
* (QENG-1834) Regression in Beaker 2.4.0 using do_scp_to (2b8b6f74)


```
(QENG-1834) Regression in Beaker 2.4.0 using do_scp_to

- repair bug and add spec test coverage
```
### <a name = "beaker2.4.0">beaker2.4.0 - 13 Feb, 2015 (bc5a6676)

* (HISTORY) update beaker history for gem release 2.4.0 (bc5a6676)

* (GEM) update beaker version to 2.4.0 (75d618b8)

* Merge pull request #678 from joshcooper/ticket/master/QENG-1812-print-ssh-environment (473f394e)


```
Merge pull request #678 from joshcooper/ticket/master/QENG-1812-print-ssh-environment

(QENG-1812) Print beaker ssh environment
```
* Merge pull request #679 from joshcooper/ticket/master/QENG-1813-puppet-server-aio-paths (aeecafdf)


```
Merge pull request #679 from joshcooper/ticket/master/QENG-1813-puppet-server-aio-paths

(QENG-1813) Use puppet-server service names
```
* (QENG-1813) Use puppet-server service names (4d63f00a)


```
(QENG-1813) Use puppet-server service names

Previously, when executing AIO acceptance tests, the beaker method
`with_puppet_running_on` would attempt to start and stop the
`puppetmaster` service. This is because the AIO defaults for
`puppetservice` and related conf.d were not specified, and would
fallback to the FOSS defaults.

This commit updates the AIO defaults to match the `puppetserver`
service, and related conf.d.
```
* (QENG-1812) Print beaker ssh environment (dcfd31d6)


```
(QENG-1812) Print beaker ssh environment

Beaker sets the PATH and RUBYLIB environment variables in
~/.ssh/environment, but it was previously difficult to tell what the end
result was.

This commit cats the ~/.ssh/environment file so we know what the PATH
and RUBYLIB environment variables are for the current SSH session.
```
* Merge pull request #676 from kevpl/qeng1809_aio_removemasterreset (ad6bc3b2)


```
Merge pull request #676 from kevpl/qeng1809_aio_removemasterreset

(QENG-1809) removed master path resets for AIO test setups
```
* (QENG-1809) removed master path resets for AIO test setups (8cc03799)


```
(QENG-1809) removed master path resets for AIO test setups

Originally, I had assumed that machines with the master role would keep their old paths, or be updated
with a completely new set.  It looks like the master pathing will actually be based upon the agent though,
since masters will be installed on top of agents now
```
* Merge pull request #669 from anodelman/answers (af4bb88c)


```
Merge pull request #669 from anodelman/answers

(QENG-1734) PE 4.0.x/shallow-gravy answers file
```
* Merge pull request #598 from nrvale0/ignore_bundle_dir (b7612cf3)


```
Merge pull request #598 from nrvale0/ignore_bundle_dir

(MAINT) also ignore the 'bundle' directory
```
* Merge pull request #672 from kevpl/qeng1795_aio_fixotherpaths (ae5f0ea2)


```
Merge pull request #672 from kevpl/qeng1795_aio_fixotherpaths

(QENG-1795) added code & conf paths to non-unix hosts
```
* Merge pull request #674 from joshcooper/maint/aio_windows (cd73846e)


```
Merge pull request #674 from joshcooper/maint/aio_windows

(maint) Add ruby to windows PATH
```
* (MAINT) also ignore the 'bundle' directory #598 (4d0aedb0)

* (maint) Add ruby to windows PATH (21484320)


```
(maint) Add ruby to windows PATH

Previously, beaker would add `puppetbindir` to the `~/.ssh/environment`,
which on Windows, excluded the ruby that the MSI installs. As a result,
puppet setup steps that rely on `gem`, e.g. when adding sources, would
fail.

This commit adds the ruby in the MSI to the `~/.ssh/environment` simply by
it being included in `puppetbindir`. Note the actual location depends on
whether we are installing x86 puppet on x64 windows, or not, so we
include both possibilities like we do for puppet's main bin directory.
```
* Merge pull request #673 from kevpl/maint_windows_fixtypo (2fd6d969)


```
Merge pull request #673 from kevpl/maint_windows_fixtypo

(MAINT) fixing windows cygwin check typo
```
* (MAINT) fixing windows cygwin check typo (de4612fb)

* (QENG-1795) added code & conf paths to non-unix hosts (198bebb4)

* Merge pull request #668 from kevpl/qeng1781_aio_pathupdate (1d89f2c8)


```
Merge pull request #668 from kevpl/qeng1781_aio_pathupdate

(QENG-1781) updated unix path entries for AIO
```
* Merge pull request #671 from puppetlabs/revert-667-qeng1784_foss_grouproot (2e890309)


```
Merge pull request #671 from puppetlabs/revert-667-qeng1784_foss_grouproot

Revert "(QENG-1784) updated FOSS group to be root instead of puppet"
```
* Merge pull request #663 from kbarber/pdb-1034-ezbake-pr-testing (34e5a230)


```
Merge pull request #663 from kbarber/pdb-1034-ezbake-pr-testing

(PDB-1034) Ezbake changes to get PDB source based builds working
```
* Revert "(QENG-1784) updated FOSS group to be root instead of puppet" (e887ef4a)

* Merge pull request #624 from kevpl/qeng1410_log_provisioningadd (e2c5df0c)


```
Merge pull request #624 from kevpl/qeng1410_log_provisioningadd

(QENG-1410) implemented provisioning log
```
* (QENG-1781) updated unix path entries for AIO (7f55277a)

* Merge pull request #667 from kevpl/qeng1784_foss_grouproot (b68442f7)


```
Merge pull request #667 from kevpl/qeng1784_foss_grouproot

(QENG-1784) updated FOSS group to be root instead of puppet
```
* (QENG-1784) updated FOSS group to be root instead of puppet (8a4adfbd)

* (QENG-1734) PE 4.0.x/shallow-gravy answers file (27449e22)


```
(QENG-1734) PE 4.0.x/shallow-gravy answers file

- add 4.0/3.99 answer generation support
```
* Merge pull request #665 from doug-rosser/el7_hostname_fix (d029c7a0)


```
Merge pull request #665 from doug-rosser/el7_hostname_fix

(QENG-1757) use a different command to set the hostname for AWS el-7 ins...
```
* (QENG-1757) use a different command to set the hostname for AWS el-7 instances (5dcc75a7)

* Merge pull request #613 from petems/improve_error_message_when_docker_not_found (abc7becd)


```
Merge pull request #613 from petems/improve_error_message_when_docker_not_found

(MAINT) Improve error message when docker not found
```
* Merge pull request #664 from dsbaars/vagrant_parallels_hypervisor (55fc8376)


```
Merge pull request #664 from dsbaars/vagrant_parallels_hypervisor

Added Vagrant Parallels Hypervisor
```
* Merge pull request #635 from liamjbennett/bitvise_communicator (a420cdac)


```
Merge pull request #635 from liamjbennett/bitvise_communicator

(gh-433) Adding support to use bitvise ssh server as an alternative ssh provider
```
* Merge pull request #651 from puppetlabs/MAINT-fix_vagrantfile_syntax_error (91723d68)


```
Merge pull request #651 from puppetlabs/MAINT-fix_vagrantfile_syntax_error

(MAINT) Fix Vagrantfile syntax error
```
* Merge pull request #643 from mcanevet/feature/openstack/credentials_from_env (89c46146)


```
Merge pull request #643 from mcanevet/feature/openstack/credentials_from_env

(gh-642) Lookup Openstack credentials from ENV
```
* Merge pull request #655 from anodelman/assertions (8f26cb82)


```
Merge pull request #655 from anodelman/assertions

(QENG-1629) Add expect_failure() to Beaker DSL (the code is provided)
```
* (gh-664) Fix and better test (6a9474f1)

* Added Vagrant Parallels Hypervisor (7d1a25a8)

* Merge pull request #659 from er0ck/QENG-1758-beaker_bash_completion_script_should_not_prevent_filename_completion (8382ed98)


```
Merge pull request #659 from er0ck/QENG-1758-beaker_bash_completion_script_should_not_prevent_filename_completion

(QENG-1758) beaker bash completion script should not prevent filename co...
```
* Merge pull request #661 from johnduarte/aio-default-paths (76427fbd)


```
Merge pull request #661 from johnduarte/aio-default-paths

(gh-660) Update default aio puppetpath path for unix
```
* (gh-660) Update default aio puppetpath path for unix (30c30d3e)


```
(gh-660) Update default aio puppetpath path for unix

This commit updates the default aio puppetpath to /etc/puppetlabs/agent
```
* (QENG-1758) beaker bash completion script should not prevent filename completion (293a6a82)


```
(QENG-1758) beaker bash completion script should not prevent filename completion

This change specifies -o default to use the default completion method
when a completion is not found with this script. This allows completion
of filenames as well as beaker's options.
```
* (QENG-1629) Add expect_failure() to Beaker DSL (the code is provided) (1a14e50c)


```
(QENG-1629) Add expect_failure() to Beaker DSL (the code is provided)

- add expect_failure method
- add expect_failure spec tests
```
* (QENG-1410) implemented feedback from PR (f004e7b2)

* (MAINT) Fix Vagrantfile syntax error (86fe7731)


```
(MAINT) Fix Vagrantfile syntax error

Missed new line:



/Users/petersouter/projects/puppet-chocolatey/.vagrant/beaker_vagrant_files/default.yml/Vagrantfile:9: syntax error, unexpected tIDENTIFIER, expecting keyword_end
    v.vm.guest = :windows    v.vm.provider :virtualbox do |vb|


```
* (gh-642) Lookup Openstack credentials from ENV (d550bd08)

* (gh-433) Adding support to use bitvise ssh server as an alternative ssh provider (f551c0ad)

* (MAINT) Adds spec for `validate_version!` (25909d02)

* (MAINT) Catch error when cant connect to docker (12a952c2)


```
(MAINT) Catch error when cant connect to docker

Right now, if you try to run a beaker test with the docker hypervisor and Docker is not running, you get a big stack trace:



Hypervisor for debian-7 is docker
Beaker::Hypervisor, found some docker boxes to create
/opt/rubies/2.0.0-p451/lib/ruby/gems/2.0.0/gems/excon-0.43.0/lib/excon/unix_socket.rb:14:in `connect_nonblock': No such file or directory - connect(2) (Errno::ENOENT) (Excon::Errors::SocketError)
	from /opt/rubies/2.0.0-p451/lib/ruby/gems/2.0.0/gems/excon-0.43.0/lib/excon/unix_socket.rb:14:in `connect'
	from /opt/rubies/2.0.0-p451/lib/ruby/gems/2.0.0/gems/excon-0.43.0/lib/excon/socket.rb:28:in `initialize'



This improves the message a bit
```
* (QENG-1410) implemented provisioning log (0a478adb)

* (PDB-1034) Ezbake changes to get PDB source based builds working (32af120c)


```
(PDB-1034) Ezbake changes to get PDB source based builds working

This involves a rework of the ezbake_utils to provide more capability to fully
install PuppetDB using these helpers.

* Some of the original API has been simplified, and the YAGNI parts removed
  since no one was using them today.
* We now do the lein install process, but using a local maven repository to
  avoid collision with other projects running on the same host.
* install_termini_from_ezbake now added to install that component
* I've switched to using the install.sh methodology on ezbake.
* This now is compatible with lein-ezbake.
* ezbake_local_cmd has been added to generalize this kind of system invocation
  and simplify testing.
* ezbake_installsh generalizes the way we invoke install.sh, and simplifies testing.
* install_ezbake_tarball_on_host has been created to generalize this step for
  the termini and service based installations to re-use. Its idempotent, in
  that it checks to ensure its not already installed.
* conditionally_clone was modified to support being passed a branch if required,
  so in the future we can simplify working on a development branch.
* Lots of yarddoc cleanups
* Some rspec coverage

Signed-off-by: Ken Barber <ken@bob.sh>
```
### <a name = "beaker2.3.0">beaker2.3.0 - 29 Jan, 2015 (3d185da0)

* (HISTORY) update beaker history for gem release 2.3.0 (3d185da0)

* (GEM) update beaker version to 2.3.0 (41028a79)

* Merge pull request #644 from electrical/hiera_config (420b01f2)


```
Merge pull request #644 from electrical/hiera_config

Add helper function to write hiera.yaml file
```
* Merge pull request #631 from mcanevet/feature/no_sync_folder (2920fe63)


```
Merge pull request #631 from mcanevet/feature/no_sync_folder

(GH-630) Add synced_folder option
```
* Merge pull request #645 from kevpl/qeng1714_aio_masterrolepaths (b825c65a)


```
Merge pull request #645 from kevpl/qeng1714_aio_masterrolepaths

(QENG-1714) fixed get_type for a machine with only non-agent roles
```
* (QENG-1714) fixed non-agent AIO path issue (eacd3d31)

* Merge pull request #657 from mcanevet/fix/el (25296221)


```
Merge pull request #657 from mcanevet/fix/el

(gh-656) fix "sudo: sorry, you must have a tty to run sudo"
```
* (gh-656) fix "sudo: sorry, you must have a tty to run sudo" (0cde5cc7)

* Merge pull request #649 from branan/maint (60993e0c)


```
Merge pull request #649 from branan/maint

(maint) Fix options access in PE 3.7 answers gen on upgrades
```
* (maint) Fix options access in PE 3.7 answers gen on upgrades (673015be)

* Merge pull request #638 from kevpl/qeng1690_aio_installpackages (c9535a35)


```
Merge pull request #638 from kevpl/qeng1690_aio_installpackages

(QENG-1690) added in helper installation method for packages
```
* Add helper functions to manage hiera config and data files (c464f5f6)


```
Add helper functions to manage hiera config and data files

- Added helper functions to manage hiera.yaml config file.
- Added helper functions to copy over hiera data files.
```
* Merge pull request #640 from petems/QENG-1695-improve_osx_support (5b050f6c)


```
Merge pull request #640 from petems/QENG-1695-improve_osx_support

(QENG-1695) Improves OSX Support
```
* (QENG-1690) added in helper installation method for packages (bba212cf)


```
(QENG-1690) added in helper installation method for packages

I had misunderstood the install_puppetlabs_dev_repo method before, thinking that it would install packages
from within the dev repo, but it's actually just installing the dev repo itself.  These changes add a
corresponding installation method to install the packages found in these repos after they've been installed
```
* (QENG-1695) Improves OSX Support (9f78eeed)


```
(QENG-1695) Improves OSX Support

* Fixes for root key location copy
* Adds a Vagrant VB OSX option
* Fixes PermitRootLogin regex
* Adds option to enable GUI
* Raises error if version not given for DMG

Now works with an example OSX Virtualbox image :+1:
```
* Merge pull request #621 from stefanmortensen/fix_root_login (a5d4d9b4)


```
Merge pull request #621 from stefanmortensen/fix_root_login

(gh-620) Enable root if user is not root for the OpenStack hypervisor
```
* Merge pull request #622 from doug-rosser/volume_size (76b8def6)


```
Merge pull request #622 from doug-rosser/volume_size

(QENG-1676) Enable root volume size changes with volume_size in the config file
```
* Merge pull request #564 from mcanevet/fix/openstack_hypervisor (7c1c52b1)


```
Merge pull request #564 from mcanevet/fix/openstack_hypervisor

(GH-632) Fix Network creation
```
* Merge pull request #636 from branan/lol_old_el (e7545fa0)


```
Merge pull request #636 from branan/lol_old_el

(QENG-1684) Allow exit code of '1' when stopping puppet agent on centos4
```
* (QENG-1684) Allow exit code of '1' when stopping puppet agent on centos4 (589ea1e1)


```
(QENG-1684) Allow exit code of '1' when stopping puppet agent on centos4

When upgrading, the agent service is already stopped. On Centos4, this
causes a failure from the init script. We want to ignore that failure.
```
* (GH-630) Add synced_folder option (619ead3d)

* Merge pull request #597 from kevpl/qeng144_masterless_supportadd (7c88b74a)


```
Merge pull request #597 from kevpl/qeng144_masterless_supportadd

(QENG-144) created masterless option, and support for masterless installs
```
* (QENG-1676) Enable root volume size changes with volume_size in the config file (f62ba27d)

* Merge pull request #614 from anodelman/aws (981ab44d)


```
Merge pull request #614 from anodelman/aws

(QENG-1662) beaker smoketests failing on ec2 with security group error
```
* (gh-620) Enable root if user is not root for the OpenStack hypervisor (3062d505)

* (QENG-1662) beaker smoketests failing on ec2 with security group error (9948ff49)


```
(QENG-1662) beaker smoketests failing on ec2 with security group error

- ensure when looking for an appropriate security group that you are
  looking in a) the provided vpc, b) in the default vpc or c) the
  appropriate region if no default vpc is defined - do not allow
  a mix of vpcs.
```
* Merge pull request #602 from er0ck/feature/master/QENG-1628-add_bash_completion_scripts_for_beaker (1d6c9437)


```
Merge pull request #602 from er0ck/feature/master/QENG-1628-add_bash_completion_scripts_for_beaker

(QENG-1628) Add bash completion scripts for beaker
```
* Merge pull request #604 from kevpl/qeng1631_eos_successfail (d93961d8)


```
Merge pull request #604 from kevpl/qeng1631_eos_successfail

(QENG-1631) allowed exit code 0 for puppet agent call for EOS during install
```
* Merge pull request #610 from electrical/vagrant_stderr (1c2e33d4)


```
Merge pull request #610 from electrical/vagrant_stderr

Add stderr output to stacktrace
```
* (QENG-1631) allowed exit code 0 for puppet agent call for EOS during install (8b466d81)

* (MAINT) Add stderr output to stacktrace (f43a94c4)

* (QENG-1628) Add bash completion scripts for beaker (a71896b4)


```
(QENG-1628) Add bash completion scripts for beaker

using this script, one can press tab after any portion (or none)
of a beaker option/command and bash will complete it or offer
suggestions.
```
* (QENG-144) created masterless option, and support for masterless installs (57391c27)

* (GH-632) Fix Network creation (3ffff71e)

### <a name = "beaker2.2.0">beaker2.2.0 - 8 Jan, 2015 (cba5f7ed)

* (HISTORY) update beaker history for gem release 2.2.0 (cba5f7ed)

* (GEM) update beaker version to 2.2.0 (4dde5f3a)

* Merge pull request #608 from chris-reeves/gh503_scp_to_dirs (1c6624bd)


```
Merge pull request #608 from chris-reeves/gh503_scp_to_dirs

(gh-503) (QENG-1485) Fix recursive copying in do_scp_to
```
* Merge pull request #603 from kevpl/qeng1562_aio_supportadd (5e3e59aa)


```
Merge pull request #603 from kevpl/qeng1562_aio_supportadd

(QENG-1562) added AIO installation support for yum/apt on FOSS
```
* Merge pull request #557 from kevpl/qeng1538_eos_fixhack (6776472e)


```
Merge pull request #557 from kevpl/qeng1538_eos_fixhack

(QENG-1538) fixes EOS hack
```
* Add expectations to spec tests for do_scp_to (abb53aa2)


```
Add expectations to spec tests for do_scp_to

Some tests which are supposed to test whether files and directories are
excluded from copies were only testing that non-excluded files *were* copied,
and didn't test that excluded files *weren't* copied. This commit explicitly
tests that excluded files are not copied.
```
* (gh-503) Update spec tests for do_scp_to (467f62a7)


```
(gh-503) Update spec tests for do_scp_to

Update spec tests following fix for recursive copying in do_scp_to
```
* (gh-503) Fix recursive copying in do_scp_to (b4fb0e66)


```
(gh-503) Fix recursive copying in do_scp_to

Because of the functionality within do_scp_to which allows certain files and
directories to be ignored when copying, each specific file/directory is copied
individually. In the existing code the source and target paths are effectively
the same, causing directories to be copied as subdirectories of themselves.
This commit ensures that all files and directories are copied to their parent
directories.
```
* Merge pull request #606 from kevpl/maint_prebuiltspec_fix (74e7ffb5)


```
Merge pull request #606 from kevpl/maint_prebuiltspec_fix

(MAINT) fixed broken host_prebuilt_steps spec tests
```
* Merge pull request #607 from anodelman/maint (6fc8b78d)


```
Merge pull request #607 from anodelman/maint

(QENG-1641) jenkins beaker spec testing reporting green on failure
```
* (QENG-1641) jenkins beaker spec testing reporting green on failure (ad97e32d)


```
(QENG-1641) jenkins beaker spec testing reporting green on failure

- fix Rakefile to report correct exit code
```
* Merge pull request #588 from madAndroid/enable_ssh_agent_forwarding_docker_and_vagrant (2146bb6d)


```
Merge pull request #588 from madAndroid/enable_ssh_agent_forwarding_docker_and_vagrant

(GH-587) SSH agent forwarding for Docker and Vagrant
```
* (MAINT) fixed broken host_prebuilt_steps spec tests (73a3a153)

* Merge pull request #605 from anodelman/aws (406d09ce)


```
Merge pull request #605 from anodelman/aws

(OPS-5099) [aws] -help with disappearing EBS volumes
```
* (OPS-5099) [aws] -help with disappearing EBS volumes (34c91223)


```
(OPS-5099) [aws] -help with disappearing EBS volumes

- no longer kill all orphan volumes when zombie hunting
```
* Merge pull request #599 from kevpl/qeng1605_configure_option (b78580a7)


```
Merge pull request #599 from kevpl/qeng1605_configure_option

(QENG-1605) added --no-configure option to skip configuration if needed
```
* Merge pull request #596 from nrvale0/fix_ssh_setup (3dd3da76)


```
Merge pull request #596 from nrvale0/fix_ssh_setup

Fix ssh setup
```
* Merge pull request #600 from kbarber/ticket/master/qeng-1594-correct-carriage-return-placement (4d99b0c0)


```
Merge pull request #600 from kbarber/ticket/master/qeng-1594-correct-carriage-return-placement

(QENG-1594) Prefix carriage returns during sshd_config append
```
* Merge pull request #601 from kevpl/qeng1627_spec_add (b8401e7f)


```
Merge pull request #601 from kevpl/qeng1627_spec_add

(QENG-1627) added spec tests to flush out host and ssh_connection testin...
```
* (QENG-1627) added spec tests to flush out host and ssh_connection testing (eab653a5)

* (QENG-1594) Prefix carriage returns during sshd_config append (52855b5f)


```
(QENG-1594) Prefix carriage returns during sshd_config append

The original fix: f2c1b1efd4d36575032294d504b15c56e3cda4e7 was appending
carriage returns instead of prefixing them. This patch corrects the order,
so QENG-1594 can be closed again.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Merge pull request #593 from electrical/symbol_to_string (c1c46b4b)


```
Merge pull request #593 from electrical/symbol_to_string

(gh-573) force symbols into strings
```
* (QENG-1605) added --no-configure option to skip configuration if needed (014da7ce)

* Merge pull request #586 from chris-reeves/gh585_vagrant_1_7_x (c05dc074)


```
Merge pull request #586 from chris-reeves/gh585_vagrant_1_7_x

(gh-585) Add support for vagrant 1.7.x
```
* Merge pull request #569 from nemski/optional_snap (4dad0067)


```
Merge pull request #569 from nemski/optional_snap

(gh-568) Make snapshot optional for vsphere
```
* (#592) make sure ssh dir is present with proper perms before enviornment file (3b06071b)

* Merge pull request #578 from cassianoleal/patch-1 (d868494c)


```
Merge pull request #578 from cassianoleal/patch-1

Fix copying module files to guest
```
* (GH-587) - Use regex to test for agent forwarding in Vagrantfile (eea7bf0e)


```
(GH-587) - Use regex to test for agent forwarding in Vagrantfile

(GH-587) - Use regex to test for agent forwarding in Vagrantfile
```
* (GH-587) - Add additonal test for docker ssh_forwarding, and change forward_ssh_agent to be a symbol, instead of a string (8a965b4c)

* (gh-573) force symbols into strings (32ed4cbc)


```
(gh-573) force symbols into strings

Fixes #573
```
* Merge pull request #589 from anodelman/aws (69826745)


```
Merge pull request #589 from anodelman/aws

(QENG-1530) beaker support to query aws instance/resource relationships
```
* Merge pull request #584 from myoung34/master (80641787)


```
Merge pull request #584 from myoung34/master

(gh-581) Fix syntax for mac address specification in Vagrantfile
```
* (GH-587) don't use 'nil?' - check whether forward_ssh_agent is true rather (f40f9a8b)

* (QENG-1530) beaker support to query aws instance/resource relationships (1003a0cc)


```
(QENG-1530) beaker support to query aws instance/resource relationships

- adding query support against ec2 vpc and security_group objects
```
* Merge pull request #572 from hajee/master (4129461f)


```
Merge pull request #572 from hajee/master

Make restarting sshd more robust on Redhat systems
```
* (GH-587) enable ssh agent forwarding for both vagrant and docker (a58fb6e4)

* (gh-585) Add support for vagrant 1.7.x (3aa080c8)


```
(gh-585) Add support for vagrant 1.7.x

As of version 1.7.x, vagrant will replace the default insecure keypair with a
randomly generated keypair on first 'vagrant up'. As a result the generated
ssh configs have changed and contain per-host private keys. Beaker was
breaking the path to these new private key files due to a substitution which
wasn't sufficiently constrained (the path to the private key now contains the
hostname, which was being replaced with the host's IP). This commit adds the
necessary constraint.
```
* (gh-577) Without the exact path to the service command, starting up a redhat vagrant box fails (99a4ef29)


```
(gh-577) Without the exact path to the service command, starting up a redhat vagrant box fails

Fixes #577
```
* (gh-581) Fix syntax for mac address specification in Vagrantfile (f1b9d51b)

* Merge pull request #560 from jlambert121/ignore_vendor (68090776)


```
Merge pull request #560 from jlambert121/ignore_vendor

(MAINT) exclude copying vendor dir to clients
```
* (PUP-3770) Fix copying module files to guest (a99c7288)


```
(PUP-3770) Fix copying module files to guest

In certain scenarios, no module files are copied to the guest. I have found this issue with modules residing under `/vagrant/module_path` and `/home/ci/.../module_path`.

The regexp generated was `/(?-mix:((\/|\A).bundle(\/|\z))|((\/|\A).git(\/|\z))|((\/|\A).idea(\/|\z))|((\/|\A).vagrant(\/|\z))|((\/|\A).vendor(\/|\z))|((\/|\A)acceptance(\/|\z))|((\/|\A)spec(\/|\z))|((\/|\A)tests(\/|\z))|((\/|\A)log(\/|\z))|((\/|\A).(\/|\z))|((\/|\A)..(\/|\z)))/`. I tested this pattern in http://rubular.com/ and found that indeed it matches all files under those directories.

The string substitution was not doing anything at all (`"\."` gets expanded to `.` instead of `\.`).

It was also only trying to replace the first `.` of each entry as it was using `String#sub` instead of `String#gsub`.

Once that was fixed, beaker worked.
```
* (gh-568) Throw descriptive exception when no snapshot exists (2496a73e)

* (gh-568) Allow snapshot option to be optional (838709b5)

* (gh-568) Allow snapshot option to be optional (d7b6d4e6)

* (MAINT) exclude copying vendor dir to clients (5fec6251)

* (QENG-1562) added AIO installation support for yum/apt on FOSS (eb4528c5)

* (QENG-1538) fixes EOS hack (55f7d2b2)


```
(QENG-1538) fixes EOS hack

In QENG-299, a hack was required to get around an issue w/EOS
for root ssh key setup.  A change was submitted to the
sshkeys repo to fix this.  This fix removes the hack, and
sets up the correct root ssh key procedure in Beaker for EOS

Conflicts:
	spec/beaker/host_prebuilt_steps_spec.rb
```
### <a name = "beaker2.1.0">beaker2.1.0 - 17 Dec, 2014 (ec089b1a)

* (HISTORY) update beaker history for gem release 2.1.0 (ec089b1a)

* (GEM) update beaker version to 2.1.0 (747aacee)

* Merge pull request #576 from anodelman/utf-8-encoding (0ff3e99e)


```
Merge pull request #576 from anodelman/utf-8-encoding

(QENG-1599) force_encoding requires string input, pukes on symbols
```
* Merge pull request #582 from kevpl/qeng1596_2.0_solaris (d949312b)


```
Merge pull request #582 from kevpl/qeng1596_2.0_solaris

(QENG-1596) fixed sed commands on solaris
```
* Merge pull request #580 from anodelman/fix-ssh-login (ff448494)


```
Merge pull request #580 from anodelman/fix-ssh-login

(QENG-1594) Beaker 2.0.0 breaks Centos 7 sshd
```
* Merge pull request #583 from anodelman/aws (9e68d52e)


```
Merge pull request #583 from anodelman/aws

(QENG-1529) beaker support to query aws instance information
```
* Merge pull request #579 from puppetlabs/vcloud_hypervisor_improvements (32ff90c9)


```
Merge pull request #579 from puppetlabs/vcloud_hypervisor_improvements

(QENG-1548) vcloud hypervisor improvements
```
* (QENG-1596) added aix and osx to SedCommand fix (e2c0aecd)

* (QENG-1596) fixed sed commands on solaris (c1894743)

* (QENG-1594) Beaker 2.0.0 breaks Centos 7 sshd (f2c1b1ef)


```
(QENG-1594) Beaker 2.0.0 breaks Centos 7 sshd

- append newline to end of sshd_config file
```
* (QENG-1548) Don't generate a hostname if 'name' is specified (11d918bb)

* (QENG-1548) Allow 'resourcepool' to be an optional param for 'vcloud' hypervisor (780dfb68)

* Merge pull request #574 from anodelman/maint (b89073d3)


```
Merge pull request #574 from anodelman/maint

(MAINT) missing assert_not_match method
```
* (QENG-1599) force_encoding requires string input, pukes on symbols (77488bc1)

* Merge pull request #575 from anodelman/tagging (1984b158)


```
Merge pull request #575 from anodelman/tagging

(MAINT) update ec2 tags with 'created_by'
```
* (MAINT) update ec2 tags with 'created_by' (d760570c)


```
(MAINT) update ec2 tags with 'created_by'

- now tag ec2 instances with Name, department, project,
  jenkins_build_url and created_by
```
* (MAINT) missing assert_not_match method (779f61bc)


```
(MAINT) missing assert_not_match method

- just add alias to assert_no_match
```
* (QENG-1529) beaker support to query aws instance information (c2d2a33c)


```
(QENG-1529) beaker support to query aws instance information

- access to individual instances by id
- access to array of all instances
```
* Merge pull request #565 from puppetlabs/add_40_answers (56d896a5)


```
Merge pull request #565 from puppetlabs/add_40_answers

(maint) Make beaker support 4.0
```
* (maint) Make beaker support 4.0 (e9fcdaf6)

### <a name = "beaker2.0.0">beaker2.0.0 - 5 Dec, 2014 (fb4b620b)

* (HISTORY) update beaker history for gem release 2.0.0 (fb4b620b)

* (GEM) update beaker version to 2.0.0 (6a1295f2)

* Merge pull request #559 from anodelman/maint (d84c5705)


```
Merge pull request #559 from anodelman/maint

(QENG-1574) update beaker gem dependencies post 1.8 EOL
```
* Merge pull request #556 from kevpl/qeng1266_cumulus_supportadd (d148eaa4)


```
Merge pull request #556 from kevpl/qeng1266_cumulus_supportadd

(QENG-1266) added cumulus support to beaker
```
* (QENG-1574) update beaker gem dependencies post 1.8 EOL (9832850a)


```
(QENG-1574) update beaker gem dependencies post 1.8 EOL

VERSION BUMP ALL THE THINGS!
```
* (QENG-1266) updated spec tests to conform to newer spec standards (235e515c)

* Merge pull request #555 from kevpl/qeng1150_puppet_trace_opts (7777210b)


```
Merge pull request #555 from kevpl/qeng1150_puppet_trace_opts

(QENG-1150) added trace option to puppet module install command via host...
```
* Merge pull request #526 from ericwilliamson/task/qeng-1454-allow-user-ports-ec2 (7a81b70e)


```
Merge pull request #526 from ericwilliamson/task/qeng-1454-allow-user-ports-ec2

(QENG-1454) Allow user to specify ports to open on ec2
```
* Merge pull request #558 from anodelman/maint (8732bd0f)


```
Merge pull request #558 from anodelman/maint

(MAINT) update CONTRIBUTING doc to reflect new RSpec test requirements
```
* (MAINT) update CONTRIBUTING doc to reflect new RSpec test requirements (34e1df05)


```
(MAINT) update CONTRIBUTING doc to reflect new RSpec test requirements

- will not allow use of deprecated RSpec method calls in Beaker spec
  tests
```
* Merge pull request #536 from anodelman/1.8 (a8276575)


```
Merge pull request #536 from anodelman/1.8

(QENG-437) beaker: EOL 1.8 ruby
```
* Merge pull request #553 from kevpl/qeng299_eos_added (336c1b7d)


```
Merge pull request #553 from kevpl/qeng299_eos_added

(QENG-299) Added support for EOS
```
* Merge pull request #551 from Mylezeem/support_vagrant_libvirt (651d2eda)


```
Merge pull request #551 from Mylezeem/support_vagrant_libvirt

(GH-552) Hypervisor: Add support for vagrant_libvirt
```
* (QENG-1266) added in review feedback (a258e924)

* Merge pull request #545 from logicminds/sshd_restart (5e72b1e0)


```
Merge pull request #545 from logicminds/sshd_restart

beaker restarts sshd incorrectly on centos 6
```
* Merge pull request #539 from mcanevet/fix/install_puppet_from_rpm (8db201a1)


```
Merge pull request #539 from mcanevet/fix/install_puppet_from_rpm

(MAINT) rpm returns 1 if package already installed
```
* (QENG-1266) added cumulus support to beaker (d4137d78)

* (QENG-1150) added trace option to puppet module install command via host option (7b3964a3)

* (QENG-299) applied review feedback (f436930d)


```
(QENG-299) applied review feedback

two specific things were done here: removal of unnecessary pe_dir
setting in spec tests, and changing HEREDOC usage to string array
join calls for better readability
```
* Merge pull request #531 from kevpl/qeng1430_2_fail (c6e78a59)


```
Merge pull request #531 from kevpl/qeng1430_2_fail

(QENG-1430) Added accept_all_exit_codes option to host exec calls
```
* Merge pull request #534 from kevpl/qeng1000_takeover (4bbc1922)


```
Merge pull request #534 from kevpl/qeng1000_takeover

(QENG-1000) Ensure that add-el-extras works on all rhel platforms
```
* Merge pull request #542 from logicminds/enable_root_login (af15ec89)


```
Merge pull request #542 from logicminds/enable_root_login

fix bug with sed conditional check during permit root login
```
* Merge pull request #549 from anodelman/cherry (20705a7b)


```
Merge pull request #549 from anodelman/cherry

(QENG-1509) merge pe-beaker and beaker post pe 3.7 release
```
* (QENG-299) Added support for EOS (cf3bf7f3)

* Merge pull request #548 from kevpl/qeng1100_rpm_noforce (b4babc29)


```
Merge pull request #548 from kevpl/qeng1100_rpm_noforce

(QENG-1100) removed unneeded force argument to rpm call
```
* (gh-552) Add support for vagrant_libvirt (15ed7785)


```
(gh-552) Add support for vagrant_libvirt

Currently vagrand backend support is limited to virtualbox,
vmware_workstation and fusion. Vagrant offers a non-official
libvirt backend through the vagrant-libvirt[1] plugin.
This commit aims to add support for vagrant_libvirt.

[1] https://github.com/pradels/vagrant-libvirt
```
* Merge pull request #544 from hunner/fix_custom_hypervisors (0423ded0)


```
Merge pull request #544 from hunner/fix_custom_hypervisors

Fix const_get for custom hypervisors
```
* (QENG-1100) removed unneeded force argument to rpm call (9b3948d0)

* Merge pull request #532 from maestrodev/docker-entrypoint (5d1b017f)


```
Merge pull request #532 from maestrodev/docker-entrypoint

Allow overriding Docker image entrypoint
```
* (gh-543) - beaker restarts sshd incorrectly on centos 6 and sshd never recovers (4043bf98)

* (MAINT) Fix const_get for custom hypervisors (d45e723c)


```
(MAINT) Fix const_get for custom hypervisors

This code must not have ever been used before, as const_get() has to be
run for each section of a namespace (and thus can't contain ::)
```
* Merge pull request #541 from anodelman/maint (5bb7a566)


```
Merge pull request #541 from anodelman/maint

(MAINT) fix broken spec test
```
* (MAINT) fix broken spec test (a1454bc0)


```
(MAINT) fix broken spec test

- fix broken spec test
- add check for deprecation warnings during spec testing
```
* (gh-546) fix bug with sed conditional check during permit root login (37741b7b)

* Merge pull request #540 from MikaelSmith/bug/master/CFACT-160-add-cfacter-wrapper (d3c9a535)


```
Merge pull request #540 from MikaelSmith/bug/master/CFACT-160-add-cfacter-wrapper

(CFACT-160) Add cfacter wrapper method
```
* Merge pull request #420 from liamjbennett/host_entry_method (e3a338f8)


```
Merge pull request #420 from liamjbennett/host_entry_method

Adding a utility method for adding host entries
```
* Merge pull request #449 from anodelman/env-fix (9d46f143)


```
Merge pull request #449 from anodelman/env-fix

(QENG-526) A friendly way for Beaker to set environment...
```
* Merge pull request #529 from kevpl/qeng846_logpath (283fa970)


```
Merge pull request #529 from kevpl/qeng846_logpath

(QENG-846) Centralized dated log path generation, and added options for ...
```
* Merge pull request #535 from kevpl/qeng1340_takeover (335ddae9)


```
Merge pull request #535 from kevpl/qeng1340_takeover

(QENG-1340) Add GitHub PR refspec to install_from_git
```
* Merge pull request #537 from kevpl/qeng688_log_default (0df6f1f7)


```
Merge pull request #537 from kevpl/qeng688_log_default

(QENG-688) made default log_level info rather than verbose
```
* Merge pull request #538 from anodelman/blimpy (10d2009a)


```
Merge pull request #538 from anodelman/blimpy

(QENG-1476) drop blimpy hypervisor from beaker
```
* (CFACT-160) Add cfacter wrapper method (9810a413)


```
(CFACT-160) Add cfacter wrapper method

Used by the Native Facter (cfacter) project to run acceptance tests.
```
* (MAINT) rpm returns 1 if package already installed (4dbfa3f9)

* fixing tests for add_system32_hosts_entry method (5b9a5ea7)

* Merge branch 'master' into host_entry_method (f5ad6ed3)

* (QENG-1476) drop blimpy hypervisor from beaker (7d21a3c0)


```
(QENG-1476) drop blimpy hypervisor from beaker

- replaced with aws_sdk
```
* (QENG-1000) added oracle support to this fix (5d09da45)

* (QENG-688) made default log_level info rather than verbose (d111ecc6)

* (QENG-437) beaker: EOL 1.8 ruby (aedddc3f)


```
(QENG-437) beaker: EOL 1.8 ruby

- remove code chunks built for ruby 1.8
- update rspec + minitest, remove test/unit
- update spec tests to meet current rspec standard, here's a good
  reference
  http://teaisaweso.me/blog/2013/05/27/rspecs-new-message-expectation-syntax/
```
* (QENG-1340) updated spec tests to match fix for this issue (214e78f4)

* (QENG-1430) added spec for accept_all_exit_codes being explicitly set to false (711db068)

* Merge pull request #522 from justinstoller/allow_custom_download_urls (20447ddd)


```
Merge pull request #522 from justinstoller/allow_custom_download_urls

QENG-1074 Add options for mac and win download from alternative sources for install_puppet
```
* Merge pull request #421 from liamjbennett/vagrant_ssh_config (34b40432)


```
Merge pull request #421 from liamjbennett/vagrant_ssh_config

Fix bug connecting to windows vagrant host
```
* Allow overriding Docker image entrypoint (d7da78fc)


```
Allow overriding Docker image entrypoint

Using docker_image_entrypoint
```
* (QENG-1430) Added accept_all_exit_codes option to host exec calls (74f97391)


```
(QENG-1430) Added accept_all_exit_codes option to host exec calls

QA was having issues with errors occuring when they'd like to have failures, since the specific
error codes are forseen and specific failure cases.  In order to help them with this use case,
I've added the accept_all_exit_codes option, which will not error on unacceptable exit codes,
defering to the test above to deal with the command's exit code as a failure or otherwise.
```
* Merge pull request #515 from justinstoller/QENG-1126 (5343e5b6)


```
Merge pull request #515 from justinstoller/QENG-1126

(QENG-1126) Allow setting IS_PE to the negative
```
* (QENG-846) Centralized dated log path generation, and added options for specific log paths (192cecf2)


```
(QENG-846) Centralized dated log path generation, and added options for specific log paths

Before, the latest link was hard to use since it jumped around, and you couldn't really get at
the timestamped log path itself because it was hidden in the log_path function.  This work
separates out the timestamped path generation into a static method so that it can be used
anywhere, and adds the current usages of it to the global options, so that they can be used
for other purposes, such as the use case for this issue: copying other files to this location
```
* Merge pull request #525 from justinstoller/GH-320-disable_vbguest_plugin (d1a728a6)


```
Merge pull request #525 from justinstoller/GH-320-disable_vbguest_plugin

(GH-320) Allow disabling of vbguest plugin auto-update
```
* Merge pull request #521 from justinstoller/maint/master/multiple_hosts_for_copy_module_to (38a0a68d)


```
Merge pull request #521 from justinstoller/maint/master/multiple_hosts_for_copy_module_to

(MAINT) Allow passing multiple hosts to copy_module_to
```
* Merge pull request #524 from jalvarezsamayoa/feature/issue_519 (a5581315)


```
Merge pull request #524 from jalvarezsamayoa/feature/issue_519

Fix #519 Unable to ssh to docker container based on Ubuntu Trusty
```
* (QENG-1454) Allow user to specify ports to open on ec2 (b1bd184f)


```
(QENG-1454) Allow user to specify ports to open on ec2

Previous to this commit, the list of ports that beaker should open for
ec2 was hard coded and incomplete. For example it was missing port
'5432' for the database node, which is the port postgresql uses.
This commit adds the ability for a user to specify additional ports to open
in their `hosts.cfg` file. By allowing this, it should provide some
flexibility to the hard coded nature of the ports, and allow beaker to
just provide the defaults that are currently known.
```
* Merge pull request #520 from anodelman/docker (76427a67)


```
Merge pull request #520 from anodelman/docker

(QENG-1450) when docker options are already set they should...
```
* Merge pull request #518 from anodelman/maint (f9548854)


```
Merge pull request #518 from anodelman/maint

(QENG-1449) proxy package managers before configuration/validation...
```
* Fix #519 Unable to ssh to docker container based on Ubuntu Trusty (846dfc34)

* Merge pull request #517 from anodelman/vagrant-maint (a7435074)


```
Merge pull request #517 from anodelman/vagrant-maint

(gh-456) Can't ssh root@127.0.0.1 via vagrant if root...
```
* (QENG-1450) when docker options are already set they should... (fd98e13b)


```
(QENG-1450) when docker options are already set they should...

... not be overridden

- as reported in https://github.com/puppetlabs/beaker/pull/509
- repackaged PR to meet contributor guidelines
```
* (QENG-1449) proxy package managers before configuration/validation... (3d960d65)


```
(QENG-1449) proxy package managers before configuration/validation...

... of hypervisor SUTs

- run proxy_package_manager for each hypervisor before
  configure/validate step
```
* (gh-456) Can't ssh root@127.0.0.1 via vagrant if root... (34a4ef48)


```
(gh-456) Can't ssh root@127.0.0.1 via vagrant if root...

... login disabled in /etc/ssh/sshd_config

- add enable_root_login step by default
- clean up spurious 'end' when generating/using an extra disk on
  virtualbox instances
- tested clean locally
```
* (MAINT) Allow passing multiple hosts to copy_module_to (36a78237)

* Merge pull request #478 from paschdan/awsSdk-nonroot (ba128d04)


```
Merge pull request #478 from paschdan/awsSdk-nonroot

(gh-477) enables root for non-root users on ec2 hypervisor
```
* Merge pull request #508 from kevpl/qeng1400_osx (8167af28)


```
Merge pull request #508 from kevpl/qeng1400_osx

QENG-1400 - Added OS X Support to Beaker's users and guests
```
* (QENG-1400) fixed whitespace issues in host file (59ed17a4)

* Merge pull request #502 from kevpl/qeng1211_retry (6f0d6da2)


```
Merge pull request #502 from kevpl/qeng1211_retry

(QENG-1211) Added documentation & tests for retry_on
```
* (QENG-1211) fixed whitespace issues (7c8f1550)

* Merge pull request #442 from leoc/add-debug-flag-to-apply-manifest-on (532b095e)


```
Merge pull request #442 from leoc/add-debug-flag-to-apply-manifest-on

(MAINT) Add --debug option to `apply_manifest_on` helper
```
* Merge pull request #460 from liamjbennett/powershell_wrapper (1b00cabb)


```
Merge pull request #460 from liamjbennett/powershell_wrapper

Adding a new powershell wrapper
```
* Merge pull request #401 from cyberious/ScpAutoExpand (4e301174)


```
Merge pull request #401 from cyberious/ScpAutoExpand

QENG-1075 Auto expand cygpath when performing scp_to on windows
```
* Merge pull request #494 from branan/skip_on_existing_node (440ae0ec)


```
Merge pull request #494 from branan/skip_on_existing_node

(maint) Don't fail if master node is already in console
```
* (maint) Add helpers for sleep until puppetserver / nc started (c76c61cb)


```
(maint) Add helpers for sleep until puppetserver / nc started

In PE 3.7, we added the JVM puppetserver and a JVM node classifier.
These services each take anywhere from 30-100 seconds to start. This
commit adds a helper function to curl until the service is started just
like we do for the (jvm) puppetdb service.
```
* (QENG-1400) Added yard documentation for OS X host users and groups (c0d32896)

* (QENG-1400) Added spec tests for OS X host users and groups (1d4d31b6)

* (maint) Add support for 3.7 answers (f08f53eb)


```
(maint) Add support for 3.7 answers

Because we could still be testing against builds with a "3.4" number
the answers haven't been completely converted yet. Once we no longer
have any 3.4 builds to test we can do a full conversion.
```
* (maint) open port 4433 on ec2 for the node classifier (87d51464)


```
(maint) open port 4433 on ec2 for the node classifier

Previous to this commit, we never explicitly opened the node classifier
port in ec2, since it is new in 3.4.
```
* Merge pull request #511 from kevpl/yard_quickfix (5dfe8980)


```
Merge pull request #511 from kevpl/yard_quickfix

(MAINT) removed yard param notation where no parameter was given
```
* (MAINT) removed yard param notation where no parameter was given (4fc43503)

* (maint) open port 5432 on ec2 for postgresql (727f3541)


```
(maint) open port 5432 on ec2 for postgresql

Previous to this commit, we never explicitly opened the database port in
ec2. Either it was somehow implicitly being included/created and that
broke, or split installs just never worked in ec2.
```
* (QENG-1400) Removed comments and added in formatting feedback (7ab657a3)

* (QENG-1400) Allowed yield blocks to get at actual command output, and returned unix style passwd user output (def2d633)


```
(QENG-1400) Allowed yield blocks to get at actual command output, and returned unix style passwd user output

Mac's dscl output isn't formatted as the /etc/passwd expected by callers.  In order to go back to this, I changed the yield to use the
information after I formatted it.  However, this fails because the callers are relying on the parameter given to them having a .stdout
call and other things like it, so I've gone back to that old way, and allowed the unix formatting to still be used in the return
```
* Merge pull request #507 from branan/osx_simplified_support (b65bf067)


```
Merge pull request #507 from branan/osx_simplified_support

(QENG-1414) Allow installation of OSX using simplified agent
```
* Merge pull request #506 from puppetlabs/aws-sdk-bump (c05dd108)


```
Merge pull request #506 from puppetlabs/aws-sdk-bump

Bump aws-sdk to v1.57.0 for eu-central-1 support
```
* (QENG-1414) Allow installation of OSX using simplified agent (0c552bd7)


```
(QENG-1414) Allow installation of OSX using simplified agent

OSX has been a supported simplified platform since its release, but
beaker did not support this deployment pattern. This change makes it
work.

Conflicts:
	lib/beaker/dsl/install_utils.rb
```
* (QENG-1400) Added support for host operations on a mac (fb1bad4a)

* Bump aws-sdk to v1.57.0 for eu-central-1 support (867660da)


```
Bump aws-sdk to v1.57.0 for eu-central-1 support

Prior to this commit, we pinned aws-sdk to v1.42.0. Today, AWS brought
the eu-central-1 datacenter online. When Beaker attempts to run its
zombie killer script(s), the AWS SDK doesn't know how to handle this
datacenter. To combat the issue, AWS released v1.57.0 of the aws-sdk gem
today to coincide with this datacenter being brought online.

This commit modifies Beaker's Gemspec to use aws-sdk v1.57.0 so that it
can properly use the eu-central-1 datacenter.
```
* (QENG-1211) Removing unnecessary description parameter from retry_on (d1c5a9c1)


```
(QENG-1211) Removing unnecessary description parameter from retry_on

Before, the description parameter was unused by retry_command, but there were usages of the
function that tried putting information into this. Removing it makes the usages more correct,
since it wasn't actually being used, and makes it conform better to our _on function's
parameter standard
```
* (maint) Use tlsv1 when curling simplified install script (e6d4c810)


```
(maint) Use tlsv1 when curling simplified install script

As of PE 3.7, the puppetmaster no longer supports pre-TLS security
standards.

Conflicts:
	lib/beaker/dsl/install_utils.rb
	spec/beaker/dsl/install_utils_spec.rb
```
* (QENG-1211) Fixed logical error in acceptable exit code argument for retry_on (9ce699d1)

* Merge pull request #493 from kevpl/qeng1257_scpto_addioerror (2e778ff5)


```
Merge pull request #493 from kevpl/qeng1257_scpto_addioerror

QENG-1257 scp_to Added IOError
```
* Merge pull request #382 from justinstoller/metadataJsonSupport (2c9839b8)


```
Merge pull request #382 from justinstoller/metadataJsonSupport

Metadata json support
```
* (QENG-1211) Added documentation & tests for retry_on (762720da)


```
(QENG-1211) Added documentation & tests for retry_on

Before, the retry_command method was private by convention, because it didn't have
tests or any documentation.  Some of the QA team wanted to use this functionality,
so now we've added those supporting items to gain confidence in its regular use.
```
* Merge pull request #495 from kevpl/qeng1374_sshconn_addclosespec (a05a6b1b)


```
Merge pull request #495 from kevpl/qeng1374_sshconn_addclosespec

(QENG-1374) Added specs for the SshConnection close function
```
* Merge pull request #489 from anodelman/pooler (1f4aaef6)


```
Merge pull request #489 from anodelman/pooler

(QENG-779) backoff from pooler reqests when retrying
```
* Merge pull request #487 from kevpl/qeng1354_spec_add (31472d55)


```
Merge pull request #487 from kevpl/qeng1354_spec_add

(QENG-1354) Added low-hanging rspec tests to improve coverage
```
* Merge pull request #468 from kbarber/add-vpc-support-to-aws-sdk (e7b7cd63)


```
Merge pull request #468 from kbarber/add-vpc-support-to-aws-sdk

Add VPC support to the aws_sdk hypervisor
```
* Allow frictionlesss install to pass params (bf62c90f)


```
Allow frictionlesss install to pass params

Previously, the frictionless agent install did not have a
way to specify puppet config settings at install time. In 3.4 the
ability was added to pass in additional settings in the form of
`section:key=value` and have it call `puppet config set` with those
options before starting puppet. This allows an agent to dynamically
configure it's certname, server or any other setting.

Conflicts:
	lib/beaker/dsl/install_utils.rb
```
* (maint) Don't fail if master node is already in console (280bdf4d)

* (QENG-1257) do_scp_to raises IOError if file doesn't exist (7db9279a)


```
(QENG-1257) do_scp_to raises IOError if file doesn't exist

Before, if the file doesn't exist, you would get a Result object back that had a nil exit_code.  Talking with some people, we decided that if you get a Result object back, it implies that the command was run, which doesn't happen here.  Now we raise an error, which is more indicative of an error in beaker setup, which is what's actually going on here.
```
* (QENG-1257) updated yard doc for do_scp_to to make parameters consistently formatted (72f8debd)

* (QENG-1374) Added specs for the SshConnection close function (64dda96f)

* (QENG-779) backoff from pooler reqests when retrying (21a9597f)


```
(QENG-779) backoff from pooler reqests when retrying

- add fibonacci backoffs to vpooler instance requests
```
* (QENG-1354) Added low-hanging rspec tests to improve coverage (bf05fa0f)


```
(QENG-1354) Added low-hanging rspec tests to improve coverage

This was just a task to get me a little more comfortable with the codebase,
and add a little more testing to plug some small gaps that we had in coverage
```
* (PE-5681) Add auth password answer on upgrade to 3.4 (093c73f7)


```
(PE-5681) Add auth password answer on upgrade to 3.4

Prior to this commit we were not providing the auth_password answer on
upgrades to 3.4.
This commit adds that answer. This will allow the tests to complete.

Conflicts:
	lib/beaker/answers/version34.rb
```
* (gh-477) enables root for non-root users on ec2 hypervisor (5d3072f7)


```
(gh-477) enables root for non-root users on ec2 hypervisor

- fixes codestyle
- fixes tests
```
* (gh-477) enables root for non-root users on ec2 hypervisor (e2f3f662)


```
(gh-477) enables root for non-root users on ec2 hypervisor

- root login is not possible on ubuntu-amis
- provision is not possible without root

This Patch enables root when the host['user'] differs from "root"
```
* (gh-472) refactoring method so that is only supports windows and will raise error on other platforms (90a19c83)

* Add VPC support to the aws_sdk hypervisor (53a32039)


```
Add VPC support to the aws_sdk hypervisor

This adds support for launching instances into an AWS VPC.

This adds two new configuration options:

- subnet_id
- vpc_id

That can be added to the HOSTS section of your beaker configuration. These
options are both mandatory for this feature to work.

The code has been basically modified to deal with the VPC object now,
if those configuration items are provided.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* renaming method to add_system32_hosts_entry (200a9c24)

* removing unused powershell command (76ce2546)

* switching method to use powershell wrapper (67a56318)

* Merge branch 'master' into host_entry_method (422a17b0)

* (gh-469) Adding a new wrapper for the powershell.exe command (a24449c3)


```
(gh-469) Adding a new wrapper for the powershell.exe command

There are several places in the codebase where this will be used as
powershell is the most common scipting environment on windows.

The aim of this new addtion is to wrap a few of the complexities of
executing powershell commands, such as discovering the powershell.exe
location and passing the correct command line paramaters.
```
* Merge pull request #4 from branan/db_names (1c40dbd2)


```
Merge pull request #4 from branan/db_names

(maint) Use pe- prefix for DB names of console_services components
Conflicts:
	lib/beaker/answers/version34.rb
	spec/beaker/answers_spec.rb
```
* Merge pull request #3 from branan/fix_specs (8c88db60)


```
Merge pull request #3 from branan/fix_specs

(maint) fix spec tests because I am an asshole
```
* Merge pull request #2 from branan/puppetserver (9fbc57f9)


```
Merge pull request #2 from branan/puppetserver

(QENG-1252) Use pe-puppetserver as master service on PE 3.4+
```
* Merge pull request #1 from briancain/maint/master/update-to-set-console-services-answers (741d088a)


```
Merge pull request #1 from briancain/maint/master/update-to-set-console-services-answers

(PE-5775) Add new console services answers to beaker for 3.4
Conflicts:
	lib/beaker/answers/version34.rb
	lib/beaker/options/presets.rb
	spec/beaker/answers_spec.rb
```
* (MAINT) Add --debug option to `apply_manifest_on` helper (0a30af04)


```
(MAINT) Add --debug option to `apply_manifest_on` helper

Before every 'puppet apply' command is executed with --verbose.
Now you can pass `debug: true`, which executes 'puppet apply' with the
--debug flag.
```
* (QENG-1126) Allow setting IS_PE to the negative (bd9999cd)


```
(QENG-1126) Allow setting IS_PE to the negative

Previously we had an environment variable "IS_PE" or "BEAKER_IS_PE" to
set whether or not we were using PE. Since then PE has become the
default. Module authors would like a similarly simple way via the ENV
to override the default and set the installation type as "FOSS".
The convention that has arisen is to use the negative in the IS_PE
environment variable (e.g. "IS_PE=no"). This brings that convention
into Beaker proper.

Original work done by @cyberious (Travis Fields).
```
* (MAINT) Fix bug connecting to windows vagrant host (bf353c1d)


```
(MAINT) Fix bug connecting to windows vagrant host

When running multiple hosts in vagrant with an linux master and windows
agent it seems that vagrant has difficulty connecting to box when the
ssh_config file contains 127.0.0.1 for the host. This change fixes the
issue by replacing it with the host ip if it has been specified in the
nodeset.

This might need a little more manual testing.
```
* Adding a utility method for adding host entries (5c3c00e8)


```
Adding a utility method for adding host entries

As much as this is a infrastructure-smell in the linux world, adding
hosts entries is still all to common in the windows world. This method
allows host entries to be configured to meet that need.

It can also be used when developing with vagrant to make sure that the
master and agent vms can see each other properly.
```
* QENG-1075 Auto expand cygpath when performing scp_to (2006a1ad)


```
QENG-1075 Auto expand cygpath when performing scp_to

Modified to have match anything on the to_path `cygpath

Added yard docs to expanding new behavior with cygpath
```
* (QENG-1074) Override mac and win url for `install_puppet` (c24d8cf8)


```
(QENG-1074) Override mac and win url for `install_puppet`

Previously we always downloaded windows or osx installation packages
from http://downloads.puppetlabs.com.

This allows the specifying of special urls for windows and osx to
`Beaker::DSL::InstallHelpers#install_puppet`.
```
* (MAINT) fix spec stubs for Modulefile/metadata.json detection (e5b1ad07)

* (MAINT) improve Modulefile/metadata.json logging msg (f5a8f642)

* (QENG-1340) Add GitHub PR refspec to install_from_git (7fa8d7d3)


```
(QENG-1340) Add GitHub PR refspec to install_from_git

 - When testing out Jenkins job configuration tweaks that must coincide with source
   changes, it can be useful to have Beaker be aware of the GitHub refspec.  This
   allows SHA references to GitHub commits / PRs that have not yet been merged,
   without having to jump through a number of additional job configurations to gain
   access to the appropriate commits.
 - Note that this does have performance implications, as performing a fetch will take
   longer on the first time.
```
* (QENG-1000) Ensure that add-el-extras works on all rhel platforms (493639d2)


```
(QENG-1000) Ensure that add-el-extras works on all rhel platforms

The --add-el-extras options was only working for platform strings of the form
el-(5,6), which meant that you couldn't have beaker add the el repo on a
'centos' platform for instance.

Change makes more use of the Beaker::Platform attributes and checks
other rhel variants (centos, scientific, and the 'redhat' variant is
another platform label used for rhel I believe).
```
* (QENG-526) A friendly way for Beaker to set environment... (1e3b31e2)


```
(QENG-526) A friendly way for Beaker to set environment...

... variables for SUTs

- add support for option :host_env, it can be set in the host
  configuration file
- requires updating each host so that sshd allows remotely setting
  environment variables
- add host.add_env_var(key,val) and host.delete_env_var(key,val) for
  using in test writing
```
* (MAINT) Add metadata.json as part of determining module root (fb25b502)

* (GH-320) Allow disabling of vbguest plugin auto-update (8d099274)


```
(GH-320) Allow disabling of vbguest plugin auto-update

A common Vagrant plugin can cause considerably lengthier test runs
unless disabled in the Vagrantfile.

This patch allows disabling the "vb auto update plugin" via an
environment variable

Originally coded by @petems (Peter Souter)
  refactored by @justinstoller (Justin Stoller)
```
### <a name = "beaker1.20.1">beaker1.20.1 - 17 Oct, 2014 (be250ad6)

* (HISTORY) update beaker history for gem release 1.20.1 (be250ad6)

* (GEM) update beaker version to 1.20.1 (3fff222d)

* Merge pull request #501 from anodelman/iptables (bc685ab5)


```
Merge pull request #501 from anodelman/iptables

(MAINT) fix broken hypervisor config spec test
```
* (MAINT) fix broken hypervisor config spec test (9c2123d8)

* Merge pull request #500 from anodelman/iptables (4d6d4919)


```
Merge pull request #500 from anodelman/iptables

(MAINT) do not disable iptables on default
```
* (MAINT) do not disable iptables on default (10e768f7)


```
(MAINT) do not disable iptables on default

- this is the desired behavior until the disable iptables function is
  more reliable
```
### <a name = "beaker1.20.0">beaker1.20.0 - 17 Oct, 2014 (24acc2d3)

* (HISTORY) update beaker history for gem release 1.20.0 (24acc2d3)

* (GEM) update beaker version to 1.20.0 (ab118389)

* Merge pull request #497 from briancain/QENG1391/master/use-tls-for-pe-curl (d03ec9b6)


```
Merge pull request #497 from briancain/QENG1391/master/use-tls-for-pe-curl

[UNDER REVIEW](QENG-1391) Use TLSv1 over SSLv3 for curl against PE
```
* Merge pull request #498 from anodelman/ec2 (57f30946)


```
Merge pull request #498 from anodelman/ec2

(MAINT) open port 4435 for dashboard
```
* (MAINT) open port 4435 for dashboard (aa4af898)


```
(MAINT) open port 4435 for dashboard

yup, do that
```
* Merge pull request #446 from branan/use_vmpooler_fqdn (00e77f59)


```
Merge pull request #446 from branan/use_vmpooler_fqdn

(QENG-1192) Use hostname specified by hypervisor everywhere.
```
* (QENG-1391) Use TLSv1 over SSLv3 for curl against PE (6449a3b6)


```
(QENG-1391) Use TLSv1 over SSLv3 for curl against PE

Prior to this commit, beaker was exclusively using SSLv3 against Puppet
Enterprise. Due to the recent information with POODLE, this commit updates
beaker to use TLS over SSL since we are disabling the use
of SSLv3.
```
* Merge pull request #475 from er0ck/feature/master/QENG-1231-preserve_hosts_onpass (fa56d804)


```
Merge pull request #475 from er0ck/feature/master/QENG-1231-preserve_hosts_onpass

(QENG-1231) add onpass option to --preserve-hosts
```
* Merge pull request #486 from kevpl/qeng270_ntp_addoption (821884e6)


```
Merge pull request #486 from kevpl/qeng270_ntp_addoption

(QENG-270) Added ntp_server as an option for host config
```
* Merge pull request #490 from anodelman/ec2 (d12ba02d)


```
Merge pull request #490 from anodelman/ec2

(QENG-1205) EC2 zombie killer can fail when instance not found
```
* (QENG-1205) EC2 zombie killer can fail when instance not found (270d6417)


```
(QENG-1205) EC2 zombie killer can fail when instance not found

- better error handling around zombie killing
```
* (QENG-270) Added ntp_server as an option for host config (b148b657)


```
(QENG-270) Added ntp_server as an option for host config

Before this, you couldn't specify an ntp server, so if you used the timesync option, it would only use the hard-coded value 'pool.ntp.org'.
This was a problem because occasionally that service couldn't be reached.  In order to fix this, we've allowed people to specify a server, so that they can get more reliable ntp services, and not see failures based on being able to reach one.
```
* Merge pull request #377 from waynr/feature/qeng-967-disable-iptables-on-el-hosts (c9145e5d)


```
Merge pull request #377 from waynr/feature/qeng-967-disable-iptables-on-el-hosts

(QENG-967) Disable iptables on el hosts bringup.
```
* Merge pull request #452 from anodelman/maint (c46271e0)


```
Merge pull request #452 from anodelman/maint

(QENG-1209) scp in debug output shows far too much output
```
* (QENG-1192) Use hostname specified by hypervisor everywhere (db171537)


```
(QENG-1192) Use hostname specified by hypervisor everywhere

reviously, we would call out to `hostname` on the SUT when deploying
PE. This may give us a name that isn't resolvable our routable by
every host in the configuration. We should instead just use whatever
the hypervisor tells us is the correct way to connect to the host.

This also sneaks in a small change to the vmpooler hypervisor, to make
it return FQDNs. Using these FQDNs is really what this is all about.
```
* Merge pull request #271 from hunner/add_fusion (9a00806f)


```
Merge pull request #271 from hunner/add_fusion

(QENG-1146) Add vagrant_fusion, vagrant_workstation and vagrant_virtualbox providers
```
* remove non-capture from regex groups (8e65b146)

* Merge pull request #462 from er0ck/fix/master/QENG-1261-fix_ntpdate_on_solaris10 (6f5162e7)


```
Merge pull request #462 from er0ck/fix/master/QENG-1261-fix_ntpdate_on_solaris10

(QENG-1261) remove solaris-10 specific ntpdate options
```
* Merge pull request #464 from anodelman/answers (e145c964)


```
Merge pull request #464 from anodelman/answers

(QENG-1054) Add functionality to install_pe to modify answers...
```
* Merge pull request #476 from leoarnold/master (189eb410)


```
Merge pull request #476 from leoarnold/master

Added link to installation instructions to README.md
```
* Merge pull request #479 from anodelman/epel (6ee6fe4c)


```
Merge pull request #479 from anodelman/epel

(QENG-1206) Acceptance failing when trying to install epel-release...
```
* (QENG-1206) Acceptance failing when trying to install epel-release... (17bd48be)


```
(QENG-1206) Acceptance failing when trying to install epel-release...

and EPEL packages from public mirrors
- add ability to set epel_url, epel_arch and epel_package as global
  options or on a per-host basis
- added reasonable default values
```
* Added link to installation instructions to README.md (5b513899)

* (QENG-1231) add onpass option to --preserve-hosts (e772e289)


```
(QENG-1231) add onpass option to --preserve-hosts
* add spec tests similar to onfail spec tests
* add cleanup to rescue when --preserve-hosts onpass
* add help statement for onpass
```
* Merge pull request #418 from liamjbennett/vagrant_box_update (decdb05c)


```
Merge pull request #418 from liamjbennett/vagrant_box_update

Adding support to vagrant for box_version and box_check_update.
```
* Merge pull request #422 from liamjbennett/vagrant_natdns (a64a3bac)


```
Merge pull request #422 from liamjbennett/vagrant_natdns

Enable natresolver and natdnsproxy for vagrant.
```
* (QENG-1261) remove solaris-10 specific ntpdate options.  -w causes an (a795d859)


```
(QENG-1261) remove solaris-10 specific ntpdate options.  -w causes an
error.
remove related spec test.
```
* (gh-470) refactoring natdns to use the unless syntax (3d67a83a)

* (QENG-1054) Add functionality to install_pe to modify answers... (6a35cda6)


```
(QENG-1054) Add functionality to install_pe to modify answers...

...file before install

- add ability to add custom_answers to individual hosts to be appended
  to answer file
- rework answer file code so that answers are an object that can be
  queried for an answer string
- instead of querying env for individual answers just pull in anything
  that matches q_*
- pull the default answer values into the presets so that it is more
  easily tracked
```
* (QENG-1209) scp in debug output shows far too much output (059248e7)


```
(QENG-1209) scp in debug output shows far too much output

- move detailed output into a new log level called 'trace', could still
  be useful for tracking networking failures - but will be disabled by
  default
- add ability to flip on/off quiet output to logging
```
* Enable natresolver and natdnsproxy for vagrant. (613ddba8)


```
Enable natresolver and natdnsproxy for vagrant.

There are cases where tests run will fail when trying to download
from the outside world due to dns issues. In order to resolve this
I configured the natdnsproxy1 and natdnshostresolver1 vagrant settings
```
* (gh-471) Adding support to vagrant for box_version and box_check_update. (24bb0951)


```
(gh-471) Adding support to vagrant for box_version and box_check_update.

If using versioned boxes from vagrant cloud and a new update is
published, by default vagrant will attempt to update that box to
the latest version. This may be undesired behaviour. Like any other
versioned object you way wish to fix that initial download to a
fixed version or a version range.
```
* (QENG-967) Disable iptables on el hosts bringup. (11cb16ef)


```
(QENG-967) Disable iptables on el hosts bringup.

Also fixes bug in `disable_iptables` where per-array-element was invoking wrong
method. Looks like `disable_iptables` was originally copied from
`copy_ssh_to_root`

Also adds rspec for Beaker::Hypervisor.configure

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-1146) Add vagrant_fusion, vmware_workstation, and vagrant_virtualbox providers (fdcbac3d)


```
(QENG-1146) Add vagrant_fusion, vmware_workstation, and vagrant_virtualbox providers

Currently the vagrant hypervisor provider just does virtualbox. This
allows the vagrant vmware_fusion and vmware_workstation plugins to be
used instead.
```
### <a name = "beaker1.19.1">beaker1.19.1 - 19 Sep, 2014 (3aafc71d)

* Merge pull request #467 from anodelman/master (3aafc71d)


```
Merge pull request #467 from anodelman/master

create beaker 1.19.1 gem
```
* (HISTORY) history update for beaker 1.19.1 gem (d5bea586)

* (GEM) version bump for 1.19.1 gem (7538dc00)

* Merge pull request #465 from anodelman/junit (38fca3f5)


```
Merge pull request #465 from anodelman/junit

(MAINT) update junit.xsl to handle more weird test case paths
```
* Merge pull request #466 from branan/QENG-1264 (c77157d5)


```
Merge pull request #466 from branan/QENG-1264

(QENG-1264) Allow users to specify recursive option for scp_{from,to}
```
* (QENG-1264) Allow users to specify recursive option for scp_{from,to} (cc1b2189)


```
(QENG-1264) Allow users to specify recursive option for scp_{from,to}

The fix for QENG-1128 caused scp_from and scp_to to ignore the
recursive flag. This caused all scp_from operations to be recursive,
which will cause a failure if trying to copy only a single file.

The fix to this, without regressing on QENG-1128, is to actually copy
the options hash locally so that we can modify it as needed for
defaults without updating any global data.
```
* (MAINT) update junit.xsl to handle more weird test case paths (c940f116)


```
(MAINT) update junit.xsl to handle more weird test case paths

- paths with (, ), \s, or / are breaking links, this fixes that
```
### <a name = "beaker1.19.0">beaker1.19.0 - 19 Sep, 2014 (6a56cc90)

* Merge pull request #463 from anodelman/make-gem (6a56cc90)


```
Merge pull request #463 from anodelman/make-gem

create beaker 1.19.0 gem
```
* (HISTORY) update history for beaker 1.19.0 gem (b00c31c1)

* (GEM) version bump for beaker 1.19.0 gem (b4e69b83)

* Merge pull request #459 from justinstoller/bug/master/QENG-1212_better (c683a928)


```
Merge pull request #459 from justinstoller/bug/master/QENG-1212_better

(QENG-1212) Improve module installation experience
```
* (QENG-1212) Improve module installation experience (61f05e90)


```
(QENG-1212) Improve module installation experience

Prior to this puppet module installation was carried out with either
`puppet_module_install` or `copy_module_to`. This replaces them with a
method `install_dev_puppet_module` that will install either via scp or
pmt from a staging forge depending on arguements and environment
```
### <a name = "beaker1.18.0">beaker1.18.0 - 18 Sep, 2014 (b9171d9c)

* Merge pull request #461 from anodelman/make-gem (b9171d9c)


```
Merge pull request #461 from anodelman/make-gem

create beaker 1.18.0 gem
```
* (HISTORY) update history for beaker 1.18.0 gem release (8f22c5c9)

* (GEM) version bump for beaker 1.18.0 (116ecd2e)

* Merge pull request #450 from anodelman/scp-repair (ee03903b)


```
Merge pull request #450 from anodelman/scp-repair

(QENG-1128) Beaker no long auto recursively scps directories to systems under test
```
* Merge pull request #361 from anodelman/openstack (2e15cdaa)


```
Merge pull request #361 from anodelman/openstack

(QENG-15) support openstack in beaker
```
* Merge pull request #388 from ferventcoder/ticket/master/allow-git-depth (4d4120a3)


```
Merge pull request #388 from ferventcoder/ticket/master/allow-git-depth

(QENG-1037) Install from git should accept depth
```
* Merge pull request #435 from leoc/add-prebuilt-packages-to-docker (c0a20691)


```
Merge pull request #435 from leoc/add-prebuilt-packages-to-docker

(gh-426) Add prebuild packages to Dockerfile
```
* Merge pull request #439 from doug-rosser/perf_fixes (7c68e4da)


```
Merge pull request #439 from doug-rosser/perf_fixes

(QENG-1033) Don't modify constants and properly support all Linux platforms in Perf
```
* Merge pull request #416 from anodelman/ec2 (de3b3f9d)


```
Merge pull request #416 from anodelman/ec2

(MAINT) add ability to list all instances associated with an ec2 keyname
```
* (QENG-1033) Remove dead rspec code (c713fdb1)

* Merge pull request #451 from anodelman/maint (34db9711)


```
Merge pull request #451 from anodelman/maint

(MAINT) broken spec fixes (docker + copy_module_to)
```
* (MAINT) broken spec fixes (docker + copy_module_to) (98454e51)


```
(MAINT) broken spec fixes (docker + copy_module_to)

- docker spec was still allowing sleeps to execute making things run
  slow
- update copy_module_to spec test to use correct ignore list
```
* (QENG-1128) Beaker no long auto recursively scps directories... (c89fae53)


```
(QENG-1128) Beaker no long auto recursively scps directories...

to systems under test

- issue was :recursive variable was being carried over successive calls
  to scp_to.  To prevent this, just set it based upon the file type
  being called
```
* Merge pull request #440 from colinPL/qeng989_solaris_gem (34e6474f)


```
Merge pull request #440 from colinPL/qeng989_solaris_gem

(QENG-989) install_puppet_from_gem fails on Solaris
```
* Merge pull request #412 from anodelman/maint (8e991e18)


```
Merge pull request #412 from anodelman/maint

(QENG-1018) default dev_builds_url in Beaker needs to be updated
```
* Merge pull request #448 from cyberious/AddIgnores (eb5a99c5)


```
Merge pull request #448 from cyberious/AddIgnores

QENG-1199 add .bundle to ignore list
```
* QENG-1199 add .bundle to ignore list (314d85ce)

* (QENG-1033) Move all functionality into the Perf module and sync the rspec tests (64e69a17)

* Merge pull request #445 from waynr/fix/qeng-1186-beaker-dsl-helpers-puppet-mixup (cbff4759)


```
Merge pull request #445 from waynr/fix/qeng-1186-beaker-dsl-helpers-puppet-mixup

(QENG-1186) Fix Beaker::DSL:Helpers.puppet_{user,group}
```
* Merge pull request #425 from jtopper/avoid_docker_clean_race (c40c37de)


```
Merge pull request #425 from jtopper/avoid_docker_clean_race

(GH-425) Sleep briefly after killing processes - Docker
```
* Merge pull request #436 from anodelman/win-fix (de316e3a)


```
Merge pull request #436 from anodelman/win-fix

(QENG-797) Enhance Beaker to look for x64 installers for Windows
```
* (QENG-1033) Reset additional_pkgs in a way supported by all Ruby versions (9e6b5283)

* (QENG-1033) additional_pkgs should be a module level variable (6623ec0e)

* (QENG-1186) Fix Beaker::DSL:Helpers.puppet_{user,group} (5bb6ee4e)


```
(QENG-1186) Fix Beaker::DSL:Helpers.puppet_{user,group}

Looks like the contents of these methods were mixed upwhen originally written.
Luckily the puppet user is usually the same as the puppet group.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-1033) combine two conditionals into a single statement (e2e91ccc)

* (QENG-989) install_puppet_from_gem fails on Solaris (45ac614e)


```
(QENG-989) install_puppet_from_gem fails on Solaris

Trying to install puppet from gems would fail on both Solaris 10 and
11. Solaris 10 now has pkgutil and gem symlinked (ln -s) to /usr/bin.
Both Solaris versions have puppet-related gems symlinked to /usr/bin
after installation. This is to avoid clobbering the PATH.
```
* (QENG-1129) support win64 open source builds (47bf159f)


```
(QENG-1129) support win64 open source builds

- add ability to install 64 bit windows builds
- supported when puppet version is 3.7+ or pe is 3.4+, and install_32 is not set for
  host or globally
- correctly update path post pe/puppet installation
```
* (QENG-1026) Add support for x64 PE windows to Beaker (59a39bd7)


```
(QENG-1026) Add support for x64 PE windows to Beaker

- default to installing 64 bit builds on 64 bit windows
- support install_32 host option, true = install 32 bit no matter the
  arch, false/unset = install 64 bit on 64 bit, otherwise 32 bit
```
* (QENG-797) Enhance Beaker to look for x64 installers for Windows (066dae5d)


```
(QENG-797) Enhance Beaker to look for x64 installers for Windows

- add ability to install 64 bit pe builds (available for pe 3.4)
- add is_x86_64? method to host, convenience method for determining arch
  of host
```
* (gh-426) Add prebuild packages to Dockerfile (f4085aca)


```
(gh-426) Add prebuild packages to Dockerfile

Without this patch every time the specs run, prebuilt packages are
installed to the new docker image. Even when preserving the image.
To increase the speed of the test suite we install those packages when
creating the Docker image. The `HostPrebuiltSteps` checks whether those
are installed and does not do anything directly starting to execute the
specs inside the image.
```
* (GH-425) Sleep after killing processes (18699dc4)


```
(GH-425) Sleep after killing processes

This avoids a race condition in which the killed processes haven't
exited by the time we try and unmount the root fs and the call to
container.delete errors.
```
* (MAINT) add ability to list all instances associated with an ec2 keyname (d5ad9e35)


```
(MAINT) add ability to list all instances associated with an ec2 keyname

- convenience function for listing all instances associated with a
  provided keyname, useful for tracking what's happening in ec2
```
* (QENG-1018) default dev_builds_url in Beaker needs to be updated (1b2a935f)


```
(QENG-1018) default dev_builds_url in Beaker needs to be updated

- update to builds.delivery.puppetlabs.net
```
* (QENG-1037) Install from git should accept depth (ffcddcc0)


```
(QENG-1037) Install from git should accept depth

When installing from larger repositories, being able to specify depth can cut
the time of git checkout in half. This becomes especially helpful when you are
checking out multiple repositories.
Due to the older git on some of the templates, this provides the older
--branch name --depth 1 commands, which means when using depth, one should
ensure the rev passed is a branch and not a single commit. Alternatively one
can add depth_branch => 'name' to repository and have that used instead of rev.
```
* (maint) formatting (239d8054)


```
(maint) formatting

This removes trailing whitespaces in install_utils.rb
```
* Add Enterprise Linux (el) (3f2bb69b)

* (QENG-15) beaker openstack support (EXPERIMENTAL) (745f1a4a)


```
(QENG-15) beaker openstack support (EXPERIMENTAL)

- experimental code to support openstack, may be missing configuration
  steps or otherwise be incomplete
- should be used as a basis for further beaker openstack infrastructure
```
### <a name = "beaker1.17.7">beaker1.17.7 - 2 Sep, 2014 (e47881f0)

* Merge pull request #444 from branan/ship_1_17_7 (e47881f0)


```
Merge pull request #444 from branan/ship_1_17_7

(maint) Bump version for 1.17.7 release
```
* (maint) Bump version for 1.17.7 release (0cb30f18)

* Merge pull request #443 from briancain/maint/master/add-node-to-classifier (701f81c2)


```
Merge pull request #443 from briancain/maint/master/add-node-to-classifier

(QENG-1182) Add node to classifier prior to adding pe_repo class
```
* (QENG-1182) Add node to classifier prior to adding pe_repo class (00b2f458)


```
(QENG-1182) Add node to classifier prior to adding pe_repo class

Prior to this commit, beaker would make the assumption that a node had
already checked into the classifier. This commit changes that by
ensuring that the node is in the classifier before giving it the pe_repo
class.
```
### <a name = "beaker1.17.6">beaker1.17.6 - 27 Aug, 2014 (bfb257bf)

* Merge pull request #441 from anodelman/make-gem (bfb257bf)


```
Merge pull request #441 from anodelman/make-gem

create beaker 1.17.6 gem
```
* (HISTORY) update history for 1.17.6 gem (a7ee6c69)

* (GEM) version bump for 1.17.6 gem (71be2050)

* Merge pull request #438 from waynr/fix/qeng-1134-remove-jvm-puppet-references (fe77e9b0)


```
Merge pull request #438 from waynr/fix/qeng-1134-remove-jvm-puppet-references

(QENG-1134) Remove 'jvm-puppet' references left in Beaker.
```
* (QENG-1134) Remove 'jvm-puppet' references left in Beaker. (5da4eebc)


```
(QENG-1134) Remove 'jvm-puppet' references left in Beaker.

Recently the `jvm-puppet` name was changed to `puppet-server`, this patch
addresses that in both `lib/` and `spec/`

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
### <a name = "beaker1.17.5">beaker1.17.5 - 22 Aug, 2014 (7e553089)

* Merge pull request #417 from anodelman/make-gem (7e553089)


```
Merge pull request #417 from anodelman/make-gem

create beaker 1.17.5 gem
```
* (HISTORY) update history for beaker 1.17.5 gem (ebefea72)

* (GEM) version bump for beaker 1.17.5 gem (4a96b147)

* Merge pull request #415 from waynr/feature/qeng-1110-install-from-ezbake-bugfix (61e56aa7)


```
Merge pull request #415 from waynr/feature/qeng-1110-install-from-ezbake-bugfix

(QENG-1110) Beaker::DSL::EZBakeUtils bugfix
```
* (QENG-1110) Beaker::DSL::EZBakeUtils bugfix (bd1d91f2)


```
(QENG-1110) Beaker::DSL::EZBakeUtils bugfix

Allows arbitrary arguments to be passed to ezbake command line.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #414 from waynr/feature/qeng-1108-create-tmpdir-for-user-fails (716ab3d4)


```
Merge pull request #414 from waynr/feature/qeng-1108-create-tmpdir-for-user-fails

(QENG-1108) Fix chown command to use ':' rather than '.'
```
* (QENG-1108) Fix chown command to use ':' rather than '.' (c2da3911)


```
(QENG-1108) Fix chown command to use ':' rather than '.'

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
### <a name = "beaker1.17.4">beaker1.17.4 - 21 Aug, 2014 (8e6d070f)

* Merge pull request #413 from anodelman/make-gem (8e6d070f)


```
Merge pull request #413 from anodelman/make-gem

create beaker 1.17.4 gem
```
* (HISTORY) update history for beaker 1.17.4 gem (bd1fe05f)

* (GEM) version bump for 1.17.4 (1e6a4a8f)

* Merge pull request #411 from anodelman/ec2 (2b4c9049)


```
Merge pull request #411 from anodelman/ec2

(MAINT) kill zombies after provided number of hours
```
* Merge pull request #409 from cyberious/ScpCopyIgnoreFix (e59632eb)


```
Merge pull request #409 from cyberious/ScpCopyIgnoreFix

QENG-1080 do_scp_to now checks for source path of absolute and prunes accordingly
```
* (MAINT) kill zombies after provided number of hours (3f3c3b27)


```
(MAINT) kill zombies after provided number of hours

- was always using the default 3 hours
```
* QENG-1080 Fixed issue where we appended the source path to the target path, we now check for absolute path prior (cdd9c7b8)

### <a name = "beaker1.17.3">beaker1.17.3 - 20 Aug, 2014 (f8a536c1)

* Merge pull request #410 from anodelman/make-gem (f8a536c1)


```
Merge pull request #410 from anodelman/make-gem

create beaker 1.17.3 gem
```
* (HISTORY) update history for 1.17.3 gem (0d6006c4)

* (GEM) version bump for 1.17.3 gem (92584d1e)

* Merge pull request #408 from anodelman/ec2 (5c8b14c0)


```
Merge pull request #408 from anodelman/ec2

(MAINT) nits in beaker ec2 support
```
* (MAINT) nits in beaker ec2 support (3d823291)


```
(MAINT) nits in beaker ec2 support

- correctly identify zombies that are over X hours old
- better notification of what instances are being examinged for possible
  termination
- properly notify user of missing aws_access_key_id and
  aws_secret_access_key during initialization
```
### <a name = "beaker1.17.2">beaker1.17.2 - 15 Aug, 2014 (c6f1f64a)

* Merge pull request #407 from anodelman/make-gem (c6f1f64a)


```
Merge pull request #407 from anodelman/make-gem

create beaker 1.17.2 gem
```
* (HISTORY) update history for 1.17.2 gem (d15db7e4)

* (GEM) update version number for 1.17.2 (f6227484)

* Merge pull request #406 from anodelman/ec2 (5799458b)


```
Merge pull request #406 from anodelman/ec2

(QENG-1090) beaker: exception when waiting for instance running in ec2
```
* Merge pull request #403 from anodelman/win-fix (956aa18c)


```
Merge pull request #403 from anodelman/win-fix

(QENG-1081) Beaker Fails During Pre-suite in the "install_pe"...
```
* Merge pull request #405 from anodelman/utf-8-encoding (410490e4)


```
Merge pull request #405 from anodelman/utf-8-encoding

(QENG-1087) beaker - failure in XML output
```
* Merge pull request #404 from anodelman/fix-default (cc38a7f4)


```
Merge pull request #404 from anodelman/fix-default

(QENG-1086) The master-start-curl-retries is preset to...
```
* (QENG-1090) beaker: exception when waiting for instance running in ec2 (ae64c8e9)


```
(QENG-1090) beaker: exception when waiting for instance running in ec2

- correctly capture AWS::EC2::Errors::InvalidInstanceID::NotFound when
  checking status of newly created instance, deal with it as another
  case that requires a retry
```
* (QENG-1087) beaker - failure in XML output (5a392c1a)


```
(QENG-1087) beaker - failure in XML output

- caused by improperly stripping unsupported unicode characters from xml
  output
- add inclusion of 'jcode' for ruby 1.8 (included with Ruby and adds
  lots of useful Unicode-oriented features to String and Regexp)
- tested on 1.9 and 1.8 and correctly replaced invalid unicode with
  escaped hex value
```
* (QENG-1086) The master-start-curl-retries is preset to... (77610212)


```
(QENG-1086) The master-start-curl-retries is preset to...

...0, which causes default hosts not to retry verifying a bounced master.

- host value being overwritten by default presets
```
* (QENG-1081) Beaker Fails During Pre-suite in the "install_pe"... (f08d67b1)


```
(QENG-1081) Beaker Fails During Pre-suite in the "install_pe"...

... Function on Windows

- when using an array of hosts the command object was overwritten and
  thus the platform specific information was lost
```
### <a name = "beaker1.17.1">beaker1.17.1 - 12 Aug, 2014 (72e60299)

* Merge pull request #399 from anodelman/make-gem (72e60299)


```
Merge pull request #399 from anodelman/make-gem

create beaker 1.17.1 gem
```
* (HISTORY) update HISTORY.md for 1.17.1 gem (21480832)

* (GEM) create beaker 1.17.1 gem (07b67f32)

* Merge pull request #397 from anodelman/maint (3e86c6f8)


```
Merge pull request #397 from anodelman/maint

(MAINT) add ability to generate history for branch other than 'master'
```
* Merge pull request #398 from nicklewis/revert-jvm-master (d9c67d1e)


```
Merge pull request #398 from nicklewis/revert-jvm-master

Revert "(QENG-997) Add PE installer answer for jvm puppet."
```
* Revert "(QENG-997) Add PE installer answer for jvm puppet." (215e115f)


```
Revert "(QENG-997) Add PE installer answer for jvm puppet."

This reverts commit b06b6313de24da82a031b6b04dc95042812b4445.

The installer doesn't actually function with this answer set, so we
certainly shouldn't be making it the default.
```
* (MAINT) add ability to generate history for branch other than 'master' (76ad94d5)


```
(MAINT) add ability to generate history for branch other than 'master'

- want to be able to generate a new HISTORY.md file based upon a
  provided branch name
```
### <a name = "beaker1.17.0">beaker1.17.0 - 12 Aug, 2014 (fb482b56)

* Merge pull request #396 from anodelman/make-gem (fb482b56)


```
Merge pull request #396 from anodelman/make-gem

(GEM) create beaker 1.17.0 gem
```
* (HISTORY) add history for 1.17.0 gem (c04acf4d)

* (GEM) create beaker 1.17.0 gem (b2528072)

* Merge pull request #336 from anodelman/higgs-installer (2d65b8d0)


```
Merge pull request #336 from anodelman/higgs-installer

(QENG-751) Request for Higgs support in installing beaker
```
* Merge pull request #391 from waynr/fix/qeng-903-jvm-puppet-debian-support (d0719d5d)


```
Merge pull request #391 from waynr/fix/qeng-903-jvm-puppet-debian-support

(QENG-903) Debian platform support for jvm-puppet.
```
* Merge pull request #395 from waynr/feature/QENG-922-puppet-user-group-methods (3ebc92c1)


```
Merge pull request #395 from waynr/feature/QENG-922-puppet-user-group-methods

(QENG-922) Add `puppet_user` and `puppet_group` DSL methods.
```
* Merge pull request #390 from jpartlow/issue/master/qeng-188-foss-service-restarts-pe-unchanged (884cb9ae)


```
Merge pull request #390 from jpartlow/issue/master/qeng-188-foss-service-restarts-pe-unchanged

(QENG-188) Allow foss runs to use service scripts (pe unchanged)
```
* Merge pull request #385 from anodelman/scp-repair (6e0fcbaa)


```
Merge pull request #385 from anodelman/scp-repair

(QENG-1012) (gh-143) beaker scp moving data one byte at a time
```
* Merge pull request #387 from colinPL/qeng_1032 (32160885)


```
Merge pull request #387 from colinPL/qeng_1032

(QENG-1032) Fix for tests without a master host
```
* Merge pull request #392 from anodelman/maint (75b61a36)


```
Merge pull request #392 from anodelman/maint

(MAINT)(gh-210) series of commits to get beaker smoketest working in ec2
```
* (gh-210) Setting PATH, ignored :environment option (ad22e590)


```
(gh-210) Setting PATH, ignored :environment option

- we do not correctly handle adding additional environment variables to
  puppet commands, this patch allows you to add those env vars
```
* Merge pull request #389 from waynr/revert/qeng-188 (42f28681)


```
Merge pull request #389 from waynr/revert/qeng-188

Revert "(QENG-188) Allow foss runs to use service scripts, take 2"
```
* Revert "(QENG-188) Allow foss runs to use service scripts, take 2" (1d9300bc)


```
Revert "(QENG-188) Allow foss runs to use service scripts, take 2"

This reverts commit 577fce4dcaf4c6879157fd51777d6691eae1496d.
```
* Merge pull request #384 from jpartlow/issue/master/qeng-188-better-foss-service-restarts (4c991d24)


```
Merge pull request #384 from jpartlow/issue/master/qeng-188-better-foss-service-restarts

(QENG-188) Allow foss runs to use service scripts, take 2
```
* (QENG-1032) Fix for tests without a master host (76329613)


```
(QENG-1032) Fix for tests without a master host

If a master role is not defined in the current test's config, then
setting a default node will fail. The code is expecting "hosts" to be a
list, but it is actually a hash. This commit fixes this issue and
adds a new spec test to validate a non-master single node is set as
default.
```
* (QENG-903) Debian platform support for jvm-puppet. (e1c336db)


```
(QENG-903) Debian platform support for jvm-puppet.

A couple simple fixes for previously unvisited code paths.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #330 from anodelman/scp-ignore (5144958f)


```
Merge pull request #330 from anodelman/scp-ignore

(QENG-762) add support to beaker scp_to/scp_from to ignore files of ...
```
* Merge pull request #371 from anodelman/xml (7d1771f4)


```
Merge pull request #371 from anodelman/xml

(QENG-845) Beaker junit xml: XML Parsing error
```
* (MAINT) aws_sdk support repairs (8d318540)


```
(MAINT) aws_sdk support repairs

- vmhostname was being set incorrectly and breaking PE installation
- move instance metadata tag addition to after instance is running
- /etc/hosts generation fixed so that it has entries for all other hosts
  on each individual host
- add agent listen port (8139)
- fix zombie killing by correctly handling volumes that may not exist
  when attempted deletion occurs
```
* (QENG-1012) (gh-143) beaker scp moving data one byte at a time (8a4a72a8)


```
(QENG-1012) (gh-143) beaker scp moving data one byte at a time

- force chunk_size during transfer
- print more debug metrics so that we can monitor how quickly files are
  moved
```
* Merge pull request #362 from anodelman/revert-343-revert-237-role-repair (82f759c5)


```
Merge pull request #362 from anodelman/revert-343-revert-237-role-repair

(QENG-431) expanded and improved role support in beaker
```
* Merge pull request #381 from waynr/feature/qeng-969-add-modify-tk-config-dsl-method (30971c2b)


```
Merge pull request #381 from waynr/feature/qeng-969-add-modify-tk-config-dsl-method

(QENG-969) Fix bug introduced with last patch.
```
* Merge pull request #370 from anodelman/junit (a3733322)


```
Merge pull request #370 from anodelman/junit

(QENG-819) stderr collected for each testcase is incorrect...
```
* Merge pull request #375 from waynr/feature/qeng-997-add-pe-installer-answer-for-jvm-puppet (d6f8792a)


```
Merge pull request #375 from waynr/feature/qeng-997-add-pe-installer-answer-for-jvm-puppet

(QENG-997) Add PE installer answer for jvm puppet.
```
* Merge pull request #374 from justinstoller/bug/master/QENG-989_gem_install_on_solaris (fd4e7279)


```
Merge pull request #374 from justinstoller/bug/master/QENG-989_gem_install_on_solaris

(QENG-989,990) Clean up open source install rough edges
```
* (QENG-969) Fix bug introduced with last patch. (ab510c71)


```
(QENG-969) Fix bug introduced with last patch.

Last patch addressed some PR comments regarding coding style and led to bug
which is now fixed.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #378 from waynr/feature/qeng-969-add-modify-tk-config-dsl-method (4449be0f)


```
Merge pull request #378 from waynr/feature/qeng-969-add-modify-tk-config-dsl-method

Feature/qeng 969 add modify tk config dsl method
```
* (MAINT) add 61613 to open port list for ec2 instances (fa34996c)


```
(MAINT) add 61613 to open port list for ec2 instances

- 61613 needs to be open for MCO to work correctly
```
* Merge pull request #355 from doug-rosser/atop_integration (3c09294c)


```
Merge pull request #355 from doug-rosser/atop_integration

(QENG-807) add --collect-perf-data option, rspec tests, and yard docs
```
* (QENG-969) Addresss PR feedback. (ed31f189)


```
(QENG-969) Addresss PR feedback.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-922) Add `puppet_user` and `puppet_group` DSL methods. (2cf5ef87)


```
(QENG-922) Add `puppet_user` and `puppet_group` DSL methods.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Remove dead line of code (a423d969)

* (QENG-969) Update `with_puppet_running_on` spec test. (db5b45f1)


```
(QENG-969) Update `with_puppet_running_on` spec test.

Test that `with_puppet_running_on` actually uses `modify_tk_conf` when the
circumstances are right.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-969) Add modify_tk_config DSL method. (1aad9e7d)


```
(QENG-969) Add modify_tk_config DSL method.

Comes with some "private" helper methods for reading tk config strings and
merging or replacing the SUT config file using Beaker::Options::OptionsHash

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-997) Add PE installer answer for jvm puppet. (b06b6313)


```
(QENG-997) Add PE installer answer for jvm puppet.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-989,990) Clean up open source install rough edges (408b730a)


```
(QENG-989,990) Clean up open source install rough edges

This ensures that puppet and friends are available after gem installs on
Solaris and Debian. It also makes sure that the config directory and
hiera.yaml file are aways present. The former change fixes QENG-989 while
the latter fixes QENG-990).

[edit: to address pull request comments]
```
* Merge pull request #365 from anodelman/maint (01c7ac7a)


```
Merge pull request #365 from anodelman/maint

(QENG-941) create contributor documentation for beaker
```
* Merge pull request #369 from anodelman/options-hash (9215548a)


```
Merge pull request #369 from anodelman/options-hash

(gh-333) Typo in method name ('has' instead of 'hash') in ...
```
* Merge pull request #296 from anodelman/confine-agents (78a75ce6)


```
Merge pull request #296 from anodelman/confine-agents

(QENG-758) add ability to select a group a beaker hosts based upon...
```
* Merge pull request #248 from justinstoller/feature/master/QENG-515-debug_env_vars (4329e6b8)


```
Merge pull request #248 from justinstoller/feature/master/QENG-515-debug_env_vars

(QENG-515) Provide Important Env Vars Set in Debug Output
```
* (QENG-845) Beaker junit xml: XML Parsing error (d33c710e)


```
(QENG-845) Beaker junit xml: XML Parsing error

- need to strip out invalid characters from strings before printing to
  xml, these characters are still invalid even if wrapped in a cdata
  tag
```
* (QENG-819) stderr collected for each testcase is incorrect... (8a5ffb15)


```
(QENG-819) stderr collected for each testcase is incorrect...

...(as seen in beaker xml output)

- keep track of the last result generated through the ssh connection
- add the last stderr to the junit xml output
- clear the collected last result before each test case
```
* (gh-333) Typo in method name ('has' instead of 'hash') in ... (fa93b233)


```
(gh-333) Typo in method name ('has' instead of 'hash') in ...

... options_hash.rb (line 101)

- yup, fix the typo
```
* Merge pull request #368 from anodelman/ec2-killer (73fe9788)


```
Merge pull request #368 from anodelman/ec2-killer

(QENG-968) automate cleanup of zombie ec2 beaker instances generated by jenkins smoketests
```
* Merge pull request #367 from anodelman/move-to-ec2 (62ddb7dd)


```
Merge pull request #367 from anodelman/move-to-ec2

(QENG-844) move beaker smoketests over to ec2
```
* (QENG-968) automate cleanup of zombie ec2 beaker instances... (505a80fb)


```
(QENG-968) automate cleanup of zombie ec2 beaker instances...

... generated by jenkins smoketests

- add support to aws_sdk hypervisor to kill zombies that have alive
  longer than a given amount of hours
- make it possible to run beaker without a hosts_file, thus making it a
  script executor
```
* Merge pull request #321 from zaphod42/issue/master/race-in-stopping-master (75105eba)


```
Merge pull request #321 from zaphod42/issue/master/race-in-stopping-master

(QENG-840) Replace puppet.conf after stopping master
```
* (QENG-844) move beaker smoketests over to ec2 (1ee634e3)


```
(QENG-844) move beaker smoketests over to ec2

- add 'lsb-release' to required packages for debian boxes, it is not in
  our default ami's
```
* (maint) Create default for master-start-curl-retries (2f8bf654)


```
(maint) Create default for master-start-curl-retries

The master-start-curl-retries option did not have a default before.
Without the default it was possible to end up with a comparison against
null when retrying a check with curl (for checking that services are
running). This adds a default of 0 (no retries) to the presets.
```
* (QENG-941) create contributor documentation for beaker (5b1fc8a9)


```
(QENG-941) create contributor documentation for beaker

- create CONTRIBUTING.md
- covers steps necessary before PRs will be merged into Beaker
```
* (QENG-431) (cleanup + split out filtering) expanded and improved role support in beaker (83f8aed1)


```
(QENG-431) (cleanup + split out filtering) expanded and improved role support in beaker

- split out filtering from applying the block to hosts
- block_on now determines if we have a filter or not
- run_block_on accepts both a set of hosts and an optional filter
```
* (QENG-431) (cleanup) expanded and improved role support in beaker (24ba4467)


```
(QENG-431) (cleanup) expanded and improved role support in beaker

- cleanup in response to review comments
```
* Revert "Revert "(QENG-431) expanded and improved role support in beaker"" (2e0b33b8)

* Clean up and document reproduction info methods in Beaker::CLI (fbb11f82)

* (maint) Remove unneeded modifications to File (975ff81a)


```
(maint) Remove unneeded modifications to File

These modifications to the FakeFS::File class do not appear to be
needed. When they are removed all of the tests continue to work as
before.
```
* (QENG-751) Request for Higgs support in installing beaker (ced78c55)


```
(QENG-751) Request for Higgs support in installing beaker

- adds install_higgs command
- executes against master node
- downloads pe packages based upon pe_ver/pe_dir
- goes up to the point in the install where human interaction is
  required (notices indication in install log that a link has been
  provided to a web server)
```
* (QENG-840) Replace puppet.conf after stopping master (ae264bed)


```
(QENG-840) Replace puppet.conf after stopping master

A webrick master watches the puppet.conf file and will try to reload and
reapply the settings catalog when it changes. The with_puppet_running_on
method gets into a race with this behavior, plus bug PUP-2834, because
it puts the backed up puppet.conf back into place *before* trying to
shut down the master process. This caused the master to periodically
read the new configuration, fail in applying it, crash, and then beaker
would try to kill the process. The process was already dead and the kill
command ends up failing. This then causes the test to fail.

This changes it so that for webrick masters, the backed up file isn't
moved back into place until *after* the master has been shut down. Since
rack masters don't ever try to reread the config file, this doesn't
affect them. Also, in the rack case, the file needs to be moved into
place *before* the master is stopped since it is actually fully
restarted.
```
* (QENG-762) add support to beaker scp_to/scp_from to ignore files of ... (53fce7cd)


```
(QENG-762) add support to beaker scp_to/scp_from to ignore files of ...

... certain name/type

- added support to scp_to for an ignore list of files/dirs.  Does not
  support globbing.
```
* (QENG-807) add --collect-perf-data option, rspec tests, and yard docs (8d1a891d)

* (QENG-188) Allow foss runs to use service scripts, take 2 (577fce4d)


```
(QENG-188) Allow foss runs to use service scripts, take 2

Prior to this commit, any run of beaker with a non-pe master that
attempted to stand up a master with a particular configuration in order
to test against it using the with_puppet_running_on() helper would
always stand up a webrick master by executing `puppet master <args>` and
then later stop it with `kill`.

The platform team needs to be able to run acceptance suites in which the
puppetmaster is started/stopped using package provided init scripts, or
by restarting apache if a passenger puppetmaster package is installed.

This PR takes the approach of enhancing Beaker::Host with a few query
methods controlled by host properties, either set in the hosts.cfg, or
directly on a master Beaker::Host instance during the execution of a
setup step.  The added properties are:

 * 'use-service' : if true, service scripts will be used instead of
manually starting a webrick master
 * 'passenger'   : if true, indicates a passenger package has been
installed, and by default graceful service restarts will be used
 * 'puppetservice' : the 'puppetservice' property has been added to the
Beaker::Host::Unix.foss_defaults with the value of 'puppetmaster'.  It
should be set to the appropriate service script name for passenger if a
passenger package has been installed.
 * 'graceful-restarts' : can be set false if you want to stop/start with
service scripts rather than use graceful restarts when running with
passenger

The Beaker::Host#uses_passenger! call may be used to set a host
appropriately for passenger.

The graceful restarts facility of the dsl helper's bounce method assumes
apache2 was used for passenger and that apach2ctl is available.

Any existing test suite which does not 'opt-in' to any of these service
host changes by specifying any of the above properties should not be
effected by this commit.  The exception to this is that PE runs will use
graceful restarts automatically with this commit.

There is also a spec related change to the FakeHost helper, which
previously was a stub pretending to provide Beaker::Host like facilities
and recording commands for review.  This became unwieldy when the
various query methods for use_service_scripts? is_using_passenger? and
so forth were added, and the FakeHost has been updated to instead use
Beaker::Host.create to provide a host instance that is then extended
with the MockedExec module stubbing the exec facilities for testing.
```
* (QENG-188) Allow foss runs to use service scripts (44d18d5f)


```
(QENG-188) Allow foss runs to use service scripts

Prior to this commit, any run of beaker with a non-pe master that
attempted to stand up a master with a particular configuration in order
to test against it using the with_puppet_running_on() helper would
always stand up a webrick master by executing `puppet master <args>` and
then later stop it with `kill`.

The platform team needs to be able to run acceptance suites in which the
puppetmaster is started/stopped using package provided init scripts, or
by restarting apache if a passenger puppetmaster package is installed.

This PR takes the approach of enhancing Beaker::Host with a few query
methods controlled by host properties, either set in the hosts.cfg, or
directly on a master Beaker::Host instance during the execution of a
setup step.  The added properties are:

 * 'use-service' : if true, service scripts will be used instead of
manually starting a webrick master
 * 'passenger'   : if true, indicates a passenger package has been
installed, and by default graceful service restarts will be used
 * 'puppetservice' : the 'puppetservice' property has been added to the
Beaker::Host::Unix.foss_defaults with the value of 'puppetmaster'.  It
should be set to the appropriate service script name for passenger if a
passenger package has been installed.
 * 'graceful-restarts' : can be set false if you want to stop/start with
service scripts rather than use graceful restarts when running with
passenger

The Beaker::Host#uses_passenger! call may be used to set a host
appropriately for passenger.

The graceful restarts facility of the dsl helper's bounce method assumes
apache2 was used for passenger and that apach2ctl is available.

Any existing test suite which does not 'opt-in' to any of these service
host changes by specifying any of the above properties should not be
effected by this commit.

There is also a spec related change to the FakeHost helper, which
previously was a stub pretending to provide Beaker::Host like facilities
and recording commands for review.  This became unwieldy when the
various query methods for use_service_scripts? is_using_passenger? and
so forth were added, and the FakeHost has been updated to instead use
Beaker::Host.create to provide a host instance that is then extended
with the MockedExec module stubbing the exec facilities for testing.
```
* Ensure IS_PE only respects different values (36abc3d8)


```
Ensure IS_PE only respects different values

Previously if we set the IS_PE or BEAKER_IS_PE environment variable at
all we would automatically make the run a PE run. This caused
non-obvious behavior for users that set IS_PE=false.

This changes the searching of the environment to only set the :type
option if [BEAKER_]IS_PE=yes|true.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Improve documentation and readability of environment parsing improvements (b27ac271)

* (QENG-758) add ability to select a group a beaker hosts based upon... (6acb6147)


```
(QENG-758) add ability to select a group a beaker hosts based upon...

...a set of properties

- a shortcut means of selecting a sub group of hosts to run commands on
```
* (QENG-5156) Provide Important Env Vars Set in Debug Output (88c18537)


```
(QENG-5156) Provide Important Env Vars Set in Debug Output

This provides the Environment Variables that are pertinent to running
Beaker as an error message after a failed run or as a debug message
on a successful run in the debug log level.
```
### <a name = "beaker1.16.0">beaker1.16.0 - 17 Jul, 2014 (c1267696)

* Merge pull request #366 from anodelman/make-gem (c1267696)


```
Merge pull request #366 from anodelman/make-gem

(HISTORY) update history for release of beaker 1.16.0 gem
```
* (HISTORY) update history for release of beaker 1.16.0 gem (385f65c6)

* Merge pull request #364 from anodelman/make-gem (b0558827)


```
Merge pull request #364 from anodelman/make-gem

(GEM) version bump for beaker 1.16.0
```
* (GEM) version bump for beaker 1.16.0 (6664c6ab)

* Merge pull request #363 from puppetlabs/revert-359-issue/master/qeng-188-foss-service-restarts (56cfac77)


```
Merge pull request #363 from puppetlabs/revert-359-issue/master/qeng-188-foss-service-restarts

Revert "(QENG-188) Allow foss runs to use service scripts"
```
* Revert "(QENG-188) Allow foss runs to use service scripts" (dbfa7b23)

* Merge pull request #359 from jpartlow/issue/master/qeng-188-foss-service-restarts (d2464451)


```
Merge pull request #359 from jpartlow/issue/master/qeng-188-foss-service-restarts

(QENG-188) Allow foss runs to use service scripts
```
* Merge pull request #360 from anodelman/fail-slow (0d0c9239)


```
Merge pull request #360 from anodelman/fail-slow

(QENG-927) Beaker does not honor --fail-mode always fails fast
```
* (QENG-927) Beaker does not honor --fail-mode always fails fast (755f13eb)


```
(QENG-927) Beaker does not honor --fail-mode always fails fast

- bug comes from regex comparison with a symbol not being coerced to a
  string in ruby 1.8, simple adding a 'to_s' resolves this
```
* Merge pull request #358 from waynr/bugfix/ezbake-utils (b83f5299)


```
Merge pull request #358 from waynr/bugfix/ezbake-utils

(QENG-924) Fix Beaker::DSL::EZBakeUtils.conditionally_clone
```
* Merge pull request #357 from jpartlow/issue/master/qeng-923-ensure-platform-codename (06aa5b81)


```
Merge pull request #357 from jpartlow/issue/master/qeng-923-ensure-platform-codename

(QENG-923) Ensure @codename is set if platform string has codename
```
* (QENG-924) Fix Beaker::DSL::EZBakeUtils.conditionally_clone (b6cd1ac6)


```
(QENG-924) Fix Beaker::DSL::EZBakeUtils.conditionally_clone

Fetch from origin then checkout the origin HEAD.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-923) Ensure @codename is set if platform string has codename (26724829)


```
(QENG-923) Ensure @codename is set if platform string has codename

Beaker 1.14.0 and up has a change to Beaker::Platform which ensures that
@version and @codename is set if the platform string contains the
version number, and that @version is set if platform string contains the
codename, but it fails to set the @codename in this later case.

Puppet currently has debian/ubuntu configs checked (used in ci) which
use platform strings of the form debian-wheezy-x86_64. We could change
these, but it looks like the intention of the Beaker::Platform object is
to provide @version and @codename (where codenames are used).

This patch ensures that @codename is set along with @version in these
cases.
```
* Merge pull request #356 from anodelman/utf-8-encoding (842a0d99)


```
Merge pull request #356 from anodelman/utf-8-encoding

(QENG-912) Beaker 1.14 breaks PE Puppet Acceptance
```
* Merge pull request #354 from anodelman/scp-repair (6e0261f2)


```
Merge pull request #354 from anodelman/scp-repair

(QENG-6) Beaker DSL `scp_*` commands print the options hash as if...
```
* (QENG-912) Beaker 1.14 breaks PE Puppet Acceptance (928fad7f)


```
(QENG-912) Beaker 1.14 breaks PE Puppet Acceptance

- was too conservative in removing non utf-8 compliant characters -
  ended up removing compliant characters along with undef/invalid
  character codes
- tested locally and it preserved messages like:
/etc/puppet/modules
├── jimmy-appleseed (v1.1.0)
├── jimmy-crakorn (v0.4.0)
└── jimmy-thelock (v1.0.0)
- correctly removed actual undef/invalid characters so that string
  methods can be run (ie, split, gsub)
```
* Merge pull request #338 from anodelman/add-history (9e6acd2e)


```
Merge pull request #338 from anodelman/add-history

(QENG-849) beaker should maintain a history file that provides...
```
* (QENG-6) Beaker DSL `scp_*` commands print the options hash as if... (9aca3a1d)


```
(QENG-6) Beaker DSL `scp_*` commands print the options hash as if...

... it were executed on the command line
- simply remove the option hash from the debug line, it isn't
  appropriate there.
```
* (QENG-849) beaker should maintain a history file that provides... (04bf6d4f)


```
(QENG-849) beaker should maintain a history file that provides...

...information per gem release

- generate a markdown history file from beaker git log
```
* (QENG-188) Allow foss runs to use service scripts (881311ab)


```
(QENG-188) Allow foss runs to use service scripts

Prior to this commit, any run of beaker with a non-pe master that
attempted to stand up a master with a particular configuration in order
to test against it using the with_puppet_running_on() helper would
always stand up a webrick master by executing `puppet master <args>` and
then later stop it with `kill`.

The platform team needs to be able to run acceptance suites in which the
puppetmaster is started/stopped using package provided init scripts, or
by restarting apache if a passenger puppetmaster package is installed.

This PR makes a few additions to OptionsHash, Host and the DSL::Helpers
to allow us to distinguish foss hosts which were spun up from source
from those which were installed from packages.  And if we are working
with packages, whether we will be attempting to restart a running
service or stop/start using service scripts.
```
### <a name = "beaker1.15.0">beaker1.15.0 - 8 Jul, 2014 (82bb4ef9)

* Merge pull request #353 from anodelman/make-gem (82bb4ef9)


```
Merge pull request #353 from anodelman/make-gem

(HISTORY) generate history file for beaker 1.15.0
```
* (HISTORY) generate history file for beaker 1.15.0 (bd77ab99)

* Merge pull request #351 from anodelman/make-gem (cc636ca0)


```
Merge pull request #351 from anodelman/make-gem

(GEM) create beaker 1.15.0 gem
```
* Merge pull request #349 from justinstoller/maint/master/do-the-right-thing (e2c1be08)


```
Merge pull request #349 from justinstoller/maint/master/do-the-right-thing

(maint) Use `#check_for_command` instead of `#check_for_package`
```
* (GEM) create beaker 1.15.0 gem (e8e2e315)

* Merge pull request #348 from pcarlisle/qeng-894-systemd-with-puppet-running (2d1cfcb9)


```
Merge pull request #348 from pcarlisle/qeng-894-systemd-with-puppet-running

(QENG-894) Fix with_puppet_running_on for systemd
```
* Merge pull request #350 from anodelman/utf-8-encoding (ce612a91)


```
Merge pull request #350 from anodelman/utf-8-encoding

(QENG-912) Beaker 1.14 breaks PE Puppet Acceptance
```
* (QENG-912) Beaker 1.14 breaks PE Puppet Acceptance (1f83c04e)


```
(QENG-912) Beaker 1.14 breaks PE Puppet Acceptance

- seems to be an issue with string encoding
- ensure that we convert from current encoding to utf-8, doesn't mangle
  utf-8 strings and correctly converts binary strings
```
* Merge pull request #339 from pcarlisle/lucid-version-code (f2ad8dec)


```
Merge pull request #339 from pcarlisle/lucid-version-code

Add lucid support to platform version codes
```
* (maint) Improve `InstallUtils#install_puppet()` (1154f9bb)


```
(maint) Improve `InstallUtils#install_puppet()`

Use `#check_for_command` instead of `#check_for_package` where appropriate
in `#install_puppet`

Previously there was no `Host#check_for_command` method, but
`Host#check_for_package` did a `which` (it effectively was checking for
the command). Now that we've separated out that behavior we need to use
the ones we mean in `InstallUtils#install_puppet()`. This is important
because when we fall back to a gem install of Puppet we ensure there is
a command `gem` available from (often) the package `rubygems`.
```
* (QENG-894) Use puppet to restart puppet (94534f4d)


```
(QENG-894) Use puppet to restart puppet

This way we don't have to detect which init system is being used. Since this
is currently only used for with_puppet_running_on it should always have puppet
available.
```
* (MAINT) Whitespace for readability (4ee2980c)

* (MAINT) Add lucid support to platform version codes (387e00fd)

### <a name = "beaker1.14.1">beaker1.14.1 - 3 Jul, 2014 (d2e750d5)

* Merge pull request #342 from anodelman/make-gem (d2e750d5)


```
Merge pull request #342 from anodelman/make-gem

(GEM) create beaker 1.14.1 gem
```
* Merge pull request #344 from waynr/maint/fix-multi-dev-repo-case (a1a05782)


```
Merge pull request #344 from waynr/maint/fix-multi-dev-repo-case

(MAINT) Fixes `Beaker::DSL::InstallUtils` broken spec.
```
* (MAINT) Fixes `Beaker::DSL::InstallUtils` broken spec. (4ae74102)


```
(MAINT) Fixes `Beaker::DSL::InstallUtils` broken spec.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #343 from puppetlabs/revert-237-role-repair (97dfa7f2)


```
Merge pull request #343 from puppetlabs/revert-237-role-repair

Revert "(QENG-431) expanded and improved role support in beaker"
```
* Revert "(QENG-431) expanded and improved role support in beaker" (e72fb990)

* Merge pull request #237 from anodelman/role-repair (ee2ce01f)


```
Merge pull request #237 from anodelman/role-repair

(QENG-431) expanded and improved role support in beaker
```
* Merge pull request #341 from waynr/maint/fix-multi-dev-repo-case (7793e89f)


```
Merge pull request #341 from waynr/maint/fix-multi-dev-repo-case

(MAINT) Fix multiple dev repo installation case.
```
* (MAINT) Fix multiple dev repo installation case. (c5f8dac8)


```
(MAINT) Fix multiple dev repo installation case.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (GEM) create beaker 1.14.1 gem (180e712d)

* (QENG-431) expanded and improved role support in beaker (part 2) (ea90a311)


```
(QENG-431) expanded and improved role support in beaker (part 2)

- add support for running commands against hosts by name
- add support for arbitrary role methods, like those for built in roles
    eg, on master, "echo hello"
        on myrole, "echo hello"
```
* (QENG-431) expanded and improved role support in beaker (4797313e)


```
(QENG-431) expanded and improved role support in beaker

- make is possible to use arbitrary role names for most beaker DSL APIs
```
### <a name = "beaker1.14.0">beaker1.14.0 - 3 Jul, 2014 (cf8ea838)

* Merge pull request #340 from anodelman/make-gem (cf8ea838)


```
Merge pull request #340 from anodelman/make-gem

(GEM) create beaker 1.14.0 gem
```
* (GEM) create beaker 1.14.0 gem (d6e4282a)

* Merge pull request #322 from waynr/feature/install-dev-release-repos (67d0bca2)


```
Merge pull request #322 from waynr/feature/install-dev-release-repos

(QENG-715) Add `install_dev_repo` to Beaker DSL
```
* (QENG-715) Remove old `install_dev_repo` (448bcfb6)


```
(QENG-715) Remove old `install_dev_repo`

This method, rather than pushing repos to the SUT, has it pull from puppet labs
internal repository. This is deprecated by the newer
`Beaker::DSL::InstallUtils.install_dev_repo` which uses a push method.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #295 from waynr/feature/ezbake-utils (6243d6ac)


```
Merge pull request #295 from waynr/feature/ezbake-utils

(QE-725) Feature/ezbake utils
```
* (QENG-715) Add yard docs. (27922d8b)


```
(QENG-715) Add yard docs.

(QENG-715) Add new rspec tests.

(QENG-715) Give methods less generic names.

As pointed out in PR review, the use cases for these methods are pretty specific
and their names ought to reflect that specificity.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #335 from cyberious/FossWindows (d41e527e)


```
Merge pull request #335 from cyberious/FossWindows

Foss windows
```
* Merge pull request #316 from maestrodev/docker-ip (47a21a3b)


```
Merge pull request #316 from maestrodev/docker-ip

Use the correct docker server ip address for ssh
```
* Merge pull request #297 from cyberious/CopyModuleTo (b6707c6f)


```
Merge pull request #297 from cyberious/CopyModuleTo

refactor copy_root_module_to to copy_module_to and add support for ignore
```
* Merge pull request #327 from cyberious/master (7f5b05e6)


```
Merge pull request #327 from cyberious/master

Fix issue with run_task and invalid or undefined methods
```
* (QENG-715) Copy methods over from puppet acceptance lib. (49b70484)


```
(QENG-715) Copy methods over from puppet acceptance lib.

Copy `fetch`, `fetch_remote_dir`, and `install_repos_on` from puppet accentance
testing library since this functionality is actually useful on pretty much all
projects using Beaker. Still needs to be cleaned up and tuned to work in this
context.

(QENG-715) Minor code cleanup.

Matches when/case indentation levels.

(QENG-715) Use new `Beaker::Platform.to_array` method.

This method simplifies the logic by highlighting through semantics the
difference between `version` and `codename`.

(QENG-715) Remove hard-coded URIs.

Grab URIs from options presets instead of hard-coding. Do this for development
builds repositories, apt repositories, and yum repositories.

(QENG-715) Add `:dev_builds_url` to Beaker presets.

Use this in `Beaker::DSL::InstallUtils.install_repos_on`.

Also renames soem variables and standardize on how to populate a string pattern
with variables since the last couple commits were injecting variables directly
into the string.

(QENG-715) Separate release repo installation step.

Some pre_suites may only want to install the release repository.

(QENG-715) Clean up `install_release_repo`

Since we are installing a public repository we don't need to go through the
intermediate fetch step.

(QENG-715) Minor bug fix and code cleanup.

Don't scp files to a directory then move them to another directory in a later
step, instead copy them directly to their intended target directory.

Also fix some typos, bugs, and other miscellany.

(QENG-715) Break find-and-sed into smaller exprs.

(QENG-715) Raise RuntimeError instead of log message.

(QENG-715) Remove extraneous SUT commands.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #323 from branan/qeng_842 (1f875bbd)


```
Merge pull request #323 from branan/qeng_842

(QENG-842) Always wait for puppetmaster to be ready when bouncing
```
* (maint) Remove default value of service-wait since it is now unused. (187bfa57)

* (QENG-725) `install_from_ezbake` check for unsupported platforms (bd0b9c58)


```
(QENG-725) `install_from_ezbake` check for unsupported platforms

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-725) Add `ezbake_tools_available?` (f5468a97)


```
(QENG-725) Add `ezbake_tools_available?`

Add `Beaker::DSL::EZBakeUtils.ezbake_tools_available?` to ensure that both the development system and the
SUT have the required software necessary for this stuff to work correctly.

Also add spec tests for this new method and update existing method rspec tests to
verify that they actually use the new method where appropriate.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Fix issue with relver not defined in msi installer (c0d3baac)

* (QENG-725) Add attributes to `Beaker::Platform` (10633f79)


```
(QENG-725) Add attributes to `Beaker::Platform`

* Add attributes to `Beaker::Platform` and use those in
  `Beaker::Platform.with_numeric_version` and
  `Beaker::Platform.with_codename_version`.
* Add spec tests to confirm that `Beaker::Platform.codename` is nil when a given
  platform does not have version codenames and to verify behavior of
  `Beaker::Platform.to_array`
* Update `Beaker::DSL::EZBakeUtils` to make use of new
  `Beaker::Platform.to_array` method.
* Update `spec/beaker/dsl/ezbake_utils.rb` to use `Beaker::Platform` object.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #331 from justinstoller/fix_install_puppet (b77db165)


```
Merge pull request #331 from justinstoller/fix_install_puppet

Fix broken debian installs of FOSS puppet
```
* Merge pull request #329 from waynr/feature/curl-retries (ee4d52d7)


```
Merge pull request #329 from waynr/feature/curl-retries

(MAINT) Feature/curl retries
```
* Merge pull request #324 from anodelman/pe-in-debug (75acc306)


```
Merge pull request #324 from anodelman/pe-in-debug

(QENG-251) Beaker should be able to run the PE installer in debug mode
```
* Merge pull request #325 from anodelman/mac-support (2f36b29c)


```
Merge pull request #325 from anodelman/mac-support

(QENG-841) don't run beaker package configuration on osx hosts
```
* Revert the stderr out instead of stdout for not success (61243ce5)

* Merge pull request #332 from waynr/feature/QENG-846-add-timestamp-to-options-hash (016ca73a)


```
Merge pull request #332 from waynr/feature/QENG-846-add-timestamp-to-options-hash

(QENG-846) Add timestamp to options hash.
```
* Merge pull request #319 from waynr/feature/pe-34-answers (93e157e7)


```
Merge pull request #319 from waynr/feature/pe-34-answers

(MAINT) Add PE 3.4 installer answers module.
```
* (QENG-846) Add timestamp to options hash. (d3083c27)


```
(QENG-846) Add timestamp to options hash.

This makes the timestamp available globally during Beaker runs so it can be used
to add files to the specific run's log directory without being confused by other
simultaneous runs of Beaker due to the use of log/latest symlink.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Fix broken debian installs of FOSS puppet (3f8d2efc)


```
Fix broken debian installs of FOSS puppet

Previously some versions of apt would not resolve the puppet-common package
dependency for versions other than the latest release. This pins the
puppet-common package to the same version as puppet to prevent these issues.
```
* Fix issue with run_task and invalid or undefined methods (ad7837ba)

* (QENG-841) don't run beaker package configuration on osx hosts (bd564de3)


```
(QENG-841) don't run beaker package configuration on osx hosts

- beaker does not know how to install packages on osx, so we shouldn't
  try to
```
* (QENG-251) Beaker should be able to run the PE installer in debug mode (c94dc9b5)


```
(QENG-251) Beaker should be able to run the PE installer in debug mode

- add verbose mode for linux/mac and win installs.
- add '-x' for bash frictionless installer
- fix issue with non-UTF-8 encoded characters generated in windows logs
```
* (QENG-842) Always wait for puppetmaster to be ready when bouncing (46ef5703)


```
(QENG-842) Always wait for puppetmaster to be ready when bouncing

Previously, we would only wait for the puppetmaster to be started if a
host config file explicitly requested it. Our init scripts actually
require this waiting pretty much across the board now, so trying to
only do this when it's needed is silly. And even when it's not needed
we only curl once - it's not a ton of overhead.
```
* (QENG-715) Add `install_dev_repo` to Beaker DSL (9b337a21)


```
(QENG-715) Add `install_dev_repo` to Beaker DSL

This is a "push" style method of installing a dev repo from
builds.puppetlabs.lan by first downloading to a directory on the local machine
then pushing to the appropriate configuration directory on the remote machine.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #314 from anodelman/maint (ee2ad375)


```
Merge pull request #314 from anodelman/maint

(QENG-124) get rid of add_master_entry
```
* (MAINT) Add PE 3.4 installer answers module. (dde96af8)


```
(MAINT) Add PE 3.4 installer answers module.

Also adds spec tests.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-725) Improve install_from_ezbake (5deb8e4c)


```
(QENG-725) Improve install_from_ezbake

Need to be able to pass in arbitrary key-value pairs to add to environment in
which `make` is called on the given host in install_from_ezbake. If the hash is
empty, then don't prepend the `env` call to make.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Use the DOCKER_HOST environment when present for ssh to docker server (4793e5b7)


```
Use the DOCKER_HOST environment when present for ssh to docker server

Honor DOCKER_HOST envvar, used with boot2docker
```
* (QENG-124) get rid of add_master_entry (eb3be3e9)


```
(QENG-124) get rid of add_master_entry

- execution of add_master_entry has been off by default for a while, so
  we know that this code is no longer necessary, this is just clean up
```
* add alias to keep current functionality (f18c71da)

* Fixed test cases and bug with copy_module_to (3ec6077a)

* (QENG-725) Minor code cleanup and EZBakeUtils fix. (2f9ee267)


```
(QENG-725) Minor code cleanup and EZBakeUtils fix.

* Fixes defaultsdir argument passed to make in `install_from_ezbake` for debian
  systems.
* Adds `--force-yes` to apt-get calls when installing packages on debian.
* Minor code cleanup when interpreting package and version information from
  `ezbake_config`

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-716) Add package_version option to install_package. (9acb4f20)


```
(QENG-716) Add package_version option to install_package.

Makes more sense to make this optional behavior in `install_package` than to
implement new method.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* refactor copy_root_module_to copy_module_to, also changed the behavior of puppet_module_install_on to use the PMT tool instead of copying the whole file to it (1718342c)

* (QENG-725) Minor bugfix and documentation addition. (26d518d1)


```
(QENG-725) Minor bugfix and documentation addition.

* Document `ezbake_stage` method.
* Fix directory creation bug in `conditionally_clone` method.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-725) Adds spec tests for EZBakeUtils. (d5665ffb)


```
(QENG-725) Adds spec tests for EZBakeUtils.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-725) Implements install_from_ezbake. (b764cf51)


```
(QENG-725) Implements install_from_ezbake.

Adds a new module, Beaker::DSL::EZbake to extend the Beaker DSL with
functionality that should be useful across multiple JVM based projects,
particularly those that use TrapperKeeper and are packaged using ezbake.

Don't want to add user to system from install_from_ezbake, that should be done
at a higher level or from within a preinst step if absolutely necessary. Also
shouldn't be making any puppet calls using Beaker before the Puppet master is
run for the first time using init scripts since this will lead to
/var/lib/puppet directories being owned by root. Bad.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-716) install_package_version (720854c2)


```
(QENG-716) install_package_version

This commit adds 'install_package_version' method to the DSL helper utils and an
associated method that given package name as well as optional version string
that will be used to construct a package name that includes a specific version
string for installation on the SUT.

This currently only supports apt and yum based package managers, as I am no
familiar enough with other platforms. For non apt or yum based platforms, an
exception will be raised.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-645) Add `master-start-curl-retries` to host options. (2d499afe)


```
(QENG-645) Add `master-start-curl-retries` to host options.

Allows per-host modification of the number of curl retries to perform when
restarting puppet master.
```
### <a name = "beaker1.13.1">beaker1.13.1 - 23 Jun, 2014 (aa09552d)

* Merge pull request #318 from anodelman/make-gem (aa09552d)


```
Merge pull request #318 from anodelman/make-gem

(GEM) create 1.13.1 beaker gem
```
* (GEM) create 1.13.1 beaker gem (c268b1c9)

* Merge pull request #317 from waynr/bugfix/retry-command-should-use-logger-method (a993fc91)


```
Merge pull request #317 from waynr/bugfix/retry-command-should-use-logger-method

(MODULES-1168) Fixes use of Beaker logger in retry_command.
```
* (QENG-833) Fixes use of Beaker logger in retry_command. (ec906978)


```
(QENG-833) Fixes use of Beaker logger in retry_command.

Looks like the Beaker DSL always assumes a method, `logger`, that returns a
Logger object--assuming that the namespace loading the DSL modules has a logger
object available as `@logger` breaks beaker-rspec.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
### <a name = "beaker1.13.0">beaker1.13.0 - 20 Jun, 2014 (5e80c638)

* Merge pull request #315 from anodelman/make-gem (5e80c638)


```
Merge pull request #315 from anodelman/make-gem

(Gem) create 1.13.0 beaker gem
```
* (Gem) create 1.13.0 beaker gem (e863091e)

* Merge pull request #302 from waynr/feature/create-tmpdir-for-user-on (4381a238)


```
Merge pull request #302 from waynr/feature/create-tmpdir-for-user-on

Feature/create tmpdir for user on
```
* Merge pull request #313 from petems/fix_noop_to_nil (e0b93239)


```
Merge pull request #313 from petems/fix_noop_to_nil

Fix noop to nil
```
* Merge pull request #229 from anodelman/pkg-vs-cmd (7b0efa1b)


```
Merge pull request #229 from anodelman/pkg-vs-cmd

(QENG-608) Check_for_package method should not use which command
```
* Merge pull request #293 from anodelman/junit (3d16318c)


```
Merge pull request #293 from anodelman/junit

(QENG-714) use all junit tags available for beaker xml output
```
* GH-312 - Change test to check command line (229e24b0)

* GH-312 Fix spec to reflect that value is nil (397df127)

* GH-312 -  Value needs to be nil if it has no value (eb984967)

* Merge pull request #311 from treydock/docker_privileged_fix (12e74e51)


```
Merge pull request #311 from treydock/docker_privileged_fix

(gh-305) Start docker containers using privileged mode
```
* Merge pull request #300 from waynr/feature/logging-improvements (145e26b7)


```
Merge pull request #300 from waynr/feature/logging-improvements

Feature/logging improvements
```
* Merge pull request #309 from petems/add_noops_option (e2e97899)


```
Merge pull request #309 from petems/add_noops_option

Add noops option
```
* Merge pull request #298 from branan/qeng_64 (75ea39cd)


```
Merge pull request #298 from branan/qeng_64

(QENG-64) Fix ordering issue when deploying the frictionless agent
```
* Fixing spec (2f4e011c)

* Merge pull request #299 from justinstoller/update-to-install_puppet (82a34ef4)


```
Merge pull request #299 from justinstoller/update-to-install_puppet

(QENG-{768,769,771}) Update to `install puppet`
```
* Merge pull request #262 from justinstoller/feature/master/QENG-438-feature_flags (b10a8c0f)


```
Merge pull request #262 from justinstoller/feature/master/QENG-438-feature_flags

(QENG-438) Pass feature flags to all instances of `apply_manifest_on`
```
* Merge pull request #310 from anodelman/maint (6d7f36e3)


```
Merge pull request #310 from anodelman/maint

(MAINT) aws-sdk 1.43 breaks beaker specs
```
* (gh-305) Start docker containers using privileged mode (981e4d4b)

* Merge pull request #276 from cyberious/RakeTasks (8f5cbd56)


```
Merge pull request #276 from cyberious/RakeTasks

Rake tasks
```
* (MAINT) aws-sdk 1.43 breaks beaker specs (368575d9)


```
(MAINT) aws-sdk 1.43 breaks beaker specs

- pin to aws-sdk 1.42.0
```
* Adding yarddoc for :noop option (ac1803b5)

* Spec for the noops flag (ed2d52f3)

* Merge pull request #303 from anodelman/vagrant-maint (1a7942ca)


```
Merge pull request #303 from anodelman/vagrant-maint

(QENG-760) support for additional disk for vagrant
```
* Improve documentation for Open Source installation methods (77ea1f45)

* OptionsHash is already indifferent (d8f3f787)

* (QENG-760) support for additional disk for vagrant (d2449cab)


```
(QENG-760) support for additional disk for vagrant

- if a given vagrant box has a disk_path then either create a new vmdk
  disk or use the provided disk
- defaults to 50 x 1024 bytes if the disk needs to created
```
* Refactor `puppet_install` (09a519a3)


```
Refactor `puppet_install`

This changes the `puppet_install` function to be more readable and reduce
code duplication. It does not change any behavior.
```
* add tests for new install_puppet functionality (cc9da3ad)

* fixup test (be4c3016)

* Fixed issue with default behavior not picking up type and hosts from rake task (3bcbfe6d)

* (MAINT) Make retry_command output easier on the eyes. (7776fc93)


```
(MAINT) Make retry_command output easier on the eyes.

Silent all the "on" commands by passing silent => true to the underlying
host.exec in the options map. Instead, handle console/logfile output for
retry_command manually. Should significantly reduce logfile size for
applications that make extensive use of retry_command, not to mention making
stdout more readable.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (MAINT) Bugfixes in host.exec and logger. (26b25332)


```
(MAINT) Bugfixes in host.exec and logger.

* Honor the :silent option in host.exec
* Many logging functions seem to try to pass positional parameters in to
  optionally_color but mistakenly flattened the list into a single argument.
  This made it impossible to choose whether or not to add a newline.
* Remove call to logger.notify with bogus arity. Seems like "args" probably
  becomes an empty array which made this method call okay previously. However,
  if there are no arguments in "*args" then no args get passed down to
  optionally_color, thus the arity of the original "*args" is preserved.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Fixup windows support for FOSS (2ebb73f8)


```
Fixup windows support for FOSS

Previously the PATH for windows was only being set to include executables
from git repos, not executables installed from native packages. This
includes the default installation path for native windows packages in the
FOSS command creation.
```
* This fixes small bugs within the install_puppet method (8c1d3338)

* (QENG-64) Fix ordering issue when deploying the frictionless agent (6f1db0b6)


```
(QENG-64) Fix ordering issue when deploying the frictionless agent

Previously, the puppet agent was not stopped on the master until all
nodes were deployed. This could cause a situation where the background
agent would be running when we attempt to deploy the frictionless
repo. In this situation, the agent run we kick off to deploy the repo
would fail. This causes the entire beaker process to bail.

We now stop the background agent immediately, preventing this
condition from occuring.
```
* update documentation (63297276)

* Use specified versions if possible (0e0fd1e7)


```
Use specified versions if possible

Previously we allowed passing :version, :facter_version, and/or
:hiera_version to `install_puppet` but only respected `:version` with
windows and osx, and the others only on osx. This will attempt to
install the versions specified for any package specified. The version
information is still optional on linux machines, and there is no way for
us to respect the dependency versions on windows (since our windows
package is an omnibus package).
```
* Provide default gem installation (a4ac5847)


```
Provide default gem installation

This allows the `install_puppet` command to accept an additional parameter
`:default_action` which, if set to 'gem_install' will attempt to install
puppet from gem if it cannot otherwise install puppet. The default for
:default_action is still to fail hard.
```
* Get OSX installation working for realz (5d604a4f)


```
Get OSX installation working for realz

Previously we were using the passed in version for the versions of puppet
and its dependencies. This adds :facter_version and a :hiera_version keys
so that we can install those dependencies explicitly on platforms that we
must. It also adds the `-pkg` opt to the installer command to work on
newer OSXs.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* fixup merge conflicts (70491772)

* fix yard docs (1e947592)

* Remove the host tasks until we can fully bake what the use case is (fea24261)

* Remove assumption of delivery.puppetlabs.net (1aec8b3f)

* Add noop argument (4bfb3848)

* (QENG-713) Update to create_tmpdir_for_user, add spectests (afa13318)


```
(QENG-713) Update to create_tmpdir_for_user, add spectests

Use `on` instead of `host.exec`.
Also removes test for Unix::Host.puppet_tmpdir.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-713) Adds create_tmpdir_on DSL method. (2e899fe2)


```
(QENG-713) Adds create_tmpdir_on DSL method.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-713) use DSL to access --configprint value (3c9c17c7)

* Refactor to have a single maintainable file for test tasks and require the rake task object (d4ca624d)

* (QENG-713) add test case and docs for 'puppet_tmpdir' method (76e0a923)

* (QENG-713) add 'puppet_tmpdir' method (92ad65cb)


```
(QENG-713) add 'puppet_tmpdir' method

Add a 'puppet_tmpdir' method in Unix::File that creates temporary
directories which are owned by the puppet user.
```
* Add the commands to install OSX. (b6d24c90)

* (QENG-714/QENG-686) use all junit tags available for beaker xml output... (5aff9fc2)


```
(QENG-714/QENG-686) use all junit tags available for beaker xml output...

... provide local xslt for viewing beaker xml output

- switch over to nokogiri (cleaner, easier)
- add logs to system-out tag
- add tag for time that each test suite takes to execute
- add property tags for each beaker option
- add junit.xsl stylesheet to interpret test results
```
* (QENG-608) Check_for_package method should not use which command (23d471a2)


```
(QENG-608) Check_for_package method should not use which command

- properly differentiate between packages and commands
- check_for_package updated to check for the given package name using
  the correct package manager per OS
- added check_for_command, which uses 'which' to determine if a command
  is currently available
- added spec test coverage for check_for_package
```
* Add extendable rake task to have define on projects utilizing beaker (a7756853)

* (QENG-438) Pass feature flags to all instances of `apply_manifest_on` (8383b54a)


```
(QENG-438) Pass feature flags to all instances of `apply_manifest_on`

Prior to this there was a number of configurable options that would
tweak Puppet's behavior when using apply_manifest_on. However there
was no good way of setting all instances of apply_manifest_on to use
a certain set of flags. e.g. set "future" parser to be true for a specific
run of suite without changing all of the tests to explicitly set the
future parser option on apply_manifest_on. This allows users to set default
flags to be passed to puppet when apply_manifest_on is called in the host
file, or in a pre-test step.

Example Host file:
  HOSTS:
    master:
      roles: [ 'master', 'agent' ]
      default_apply_opts:
        parser: future

Example BeakerRSpec spec_helper.rb
  hosts.each do |host|
    host[:default_apply_opts] ||= {}
    host[:default_apply_opts].merge!( :parser => 'future' ) if ENV['FUTURE_PARSER'] == 'true'
  end
```
### <a name = "beaker1.12.2">beaker1.12.2 - 12 Jun, 2014 (a31ba183)

* Merge pull request #308 from anodelman/make-gem (a31ba183)


```
Merge pull request #308 from anodelman/make-gem

create 1.12.2 gem
```
* create 1.12.2 gem (9d534154)

* Merge pull request #306 from branan/qeng_775 (4f601ce7)


```
Merge pull request #306 from branan/qeng_775

(QENG-775) Do not use puppet to stop puppet on older PE on SLES
```
* Merge pull request #307 from anodelman/maint (c0e1e821)


```
Merge pull request #307 from anodelman/maint

(MAINT) update nokogiri dependency
```
* (MAINT) update nokogiri dependency (7f4428ff)


```
(MAINT) update nokogiri dependency

- Fixes: Unable to resolve dependencies: aws-sdk requires nokogiri (>= 1.4.4);
  rbvmomi requires nokogiri (>= 1.4.1); beaker requires nokogiri (=
  1.5.10); fog requires nokogiri (>= 1.5.11, ~> 1.5)
```
* (QENG-775) Do not use puppet to stop puppet on older PE on SLES (d6edc27b)


```
(QENG-775) Do not use puppet to stop puppet on older PE on SLES

A bug in the init script on older versions of SLES causes the init
script to kill our `puppet resource` invocation as well as the daemon
agent.
```
* Merge pull request #224 from anodelman/fix-default (7fb3468a)


```
Merge pull request #224 from anodelman/fix-default

(QENG-597) 'master' DSL helper can return a non-master node...
```
* Merge pull request #273 from electrical/feature/proxy (1565da4a)


```
Merge pull request #273 from electrical/feature/proxy

Add option to enable and set package manager proxy url
```
* Merge pull request #294 from smcclellan/remove-unneeded-razor-method (79105ca6)


```
Merge pull request #294 from smcclellan/remove-unneeded-razor-method

Removing unnecessary `razor` wrapper function
```
* Removing unnecessary `razor` wrapper function (2694de34)


```
Removing unnecessary `razor` wrapper function

The `razor` function was unnecessarily defined in the
wrapper, which was overriding a helper definition.
```
* Merge pull request #247 from JHaals/hypervisor (a4d3fd92)


```
Merge pull request #247 from JHaals/hypervisor

Support custom hypervisors
```
* Merge pull request #285 from anodelman/pry-support (57830472)


```
Merge pull request #285 from anodelman/pry-support

(QENG-695) beaker workflow with pry
```
* Merge pull request #290 from anodelman/remove-expand-path (a6e1c722)


```
Merge pull request #290 from anodelman/remove-expand-path

(QENG-40) remove expandpath from file loading in beaker require blocks
```
* (QENG-40) remove expandpath from file loading in beaker require blocks (0ec356f8)


```
(QENG-40) remove expandpath from file loading in beaker require blocks

- just use an expected path in requires
```
* (QENG-695) beaker workflow with pry (87807287)


```
(QENG-695) beaker workflow with pry

- add pry gem to development environment
```
* Add option to enable and set package manager proxy url (224480d6)


```
Add option to enable and set package manager proxy url

With this feature you can set the proxy url for the package manager.
Currently supports Yum and Apt package managers.
```
* Support custom hypervisors (230a47b3)

* (QENG-597) 'master' DSL helper can return a non-master node... (0121835a)


```
(QENG-597) 'master' DSL helper can return a non-master node...

...when actual master is confined away

- change around the logic so that the default node is defined at options
  parsing, not during test runtime
- determine the default node by it either being
  1.  the node with the role defined  as 'default'
  2.  the master node
  3.  the only node
  Then add the role 'default' to that node, if necessary
- differentiate between master and default, no longer allow the default
  to be used as a master if the master is undefined (keep roles clear,
  the master should only be the node defined as master)
```
### <a name = "beaker1.12.1">beaker1.12.1 - 30 May, 2014 (36b14dc7)

* Merge pull request #291 from anodelman/make-gem (36b14dc7)


```
Merge pull request #291 from anodelman/make-gem

create beaker 1.12.1 gem
```
* create beaker 1.12.1 gem (dfa26942)

* Merge pull request #288 from anodelman/options-hash-merge (aa5ab50f)


```
Merge pull request #288 from anodelman/options-hash-merge

(QENG-743) Beaker options hash 'merge' should not modify the...
```
* Merge pull request #287 from branan/qeng-740 (0375b148)


```
Merge pull request #287 from branan/qeng-740

(QENG-740) Insert a flag into the options hash when doing a PE upgrade
```
* (QENG-743) Beaker options hash 'merge' should not modify the... (25fa3529)


```
(QENG-743) Beaker options hash 'merge' should not modify the...

...global settings
- merge was behaving like merge!
- merging two OptionsHash objects should result in a new OptionsHash
  and not affect the original hashes at all.
```
* (QENG-740) Insert a flag into the options hash when doing a PE upgrade (13d4ffa8)

* Merge pull request #279 from electrical/docker_input_validation (30b79043)


```
Merge pull request #279 from electrical/docker_input_validation

Log an error when docker image is not set, empty or nil
```
* Merge pull request #283 from mhaskel/osx-mktemp-fix (1c54beae)


```
Merge pull request #283 from mhaskel/osx-mktemp-fix

For OSX the order of parameters for mktemp matters.
```
* For OSX the order of parameters for mktemp matters. (bec7d2c5)

* (MAINT) Log an error when docker image is not set, empty or nil (9adb1987)

* Merge pull request #268 from hunner/add_pm_install (f71cb779)


```
Merge pull request #268 from hunner/add_pm_install

Move puppet_module_install out of beaker-rspec
```
* Move puppet_module_install out of beaker-rspec (cb1615d5)

### <a name = "beaker1.12.0">beaker1.12.0 - 21 May, 2014 (591d3595)

* Merge pull request #272 from anodelman/make-gem (591d3595)


```
Merge pull request #272 from anodelman/make-gem

update beaker version to  1.12.0
```
* update beaker version to  1.12.0 (77ae9c7d)

* Merge pull request #270 from anodelman/mac-support (e7b4fa98)


```
Merge pull request #270 from anodelman/mac-support

add support for pe installation on mac
```
* Merge pull request #267 from branan/el4_is_lame_comma_yo (14b195a7)


```
Merge pull request #267 from branan/el4_is_lame_comma_yo

(maint) Do not use puppet to stop agent service on el4
```
* (QENG-337) additional platform support in beaker (mac osx) (part 2) (a0e6388c)


```
(QENG-337) additional platform support in beaker (mac osx) (part 2)

- add spec coverage for mac pe dmg install
```
* (maint) Do not use puppet to stop agent service on el4 (e0181123)

* (QENG-337) additional platform support in beaker (mac osx) (56c9540f)


```
(QENG-337) additional platform support in beaker (mac osx)

- adding dmg installation support for max osx
```
### <a name = "beaker1.11.2">beaker1.11.2 - 16 May, 2014 (f28c387b)

* Merge pull request #266 from branan/release_1.11.2 (f28c387b)


```
Merge pull request #266 from branan/release_1.11.2

Bump release version to 1.11.2
```
* Merge pull request #265 from branan/stop_agent_with_puppet (dd925b7b)


```
Merge pull request #265 from branan/stop_agent_with_puppet

(maint) Always use puppet to stop the agent service
```
* Bump release version to 1.11.2 (39cea895)

* Merge pull request #254 from nicklewis/root-keys-redirect (65c22a01)


```
Merge pull request #254 from nicklewis/root-keys-redirect

Follow redirects to get root keys script
```
* (maint) Always use puppet to stop the agent service (7df657fc)


```
(maint) Always use puppet to stop the agent service

Previously, the agent stop used platform-specific init management
tools. This is kind of silly, since we know that puppet exists. This
simplifies the agent stop to simply use puppet to stop the agent.
```
* Merge pull request #264 from branan/qeng-672 (5e79ed31)


```
Merge pull request #264 from branan/qeng-672

(QENG-672) Ensure beaker checks pe_dir from host as well as pe_ver
```
* (QENG-672) Ensure beaker checks pe_dir from host as well as pe_ver (4ec1a8df)


```
(QENG-672) Ensure beaker checks pe_dir from host as well as pe_ver

The previous code for QENG-672 only fixed the version lookup, not the
source path lookup.
```
* Merge pull request #263 from daniel-pittman/add-razor-command (d8cab43b)


```
Merge pull request #263 from daniel-pittman/add-razor-command

Add `razor` command helper to beaker
```
* Add `razor` command helper to beaker (79bdaf8a)


```
Add `razor` command helper to beaker

This adds a helper for testing Razor

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Follow redirects to get root keys script (d2097f53)


```
Follow redirects to get root keys script

This URL has changed from raw.github.com to raw.githubusercontent.com,
but the curl command wasn't following redirects. This updates the URL
and also adds the appropriate flag for redirects to protect against any
such future redirects.
```
### <a name = "beaker1.11.1">beaker1.11.1 - 15 May, 2014 (f684a724)

* Merge pull request #261 from anodelman/make-gem (f684a724)


```
Merge pull request #261 from anodelman/make-gem

create beaker 1.11.1 gem
```
* Merge pull request #256 from anodelman/google-cloud (3eb465ea)


```
Merge pull request #256 from anodelman/google-cloud

(gh-255) GCE metadata value not specified
```
* create beaker 1.11.1 gem (99d2388c)

* Merge pull request #252 from anodelman/maint (552692f0)


```
Merge pull request #252 from anodelman/maint

(MAINT) remove spaces before EOL
```
* Merge pull request #257 from anodelman/upgrade-ver (b0588a28)


```
Merge pull request #257 from anodelman/upgrade-ver

(QENG-672) Beaker will ignore host-specific pe_dir if a global pe_dir...
```
* Merge pull request #253 from electrical/docker_image_removal (1bd03328)


```
Merge pull request #253 from electrical/docker_image_removal

Add option to preserve the built docker image
```
* Merge pull request #246 from justinstoller/feature/master/QENG-514-print_original_command (e42c17c0)


```
Merge pull request #246 from justinstoller/feature/master/QENG-514-print_original_command

(QENG-514) Provide the Command Beaker was Ran with in Debug Output
```
* (QENG-672) Beaker will ignore host-specific pe_dir if a global pe_dir... (6338dc34)


```
(QENG-672) Beaker will ignore host-specific pe_dir if a global pe_dir...

... is set

- check the individual host version setting first then default to the
  global options hash
```
* (gh-255) GCE metadata value not specified (85a20877)


```
(gh-255) GCE metadata value not specified

- do not set nil/'' values as metaData
- do not set metaData at all if there are no values
```
* Add option to preserve the built docker image (85380b03)


```
Add option to preserve the built docker image

With the nodeset config option 'docker_preserve_image' we can disable the image deletion.
This is useful when running in CI environments and multiple containers are built using the same dockerfile content and re-used allot of times.
```
* (MAINT) remove spaces before EOL (9593ed5d)


```
(MAINT) remove spaces before EOL

- cleanup!
```
* Do not destructively consume ARGV (d8796847)


```
Do not destructively consume ARGV

Previously we were calling parse! which has the side effect of deleting
options from ARGV as it recognizes them. To work around this behavior
in previous commits, the desired options needed to be saved before hand.
Simply not mutating ARGV is much easier. Also adds a test.
```
* Merge pull request #250 from anodelman/mac-support (63a9c205)


```
Merge pull request #250 from anodelman/mac-support

(MAINT) add support for osx
```
* (MAINT) add support for osx (b07fed2c)


```
(MAINT) add support for osx

- so far, just add it to the supported platforms list
```
* Merge pull request #244 from justinstoller/maint/master/refactor_parser_tests (448d7d4c)


```
Merge pull request #244 from justinstoller/maint/master/refactor_parser_tests

Refactor parser specs to be more robust
```
* Merge pull request #236 from liamjbennett/windows_instalpuppet (aae95824)


```
Merge pull request #236 from liamjbennett/windows_instalpuppet

adding support for windows to install_puppet
```
* (QENG-514) Provide the Command Beaker was Ran with in Debug Output (312c7797)


```
(QENG-514) Provide the Command Beaker was Ran with in Debug Output

This prints at the end of the run the application & arguments to stdout
if log level is debug *or* if the run failed.
```
* Refactor parser specs to be more robust (0bee5099)


```
Refactor parser specs to be more robust

This removes unnecessary tests and changes the expected output
to only test for the parsed inputs (not testing the default values)
```
* updating install_puppet to support 32-bit windows (005a49c6)

* adding support for windows to install_puppet (b9dde43f)

### <a name = "beaker1.11.0">beaker1.11.0 - 8 May, 2014 (a389e3d1)

* Merge pull request #245 from anodelman/make-gem (a389e3d1)


```
Merge pull request #245 from anodelman/make-gem

create beaker 1.11.0 gem
```
* create beaker 1.11.0 gem (12553059)

* Merge pull request #242 from anodelman/jwt-break (0ae54018)


```
Merge pull request #242 from anodelman/jwt-break

(QENG-655) beaker dying on ruby 1.8 with jwt gem version mismatch...
```
* (QENG-655) beaker dying on ruby 1.8 with jwt gem version mismatch... (468f1ff6)


```
(QENG-655) beaker dying on ruby 1.8 with jwt gem version mismatch...

... error from google-api-client

- jwt was updated today and caused this break
```
* Merge pull request #239 from mhaskel/allow-el-7 (96bf2669)


```
Merge pull request #239 from mhaskel/allow-el-7

Add ability to run install_puppet with el7.
```
* Add ability to run install_puppet with el7. (bcc1b863)

* Merge pull request #234 from liamjbennett/windows_add_module_path (ac676e17)


```
Merge pull request #234 from liamjbennett/windows_add_module_path

adding modulepath to apply_manifest_on
```
* Merge pull request #235 from liamjbennett/fix_sshtoroot (3a65fb86)


```
Merge pull request #235 from liamjbennett/fix_sshtoroot

fixing ssh_to_root when run on windows
```
* adding yardoc for new option (94d2586a)

* fixing ssh_to_root when run on windows (a8180fcf)

* adding modulepath to apply_manifest_on (4e2b1f05)

* Merge pull request #221 from anodelman/env-fix (dc11aa26)


```
Merge pull request #221 from anodelman/env-fix

(QENG-275) redesign beaker's env var support
```
* Merge pull request #233 from anodelman/fix-travis (2c863726)


```
Merge pull request #233 from anodelman/fix-travis

(MAINT) travis failing on ruby 1.8
```
* (MAINT) travis failing on ruby 1.8 (4ccd0efb)


```
(MAINT) travis failing on ruby 1.8

 - https://github.com/travis-ci/travis-ci/issues/2217
   Ruby 1.8.7 installs ree-1.8.7-2012.02 instead of MRI
```
* Merge pull request #225 from johnduarte/QENG-600 (2ec3aaa7)


```
Merge pull request #225 from johnduarte/QENG-600

(QENG-600) Install lsb-release package if needed
```
* (QENG-600) Change package install call to host.package_install (eb2370fa)

* Merge pull request #206 from justinstoller/maint/master/QENG-430-addtl_win_defaults (b658b9ab)


```
Merge pull request #206 from justinstoller/maint/master/QENG-430-addtl_win_defaults

(QENG-430) Add moduledir defaults to windows hosts
```
* Merge pull request #223 from cyberious/InstallRootModule (4a140f8a)


```
Merge pull request #223 from cyberious/InstallRootModule

Add ability to copy root module out to a host server
```
* Merge pull request #231 from anodelman/1.8-travis-failures (465d62bb)


```
Merge pull request #231 from anodelman/1.8-travis-failures

(MAINT) add redcarpet gem for travis errors
```
* (MAINT) add redcarpet gem for travis errors (379a59ff)


```
(MAINT) add redcarpet gem for travis errors

- add redcarpet gem (pinned to 1.17.2) required by
  yard

- do not run yard on ruby 1.8 because of this:

  [error]: Missing 'redcarpet' gem for Markdown formatting. Install it
  with `gem install redcarpet`
```
* Convert to using options instead of params for copy_root_module_to (a0d73bc9)

* Merge pull request #228 from anodelman/yard-travis (85687615)


```
Merge pull request #228 from anodelman/yard-travis

(MAINT) add travis coverage for yard docs
```
* Merge pull request #226 from anodelman/yard-fix (5257d02b)


```
Merge pull request #226 from anodelman/yard-fix

(MAINT) yard doc errors/warnings
```
* (MAINT) add travis coverage for yard docs (42805fb4)


```
(MAINT) add travis coverage for yard docs

- will stop us from checking in yard doc warnings/errors
```
* (MAINT) yard doc errors/warnings (6e734ddd)


```
(MAINT) yard doc errors/warnings

- cleaned up any existing yard doc errors and warnings
```
* (QENG-600) Install lsb-release package if needed (ede28dea)


```
(QENG-600) Install lsb-release package if needed

For Debian and Ubuntu systems, check if lsb-release package is
installed. Install if needed. This package is needed to correctly
determine the release packages of puppet to install on the SUT.
This package is not present on a minimal Debian 7 installation.
```
* Merge pull request #171 from richardc/docker (a790c0bf)


```
Merge pull request #171 from richardc/docker

Add a docker hypervisor
```
* rename extra_commands to docker_image_commands (dfa40d7b)


```
rename extra_commands to docker_image_commands

Before all the docker handles were prefixed with docker_ *apart* from the one
for extra_commands.  For consistency rename it.
```
* Add ability to copy root module out to a host server (b9bd845d)

* don't allow docker on ruby 1.8 (063a8183)


```
don't allow docker on ruby 1.8

- don't add the gem 'docker' if using < ruby 1.9
- don't 'require docker' until we are sure that we are loading that
  class
- raise an error if attempting to use the docker hypervisor with ruby <
  1.9
```
* Add moduledir defaults to windows hosts (f2cc22de)

* Add spec testing to the docker hypervisor (2c159e77)

* Make the mkdir always succeed (76ad591d)


```
Make the mkdir always succeed

In some docker images the /var/run/sshd directory already exists, so mkdir will
exit non-zero and fail.  Change to mkdir -p instead.
```
* Add RHEL variant platforms to docker hypervisor (584c2c81)


```
Add RHEL variant platforms to docker hypervisor

When doing PE testing the platform name is used to determine which
PE tarball is required.  For RedHat Enterprise Linux derivatives
the platform identifier is /^el-/
```
* Handle errors at cleanup of docker resources (a9728382)


```
Handle errors at cleanup of docker resources

* catches images and container exceptions
* show proper error message from docker
```
* Cleanup intermediate images during image.build (e32f8ee5)


```
Cleanup intermediate images during image.build

We always build images to throw them away, so specify { :rm => true } to the
build options so we discard the intermediate images too.
```
* Expose logging from docker-api (e2d24b8f)


```
Expose logging from docker-api

This commit exposes the logging from docker-api into the normal
beaker logging.
```
* Refactor the flow of platform specific actions (a197d7d7)


```
Refactor the flow of platform specific actions

The previous flow (using the return value from the case statement) was
needlessly complex and caused some confusion.  Refactor to add more explicit
appends to the dockerfile variable in each when block.
```
* Install ssh clients in the docker hypervisor (0f6f097d)


```
Install ssh clients in the docker hypervisor

Some docker base images are seriously stripped down and will not
include the ssh client packages.  These are normally where the scp
and sftp binaries live which are needed in later provisioning steps.
```
* Increase read/write timeouts in the docker hypervisor (e5585675)


```
Increase read/write timeouts in the docker hypervisor

This change increases the read and write timeouts to the docker api.
By default this is 60 seconds

Additionally we use the version assertion from docker-api so we
don't try and talk to an incompatible api version.
```
* (QENG-275) redesign beaker's env var support (aa7bb857)


```
(QENG-275) redesign beaker's env var support

- move all env vars reading to options parsing
- rename beaker env vars to match format BEAKER_*name*, still support
  old name format for now
```
* Add a `docker_cmd` option to the docker hypervisor (09200f34)


```
Add a `docker_cmd` option to the docker hypervisor

This opens up the ability to have the docker container run something
closer to an init rather than a simple sshd.  This allows the
container to behave more like a system under test with fully working
service supervision.
```
* Add openSUSE and SLES support to docker hypervisor. (8bae0903)


```
Add openSUSE and SLES support to docker hypervisor.

On SUSE variants the package installer is called zypper, so add the
RUN statements to install the sshd in terms of zypper.

Additionally we need to explictly configure the sshd to allow root
login via passwords, bypassing pam.
```
* Add a docker hypervisor (f1634157)


```
Add a docker hypervisor

This is a quite simple hypervisor, and only supports linux flavours
currently.  Many things around inter-node communications will
probably not work.

The basic approach is we spin up a new image based on an upstream
one, add a sshd to it, tag the image with the name of the host and
then create a container from it.  This container should then be
usable as a system under test.

The implementation is largely based on both the existing Beaker::Vagrant
hypervisor, and docker-kitchen.
https://github.com/portertech/kitchen-docker All bugs are mine.

Still a few things to do around finding existing nodes, but for now
it makes basic enough images that you can run no tests in 11 seconds.

    $ cat docker-test.yml
    HOSTS:
      ubuntu-12-10:
        platform: ubuntu-12.10-x64
        image: ubuntu:12.10
        hypervisor: docker
    CONFIG:
       type: foss



$ time ruby -Ilib ./bin/beaker --hosts docker-test.yml   --no-debug
{
    "log_level": "info",
    "trace_limit": 10,
    "hosts_file": "docker-test.yml",
    "options_file": null,
    "type": "foss",
    "provision": true,
    "preserve_hosts": "never",
    "root_keys": false,
    "quiet": false,
    "xml": false,
    "color": true,
    "dry_run": false,
    "timeout": 300,
    "fail_mode": "slow",
    "timesync": false,
    "repo_proxy": false,
    "add_el_extras": false,
    "consoleport": 443,
    "pe_dir": "/opt/enterprise/dists",
    "pe_version_file": "LATEST",
    "pe_version_file_win": "LATEST-win",
    "dot_fog": "/Users/richardc/.fog",
    "ec2_yaml": "config/image_templates/ec2.yaml",
    "help": false,
    "ssh": {
        "config": false,
        "paranoid": false,
        "timeout": 300,
        "auth_methods": [
            "publickey"
        ],
        "port": 22,
        "forward_agent": true,
        "keys": [
            "/Users/richardc/.ssh/id_rsa"
        ],
        "user_known_hosts_file": "/Users/richardc/.ssh/known_hosts"
    },
    "HOSTS": {
        "ubuntu-12-10": {
            "roles": [
                "master"
            ],
            "platform": "ubuntu-12.10-x64",
            "image": "ubuntu:12.10",
            "hypervisor": "docker",
            "extra_commands": [
                "touch /tmp/foo"
            ]
        }
    },
    "helper": [],
    "load_path": [],
    "tests": [],
    "pre_suite": [],
    "post_suite": [],
    "install": [],
    "modules": [],
    "logger": "#<Beaker::Logger:0x007fbd9f087910>"
}
Beaker::Hypervisor, found some docker boxes to create
Provisioning docker
provisioning ubuntu-12-10

Setup: Update /etc/hosts on master with master's ip
Add Master entry to /etc/hosts
No tests to run for suite 'pre_suite'
No tests to run for suite 'tests'
No tests to run for suite 'post_suite'
Cleanup: cleaning up after successful run
Cleaning up docker
systest completed successfully, thanks.

real    0m11.892s
user    0m0.825s
sys     0m0.115s


```
### <a name = "beaker1.10.0">beaker1.10.0 - 22 Apr, 2014 (fbef5d2b)

* Merge pull request #220 from anodelman/make-gem (fbef5d2b)


```
Merge pull request #220 from anodelman/make-gem

create beaker 1.10.0 gem
```
* create beaker 1.10.0 gem (07b37988)

* Merge pull request #219 from kylog/maint/remove-unneeded-apt-get-install-options (bb199d3e)


```
Merge pull request #219 from kylog/maint/remove-unneeded-apt-get-install-options

(maint) Remove unneeded options for 'apt-get update'
```
* (maint) Remove unneeded options for 'apt-get update' (46abba11)


```
(maint) Remove unneeded options for 'apt-get update'

Previously apt-get update was invoked with the -y -f -m
options. None of these options actually make sense for *update*
(though -y makes total sense for *install*). Starting with
trusty's apt-get, apt-get actually rejects (at least) -f for
apt-get install.

So this patch simply removes those unneeded options.
```
* Merge pull request #217 from anodelman/fix-filesort (461dc5ff)


```
Merge pull request #217 from anodelman/fix-filesort

(MAINT) correctly sort test files
```
* (MAINT) correctly sort test files (43f58f85)


```
(MAINT) correctly sort test files

- turns out that we aren't actually correctly sorting files and this
  affects how tests are run on hosts.
```
* Merge pull request #216 from anodelman/wrap-ip (935bf5b4)


```
Merge pull request #216 from anodelman/wrap-ip

(QENG-486) add easy access to ip address per beaker host
```
* (QENG-486) add easy access to ip address per beaker host (5ab04522)


```
(QENG-486) add easy access to ip address per beaker host

- either use the already determined ip address or figure it out through
  ifconfig/ipconfig
```
* Merge pull request #214 from cyberious/windows_vagrant (e19b0f1d)


```
Merge pull request #214 from cyberious/windows_vagrant

Add beaker windows support to auto identify port and guest
```
* Merge pull request #211 from waynr/features/arbitary-puppetservice-name_curl-with-retries (9287c068)


```
Merge pull request #211 from waynr/features/arbitary-puppetservice-name_curl-with-retries

Features/arbitary puppetservice name curl with retries
```
* Merge pull request #207 from electrical/future_parser (1022e573)


```
Merge pull request #207 from electrical/future_parser

Add future parser as option when applying a manifest
```
* Add beaker windows support to auto identify port and guest (103b00eb)

* Merge pull request #203 from kbarber/ticket/master/pdb-554 (e055e6c9)


```
Merge pull request #203 from kbarber/ticket/master/pdb-554

Ticket/master/pdb 554 Fix zombied instances and volumes for EC2
```
* Merge pull request #209 from anodelman/optional-validation (1fb25d3a)


```
Merge pull request #209 from anodelman/optional-validation

(QENG-433) make validation steps in beaker optional
```
* Merge pull request #202 from anodelman/exit-with-xml (43e2f8b0)


```
Merge pull request #202 from anodelman/exit-with-xml

(QENG-409) Beaker does not write out JUnit XML when...
```
* Add test and yardoc (d1d7f05e)

* PDB-554 Remove wait_for_ssh now the underlying layers handles it (cc9bd071)


```
PDB-554 Remove wait_for_ssh now the underlying layers handles it

Signed-off-by: Ken Barber <ken@bob.sh>
```
* (QENG-425) Alter with_puppet_running_on logic. (ec2dba43)


```
(QENG-425) Alter with_puppet_running_on logic.

Only use initscript to restart if puppetservice is defined.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* Merge pull request #205 from anodelman/vmname-confusion (71e3db8e)


```
Merge pull request #205 from anodelman/vmname-confusion

(maint) create host.hostname procedure
```
* Merge pull request #197 from anodelman/google-cloud (3666309c)


```
Merge pull request #197 from anodelman/google-cloud

(QENG-407) update google compute to differentiate between template and platform
```
* PDB-554 Execute configure_hosts() after wait_for_ssh() (b8a47ead)


```
PDB-554 Execute configure_hosts() after wait_for_ssh()

Signed-off-by: Ken Barber <ken@bob.sh>
```
* PDB-554 Provide a bare minimum /etc/hosts for Ubuntu 10.04 compatibility (cf1f6760)


```
PDB-554 Provide a bare minimum /etc/hosts for Ubuntu 10.04 compatibility

Signed-off-by: Ken Barber <ken@bob.sh>
```
* PDB-554 Use ec2's dynamic names (db5f514e)


```
PDB-554 Use ec2's dynamic names

This obviates the need for /etc/hosts modification by using the EC2 public
names only.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* PDB-554 Correct handling of /etc/hosts creation and ensure hostnames are set (8d0e76c8)


```
PDB-554 Correct handling of /etc/hosts creation and ensure hostnames are set

Signed-off-by: Ken Barber <ken@bob.sh>
```
* PDB-554 Use hack_etc_hosts instead and make a wait_for_ssh method (1b7fb16d)


```
PDB-554 Use hack_etc_hosts instead and make a wait_for_ssh method

The wait_for_ssh method works around a race during provisioning whereby a
machine can come up and be ready for SSH connections, but you will get an
authenthentication error if you try to quickly.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* (QENG-425) Support optional curl_with_retries behavior. (f8410ada)


```
(QENG-425) Support optional curl_with_retries behavior.

Specifically, when restarting the puppet master using the initscript/service,
allow per-host configuration to specify whether or not to actually wait for the
puppet master to listen on port 8140 by attemping to grok with. Try up to 120
times at 1-second intervals.

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* (QENG-425) Generalize with_puppet_running_on method. (2b56e90a)


```
(QENG-425) Generalize with_puppet_running_on method.

Instead of always using pe-httpd as the service name for PE Puppet master, set
that as the default and allow customization on a per-host basis (probably
through Beaker config).

Signed-off-by: Wayne <wayne@puppetlabs.com>
```
* PDB-554 Decompose #provision and break out amiports into its own class (e8be9cf8)


```
PDB-554 Decompose #provision and break out amiports into its own class

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Merge pull request #201 from maestrodev/provision-anyway (628d712c)


```
Merge pull request #201 from maestrodev/provision-anyway

If provision option is set to false but Vagrantfile not found, then provision anyway
```
* Error early if provision option is set to false but Vagrantfile not found (20ae80b4)


```
Error early if provision option is set to false but Vagrantfile not found

User needs to enable provision
```
* (QENG-433) make validation steps in beaker optional (e2fa5239)


```
(QENG-433) make validation steps in beaker optional

- turn on/off with -(-no)-validate
- defaults to 'true'
```
* Add future parser as option when applying a manifest (6eb69b1e)


```
Add future parser as option when applying a manifest

This option can enable the use of the future parser when applying a manifest.
I'm not 100% sure though what it will do on older puppet versions that don't support that option.
```
* (maint) create host.hostname procedure (27581ea9)


```
(maint) create host.hostname procedure

- convenience method for accessing the hostname of the given host
```
* PDB-554 Set ENV variable jenkins_build_url to ensure test matches (5fffee41)


```
PDB-554 Set ENV variable jenkins_build_url to ensure test matches

Signed-off-by: Ken Barber <ken@bob.sh>
```
* firewall + ssh fixes for google compute (e45b4694)


```
firewall + ssh fixes for google compute

- firewall allows ports 8080/8081
- retry on failure to authenticate errors (happens when google compute
  boxes haven't successfully spun up yet)
```
* PDB-554 Add image checking and root device setup (5b9b7da1)


```
PDB-554 Add image checking and root device setup

Signed-off-by: Ken Barber <ken@bob.sh>
```
* (QENG-409) Beaker does not write out JUnit XML when... (5a8b5297)


```
(QENG-409) Beaker does not write out JUnit XML when...

...certain internal exceptions occur
- on ruby 1.8 Timeouts are raised as Interrupt (parented by SignalException)
  instead of out of RuntimeError (which is parented by StandardError) and are
  thus not being caught appropraitely.
- added spec test coverage for correct error reporting
```
* PDB-554 Implement a new EC2 backend and add jenkins_build_url to tags (44e8258a)


```
PDB-554 Implement a new EC2 backend and add jenkins_build_url to tags

This patch implements a replacement for the blimpy backend. It replaces the
use of blimpy to launch EC2 nodes with the Amazon AWS::EC2 library.

This was introduced to provide more control over handling error states, without
the granular control of a lower level library we are relying on blimpy to have
error handling (which it largely does not).

My theory was that we could either improve blimpy to do more, or just replace
it with a better driver that allows us to maintain our provisioning code on
its own without worrying about an upstream project. Since we don't use blimpy
for anything else, and we don't want the delay of having an upstream project
release our changes replacement seemed like a better option.

The driver is initiated with the hypervisor: ec2 setting in the users template
files and is built to match the blimpy behaviour in the way it configures
security groups and key pairs. To a reasonable extent users using blimpy right
now should be able to switch over with very little change.

As an aside, I've also added the ability to pass through the BUILD_URL from
a jenkins job as a tag in EC2 (and I've added this code to GCE as well). This
allows a better traceback from VM's to a particular job so we can identify
zombied jobs better.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* (QENG-407) update google compute to differentiate between template and platform (b29dcfcd)


```
(QENG-407) update google compute to differentiate between template and platform

- assume that the google compute image name will be in host[:image],
  otherwise default to host[:platform]
- fixes up the differentiations between google naming rules and our
  internal platform naming rules
```
### <a name = "beaker1.9.1">beaker1.9.1 - 27 Mar, 2014 (747ee73e)

* Merge pull request #196 from anodelman/make-gem (747ee73e)


```
Merge pull request #196 from anodelman/make-gem

create beaker 1.9.1 gem
```
* create beaker 1.9.1 gem (edc0a229)


```
create beaker 1.9.1 gem

- fix vagrant support
```
* Merge pull request #195 from anodelman/vagrant-etc-hosts (c28beef8)


```
Merge pull request #195 from anodelman/vagrant-etc-hosts

(maint) vagrant hypervisor support broken by bad call to hack_etc_hosts
```
* (maint) vagrant hypervisor support broken by bad call to hack_etc_hosts (843135a3)


```
(maint) vagrant hypervisor support broken by bad call to hack_etc_hosts

- nertz
```
### <a name = "beaker1.9.0">beaker1.9.0 - 26 Mar, 2014 (7feb8327)

* Merge pull request #194 from anodelman/make-gem (7feb8327)


```
Merge pull request #194 from anodelman/make-gem

create beaker 1.9.0 gem
```
* create beaker 1.9.0 gem (e4e2d9eb)

* Merge pull request #151 from anodelman/refactor-fetch (e5fd940d)


```
Merge pull request #151 from anodelman/refactor-fetch

(QA-769) Beaker fetch_puppet for PE needs to be refactored
```
* Merge pull request #187 from colinPL/fusion_spec_spanshots (adbc085a)


```
Merge pull request #187 from colinPL/fusion_spec_spanshots

(maint) Add spec Tests for Empty Fusion Snapshots
```
* Merge pull request #193 from anodelman/curl-wrapper (c5cce8fd)


```
Merge pull request #193 from anodelman/curl-wrapper

(QENG-382) Acceptance tests use curl's default ssl settings
```
* Merge pull request #181 from anodelman/ec2-tags (e6f760d7)


```
Merge pull request #181 from anodelman/ec2-tags

(OPS-2548) Cloud Asset Tagging for QA
```
* Merge pull request #167 from anodelman/google-cloud (aed481f0)


```
Merge pull request #167 from anodelman/google-cloud

Google cloud support in beaker
```
* (QENG-382) Acceptance tests use curl's default ssl settings (b851da4f)


```
(QENG-382) Acceptance tests use curl's default ssl settings

- create curl_on dsl extension, runs curl command with --sslv3 when
  executing PE tests
```
* Merge pull request #192 from kylog/maint/pin-rake-to-support-ruby-1.8.7 (0ff1f9c2)


```
Merge pull request #192 from kylog/maint/pin-rake-to-support-ruby-1.8.7

(maint) Pin rake to the last version that supported ruby 1.8.7
```
* (maint) Pin rake to the last version that supported ruby 1.8.7 (5e498b1a)

* (maint) Add spec Tests for Empty Fusion Snapshots (2253d688)


```
(maint) Add spec Tests for Empty Fusion Snapshots

Add three spec tests to exercise that invalid Fusion snapshots raise the
proper errors.
```
* (OPS-2548) Cloud Asset Tagging for QA (919ad9ac)


```
(OPS-2548) Cloud Asset Tagging for QA

- add tags for department/project to ec2
- add annotation for department/project to vcloud
- add metadata to google compute instances
```
* added yard documentation to google compute code + new platform class (d7b6cebf)


```
added yard documentation to google compute code + new platform class

- we like docs!
- i should do this more often!
- please don't check for grammar
```
* (QA-769) Beaker fetch_puppet for PE needs to be refactored (98490ba0)


```
(QA-769) Beaker fetch_puppet for PE needs to be refactored

- just some code clean up, split out windows and unix host PE fetching
  into two different functions
- tested locally on unix-style hosts
```
* split out google compute related code to its own class (0ed3d54c)


```
split out google compute related code to its own class

- tidy!
```
* added retry for network failure errors (118b4a15)

* add firewall to google default network for given project (6a4cbcbe)


```
add firewall to google default network for given project

- to ensure that pe ports are open
```
* google cloud integration (95108d39)

### <a name = "beaker1.8.2">beaker1.8.2 - 21 Mar, 2014 (0f848be8)

* Merge pull request #189 from anodelman/make-gem (0f848be8)


```
Merge pull request #189 from anodelman/make-gem

create beaker 1.8.2 gem
```
* create beaker 1.8.2 gem (d97e62db)


```
create beaker 1.8.2 gem

- to include alteration of beaker configure/validate post-provisioning
  steps
```
* Merge pull request #178 from anodelman/configuration-cleanup (7b6b5a84)


```
Merge pull request #178 from anodelman/configuration-cleanup

(QENG-310) move various host configuration steps together
```
* (QENG-310) move various host configuration steps together (7d1a7e38)


```
(QENG-310) move various host configuration steps together

- remove utils directory, place contents in host_prebuild_steps.rb
- update specs to reflect where code was moved
- update hypervisor.rb to use default, pre-built steps

- addon: remove last reference to systest
```
### <a name = "beaker1.8.1">beaker1.8.1 - 19 Mar, 2014 (4de3450e)

* Merge pull request #186 from anodelman/make-gem (4de3450e)


```
Merge pull request #186 from anodelman/make-gem

create beaker 1.8.1 gem
```
* create beaker 1.8.1 gem (1b674eec)

* Merge pull request #185 from branan/use_cmd_for_msiexec (65a0386e)


```
Merge pull request #185 from branan/use_cmd_for_msiexec

(maint) Wrap windows PE installation in `cmd /C`
```
* (maint) Install PE on windows synchronously (5bcd04ca)


```
(maint) Install PE on windows synchronously

Previously, beaker would call msiexec in a way that would cause it to
run asynchronously. This worked pretty much by chance, because beaker
did enough other stuff before trying to run puppet on the Windows
machine.

This wraps the msiexec call in `start /w`, which waits for the
installation to finish before continuing. This ensures that puppet is
fully installed before beaker continues.
```
* (maint) Wrap windows PE installation in `cmd /C` (08de0d72)


```
(maint) Wrap windows PE installation in `cmd /C`

When cygwin converts the posix-style commandline that bash provides to
a windows-style one for calling msiexec, it adds quotes around some
arguments. These quotes cause msiexec to fail. By wrapping the msiexec
invocation in `cmd /C`, we use the windows command interpreter to
handle the command line instead of bash/cygwin. This avoids the
translation issues introduced by cygwin.
```
### <a name = "beaker1.8.0">beaker1.8.0 - 17 Mar, 2014 (0cea9162)

* Merge pull request #183 from anodelman/make-gem (0cea9162)


```
Merge pull request #183 from anodelman/make-gem

create beaker 1.8.0 gem
```
* create beaker 1.8.0 gem (3d1ca003)

* Merge pull request #179 from anodelman/result-object-fix (7fae4e96)


```
Merge pull request #179 from anodelman/result-object-fix

(QENG-319) The "result" Object Doesn't Have Promised Attributes
```
* Merge pull request #170 from anodelman/fusion-fixes (b27b57a1)


```
Merge pull request #170 from anodelman/fusion-fixes

(QENG-280) beaker throws sort error when it can't locate fusion snapshots
```
* Merge pull request #177 from zaphod42/issue/master/qeng-326-dump-logs-for-shutdown-errors (3fa2f380)


```
Merge pull request #177 from zaphod42/issue/master/qeng-326-dump-logs-for-shutdown-errors

(QENG-326) Dump puppet logs on failed shutdown
```
* Merge pull request #180 from hunner/fix_default_agents (cb2306f3)


```
Merge pull request #180 from hunner/fix_default_agents

(QENG-328) Only disallow agent-only nodes from using master/database/dashboard roles
```
* Merge pull request #175 from electrical/opensuse (aca94567)


```
Merge pull request #175 from electrical/opensuse

Add opensuse to the list ( Its the same as SLES stuff )
```
* make ntp command configurable per and allow for retries (bbd2d623)

* Add regex check here as well (9b54db38)

* CLeanup if/elsif to case/when statements (ba0a2486)

* Merge pull request #182 from nicklewis/generate_3.3_answers (1e31d730)


```
Merge pull request #182 from nicklewis/generate_3.3_answers

Support generating answers for PE 3.3
```
* Support generating answers for PE 3.3 (e3d933c7)


```
Support generating answers for PE 3.3

For now, these are the same answers as for PE 3.2.
```
* Remove all opensuse references, we only use sles. (e7da7d9b)

* (QENG-328) Only disallow agent-only nodes from using master/database/dashboard roles (28e15cdb)

* SLES and OpenSuSE are the same. (e74e12f0)


```
SLES and OpenSuSE are the same.

Make sure we check and install the right package and call sntp for setting the time
```
* (QENG-326) Ignore errors when dumping logs (9435273d)


```
(QENG-326) Ignore errors when dumping logs

If the log dump encounters an error, that error would mask any errors
with the teardown of the puppet system. This changes that to log the
error from the log dump and continue on as normal. The logs won't be
dumped (maybe. depends on where the error was encountered), but the
problem will be reported and so will the original teardown problem.
```
* Merge pull request #173 from anodelman/answer-access (7a76fbfa)


```
Merge pull request #173 from anodelman/answer-access

(QENG-318) Add interface for introspecting answers
```
* Merge pull request #169 from jpartlow/dont_destroy_callers_opts (a52fbac5)


```
Merge pull request #169 from jpartlow/dont_destroy_callers_opts

(maint) Preserve :__commandline_args__ if provided in conf_opts
```
* Merge pull request #158 from electrical/pe_ver_env (100916bd)


```
Merge pull request #158 from electrical/pe_ver_env

Add pe_ver ENV variable so we can control it outside the config files.
```
* (QENG-319) The "result" Object Doesn't Have Promised Attributes (789d5004)


```
(QENG-319) The "result" Object Doesn't Have Promised Attributes

- to support old tests, yield self on a block with arity of 0
- to support new tests, yield result on a block with arity of 1
```
* Merge pull request #172 from anodelman/scrub-README (2e60adbe)


```
Merge pull request #172 from anodelman/scrub-README

(QENG-309) remove documentation from Beaker README
```
* (QENG-326) Dump puppet logs on failed shutdown (bbd45199)


```
(QENG-326) Dump puppet logs on failed shutdown

Right now the puppet logs are only dumped if there was a failure to
start the service. That means that when there is a failure on shutdown
we are left in the dark. This adds dumping of the logs when a error is
raised in the shutdown process.

This also improves the FakeHost so that it can support the [] method
instead of having a catch-all stub. By implementing the method is makes
the fake more resilient to changes and reduces the need for stubs of
what is mostly a value object.
```
* Merge pull request #174 from anodelman/file-reading (7ec9d31d)


```
Merge pull request #174 from anodelman/file-reading

(QENG-120) Beaker will raise "empty directory used as an option"...
```
* Fix NTP part. (136e97d3)


```
Fix NTP part.

Should have looked better at which part installs the ntpdate package.
```
* Add OpenSuse ntp stuff + tests (71780e3c)

* Add opensuse to the list ( Its the same as SLES stuff ) (c18b4b37)

* (QENG-120) Beaker will raise "empty directory used as an option"... (85d21e12)


```
(QENG-120) Beaker will raise "empty directory used as an option"...

...when a directory does not exist
- better error messaging
```
* (QENG-318) Add interface for introspecting answers (4dfdcb04)


```
(QENG-318) Add interface for introspecting answers

- when answers are generated add answers to each host object
- answers will be accessible at host[:answers][:q_install]
```
* (QENG-309) remove documentation from Beaker README (84895a99)


```
(QENG-309) remove documentation from Beaker README

- documentation has all been moved to the github beaker wiki
```
* (QENG-280) beaker throws sort error when it can't locate fusion snapshots (490ee15d)


```
(QENG-280) beaker throws sort error when it can't locate fusion snapshots

- add check for snapshot definition per fusion host
- add check that snapshot exist per-existing fusion vm
```
* (maint) Preserve :__commandline_args__ if provided in conf_opts (fd6ae04c)


```
(maint) Preserve :__commandline_args__ if provided in conf_opts

Oops, made the mistake of rudely ripping :__commandline_args__ from
with_puppet_running_on's conf_opts when I first added this bit.  This
should preserve the :__commandline_args__ for future callers while still
keeping it out of the puppet.conf creation step.
```
* Merge pull request #168 from hunner/fix_pooled (08fa63b8)


```
Merge pull request #168 from hunner/fix_pooled

(QENG-289) Raise error when template is nil
```
* (QENG-289) Raise error when template is nil (ce839a6b)

* Merge pull request #165 from anodelman/convert-platform-version (3d77dbb5)


```
Merge pull request #165 from anodelman/convert-platform-version

(QENG-279) add ability to convert from platform version number to
```
* Merge pull request #166 from branan/mutable_maps_suck_2_electric_boogaloo (7bf27a15)


```
Merge pull request #166 from branan/mutable_maps_suck_2_electric_boogaloo

(maint) Don't munge the user's opts hash in `on`
```
* Merge pull request #164 from anodelman/ntp-control (63625e22)


```
Merge pull request #164 from anodelman/ntp-control

(QENG-278) beaker's ntp_control doesn't really work
```
* Merge pull request #163 from anodelman/set-stacktrace-limit (74f275a4)


```
Merge pull request #163 from anodelman/set-stacktrace-limit

(QENG-274) makes number of lines reported in stack trace configurable
```
* (maint) Don't munge the user's opts hash in `on` (ae8f02f4)


```
(maint) Don't munge the user's opts hash in `on`

Previously, if the user specified `:environment` in the opts to `on`
(or to a higher-level method that passes on opts to `on`), `on` would
delete that key when it was called. This not only makes it impossible
to call `on` sanely in a loop, but is generally a pretty shitty thing
to do to our users' data.

This changes the code to not modify the hash.
```
* (QENG-279) add ability to convert from platform version number to (3217a82d)


```
(QENG-279) add ability to convert from platform version number to
version codename and back

- for debian and ubuntu boxes where this comes up a lot in our
  automation
```
* (QENG-278) beaker's ntp_control doesn't really work (5a53bf15)


```
(QENG-278) beaker's ntp_control doesn't really work

- correctly re-run ntpdate command on failure
```
* (QENG-274) makes number of lines reported in stack trace configurable (86f17764)

* Merge pull request #162 from anodelman/pe-install-configuration (d34339aa)


```
Merge pull request #162 from anodelman/pe-install-configuration

(QENG-271) ability to set pe_ver/pe_dir as a default
```
* (QENG-271) ability to set pe_ver/pe_dir as a default (ca6a8301)


```
(QENG-271) ability to set pe_ver/pe_dir as a default

- just add the check to see if pe_ver is set in options before
  attempting the version scraper
```
* Add pe_ver ENV variable so we can control it outside the config files. (668be93e)


```
Add pe_ver ENV variable so we can control it outside the config files.
This can be handy when you want to test against different PE versions in jenkins for example.
```
### <a name = "beaker1.7.0">beaker1.7.0 - 19 Feb, 2014 (0ad045fe)

* Merge pull request #160 from anodelman/make-gem (0ad045fe)


```
Merge pull request #160 from anodelman/make-gem

create 1.7.0 beaker gem
```
* create 1.7.0 beaker gem (85e47076)

* Merge pull request #141 from anodelman/vagrant-mem-size (9ac309b2)


```
Merge pull request #141 from anodelman/vagrant-mem-size

(QA-794) make vagrant vm size configurable through beaker
```
* Merge pull request #148 from anodelman/conf-only (54ba4861)


```
Merge pull request #148 from anodelman/conf-only

(QA-806) have a means to dump env without running beaker test
```
* Merge pull request #133 from hunner/verbose_default (4b1653ea)


```
Merge pull request #133 from hunner/verbose_default

(QA-787) Change default output to verbose
```
* Merge pull request #154 from branan/programmable_upgrades (83a3d4dd)


```
Merge pull request #154 from branan/programmable_upgrades

(QA-845) Allow PE upgrade version to be specified in the config
```
* Merge pull request #142 from anodelman/vagrant-1.8 (dbac20fe)


```
Merge pull request #142 from anodelman/vagrant-1.8

(QA-816) beaker vagrant support requires ruby 1.9+
```
* Merge pull request #153 from colinPL/invalid_dir_name (7bf655f4)


```
Merge pull request #153 from colinPL/invalid_dir_name

(QA-841) Windows complains about colons in dir names
```
* (QA-845) Allow PE upgrade version to be specified in the config (e6e05b6e)


```
(QA-845) Allow PE upgrade version to be specified in the config

Previously, when doing an upgrade beaker could only get a version by
reading the LATEST file. This makes it difficult to track exactly
which version is going to be tested in a given test run. By allowing
the version to be specified in the config file, we can make sure
beaker installs precisely the PE version that we care about for
testing.
```
* (QA-841) Windows complains about colons in sir names (6215fe4a)


```
(QA-841) Windows complains about colons in sir names

Creating a directory with colons (':') in the name will fail on Windows
and prevent beaker from executing tests. This change moves from calling
%T to using %H_%M_%S for time-based directory names.
```
* Merge pull request #147 from branan/we_wouldnt_have_this_problem_in_clojure (854adeac)


```
Merge pull request #147 from branan/we_wouldnt_have_this_problem_in_clojure

[maint] Do not modify the options hash in apply_manifest_on
```
* (QA-806) have a means to dump env without running beaker test (88f50a08)


```
(QA-806) have a means to dump env without running beaker test

- add --parse-only option to dump options and exit, useful for testing
```
* [maint] Do not modify the options hash in apply_manifest_on (391344d6)


```
[maint] Do not modify the options hash in apply_manifest_on

1) This is just poor behavior
2) When an array of hosts is passed, apply_manifest_on is run more
than once. In this situation, the first one modifies the options hash
and ruins it for all its friends
```
* Merge pull request #139 from branan/command_timestamp (c7a388a4)


```
Merge pull request #139 from branan/command_timestamp

(QA-805) Add timestamp to on(host) calls
```
* Merge pull request #144 from kbarber/maint/master/support-fedora-when-determining-ip (de2e015a)


```
Merge pull request #144 from kbarber/maint/master/support-fedora-when-determining-ip

Fix regexp for finding ip address for Fedora
```
* Merge pull request #140 from branan/boy_do_i_suck (f76e2a2f)


```
Merge pull request #140 from branan/boy_do_i_suck

(maint) apply_manifest_on should still return a value when operating on ...
```
* Fix regexp for finding ip address for Fedora (bd20870f)


```
Fix regexp for finding ip address for Fedora

The previous command for finding the IP address of a host:

	ip a | awk '/g/{print$2}'

Picks up all kinds of stray entries, on Amazon Linux for example:

	# ip a | awk '/g/{print$2}'
	109.74.196.121/24
	2a01:7e00::f03c:91ff:fe96:e1e4/64
	gre0:
	0.0.0.0
	gretap0:
	ip6gre0:

On a Fedora 20 box hosted in EC2:

	# ip a|awk '/g/{print$2}'
	lo:
	eth0:
	10.232.140.48/26

This is because its just looking for the letter 'g' which is not accurate
enough. Some interface lines have the word 'group' for example.

Changing this to the actual word 'global' seems to solve it:

	# ip a | awk '/global/{print$2}'
	109.74.196.121/24

This has been tested to work on:

* Debian 6/7
* Fedora 18, 20
* Amazon Linux
* Redhat 5/6

So I believe the behaviour should still be consistent after this change.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* (QA-816) beaker vagrant support requires ruby 1.9+ (04105fc4)


```
(QA-816) beaker vagrant support requires ruby 1.9+

- remove references to popen3 and use backticks
- can we please deprecate ruby 1.8 support?  please?
```
* (QA-794) make vagrant vm size configurable through beaker (cee83d07)


```
(QA-794) make vagrant vm size configurable through beaker

- add support for a vagrant_memsize in the config file
- default to 1024
```
* (maint) apply_manifest_on should still return a value when operating on an array (ed729178)

* (QA-805) Add timestamp to on(host) calls (b741840c)


```
(QA-805) Add timestamp to on(host) calls

Previously there was no timestamp, which makes it hard to correlate
beaker commands with logs on the SUT.

    lw5bhs6m2zu4ysb (centos5-64-1) 14:21:44$  which curl
    /usr/bin/curl

    lw5bhs6m2zu4ysb (centos5-64-1) executed in 5.99 seconds
```
* Merge pull request #138 from colinPL/gitignore_add_patterns (6d281a45)


```
Merge pull request #138 from colinPL/gitignore_add_patterns

(maint) Add new patterns to gitignore
```
* (maint) Add new patterns to gitignore (5bc4ec43)


```
(maint) Add new patterns to gitignore

Added new patterns to gitignore for IDEA, rbenv, and vagrant files and
folders. The tmp directory patterns were reduced from two to one.
```
* (QA-787) Change default output to verbose (c064ae45)

### <a name = "beaker1.6.2">beaker1.6.2 - 31 Jan, 2014 (ed048e29)

* Merge pull request #137 from anodelman/make-gem (ed048e29)


```
Merge pull request #137 from anodelman/make-gem

create beaker 1.6.2 gem
```
* create beaker 1.6.2 gem (665103a3)

* Merge pull request #136 from branan/apply_manifest_on_array (23c85a0e)


```
Merge pull request #136 from branan/apply_manifest_on_array

(maint) Re-Allow an array of hosts in apply_manifest_on
```
* (maint) Re-Allow an array of hosts in apply_manifest_on (6271538b)


```
(maint) Re-Allow an array of hosts in apply_manifest_on

Before it was refactored, apply_manifest_on allowed an array of
hosts. The Puppet acceptance tests rely on this behavior, so we need
to re-introduce it.
```
### <a name = "beaker1.6.1">beaker1.6.1 - 30 Jan, 2014 (468bbb6f)

* Merge pull request #135 from anodelman/make-gem (468bbb6f)


```
Merge pull request #135 from anodelman/make-gem

create beaker 1.6.1 gem
```
* create beaker 1.6.1 gem (015d2a8a)

* Merge pull request #132 from branan/pe_rake_explicit_path (04279591)


```
Merge pull request #132 from branan/pe_rake_explicit_path

(maint) Use explicit path to rake when running PE console rake tasks
```
* Merge pull request #134 from branan/fix_32_answers_gen (ce9b1f81)


```
Merge pull request #134 from branan/fix_32_answers_gen

(maint) Make the 'database' host available in 3.2 answers gen
```
* (maint) Add test for the 3.2 upgrade answers generation (8c33486c)

* (maint) Make the 'database' host available in 3.2 answers gen (da936395)


```
(maint) Make the 'database' host available in 3.2 answers gen

Because answers gen does not have access to normal beaker context, the
special hosts need to be made available explicitly.
```
* (maint) Use explicit path to rake when running PE console rake tasks (da88c2b4)


```
(maint) Use explicit path to rake when running PE console rake tasks

Bundler and/or rake gets confused when we aren't explicit.
```
### <a name = "beaker1.6.0">beaker1.6.0 - 30 Jan, 2014 (3787bdb8)

* Merge pull request #131 from branan/qa_777 (3787bdb8)


```
Merge pull request #131 from branan/qa_777

(QA-777) Allow beaker to deploy a split PE on version 3.2
```
* (QA-777) Allow beaker to deploy a split PE on version 3.2 (846f814c)


```
(QA-777) Allow beaker to deploy a split PE on version 3.2

3.2 includes a large database schema change. Part of the schema
migration is to validate availability of free space. On split
configurations, the dashboard upgrader will ask the user to make sure
there is sufficient space on the database node. We need to answer
"yes" to this from Beaker.
```
* Merge pull request #130 from anodelman/make-gem (6aa7bb1e)


```
Merge pull request #130 from anodelman/make-gem

cut beaker 1.6.0 gem
```
* cut beaker 1.6.0 gem (ff7350fd)

* Merge pull request #117 from johnduarte/maint-add-forgeapi-stub (38b014e9)


```
Merge pull request #117 from johnduarte/maint-add-forgeapi-stub

Add forgeapi stub to support forge api v3
```
* Merge pull request #129 from branan/tmpfile_not_tmp (557a4d15)


```
Merge pull request #129 from branan/tmpfile_not_tmp

(maint) Use host.tmpfile instead of manually generating file names
```
* Merge pull request #1 from anodelman/maint-add-forgeapi-stub (b8385e1b)


```
Merge pull request #1 from anodelman/maint-add-forgeapi-stub

Maint add forgeapi stub
```
* fix for spec test bustage (dcfdea27)

* (maint) Use host.tmpfile instead of manually generating file names (42dee62d)


```
(maint) Use host.tmpfile instead of manually generating file names

Generating a file name in /tmp/ breaks on windows, where /tmp/ can
actually point to a different path depending on if a command is
executing in a cygwin or cmd context.
```
* Add forgeapi stub to support forge api v3 (c029dcaf)


```
Add forgeapi stub to support forge api v3

Version 3 of the forge api will have a canonical source at
forgeapi.puppetlabs.com.

This patch adds this source as a source for the forge stub so
that beaker can set the environemnt to respond correctly for both
version 1 and version 3 of the api.
```
* Add forgeapi stub to support forge api v3 (60b7bb9b)


```
Add forgeapi stub to support forge api v3

Version 3 of the forge api will have a canonical source at
forgeapi.puppetlabs.com.

This patch adds this source as a source for the forge stub so
that beaker can set the environemnt to respond correctly for both
version 1 and version 3 of the api.
```
### <a name = "beaker1.5.0">beaker1.5.0 - 29 Jan, 2014 (78db5afb)

* Merge pull request #128 from anodelman/make-gem (78db5afb)


```
Merge pull request #128 from anodelman/make-gem

create beaker 1.5.0 gem
```
* create beaker 1.5.0 gem (509cae6c)

* Merge pull request #124 from anodelman/preserve-on-failue (32114959)


```
Merge pull request #124 from anodelman/preserve-on-failue

(QA-723) add preserve hosts on failure option to beaker
```
* Merge pull request #126 from anodelman/no-master (cecb9a58)


```
Merge pull request #126 from anodelman/no-master

(QA-775) allows beaker to run with no master defined
```
* (QA-775) allows beaker to run with no master defined (06ad5f18)


```
(QA-775) allows beaker to run with no master defined

- what is says on the tin
```
* Merge pull request #125 from branan/heterogenous_frictionless_support (b5471753)


```
Merge pull request #125 from branan/heterogenous_frictionless_support

(QA-773) Support installing any frictionless agent on any master
```
* (QA-773) Support installing any frictionless agent on any master (e4afb02f)


```
(QA-773) Support installing any frictionless agent on any master

Previously, beaker only supported installing a frictionless agent if
it had the same platform as the master. This code allows heterogenous
deployments by properly classifying the master for the platform of
each frictionless node in the configuration.

This is (once again) kind of a quick-and-dirty solution. It'll get
cleaned up as part of QA-769, wherein we refactor the mess known as
the PE installation code.
```
* (QA-723) add preserve hosts on failure option to beaker (6cf27d80)


```
(QA-723) add preserve hosts on failure option to beaker

- still support fast/slow fail modes, in slow mode will continue to
  attempt to run tests + test suits
- create preserve_hosts modes:
  always = keep 'em around no matter what
  onfail = only preserve if there was a failure during testing
  never  = kill 'em no matter what
- added spec test coverage for these modes
```
### <a name = "beaker1.4.1">beaker1.4.1 - 27 Jan, 2014 (bc6a7d32)

* Merge pull request #123 from anodelman/make-gem (bc6a7d32)


```
Merge pull request #123 from anodelman/make-gem

cut beaker1.4.0 gem
```
* cut beaker1.4.1 gem (7fa876f6)

* Merge pull request #122 from branan/fix_windows_pe_installation (1c9bd227)


```
Merge pull request #122 from branan/fix_windows_pe_installation

(QA-753) Make sure to still support saving MSIs locally
```
* (QA-753) Make sure to still support saving MSIs locally (064f074f)


```
(QA-753) Make sure to still support saving MSIs locally

The initial commit for QA-753 didn't account for the MSI case, which
still requires saving the .msi file locally. This adds a save_locally
option to the cURL command line, based on whether we're fetch an msi.
```
### <a name = "beaker1.4.0">beaker1.4.0 - 24 Jan, 2014 (c24f0194)

* Merge pull request #119 from hunner/expect_changes (c24f0194)


```
Merge pull request #119 from hunner/expect_changes

Add :expect_changes to apply_manifest_on()
```
* Merge pull request #120 from anodelman/make-gem (543ae22a)


```
Merge pull request #120 from anodelman/make-gem

cut a beaker 1.4.0 beaker gem
```
* Merge pull request #121 from nicklewis/PE-2627-use-agent-install.bash (08aed82b)


```
Merge pull request #121 from nicklewis/PE-2627-use-agent-install.bash

(PE-2627) Use generic install.bash to install frictionless agents
```
* (PE-2627) Use generic install.bash to install frictionless agents (d8817e4a)


```
(PE-2627) Use generic install.bash to install frictionless agents

Rather than use a platform-specific script, we now have a generic
install.bash script which can be used to install agents of any platform.
Because install.bash downloads the platform-specific script, using it
effectively tests the correctness of both scripts.
```
* cut a beaker 1.4.0 beaker gem (f274c927)

* Merge pull request #112 from nicklewis/upgrade-frictionless-agents (696d7583)


```
Merge pull request #112 from nicklewis/upgrade-frictionless-agents

(PE-2586) Support using frictionless install for upgrades
```
* Add :expect_changes to apply_manifest_on() (80ac33a9)

* Merge pull request #108 from hunner/install_puppet (d59e7316)


```
Merge pull request #108 from hunner/install_puppet

(QA-720) Provide way to install from public repos
```
* Merge pull request #114 from joshcooper/issue/master/QA747-Add-timing-info (990f685d)


```
Merge pull request #114 from joshcooper/issue/master/QA747-Add-timing-info

(QA-747) Log the amount of time each command takes to execute
```
* (QA-747) Log the amount of time each command takes to execute (e814c5c7)


```
(QA-747) Log the amount of time each command takes to execute

Previously, there was no way to tell how long each beaker command took
to execute on a remote VM. I would like to know this information to
track down a timing issue in acceptance testing on Windows.

This commit modifies the host object to log timing information when
beaker is run in debug mode. It uses the same logging prefix as is used
when displaying the executed command, e.g.

    a4e5hyo2m0ooom1 (master) $  cp /etc/puppet/puppet.conf ...
    a4e5hyo2m0ooom1 (master) executed in 0.01 seconds
```
* (PE-2586) Support using frictionless install for upgrades (0a30c9b0)


```
(PE-2586) Support using frictionless install for upgrades

We now only use frictionless install for versions that support it. This
way we can test frictionless upgrade (which is identical to install)
from non-frictionless installs of older versions, while also testing it
from frictionless installs for versions that support it.
```
* Provide way to install from public repos (aa5048e4)


```
Provide way to install from public repos

This commit adds an `install_puppet` DSL method that may be used to
simply add the public Puppet Labs repositories and install puppet.
```
### <a name = "beaker1.3.2">beaker1.3.2 - 23 Jan, 2014 (39bbbf0c)

* Merge pull request #118 from anodelman/make-gem (39bbbf0c)


```
Merge pull request #118 from anodelman/make-gem

create beaker 1.3.2 gem
```
* create beaker 1.3.2 gem (ed76fe91)

* Merge pull request #97 from anodelman/fix-fatal-errors (9d53714b)


```
Merge pull request #97 from anodelman/fix-fatal-errors

(QE-602) Beaker Throws Fatal Error when Displaying Current Version
```
* Merge pull request #116 from hunner/fix_tarball_dl (f96a1ac6)


```
Merge pull request #116 from hunner/fix_tarball_dl

Correct specs for QA-753
```
* Correct specs for QA-753 (e2e8fc25)

* Merge pull request #104 from anodelman/pin-rubygems (eeb972c5)


```
Merge pull request #104 from anodelman/pin-rubygems

unpin rubygems for travis CI
```
* Merge pull request #103 from anodelman/pin-rbvmomi (a786f358)


```
Merge pull request #103 from anodelman/pin-rbvmomi

unpin rbvmomi from 1.6.0
```
* Merge pull request #115 from branan/pe_tgz_unpack (116a1e9f)


```
Merge pull request #115 from branan/pe_tgz_unpack

(QA-753) Don't write or read the PE tarball more than we have to
```
* (QA-753) Don't write or read the PE tarball more than we have to (809e5f37)


```
(QA-753) Don't write or read the PE tarball more than we have to

The PE tarball is big and our storage isn't always happy about
that. By streaming the tarball unpack, we can avoid a write and then a
read of the 800MB tar. On a matrix of 200 nodes, that comes up to 20
million 4K blocks written then read, for no real gain.
```
* Merge pull request #105 from anodelman/vagrant-ip (6a16958b)


```
Merge pull request #105 from anodelman/vagrant-ip

(QA-644) Beaker vagrant backend corrupts /etc/hosts when --no-provision is passed
```
* Merge pull request #111 from alexharv074/add_https_install_support (92a6ee4a)


```
Merge pull request #111 from alexharv074/add_https_install_support

Add HTTPS support to the link_exists? method
```
* Add HTTPS support to the link_exists? method in Beaker::DSL::InstallUtils. (19144424)

* Merge pull request #110 from kurtwall/master (d80eca24)


```
Merge pull request #110 from kurtwall/master

Update regex to support internal github mirror
```
* Update regex to support internal github mirror (b3c8c55c)

* Merge pull request #107 from hunner/manifest_files (d17b78c6)


```
Merge pull request #107 from hunner/manifest_files

(QA-705) Create manifest files to apply
```
* adding spec tests for pulling ip addresses from existing Vagrantfile (78de9675)


```
adding spec tests for pulling ip addresses from existing Vagrantfile

- spec tests are good!
```
* (QA-705) Create manifest files to apply (f04bae10)


```
(QA-705) Create manifest files to apply

When applying puppet manifests with `puppet apply` beaker will generate
the manifest code and send it to `stdin`. This is troublesome for
debugging as the actual code is never shown and hard to replicate.

This commit causes the manifest code to be stored in a `.pp` file in
`/tmp` and apply that file so that it may be viewed and reused when
debugging. This is similar to how rspec-system does it.
```
* (QA-644) Beaker vagrant backend corrupts /etc/hosts when --no-provision is passed (b047b9f0)


```
(QA-644) Beaker vagrant backend corrupts /etc/hosts when --no-provision is passed

- add support to beaker for determining ip addresses of currently up
  vagrant hosts through reading the Vagrantfile
- if the Vagrantfile doesn't exist or ip addresses can't be determined
  then quit
```
* pin rubygems to 2.2.1 for travis CI (66dbb126)


```
pin rubygems to 2.2.1 for travis CI

- issue with 1.8.7 bustage fixed in rubygems 2.2.1
http://blog.rubygems.org/2014/01/06/2.2.1-released.html
```
* Merge pull request #100 from aperiodic/vagrant-netmask (b4832f3e)


```
Merge pull request #100 from aperiodic/vagrant-netmask

Beaker uses netmask from config for vagrant boxes if present
```
* unpin rbvmomi from 1.6.0 (daca9ea6)


```
unpin rbvmomi from 1.6.0

- rbvmomi issue fixed for ruby 1.8.7, should be good to go now
```
* Merge pull request #102 from anodelman/pin-rubygems (2a4bab0a)


```
Merge pull request #102 from anodelman/pin-rubygems

Rubygems broke spec for rvm 1.8.7
```
* Rubygems broke spec for rvm 1.8.7 (93b53b13)


```
Rubygems broke spec for rvm 1.8.7

- Temporary workound until https://github.com/rubygems/rubygems/pull/763 is merged
```
* Beaker uses netmask from config for vagrant boxes if present (4d3ad95a)

* (QE-602) Beaker Throws Fatal Error when Displaying Current Version (9840390a)


```
(QE-602) Beaker Throws Fatal Error when Displaying Current Version

- just don't do a gemspec load when looking for the version number, thus
  it doesn't end up calling git-ls, thus no fatal errors
```
### <a name = "beaker1.3.1">beaker1.3.1 - 18 Dec, 2013 (08b59809)

* Merge pull request #99 from anodelman/make-gem (08b59809)


```
Merge pull request #99 from anodelman/make-gem

create 1.3.1 beaker gem
```
* create 1.3.1 beaker gem (8dc431b1)


```
create 1.3.1 beaker gem

- pin rbvmomi to 1.6 to avoid bustage
```
* Merge pull request #98 from anodelman/pin-rbvmomi (739658cd)


```
Merge pull request #98 from anodelman/pin-rbvmomi

(QA-659) Pin beaker to rbvmomi 1.6.0
```
* (QA-659) Pin beaker to rbvmomi 1.6.0 (e680d603)


```
(QA-659) Pin beaker to rbvmomi 1.6.0

- pin to rbvmomi 1.6.0 until we can figure out what's broken with
  latest rbvmomi
```
### <a name = "beaker1.3.0">beaker1.3.0 - 13 Dec, 2013 (5815f829)

* Merge pull request #96 from anodelman/make-gem (5815f829)


```
Merge pull request #96 from anodelman/make-gem

creating beaker 1.3.0 gem
```
* creating beaker 1.3.0 gem (22b63cdc)


```
creating beaker 1.3.0 gem

- adding support for --log-level
- bug fixes
```
* Merge pull request #86 from anodelman/log-level (f0ff1e76)


```
Merge pull request #86 from anodelman/log-level

expanded log level support
```
* Merge pull request #93 from nicklewis/frictionless-agent-install (89dfcbd2)


```
Merge pull request #93 from nicklewis/frictionless-agent-install

Install agents using the frictionless agent install
```
* Merge pull request #94 from hunner/catch_changes (6b45fa34)


```
Merge pull request #94 from hunner/catch_changes

(QE-613) Add `:catch_changes` to check for manifest resource changes
```
* Merge pull request #85 from anodelman/fix-uri (67dfb36a)


```
Merge pull request #85 from anodelman/fix-uri

(QE-588) vcloud_pooled: undefined method `request_uri'
```
* Merge pull request #95 from anodelman/test-order (85a56a6e)


```
Merge pull request #95 from anodelman/test-order

(QE-622) Beaker Does not Run Pre-suites in the Order Specified
```
* (QE-622) Beaker Does not Run Pre-suites in the Order Specified (59c4de32)


```
(QE-622) Beaker Does not Run Pre-suites in the Order Specified

- move sorting of test files into the option parser
- sort directores, keep ordering of items on command line
- added additional spec tests to confirm change
```
* Validate that we don't allow frictionless master, etc (30e89d4e)


```
Validate that we don't allow frictionless master, etc

Frictionless install is only supported for agent-only installs, so we
check that any frictionless node doesn't have any non-agent roles
specified.
```
* (QE-613) Add `:catch_changes` to check for manifest resource changes (9edaa60d)


```
(QE-613) Add `:catch_changes` to check for manifest resource changes

Many times when testing modules we apply puppet code twice in a row and
verify that the second run does not produce any resource changes to
verify that the resources are idempotent. The `:catch_changes` option
can be used to monitor for this result.
```
* Install agents using the frictionless agent install (1e954247)


```
Install agents using the frictionless agent install

This change adds logic for installing using the new curlbash style of
agent install. In order to support testing both the old and new styles
of install, we add a new agent role of "frictionless", which indicates
that the node should be installed in the new style. This simply causes
it not to download the PE tarball or generate answer files, and to curl
and run a script from the master (based on the platform tag).
```
* Merge pull request #92 from anodelman/make-gem (a41045a4)


```
Merge pull request #92 from anodelman/make-gem

release beaker 1.2.0
```
* (QE-588) vcloud_pooled: undefined method `request_uri' (2640f935)


```
(QE-588) vcloud_pooled: undefined method `request_uri'

- ensure that a scheme is defined for the vcloud pooling api uri
- if no scheme is defined the uri returned is a simple uri object that
  does not support the 'request_uri' method
```
* expanded log level support (0259a764)


```
expanded log level support

- support the following levels:
  5 debug
  4 verbose
  3 info
  2 notify
  1 warn
- each level reports itself plus the levels under it
- added 'info' level that reports in BLUE
- 'debug' level adds full stack traces
- todo: would like to review our current logging messages and see
        what needs to be assigned a new level
```
### <a name = "beaker1.2.0">beaker1.2.0 - 5 Dec, 2013 (59070752)

* release beaker 1.2.0 (59070752)


```
release beaker 1.2.0

- support :expect_failures in apply_manifest_on
- various bug fixes
```
* Merge pull request #91 from hunner/apply-manifest-fix (7fcf42b3)


```
Merge pull request #91 from hunner/apply-manifest-fix

(QE-598) apply_manifest_on fails if acceptable_exit_codes is not set
```
* Add specs for this bug (a11b7163)

* (QE-598) apply_manifest_on fails if acceptable_exit_codes is not set (5a9b0227)


```
(QE-598) apply_manifest_on fails if acceptable_exit_codes is not set

- was using 0 instead of [0] as the default acceptable exit code
```
* Merge pull request #89 from hunner/expect_failures (41a82683)


```
Merge pull request #89 from hunner/expect_failures

Add `:expect_failures` option
```
* Add `:expect_failures` option (f6b38e5e)


```
Add `:expect_failures` option

When performing positive tests of applying manifests, the
`#apply_manifest` method may be called with `:catch_failures => true`.

This commit also adds an argument of `:expect_failures` to allow
`#apply_manifest` to perform negative tests.
```
* Merge pull request #88 from hunner/fix_catch_failures (8aa70bf4)


```
Merge pull request #88 from hunner/fix_catch_failures

Fix catch_failures option
```
* Fix catch_failures option (314072e4)


```
Fix catch_failures option

If `:catch_failures => true` is supplied and no extra
`:acceptable_exit_codes` are supplied, a bug hindered the
`#apply_manifest_on` method from performing correctly.
```
* Merge pull request #87 from anodelman/make-gem (c516ed07)


```
Merge pull request #87 from anodelman/make-gem

make 1.1.0 gem
```
* make 1.1.0 gem (a631327c)


```
make 1.1.0 gem

- includes implementation for everything needed to deploy test packages on top
  of an installed PE.
```
* Merge pull request #39 from branan/master (b4e583fb)


```
Merge pull request #39 from branan/master

RFC: QE-147 and QE-148
```
* Merge pull request #84 from kbarber/maint/master/retry-blimpy-on-systemcall-errors (eb07eb6f)


```
Merge pull request #84 from kbarber/maint/master/retry-blimpy-on-systemcall-errors

Catch SystemCallError during blimpy provision for retry
```
* Catch SystemCallError during blimpy provision for retry (9f09862d)


```
Catch SystemCallError during blimpy provision for retry

Previously we were only catching Fog::Errors::Error exceptions, this patch
makes sure that system call failures are also caught, so things like connection
refused and no route to host which are generally transient, are caught and
retried properly.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Merge pull request #72 from anodelman/check-platform-set (7dc0dc22)


```
Merge pull request #72 from anodelman/check-platform-set

(QE-519) beaker should raise error if host does not have a platform set
```
* Merge pull request #80 from anodelman/hunner (a97c5e18)


```
Merge pull request #80 from anodelman/hunner

move VagrantFiles into .vagrant_files directory of working directory
```
* Merge pull request #83 from anodelman/make-gem (9f13ae00)


```
Merge pull request #83 from anodelman/make-gem

make 1.0.1 gem
```
* enforcing platform format of OS-VERSION-ARCH (1f4320da)


```
enforcing platform format of OS-VERSION-ARCH

- added spec tests to ensure that we correctly sort out bad platform
  names
- will need to write an associated patch to update our node
  configuration files to meet the new standard
```
* move VagrantFiles into .vagrant_files directory of working directory (745798c3)

* documentation for supported HOST settings (590aa14f)

* Only update apt repo if needed (3d882250)


```
Only update apt repo if needed

Previously, the code would run apt-get update at every package
install. This memoizes when apt-get update has been run so we don't
need to run it as frequently
```
* (QE-519) beaker should raise error if host does not have a platform set (a4b6e89a)


```
(QE-519) beaker should raise error if host does not have a platform set

- beaker tries to do crazy things when hosts aren't on supported
  platforms, let's check that option right at the start
```
* (QE-147) Add support to deploy package repositories (1acb64e5)

* (QE-148) support upgrading packages (e5c27201)

### <a name = "beaker1.0.1">beaker1.0.1 - 25 Nov, 2013 (70f55b11)

* make 1.0.1 gem (70f55b11)

* Merge pull request #82 from branan/support_pe_32 (cea4c4f4)


```
Merge pull request #82 from branan/support_pe_32

Add support for PE 3.2 with its new answers requirements
```
* Merge pull request #79 from anodelman/make-gem (344aa275)


```
Merge pull request #79 from anodelman/make-gem

pre-release of 1.0.1 beaker
```
* Add support for PE 3.2 with its new answers requirements (90b7afe1)

* Merge pull request #76 from justinstoller/merge/handle-missing-puppet.conf (9cc9434b)


```
Merge pull request #76 from justinstoller/merge/handle-missing-puppet.conf

handle missing puppet.conf
```
* Merge pull request #71 from justinstoller/pessimistically_version_deps (8730cf06)


```
Merge pull request #71 from justinstoller/pessimistically_version_deps

[fixes QE-504] allow Beaker gem to be installed on 1.8
```
* Merge pull request #73 from jpartlow/maint/master/dump_master_log_only_if_fail_startup (a816006e)


```
Merge pull request #73 from jpartlow/maint/master/dump_master_log_only_if_fail_startup

(maint) Dump master puppet log if failed to start puppet.
```
* Merge pull request #77 from hunner/destroy_nothing (9bc67be5)


```
Merge pull request #77 from hunner/destroy_nothing

Destroy vagrant hosts only if Vagrantfile exists
```
* Destroy vagrant hosts only if Vagrantfile exists (f0c298f3)


```
Destroy vagrant hosts only if Vagrantfile exists

The new `vagrant destroy --force` run during the vagrant hypervisors
`provision` method added in #48 seems to fail if no `Vagrantfile` has
ever been created for a nodeset. This fixes that.
```
* Use Beaker::Command when working within hosts (6551ca6d)

* (maint) Dump master puppet log if failed to start puppet. (64254fc4)


```
(maint) Dump master puppet log if failed to start puppet.

Centralize logging after puppet master fails to start.
```
* Define host method to check for file existence (84bf88c0)

* Pessimistically lock down runtime and transitive dependencies (8c76afcc)

* Gracefully handle lack of puppet.conf (faff7721)


```
Gracefully handle lack of puppet.conf

When `#with_puppet_running_on` is executed, it attempts to back up
puppet.conf and replace it for the duration for the test. The old
behavior of the code would always try to back up the file regardless of
the existence of the file, and would fail when the copy failed. This
commit ensures that the puppet.conf file is only backed up when present,
and the temporary puppet.conf is returned to the original state
when the method returns.
```
### <a name = "beaker1.0.1pre">beaker1.0.1pre - 20 Nov, 2013 (8cffaf28)

* pre-release of 1.0.1 beaker (8cffaf28)

* Merge pull request #78 from hunner/fact_on (8d3fcbb5)


```
Merge pull request #78 from hunner/fact_on

Rename `fact` to `fact_on` for uniformity
```
* Rename `fact` to `fact_on` for uniformity (54194ede)


```
Rename `fact` to `fact_on` for uniformity

The DSL method `fact` was recently added, but most dsl methods take the
form of `<method>_on` for multi-node functions and `<method>` for
running on a default node. This makes `fact_on()` run on designated
nodes, and `fact()` run on the default node.
```
* Merge pull request #57 from anodelman/vcloud-cleanup (ec5a38e3)


```
Merge pull request #57 from anodelman/vcloud-cleanup

(QE-439) beaker is not catching rbvmomi exceptions when cleaning up vCloud VMs
```
* Merge pull request #70 from anodelman/silence-test-unit (0f40839e)


```
Merge pull request #70 from anodelman/silence-test-unit

(QE-46) Beaker includes Test::Unit specific code
```
* Merge pull request #67 from anodelman/add-version (5efd2da5)


```
Merge pull request #67 from anodelman/add-version

(QE-502) beaker should support --version
```
* Merge pull request #56 from anodelman/facter-shortcut (7df75012)


```
Merge pull request #56 from anodelman/facter-shortcut

(QE-364) have beaker 'chomp' stdout from execution result
```
* Merge pull request #51 from anodelman/vagrant-error-out (c2d6185c)


```
Merge pull request #51 from anodelman/vagrant-error-out

(QE-451) stop run when vagrant commands fail
```
* Merge pull request #48 from anodelman/fix-vagrant (1959b6f1)


```
Merge pull request #48 from anodelman/fix-vagrant

(QE-204) allow for use of local vagrant file when using --no-provision
```
* (QE-46) Beaker includes Test::Unit specific code (d88e1928)


```
(QE-46) Beaker includes Test::Unit specific code

- this was an issue with test::unit having autorun on by default,
  resulting in log spew when shutting down beaker
```
* Merge pull request #69 from branan/socket_timeout_fixup (15b6a774)


```
Merge pull request #69 from branan/socket_timeout_fixup

[QE-498] Fix port_open? on linux
```
* [QE-498] Fix port_open? on linux (bcfb82cb)


```
[QE-498] Fix port_open? on linux

The previous fix for QE-498 apparently relied on some
platform-specific behavior around async sockets. This goes back to the
old blocking socket method, but keeps the new behavior around socket
timeouts.
```
* Merge pull request #68 from anodelman/missing-gem (9e73cc52)


```
Merge pull request #68 from anodelman/missing-gem

(QE-501) beaker raises warning about missing gem (unf)
```
* (QE-501) beaker raises warning about missing gem (unf) (d7d0e731)


```
(QE-501) beaker raises warning about missing gem (unf)

- adding missing gem broke platform testing
- commenting out offending line in beaker.gemspec, it can easily be
  flipped back on if desired
```
* (QE-502) beaker should support --version (dbb13faf)

* Merge pull request #64 from anodelman/make-gem (dd89f4d1)


```
Merge pull request #64 from anodelman/make-gem

create beaker 1.0.0 gem
```
* Merge pull request #65 from anodelman/port-open (1f537b19)


```
Merge pull request #65 from anodelman/port-open

(QE-498) with_puppet_running_on can fail if TCP handshake takes > 1s
```
* Merge pull request #66 from anodelman/missing-gem (607f2baf)


```
Merge pull request #66 from anodelman/missing-gem

(QE-501) add missing gem 'unf'
```
* (QE-501) add missing gem 'unf' (d4cf39ba)

* (QE-498) with_puppet_running_on can fail if TCP handshake takes > 1s (3d561b84)


```
(QE-498) with_puppet_running_on can fail if TCP handshake takes > 1s

- found solution online using non-blocking sockets, work locally
```
* Merge pull request #60 from adrienthebo/quote-bash-conditional-arguments (22d04f1a)


```
Merge pull request #60 from adrienthebo/quote-bash-conditional-arguments

Quote ruby interpolated data in bash commands
```
* Merge pull request #62 from justinstoller/pooling-again (e7c01681)


```
Merge pull request #62 from justinstoller/pooling-again

Pooling again
```
* Merge pull request #59 from justinstoller/18test (032f6fee)


```
Merge pull request #59 from justinstoller/18test

Test on 1.8.7
```
* test, refactor, and improve option hash printing (25fd8ae3)

* Quote ruby interpolated data in bash commands (fa0af43b)


```
Quote ruby interpolated data in bash commands

Bash conditionals demonstrate strange behaviors when not given an arg.
Given the following:

    if [ -f  ]; then
      echo "how did I get here?"
    fi
    #=> how did I get here?

Wrapping ruby interpolated variables in quotes act as expected:

    if [ -f '' ]; then echo
      "how did I get here?"
    else
      echo "the empty string is not a file"
    fi
    #=> the empty string is not a file

The moral of the story is that bash exists to make everybody sad.
```
* PR comment improvements (3f1df347)

* Fix vcloud work to be 1.8 compat (3d73698a)

* fix deprecation warnings with RSpec 2.14 (8dbcee1a)

* Bump RSpec version (017ff432)

* actually test Solaris "hypervisor" (ddb61db3)

* fixup Beaker::Options::OptionsHash specs on 1.8.7 (3d81b32d)

* fixup Beaker::DSL::Roles specs on 1.8.7 (03fffe88)

* fixup Beaker::PuppetCommand specs on 1.8.7 (9bcfa6a6)

* fixup Beaker::Host specs on 1.8.7 (08197424)

* capture the correct Exception for bad YAML files on 1.8.7 (31c24a24)

* fixup Beaker::DSL::InstallUtils specs on 1.8.7 (cd79851d)

* fixup Beaker::DSL::Helpers specs on 1.8.7 (998448f9)

* (QE-439) beaker is not catching rbvmomi exceptions when cleaning up vCloud VMs (7857d143)


```
(QE-439) beaker is not catching rbvmomi exceptions when cleaning up vCloud VMs

- catch RbVmomi::VIM::ManagedObjectNotFound and handle appropriately
```
* remove deprecated beaker.rb (c7ededce)

* add 1.8.7 to the travis matrix (65b62f0b)

* pass tasks instead of objectSet to wait_for_tasks (30f2288d)

* repair spec test (9f7d2863)

* cleaner re-use of vagrant boxes, review comment fixes (f130c2d6)

* add retry for failure to find host in pool (4f9c928a)


```
add retry for failure to find host in pool

- will retry until timeout to grab pooled box for a given host
- raises readable error upon failure to allocated pooled host
```
* remove race condition upon vm cloning, general cleanup (4e45e456)

* make vcloud hypervisor code better (5c8b1da9)


```
make vcloud hypervisor code better

- break out pooled vs. non-pooled code
- break up long proceduces
- avoid code duplication
```
* (QE-364) have beaker 'chomp' stdout from execution result (f9d0f84a)


```
(QE-364) have beaker 'chomp' stdout from execution result

- create dsl helper to access facter facts
```
* (QE-451) stop run when vagrant commands fail (5e1b08d1)


```
(QE-451) stop run when vagrant commands fail

- check exit codes of vagrant commands
- raise an error if vagrant commands fail
```
* (QE-204) allow for use of local vagrant file when using --no-provision (0da2d66f)


```
(QE-204) allow for use of local vagrant file when using --no-provision

- use already set up vagrant boxes when running with --no-provision
```
* fixes in response to review comments (29df8b50)

* vCloud host-pooling (2b974cfb)


```
vCloud host-pooling

- This PR enabled the use of the "pooling_api" configuration parameter:
- spec tests for vsphere/vcloud hypervisors
```
### <a name = "beaker1.0.0">beaker1.0.0 - 8 Nov, 2013 (c85186b7)

* create beaker 1.0.0 gem (c85186b7)


```
create beaker 1.0.0 gem

- include vpooling work
```
* Merge pull request #55 from justinstoller/maint/master/revert-vpooling (bed4ff69)


```
Merge pull request #55 from justinstoller/maint/master/revert-vpooling

Revert "Merge pull request #38 from anodelman/vcloud-pooling"
```
* Revert "Merge pull request #38 from anodelman/vcloud-pooling" (b4b7143a)


```
Revert "Merge pull request #38 from anodelman/vcloud-pooling"

This reverts commit 0f2ffc5e15fe9503518b01d2b92be40fdf6dc74c, reversing
changes made to 6ccbe4c80100715c934b0df475a0739e7cbf038b.
```
* Merge pull request #38 from anodelman/vcloud-pooling (0f2ffc5e)


```
Merge pull request #38 from anodelman/vcloud-pooling

vCloud host-pooling
```
* pass tasks instead of objectSet to wait_for_tasks (e9c2733d)

* add retry for failure to find host in pool (ccb0ae68)


```
add retry for failure to find host in pool

- will retry until timeout to grab pooled box for a given host
- raises readable error upon failure to allocated pooled host
```
* Merge pull request #53 from jpartlow/issue/master/fix_windows_group_list_allowed_characters (6ccbe4c8)


```
Merge pull request #53 from jpartlow/issue/master/fix_windows_group_list_allowed_characters

Relax regex for windows group names
```
* remove race condition upon vm cloning, general cleanup (d4011c9e)

* Relax regex for windows group names (f008ca55)


```
Relax regex for windows group names

Windows::Group.group_list was only recording group names matching
/[\w ]/, but windows groups have a much larger set of valid characters
(http://technet.microsoft.com/en-us/library/bb726984.aspx).  This was
causing a failure on a Windows 2012 template which had a group with a
'-' in it.

Instead of trying to specify what is valid, accept whatever the wmic
group indicates is a group, since it should know.
```
* Merge pull request #52 from jpartlow/issue/master/determine_windows_arch_for_2003_through_2012 (0534ce72)


```
Merge pull request #52 from jpartlow/issue/master/determine_windows_arch_for_2003_through_2012

Identify os architecture on windows 2003, 2008, 2012
```
* make vcloud hypervisor code better (b6424e2a)


```
make vcloud hypervisor code better

- break out pooled vs. non-pooled code
- break up long proceduces
- avoid code duplication
```
* Merge pull request #50 from anodelman/hunner (86d2ed47)


```
Merge pull request #50 from anodelman/hunner

potential fix for failing travis tests
```
* Merge pull request #49 from anodelman/missing-msg (3ade22a6)


```
Merge pull request #49 from anodelman/missing-msg

remove use of undefined variable 'msg'
```
* Merge pull request #46 from anodelman/fix-hypervisor-cleanup (0576fb1d)


```
Merge pull request #46 from anodelman/fix-hypervisor-cleanup

(QE-440) beaker hypervisor creator not returning hypervisor object
```
* Identify os architecture on windows 2003, 2008, 2012 (b844f41d)


```
Identify os architecture on windows 2003, 2008, 2012

Previous tests relied on wmi os osarchitecture property, which is not
present on Windows 2003.  Now we check osarchitecture first, and use
its result if successful.  If that attempt fails we fall back to
grepping the wmi os name property for an x64 string.
```
* Merge pull request #44 from justinstoller/maint/master/one_more_time_with_feeling (5e14a7f7)


```
Merge pull request #44 from justinstoller/maint/master/one_more_time_with_feeling

add back signing of dns-alt-name certs
```
* potential fix for failing travis tests (81d7eee0)

* remove use of undefined variable 'msg' (509abbf5)

* Merge pull request #47 from jpartlow/issue/master/windows_package_install_fails_testing_result (030f6ebb)


```
Merge pull request #47 from jpartlow/issue/master/windows_package_install_fails_testing_result

Correctly determine win arch for installing packages.
```
* Correctly determine win arch for installing packages. (6892acbb)


```
Correctly determine win arch for installing packages.

My previous implementation had a bug in that it expected execute to
return a result object.  Instead, execute exposes the result object to a
passed block.  So now we check the result within a block and set rootdir
and cygwin executable there.
```
* Merge pull request #41 from hunner/single_exit_codes (d124332f)


```
Merge pull request #41 from hunner/single_exit_codes

Allow single exit codes
```
* (QE-440) beaker hypervisor creator not returning hypervisor object (a4407e2d)

* Merge pull request #45 from anodelman/187-mimetypes (2f12fdd0)


```
Merge pull request #45 from anodelman/187-mimetypes

(QE-428) bundle install fails on Ruby 1.8.7 because of new mime-types 2.0 dependency requiring 1.9.2
```
* (QE-428) bundle install fails on Ruby 1.8.7 because of new mime-types 2.0 dependency requiring 1.9.2 (fd70a79c)


```
(QE-428) bundle install fails on Ruby 1.8.7 because of new mime-types 2.0 dependency requiring 1.9.2

- add entry to gemspec to use mime-types 1.25 with ruby 1.8.7
```
* fixes in response to review comments (adf10c49)

* add back signing of dns-alt-name certs (b57f3a6c)

* Revert "QE-364 Clean up line endings" (a1c40a10)


```
Revert "QE-364 Clean up line endings"

This reverts commit 38d7810ee26b74656344eba429e1826031a4b1df.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Merge pull request #43 from kylog/feature/add-hostname-to-dns-exception (8cd4649d)


```
Merge pull request #43 from kylog/feature/add-hostname-to-dns-exception

Add hostname to dns exception
```
* Merge pull request #40 from hunner/chomp_lineendings (4607f820)


```
Merge pull request #40 from hunner/chomp_lineendings

QE-364 Clean up line endings
```
* Merge pull request #42 from kbarber/maint/master/yarddocs-answers (93336666)


```
Merge pull request #42 from kbarber/maint/master/yarddocs-answers

Add yarddocs to beaker/answers* modules
```
* Merge pull request #33 from anodelman/default-host-support (da359c35)


```
Merge pull request #33 from anodelman/default-host-support

QE-361 support using a default host in tests
```
* Add hostname to dns exception (97dd071a)


```
Add hostname to dns exception

Without this patch the exception message on dns failures looks like:

DNS resolution failed after 300 seconds (RuntimeError)

This patch adds the hostname, possibly helpful for troubleshooting infrastructure failures.
```
* Add yarddocs to beaker/answers* modules (0cc49ef8)


```
Add yarddocs to beaker/answers* modules

This just documents those 4 files with yard-docs. Also fixed some minor
style issues.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Allow single exit codes (00bc74c3)


```
Allow single exit codes

When using `:allowed_exit_codes` it is cumbersome to always have an
array of specified values. This change allows `:allowed_exit_codes => 1`
to be used.
```
* QE-364 Clean up line endings (38d7810e)


```
QE-364 Clean up line endings

When using `Beaker::Command` helpers such as `facter()` or even `on()`
the resulting output is often a single line and of interest for its
value. The newline returned at the end of the line is not relevant to
interests and ends up getting `.chomp` called on it in almost every
case.

This change chomps the final newline off of stdout and stderr output so
that tests can be more simply written without having to `.chomp`
```
* Merge pull request #37 from hunner/ip_space (e50fb002)


```
Merge pull request #37 from hunner/ip_space

Avoid using 192.168.0.0/16
```
* vCloud host-pooling (d4351a3c)


```
vCloud host-pooling

- This PR enabled the use of the "pooling_api" configuration parameter:
- spec tests for vsphere/vcloud hypervisors
```
* Avoid using 192.168.0.0/16 (de49ec64)


```
Avoid using 192.168.0.0/16

When using 192.168.0.0/16 address space on a 192.168.x.0/24 NAT'd
network (such as most home routers) VirtualBox will complain that the
virtual private network overlaps with an existing network and refuses to
start the VMs. 10.255.0.0/16 is a less-likely to conflict range, though
not perfect.
```
* Merge pull request #35 from anodelman/utils-shared-spec (7a6eb411)


```
Merge pull request #35 from anodelman/utils-shared-spec

spec test coverage for utils/ and shared/
```
* Merge pull request #36 from hunner/avoid_ip_1 (a8bb71e3)


```
Merge pull request #36 from hunner/avoid_ip_1

Avoid IPs ending in .0, .1, or .255
```
* Avoid IPs ending in .0, .1, or .255 (d5aca5be)


```
Avoid IPs ending in .0, .1, or .255

Vagrant 1.2.5 and later do not allow IPs ending in `.1`, in addition to
the usual limitations of `.0` or `.255`.
```
* Merge pull request #28 from anodelman/hyper-spec (c4a52401)


```
Merge pull request #28 from anodelman/hyper-spec

spec test coverage for hypervisors
```
* modified to use make_host/make_hosts methods in helpers.rb (a08c3a74)


```
modified to use make_host/make_hosts methods in helpers.rb

- more general cleanup
```
* review fixes and changes (6dfc7f50)

* review comments + shifting other spec tests to centralized host creation (4f1c79cf)


```
review comments + shifting other spec tests to centralized host creation

- now that we have make_hosts the rest of the specs should use it
- cleanup!
```
* Merge pull request #30 from anodelman/win64 (536f8c8f)


```
Merge pull request #30 from anodelman/win64

QE-348 - beaker can't run puppet on 64 bit windows hosts
```
* fixes for hyperviser spec tests (14613ce6)


```
fixes for hyperviser spec tests

- move shared code to helpers.rb
- general cleanup
```
* QE-361 support using a default host in tests (fc890412)


```
QE-361 support using a default host in tests

- create a default host
- support using the role as a valid host in calls to #on
  eg, on 'loadbalancer', "echo hello"
- create shell command to run on default host
- provide matchin commands to *_on
- spec tests for new commands, some backfill
```
* Merge pull request #32 from justinstoller/bug/master/allow_2 (260e204a)


```
Merge pull request #32 from justinstoller/bug/master/allow_2

Allow 2 as exit code when non-agent cert submit
```
* Allow 2 as exit code when non-agent cert submit (d7bdf632)


```
Allow 2 as exit code when non-agent cert submit

We have nodes with more-than-just-an-agent ensure they've
checked in prior to signing certs (in case they do not follow default
naming schemes). Unfortunately in some cases the agent will also change
the system, returning 2. This is valid behavior.
```
* Merge pull request #31 from branan/3x_answers (a7028cd1)


```
Merge pull request #31 from branan/3x_answers

Use PE 3.0 answer gen for all 3.X
```
* Merge pull request #27 from justinstoller/maint/master/breaking_my_world (1fe1e18d)


```
Merge pull request #27 from justinstoller/maint/master/breaking_my_world

work with separate master/agent certs on master
```
* Use PE 3.0 answer gen for all 3.X (c633f897)

* Merge pull request #29 from anodelman/sles-pkg-install (8ad0a222)


```
Merge pull request #29 from anodelman/sles-pkg-install

support for package installation on sles SUTs
```
* fixup spec test (ef5596b3)

* fix per branans comments (3986c29e)

* QE-348 - beaker can't run puppet on 64 bit windows hosts (0f3a2a42)


```
QE-348 - beaker can't run puppet on 64 bit windows hosts

- use "Program Files" on win32 windows host
- use "Program Files (x86)" on win64 windows host
```
* support for package installation on sles SUTs (d3d76b31)


```
support for package installation on sles SUTs

- using 'zypper in' for installation
- using 'zypper rm' for removal
```
* ensure weve requested a cert.... (bb544522)

* fix for fusion specs run on non-mac (39dc7d27)

* creation of /shared spec tests (59771de8)

* creation of utils/ spec tests (27c6289f)

* work with separate master/agent certs on master (5f22d48b)


```
work with separate master/agent certs on master

This makes sure the agent's server is the same as the master's certname
and will sign the console/master/database cert in case an agent on those
boxes has a unique cert
```
* Merge pull request #26 from anodelman/do-cleanup (fffe7b39)


```
Merge pull request #26 from anodelman/do-cleanup

move validation to main testing loop - ensures cleanup on failure
```
* Merge pull request #25 from anodelman/keyfile (bde5539c)


```
Merge pull request #25 from anodelman/keyfile

fix for not using --keyfile specified in an options file
```
* move validation to main testing loop - ensures cleanup on failure (619e5a7a)

* fix for not using --keyfile specified in an options file (8e164809)

* Merge pull request #22 from anodelman/yield-result (f3519eb6)


```
Merge pull request #22 from anodelman/yield-result

(QE-245)  Execution results should be available inside a block
```
* creation of solaris spec tests (65bfd96d)

* creation of aixer spec tests (41e4091a)

* creation of blimper spec tests (d7615cee)

* Merge pull request #14 from jpartlow/issue/master/with_puppet_running_on (0652d413)


```
Merge pull request #14 from jpartlow/issue/master/with_puppet_running_on

Issue/master/with puppet running on
```
* creation of vagrant spec tests (61a5c2a2)

* Allow solaris as master for non-pe tests. (651c6aad)


```
Allow solaris as master for non-pe tests.

Foss acceptance tests historically check solaris as a master.  This
changes the options parser normalization to allow solaris hosts the
master role if the run type is not pe.
```
* spec test fixes for testing yielding in #on (7b92102e)

* (maint) Break up mocks_and_helpers (e43d84f8)


```
(maint) Break up mocks_and_helpers

There is a spec/mocks, helpers and matchers file now included by
spec_helper.  Additional mock class and matcher from dsl/helpers_spec
have been moved into them as well.
```
* (maint) Confine execute_commands_matching matcher to FakeHost (fd2969e0)


```
(maint) Confine execute_commands_matching matcher to FakeHost

The matcher only works with the FakeHost mock.  This just tests that
condition before attempting the test.
```
* spec tests for stdout/stderr/exit_code values after calling on (793057b2)

* creation of fusion spec tests (dfe81660)

* Merge pull request #24 from justinstoller/bug/master/QE311-undefined_wait (74610f21)


```
Merge pull request #24 from justinstoller/bug/master/QE311-undefined_wait

(QE-311) Bring just Scott's fix in (closes #20)
```
* Merge pull request #23 from anodelman/vagrant-file (19cd2931)


```
Merge pull request #23 from anodelman/vagrant-file

fix for changed option name (:config to :hosts_file)
```
* Merge pull request #21 from anodelman/beaker-rspec (e20ea5a8)


```
Merge pull request #21 from anodelman/beaker-rspec

Revert "Merge pull request #17 from anodelman/beaker-rspec"
```
* fix for changed option name (:config to :hosts_file) (9765c75a)


```
fix for changed option name (:config to :hosts_file)

Was causing error when using vagrant SUTs
```
* (QE-245)  Execution results should be available inside a block (3a5f9ec2)


```
(QE-245)  Execution results should be available inside a block

Moving accessors out of test_case and into the dsl so that beaker-rspec
will be able to access them
```
* Merge pull request #15 from anodelman/multi-version (b3df7aac)


```
Merge pull request #15 from anodelman/multi-version

Multi-version PE installation
```
* Revert "Merge pull request #17 from anodelman/beaker-rspec" (2b9edf69)


```
Revert "Merge pull request #17 from anodelman/beaker-rspec"

This reverts commit 90c2642b4ad2323cb6c9fe642d7befdf5af7168a, reversing
changes made to 18cef9f78a3d3be4963bbde32cb394c70a83641f.

This change was ineffective and did not actually allow for the use of
the host-file env var.
```
* spacing fixes in new spec tests (37f01eda)

* spec tests for install_utils and answers.rb (742b82c1)


```
spec tests for install_utils and answers.rb

- increasing spec test coverage of new functionality
```
* (maint) Correct solaris 11/10 package install/uninstall (8751772a)


```
(maint) Correct solaris 11/10 package install/uninstall

Solaris has different package handling between 11 and 10.  We were
correct on install for Solaris 11, but uninstall was Solaris 10.

Now differentiate between the two with the correct package handlers for
11 and 10 respectively.

This also corrects a bug checking for existing packages in Solaris 10.
The which command returns an exit code of 0, even if the command is not
found.  So we're testing stdout explicitly to see if a path to command
was returned.
```
* (maint) Remove reference to nonexistent puppetpath. (a99173bb)


```
(maint) Remove reference to nonexistent puppetpath.

This would have failed if no backup_file was provided.  Now backup_file
is required without default.
```
* Use @options[:timeout] instead of wait (747bde15)

* Merge pull request #12 from hunner/hide_vagrantfile (c5e3840c)


```
Merge pull request #12 from hunner/hide_vagrantfile

I had a closer look at the code and this looks good.  Merging.
```
* spec test fix (d673c27f)


```
spec test fix
- needed to add new command line argument
```
* further review comment fixes (aacf9170)


```
further review comment fixes
- make do_install @api private
- fix spec tests
```
* Merge pull request #17 from anodelman/beaker-rspec (90c2642b)


```
Merge pull request #17 from anodelman/beaker-rspec

allow for setting the hosts file from an ENV var
```
* (maint) Check that puppet's master process has finished (2b1bb515)


```
(maint) Check that puppet's master process has finished

This avoids occasional errors where the next test's
with_puppet_running_on tries to start a new master before the previous
test's has shutdown completely.
```
* use 3.0 answer files for 3.1 builds (facef385)

* fix for bug found by branan when generating answer file for an upgrade (e87db4b2)


```
fix for bug found by branan when generating answer file for an upgrade
- need to correctly make the answers file for the upgrade version, not
  the current version
- also update the host pe_ver post-upgrade to reflect the new state
```
* Merge pull request #18 from puppetlabs/timeout_option (18cef9f7)


```
Merge pull request #18 from puppetlabs/timeout_option

Allow a --timeout option for vCloud provisioning
```
* Merge pull request #16 from kbarber/travis-ci-support (5f453bd9)


```
Merge pull request #16 from kbarber/travis-ci-support

Add .travis.yml for initial travis CI support
```
* Add a 'vCloud only' note (58ae01bb)

* more review comment fixes (fb14b74c)


```
more review comment fixes
- repaired broken spec tests from option parsing change
- edits to yard docs
```
* (maint) Echo empty string to wmic for stdin (7db5ac15)


```
(maint) Echo empty string to wmic for stdin

wmic on 2003, at least, blocks waiting on standard in.  This change
gives it something to consume so that it continues.
```
* Allow a --timeout option for vCloud provisioning (09821fcb)

* Add a method to confine hosts for a specific test block (d1e26942)


```
Add a method to confine hosts for a specific test block

The Beaker::DSL::Helpers#confine method would change the test's array of
hosts at the point it was called, and any subsequent tests or tear down
blocks would only operate on that restricted subset of hosts.

This patch adds a confine_block method which allows you to confine hosts
for a specific block of code, ensuring that the hosts array is reset to
its original value after the block is done.  This allows you to confine
a subset of a test, but still have a teardown clean up all hosts, for
example.
```
* code review improvements (806a5d46)


```
code review improvements
- yard documentation for install and upgrade
- moved pe_ver and pe_dir discovery to install_pe and out of option
  parsing (only do it if you need it)
- changed answer file generation to be generically 2.0 instead of 2.0.3
```
* allow for setting the hosts file from an ENV var (cb632f56)


```
allow for setting the hosts file from an ENV var
- set the --hosts file ENV (using hosts_file or config_file)
```
* add support for 2.0.3 installs (4ac0cf2b)


```
add support for 2.0.3 installs
- can now have both pe_dir and pe_ver/pe_ver_win in hosts file per-node
- 2.0.3 answer file generation
```
* fix for upgrades to less than 3.0 pe (18aa42a6)


```
fix for upgrades to less than 3.0 pe
- have to apply the pre 3.0 rules for upgrades to a pre 3.0 version
- added a check for ensuring that solaris/aix/windows are agent only
```
* Add .travis.yml for initial travis CI support (db43bc40)


```
Add .travis.yml for initial travis CI support

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Incorrect number of arguments for load_legacy_config in vspher_helper (0975ea14)

* no longer have to pass version to upgrade_pe command (b98a10ef)


```
no longer have to pass version to upgrade_pe command
- fixed so that it determines the upgrade version from the upgrade path
  LATEST file
```
* multi-vesion pe installation (ecfa1c1f)


```
multi-vesion pe installation
- can now have each host identify a pe_dir to pull from
- host file supports a 'pe_dir' per node
- still uses the LATEST file (sorry, Branan)
- fixed upgrade code alongside install code
```
* Uninstall packages on unix (62990dcc)

* Merge pull request #11 from anodelman/option-parsing (17be7c85)


```
Merge pull request #11 from anodelman/option-parsing

(QE-117) overhaul of option parsing in beaker
```
* (maint) Dump master puppet log if fail to start (1837c8ad)

* raise/rescue ArgumentError on failure to find single host for a role (acad550e)

* Merge pull request #9 from anodelman/vagrant-netmask (49789312)


```
Merge pull request #9 from anodelman/vagrant-netmask

(QE-203) vagrant uses different ip submasks by default
```
* (maint) Allow options to be passed for package installation (e2800288)


```
(maint) Allow options to be passed for package installation

Host::Unix::Pkg#install_package previously took only the package name.
An additional string of commandline options may now be passed and will
be included in the yum, apt-get or solaris pkg install line.
```
* documenting the new option parsing code (52539070)

* adding spec tests for new options parsing code (7d1f30b0)

* (maint) Fix with_puppet_running_on for testing with packages (f6b57e42)


```
(maint) Fix with_puppet_running_on for testing with packages

PuppetAcceptance::DSL::Helpers#with_puppet_running_on had incomplete
changes brought in from the pe Puppet::Acceptance::ConfigUtils, which I
think were being shadowed by the direct inclusion of ConfigUtils in
tests using with_puppet_running_on.

This patch finishes up the with_puppet_running_on implementation and
adds two things.  One a :__commandline_args__ option to allow passing of
commandline flags to puppet in addition to configuration settings.  And
two, an attempt to ensure that errors raised during setup or execution
of the block are not masked by a failure in teardown.

Conflicts:
	lib/beaker/dsl/helpers.rb
	spec/beaker/dsl/helpers_spec.rb
```
* Create the vagrant file in a sub directory (1472ee94)


```
Create the vagrant file in a sub directory

The vagrant file was previously dropped in the current working
directory. This commit causes the vagrant file to be created in
`vagrant_files/<config>/Vagrantfile` so that it does not conflict with
tests running against multiple cfg files.
```
* not passing @options[:dot_fog] through correctly (580c224c)

* Add package installation for solaris. (4821e344)


```
Add package installation for solaris.

Also fixes a bug referencing 'host' instead of self in the message
raised when platform cannot install package.
```
* first pass of fixes for review comments (b3be4b46)


```
first pass of fixes for review comments
- don't 'exit' from option parsing, just raise appropriate errors
- moved option dump into a logging command in cli
- moved exiting on --help into the cli
- made it possible to send different array than ARGV to
  command_line_parsing
- reworked recursive print out of options
- reordered merge of options in host.rb (ensure that defaults is lowest
  priority)
- renamed 'defaults' to 'presets' as these are options that can come
  from env vars exported before a test run
- fixed broken spec tests
```
* (maint) Remove incorrect parameter from Command.new call (7738d743)


```
(maint) Remove incorrect parameter from Command.new call

Command.new does not take a host.  This line was treating host as the
command line, and then attempting to flatten the actual command line
string which it expected to be an Array of args.
```
* cleaner handling of running the different test suites (904ea552)


```
cleaner handling of running the different test suites
- no reason to override the :tests in @options
```
* Dump syslog on either rhel or debian if fail to kill puppet master (65c7983a)


```
Dump syslog on either rhel or debian if fail to kill puppet master

It's very difficult to debug why we were unable to kill the puppet
master (presumably it died or was killed by an earlier action).  And
usually our vms are spun down after execution.  If it's a transient
issue, then trying to track it down in a controlled environment is
difficult as well.  So this takes a stab at dumping the default logdest
target (syslog) on either a rhel or debian based system.
```
* Merge pull request #10 from apchamberlain/master (abfed9ba)


```
Merge pull request #10 from apchamberlain/master

Fusion/fission configuration cleanup in README
```
* fixing default values for arguments that can be lists of items (84441b3f)


```
fixing default values for arguments that can be lists of items
- ensures that lists of items options (tests, pre-suite, etc) default to
  []
- fixes how file options are merged into the rest of the arguments
- fix up getting pe version number from LATEST file
```
* moving hypervisor config files to @options variable (33eea5da)


```
moving hypervisor config files to @options variable
- makes it clear where these magic files are located
- added error checking to ensure that they are present for appropriate
  hypervisors
- check in advance that there is one and only one 'master' in the given
  host config
```
* fixes for hypervisors using new option formatting (11cf1100)

* fixing spec tests to handle new option format (ff7c38b2)


```
fixing spec tests to handle new option format
- also broken tests from previous work (should run spec more often...)
```
* Cleaned up explanation of .fissionrc file; changed references to .VMX files to .vmwarevm (35d1bed3)

* missing file options.rb added (8a30c07d)


```
missing file options.rb added
- moved pe version discovery into pe_version_scraper
```
* move options parsing into own directory (3b81c094)


```
move options parsing into own directory
- deprecate @config
- switch hypervisor classes to no longer use @config
- use special OptionHash that doesn't differentiate between string +
  symbols
- add first pass validation of command line options
- roll out command line parsing into its own class
```
* (QE-203) vagrant uses different ip submasks by default (b60c0fa5)


```
(QE-203) vagrant uses different ip submasks by default
Vagrant was assigning each VM to a different submask, hence them not
being able to connect to each other. In effect, they were all on
different networks.
Force a shared submask.
```
* initial commit of moving all argument parsing into options_parsing (7841eed6)

### <a name = "beaker0.0.0">beaker0.0.0 - 20 Aug, 2013 (c49dc525)

* Merge pull request #8 from anodelman/gemify (c49dc525)


```
Merge pull request #8 from anodelman/gemify

set version number to 0.0.0, set description/summary for gem
```
* setting version number to 0.0.0 (606e1770)

* Merge pull request #7 from anodelman/gemify (43fcc786)


```
Merge pull request #7 from anodelman/gemify

pulling out last references to PuppetAcceptance module
```
* pulling out last references to PuppetAcceptance module (2575b020)

* pulling out last references to PuppetAcceptance module (4775190e)

* Merge pull request #5 from anodelman/gemify (e2ed1a0e)


```
Merge pull request #5 from anodelman/gemify

rename puppet-acceptance to beaker, PuppetAcceptance to Beaker
```
* Merge pull request #6 from anodelman/installer (343ddbb6)


```
Merge pull request #6 from anodelman/installer

installation/upgrade code in harness
```
* adding 'wait for puppetdb to start on 3.0.0, PE-1105' (85868c2d)


```
adding 'wait for puppetdb to start on 3.0.0, PE-1105'
https://github.com/puppetlabs/pe_acceptance_tests/commit/c479972d4202f04d5c03baf8e0b2ef0b25e16dbf
```
* adding 'fix negative grep command' from pe_acceptance_tests (53ec9a82)


```
adding 'fix negative grep command' from pe_acceptance_tests
https://github.com/puppetlabs/pe_acceptance_tests/commit/7599ff9e0a428effa8a9c5137e5d2f10f071abc8
```
* adding branan's answer file changes to the built in installer (3b6e9397)

* installation/upgrade code in harness (9041aee5)


```
installation/upgrade code in harness
add pe_install and pe_upgrade commands to the dsl
```
* rename puppet-acceptance to beaker, PuppetAcceptance to Beaker (30c2dfd1)

* Merge pull request #1 from anodelman/rhel4 (83349ef1)


```
Merge pull request #1 from anodelman/rhel4

(QE-189) Puppet Acceptance needs to be able to handle rhel4
```
* Merge pull request #2 from anodelman/installer (c77728e9)


```
Merge pull request #2 from anodelman/installer

QE-97) move installation into the test harness
```
* nit - missing comma (aede8c4e)

* remove references to 'redhat', our naming is standardized on el-* (fce1f6be)

* Merge pull request #3 from anodelman/cruft (647f7992)


```
Merge pull request #3 from anodelman/cruft

(QE-51) Remove cruft from the harness
```
* Merge pull request #4 from anodelman/validator (277daf4e)


```
Merge pull request #4 from anodelman/validator

(QE-150) update harness to use correct 32/64 bit version of cygwin setup.exe
```
* (QE-150) update harness to use correct 32/64 bit version of cygwin setup.exe (11628606)


```
(QE-150) update harness to use correct 32/64 bit version of cygwin setup.exe
Can't be landed till https://jira.puppetlabs.com/browse/QE-145 is fixed.
This patch depends on the windows static vms being updated
```
* (QE-51) Remove cruft from the harness (ec506e76)


```
(QE-51) Remove cruft from the harness
Removes:
    * old node configuration files
    * the entire setup/git directory
    * remove pe_versions file
    * remove pe dependency versions variable from test_case/test_config
    * removes templates
    * removes old xml files
```
* QE-97) move installation into the test harness (c6058ccc)


```
QE-97) move installation into the test harness
* move pe installation into the test harness dsl
* does not change logic as to env vars/options
* fixup validation module structure
* add support for basic upgrading
```
* (QE-189) Puppet Acceptance needs to be able to handle rhel4 (ad24d8e5)


```
(QE-189) Puppet Acceptance needs to be able to handle rhel4
- skips epel installation on rhel4
- skips package installation on rhel4
- increased timeout for vcloud dns resolution
```
* Merge pull request #507 from anodelman/revert-cruft-removal (68272162)


```
Merge pull request #507 from anodelman/revert-cruft-removal

Revert "Merge pull request #490 from justinstoller/maint/master/remove_cruft"
```
* Revert "Merge pull request #490 from justinstoller/maint/master/remove_cruft" (307b8b78)


```
Revert "Merge pull request #490 from justinstoller/maint/master/remove_cruft"

This reverts commit 715b335f7f7623f00a28312072b0ec1123965eb3, reversing
changes made to 3b4891b6acaa6932be950ff51995c7191410acdb.
```
* Merge pull request #489 from justinstoller/bug/master/QE55-upstream_with_puppet_running_on (c348a792)


```
Merge pull request #489 from justinstoller/bug/master/QE55-upstream_with_puppet_running_on

Add an alternative to with_master_running_on that can be used with PE
```
* Merge pull request #500 from puppetlabs/vcloud_windows_customization (463f8f08)


```
Merge pull request #500 from puppetlabs/vcloud_windows_customization

vCloud Windows customization
```
* Merge pull request #490 from justinstoller/maint/master/remove_cruft (715b335f)


```
Merge pull request #490 from justinstoller/maint/master/remove_cruft

Remove a lot of the cruft left in the source tree.
```
* Merge pull request #505 from branan/scp_from_signature (3b4891b6)


```
Merge pull request #505 from branan/scp_from_signature

Fix scp_from signature to match the way it is invoked.
```
* Fix scp_from signature to match the way it is invoked. (a5e84200)


```
Fix scp_from signature to match the way it is invoked.

The signature had an extra options hash which was not passed by the
host.rb code which calls the method.
```
* Merge pull request #499 from anodelman/validator (30f6ce23)


```
Merge pull request #499 from anodelman/validator

(QE-90)  validate test systems have required packages/services before testing
```
* move install_package and check_for_package into appropriate host (391c6250)


```
move install_package and check_for_package into appropriate host
platform code
supports windows and unix - not solaris + aix
windows installs cygwin packages, cannot install 3rd party cygwin
packages (like ntpdate)
```
* Merge pull request #501 from puppetlabs/QE-80-use_absolute_template_path (0a5ac969)


```
Merge pull request #501 from puppetlabs/QE-80-use_absolute_template_path

(QE-80) Support absolute paths in 'template' host variable
```
* Merge pull request #503 from puppetlabs/QE-136-vcloud_first_char_alpha (4f72dbe3)


```
Merge pull request #503 from puppetlabs/QE-136-vcloud_first_char_alpha

(QE-136) Ensure first character of vCloud hostname is alphabetical
```
* Ensure first character of hostname is alphabetical (24c99d64)

* Merge pull request #502 from anodelman/vagrant-warnings (d1a90dba)


```
Merge pull request #502 from anodelman/vagrant-warnings

(QE-129) test harness reports vagrant warnings on box set up
```
* (QE-129) test harness reports vagrant warnings on box set up (a9a52db6)


```
(QE-129) test harness reports vagrant warnings on box set up
Was using Vagrantfile format 1.0 instead of 2.0, with 2.0 the warning
goes away
```
* Restoring error message (d69c54b5)

* Merge pull request #498 from anodelman/set-vagrant-memory-size (136c2129)


```
Merge pull request #498 from anodelman/set-vagrant-memory-size

(QE-96)  vagrant boxes' default memory allocation is too small
```
* Typo in hypervisor/vsphere (e946b824)

* Support absolute paths in 'template' host variable (b3a2ae3e)

* s/vagrant/vCloud/ (da8939bd)

* Better organization for customization-spec code (d97383f7)

* (QE-90)  validate test systems have required packages/services before (55b2a48a)


```
(QE-90)  validate test systems have required packages/services before
testing.  First pass -  checks for curl and ntpdate, installs if missing
```
* Additional waiting for vCloud customization (4953981a)

* Merge pull request #497 from puppetlabs/vcloud_windows_customization (36489149)


```
Merge pull request #497 from puppetlabs/vcloud_windows_customization

vCloud customization
```
* (QE-96)  vagrant boxes' default memory allocation is too small to run (06366322)


```
(QE-96)  vagrant boxes' default memory allocation is too small to run
puppet on, make default size 1G of RAM
```
* Allow extra time for the super-slow guest customization (510a38ba)

* Include a logger msg if using a customization spec (57dad7b6)

* Use customization spec if one exists (0d684be5)

* Adding 'find_customization' method (99ad761c)

* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (c9e7cea2)

* Merge pull request #491 from justinstoller/bug/master/QE71-alwasy_remove_harness_stack (66e0dcdf)


```
Merge pull request #491 from justinstoller/bug/master/QE71-alwasy_remove_harness_stack

Remove references to the harness's call stack in back traces
```
* Merge pull request #494 from puppetlabs/remove_blimpy_git_setup (778bf1de)


```
Merge pull request #494 from puppetlabs/remove_blimpy_git_setup

Removing Git/Ruby setup routines in the Blimpy hypervisor
```
* Merge pull request #496 from justinstoller/maint/master/QE72-Log_is_intialized_already___geez____ (68b9f14e)


```
Merge pull request #496 from justinstoller/maint/master/QE72-Log_is_intialized_already___geez____

Only define the constant Log if it isn't already defined
```
* Only define the constant Log if it isn't already defined (e7090f58)

* Merge pull request #492 from anodelman/print-config (027fbc89)


```
Merge pull request #492 from anodelman/print-config

(maint) report error when using an empty directory, print options with --debug
```
* Syntax (spacing) (1a60c5f0)

* Removing Git/Ruby setup routines in the Blimpie hypervisor (e8406ada)

* Merge pull request #488 from anodelman/better-vagrant (c3304e07)


```
Merge pull request #488 from anodelman/better-vagrant

(QE-62) log into vagrant boxes as root/administrator
```
* (maint) report error when using an empty directory for (2c5b3028)


```
(maint) report error when using an empty directory for
pre-suite/post-suite/tests, print options when running with --debug
```
* Remove references to the harness's call stack in back traces (12778549)


```
Remove references to the harness's call stack in back traces

Prior to this when NOT running in `--debug` mode the harness's call
stack would be removed from any stack trace to clarify the calling
methods within a test. This extends that functionality to `--debug`
mode.
```
* code cleanup/reorganization (4c202601)

* remove a bunch of cruft (48767873)

* Add an alternative to with_master_running_on that can be used with PE (df7b0bdf)


```
Add an alternative to with_master_running_on that can be used with PE

Previously we added methods called `with_puppet_running_on` to several
individual projects so that we could get them to have similar behavior
to `with_master_running_on` but work on our enterprise products as well.
This combines and refactors the downstream `with_puppet_running_on`
implementation, bringing them into the harness proper.
```
* Merge pull request #487 from anodelman/overwritten-options (2b38984c)


```
Merge pull request #487 from anodelman/overwritten-options

(21596) pre-suite when set in options.rb is overwritten by default
```
* (21596) pre-suite when set in options.rb is overwritten by default, (c2866d16)


```
(21596) pre-suite when set in options.rb is overwritten by default,
merge defaults after merging file options
```
* Merge pull request #486 from briancain/maint/master/many_helper_functionality_redo (2b69dd95)


```
Merge pull request #486 from briancain/maint/master/many_helper_functionality_redo

(maint) Add Multiple Helper Options
```
* (maint) Add Multiple Helper Options (d30280f4)


```
(maint) Add Multiple Helper Options

Prior to this commit, puppet-acceptance could only handle one helper
while testing. This commit fixes that by allowing for multiple helpers
to be passed in as many times as you want.
```
* Merge pull request #484 from anodelman/QE-56 (after rebasing) (294f2813)

* Merge pull request #482 from anodelman/QE-43 (f54f699a)


```
Merge pull request #482 from anodelman/QE-43

(QE-43) handle empty pre-suite/tests/post-suite options
```
* fix inconsistant spacing in README (8017bb57)

* fixup some README typos (fe44695f)

* (QE-62) log into vagrant boxes as root/administrator (5fb970de)

* (QE-56) remove deprecated command line options, alter confusing options (10f70e26)

* Merge pull request #483 from djm68/add_apache_license (43ee1370)


```
Merge pull request #483 from djm68/add_apache_license

(maint) Add Apache License v2.0
```
* (maint) Add Apache License v2.0 (cd696b31)

* (QE-43) handle empty pre-suite/tests/post-suite options (91e19276)

* Merge pull request #481 from anodelman/QE-40 (bd123179)


```
Merge pull request #481 from anodelman/QE-40

(QE-40) inter-vagrant box communication not working
```
* fix how ips are handled for vagrant boxes (93f8c809)

* Merge pull request #474 from anodelman/install_vs_type_vs_setupdirs (84fae932)


```
Merge pull request #474 from anodelman/install_vs_type_vs_setupdirs

(20583/21110) normalize --install, --type, --setup-dirs, --helpers
```
* (QE-40) inter-vagrant box communication not working (dfaab70f)

* Merge pull request #480 from anodelman/QE-39 (0fb1686c)


```
Merge pull request #480 from anodelman/QE-39

(QE-39) test harness fails to set up multiple vagrant hosts
```
* (QE-39) test harness fails to set up multiple vagrant hosts (6885aed9)

* Merge pull request #479 from anodelman/vagrant (6818a6ff)


```
Merge pull request #479 from anodelman/vagrant

(19852) Vagrant support in the test harness
```
* Merge pull request #478 from anodelman/fix_environment_construction (012fd64a)


```
Merge pull request #478 from anodelman/fix_environment_construction

(QE-25) fix :environment options being used as puppet argument
```
* Merge pull request #476 from zaphod42/remove-linux-agent-from-windows (1b480336)


```
Merge pull request #476 from zaphod42/remove-linux-agent-from-windows

Remove unneeded roles from linux node in windows tests
```
* Merge pull request #477 from anodelman/QE-12 (89241783)


```
Merge pull request #477 from anodelman/QE-12

(QE-12) Harness should only require rbvmomi if vsphere/vcloud hypervisor is in use
```
* adding documentation for Vagrant support (de0b6924)

* moved aix+solaris provisioning to network_manager (d7bee05b)

* remove vm_control.rb, finish vcloud work (ad106701)

* moved vcloud provisioning to network_manager (0802f23a)

* moved vsphere provisioning to network_manager (104a59dc)

* moved blimpy provisioning to network_manager (0fd9d9d9)

* moved fusion provisioning to network_manager (d0e8553b)

* improved env merging, added spec tests for PuppetCommands (82f841a4)

* (QE-25) fix :environment options being used as puppet argument (fae27a2d)

* initial commit of vagrant provisioning (a65b6234)

* (QE-12) Harness should only require rbvmomi if vsphere/vcloud hypervisor is in use (430d372f)

* Remove unneeded roles from linux node in windows tests (a61bb8be)


```
Remove unneeded roles from linux node in windows tests

The linux node have extra roles (specifically agent) caused it to
execute a large number of tests that it doesn't need to. The linux
agents are tested in a different setup already. Removing the agent from
the linux node should also drastically reduce the runtime of the tests.
```
* (21110) add the --load-path option (8c218eeb)

* (20583) `--install', `--type', and `--setup-dirs' are confusing (c3324940)

### <a name = "pe3.0">pe3.0 - 6 Jun, 2013 (0b52d9c5)

* Merge pull request #475 from anodelman/fix-empty-tests (0b52d9c5)


```
Merge pull request #475 from anodelman/fix-empty-tests

(QE-5) remove implicit array creation
```
* (QE-5) remove implicit array creation (2981a205)

* Merge pull request #473 from anodelman/fix-empty-tests (db40387b)


```
Merge pull request #473 from anodelman/fix-empty-tests

move to standardized error handling
```
* Merge pull request #472 from branan/http_latest_for_win (59bf076b)


```
Merge pull request #472 from branan/http_latest_for_win

Use 'open' instead of 'File.open' for getting the latest windows ver
```
* Use 'open' instead of 'File.open' for getting the latest windows ver (96d53fff)


```
Use 'open' instead of 'File.open' for getting the latest windows ver

The top-level 'open' method can open HTTP URIs which the File.open
method cannot. This is already used for unix hosts.
```
* Merge pull request #471 from justinstoller/maint/20969/path_vs_env_vars_on_win (bcbe0a5d)


```
Merge pull request #471 from justinstoller/maint/20969/path_vs_env_vars_on_win

(20969) Use colon for path separator on all platforms
```
* Merge pull request #468 from branan/node_name_win (ddc0412c)


```
Merge pull request #468 from branan/node_name_win

Fix host::node_name for windows
```
* Merge pull request #470 from anodelman/proxy-config (3a7b617f)


```
Merge pull request #470 from anodelman/proxy-config

(21063) Regression: proxy configuration doesn't work because missing method
```
* (20969) Use colon for path separator on all platforms (baea908d)


```
(20969) Use colon for path separator on all platforms

I had this backwards in 3d510e4b6f and inadvertly pushed for the two
to be normalized in 5966907. This is needed because Cygwin systems
interpret the PATH env var (and require a colon as a separator) prior
to passing it on to Windows while other env vars are passed directly
to the OS.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* (21063) Regression: proxy configuration doesn't work because of method missing (489875ca)

* move to standardized error handling (b2ff6025)

* Merge pull request #469 from anodelman/fix-empty-tests (dd34b33f)


```
Merge pull request #469 from anodelman/fix-empty-tests

(21086) Runtime error when setup steps contain no tests
```
* (21086) Runtime error when setup steps contain no tests (e5946414)

* Merge pull request #467 from anodelman/ec2-config-to-lib (f4f5e8e1)


```
Merge pull request #467 from anodelman/ec2-config-to-lib

move ec2 install git+ruby from setup/early to lib
```
* Fix host::node_name for windows (2e743ace)

* Merge pull request #466 from anodelman/cleanup-snaps (1b9a6d0e)


```
Merge pull request #466 from anodelman/cleanup-snaps

(20979) fix how snapshots are determined, remove hardcoded snapshot names
```
* Merge pull request #455 from anodelman/ntpdate-lib (44524850)


```
Merge pull request #455 from anodelman/ntpdate-lib

move more of /setup/early to lib
```
* (20979) normalize how snapshots are determined, remove hardcoded snapshot name assumptions (35e34bbc)

* better error reporting of failures to setup (72658c49)


```
better error reporting of failures to setup

Conflicts:
	lib/puppet_acceptance/cli.rb
```
* reorganizing based on review comments, replace HostCommand with Command (a01e7505)

* Merge pull request #464 from puppetlabs/vcloud_linked_clones (3ac95d84)


```
Merge pull request #464 from puppetlabs/vcloud_linked_clones

Use linked clones (copy-on-write)
```
* Removing set-delta-disk code (e6500944)

* Merge pull request #463 from anodelman/fix-win-command (4759de81)


```
Merge pull request #463 from anodelman/fix-win-command

(#20969) use the correct path separator for windows
```
* Merge pull request #462 from anodelman/remove-vmrun (e8e0532c)


```
Merge pull request #462 from anodelman/remove-vmrun

(#20776) replace --vmrun with --hypervisor and deprecate --vmrun
```
* Use linked clones (copy-on-write) (8c50d167)

* (#20969) use the correct path separator for windows (5966907e)

* (#20776) replace --vmrun with --hypervisor and deprecate --vmrun (e2668b5f)

* adding keywords to hook into the log parser module for jenkins (94dc3863)

* Merge pull request #460 from puppetlabs/annotation_and_syntax (a1853500)


```
Merge pull request #460 from puppetlabs/annotation_and_syntax

Annotation and syntax
```
* Syntax/verbiage changes (8d7fd627)

* Annotate vcloud VMs (36cf17b0)


```
Annotate vcloud VMs
Base template, creation time, and link to CI build
```
* Merge pull request #458 from anodelman/remove-preserve-hosts-file (f6d61a19)


```
Merge pull request #458 from anodelman/remove-preserve-hosts-file

(#20863) removes host file generation from --preserve-hosts option
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (2c6631fa)

* (maint) add new cfg for PuppetDB perf testing (9a2b9049)

* (#20863) removes host file generation from --preserve-hosts option (369707cf)

* moving error handling to helpers.rb (f65457d7)

* Merge pull request #457 from anodelman/red-on-fail (bcf4a523)


```
Merge pull request #457 from anodelman/red-on-fail

(#20930) fix jenkins green on failure bug
```
* push exit code from system call up through systest.rb (746221a6)

* push the raised exception up the chain (20bb90ea)

* push error handling into utils/vm_control (7de66e88)

* move ec2 install git+ruby from setup/early to lib (6a021637)

* Merge pull request #456 from anodelman/better-error-logging (953ef900)


```
Merge pull request #456 from anodelman/better-error-logging

(maint) improved error logging on vm_control.rb failure
```
* (maint) improved error logging on vm_control.rb failure (91bf2e25)

* Merge pull request #454 from puppetlabs/vcloud_fixup (a0eb3b4e)


```
Merge pull request #454 from puppetlabs/vcloud_fixup

Remove line-break
```
* Remove line-break (d14e3297)

* Merge pull request #453 from anodelman/vm-control-lib (6211cf0f)


```
Merge pull request #453 from anodelman/vm-control-lib

(maint) add error messaging for missing vCloud templates
```
* (maint) add error messaging for missing vCloud templates (a4eaa041)

* (maint) add error messaging for missing vCloud templates (4737fcd7)

* Merge pull request #452 from branan/dont_delete_template_please (c1f27937)


```
Merge pull request #452 from branan/dont_delete_template_please

Fix deploying from vcloud templates
```
* (20880) Complete the conversion of vcloud spinup to a library (ee4c6e63)


```
(20880) Complete the conversion of vcloud spinup to a library

An old variable name from the monolithic reverter was left in the
vcloud code. This changes it to its proper modern name.
```
* (maint) Rescue any cleanup exception (8d5b0497)


```
(maint) Rescue any cleanup exception

Previously, a failure in the cleanup step would cause any exception
from the earlier step(s) to be discarded. This manually handles
cleanup exceptions so the original failure is not masked.
```
* (20880) Use the correct config hash in the vm setup library (86dc3b05)


```
(20880) Use the correct config hash in the vm setup library

There is (unfortunately) a difference between the puppet acceptance
config object and the configuration hash. The config hash is accessed
via the `'CONFIG'` entry in the object. This simply changes the
`@config` member of the vm controller to use the correct hash.
```
* (maint) Do not fall back to the user-specified VM name when doing vcloud cleanup (a91c2c68)


```
(maint) Do not fall back to the user-specified VM name when doing vcloud cleanup

The vcloud provisioning will never create a VM with the user-specified
name, so falling back to it was pointless, and could cause the harness
to delete VMs not associated with the current test run, or worse,
templates.

As a special bonus, if any hosts don't have vmhostname set, we will
warn that they were likely not provisioned correctly in the first
place.
```
* better error checking for failed setup steps, code cleanup (54a43a38)

* Merge pull request #451 from anodelman/maint-vm-control (d47420f4)


```
Merge pull request #451 from anodelman/maint-vm-control

(maint) references to @config breaking, add @config to initialization of
```
* (maint) references to @config breaking, add @config to initialization of (48a1db3d)


```
(maint) references to @config breaking, add @config to initialization of
vm_control object
```
* move --repo-proxy, --extra-repos to lib (a2c9c4ca)

* Merge pull request #448 from anodelman/vm-control-lib (a563b6db)


```
Merge pull request #448 from anodelman/vm-control-lib

(20750) move vm setup/teardown from test steps to lib
```
* fix whitespace (ccb0a159)

* Merge branch 'master' into vm-control-lib (20820188)


```
Merge branch 'master' into vm-control-lib

Conflicts:
	setup/cleanup/00-vmrun.rb
	setup/early/00-vmrun.rb
```
* move syncing root keys from early/ to lib (22fef77a)

* move ruby version control to lib (e1f33c55)

* move etc/host editing from early/ to lib (3d1b28ed)

* Merge pull request #450 from branan/consoleport_as_integer (62411974)


```
Merge pull request #450 from branan/consoleport_as_integer

Force consoleport to always be an integer
```
* Force consoleport to always be an integer (0fb5ed8d)

* Revert "Ensure the consoleport is always a string." (d4e76ad4)


```
Revert "Ensure the consoleport is always a string."

This was stupid. YAML creates integers automatically by default, so
unless the consoleport was set via ENV it would be an integer
previously. Making the default a string didn't do anything to unify
the values.

This reverts commit ec28d512cc068c54d3918d160b599e9917e431f1.
```
* (20750) move ntp commands from test steps to lib (fa193b6d)

* Merge pull request #449 from branan/consoleport_as_string (8e258ead)


```
Merge pull request #449 from branan/consoleport_as_string

Ensure the consoleport is always a string.
```
* Ensure the consoleport is always a string. (ec28d512)


```
Ensure the consoleport is always a string.

Previously, the consoleport would be a string if set by the
environment or a config file, but an integer if left at its
default. This changes the default to a string.

I'm changing the default to a string rather than converting the
env/cfg value to an integer because we have historically set the
consoleport in our config files, so this way it is less likely to
break things.
```
* Merge pull request #446 from puppetlabs/dont_redefine_i (d9267458)


```
Merge pull request #446 from puppetlabs/dont_redefine_i

The index (i) was being redefined in Ruby 1.8, but is needed for parallelization
```
* The index (i) was being redefined, but is needed for parallelization (fac32e3a)

* Merge pull request #445 from puppetlabs/template_deploy (21665a93)


```
Merge pull request #445 from puppetlabs/template_deploy

Deploy dynamic VMs from templates
```
* Re-wording (5072163a)

* Notes on new 'vcloud' --vmrun option (69cd7d6a)

* Fail unless datastore, resource pool, and folder destinations are specified (71d533f5)

* Clean-up (delete) dynamicly-provisioned VMs (5948a32b)

* Provision VMs from templates with --vmrun vcloud (073f1abd)

* Use/connect to 'vmhostname' if set (e239f659)

* Merge pull request #444 from anodelman/install-keywords (8281a776)


```
Merge pull request #444 from anodelman/install-keywords

(#20749) add keyword support to --install
```
* adding spec tests for parse_install_options (92e4a196)

* (20750) move vm setup/teardown from test steps to lib (fc08794a)

* making parse_install_options not change in place (d95a5432)

* (cleanup) tidied up the case statement structure (59f8bbcd)

* (#20749) add keyword support to --install (ceb9b19e)

* Merge pull request #436 from anodelman/fix-vmrun-option (63dcf3f6)


```
Merge pull request #436 from anodelman/fix-vmrun-option

(#20651) Fix vmrun command line option
```
* Merge pull request #442 from puppetlabs/template_deploy-vsphere_methods (d650070a)


```
Merge pull request #442 from puppetlabs/template_deploy-vsphere_methods

Methods to facilitate deploying VMs from templates
```
* Merge pull request #441 from anodelman/fail-stop (593fb9e4)


```
Merge pull request #441 from anodelman/fail-stop

(new feature) replace --fail-fast with --fail-mode
```
* (maint) add documentation for --fail-mode (6f42971e)

* Merge pull request #443 from puppetlabs/verbose_host_unavailable_error (4fc24ae9)


```
Merge pull request #443 from puppetlabs/verbose_host_unavailable_error

Tell me which hostname is unreachable
```
* Tell me which hostname is unreachable (b7cf4d3b)

* Methods to facilitate deploying VMs from templates (83954955)


```
Methods to facilitate deploying VMs from templates

- find_datastore <name>

  Returns a VIM::Datastore object; used in relocateSpec to deploy a VM
  onto a different datastore as the origin template

- find_folder <name or path>

  Returns a VIM::Folder object; used in CloneVM_Task to specify the
  destination folder for a deployed VM, specified by name ("Delivery")
  or path ("Delivery/Quality Assurance/FOSS/Dynamic")

- find_pool <name or path>

  Returns a VIM::ResourcePool object; used in relocateSpec to deploy
  a VM into a specified resource pool, specified by name ("Delivery")
  or path ("Delivery/Quality Assurance/FOSS/Dynamic")
```
* Merge pull request #440 from justinstoller/host_defaults (11d32818)


```
Merge pull request #440 from justinstoller/host_defaults

Improve host defaults for PE vs FOSS porting
```
* (new feature) replace --fail-fast with --fail-mode (51f5d476)

* updating README.md to add new configuration options (d63ce4bc)

* add --no-revert option to skip all reverting, also adding revert option in config files per-host (a8887ca2)

* Improve host defaults for better interop between FOSS and PE (d3d64e5f)

* Remove un-used and un-useful setup steps (ee9cb424)


```
Remove un-used and un-useful setup steps

This patch removes the post install Ruby check, several other unused
setup steps and the CLI references to PE specific setup steps that
should no longer be in the harness.
```
* Specify if we are doing a PE run via env var (42479b63)


```
Specify if we are doing a PE run via env var

Previously we determined if we were running a PE suite based on what
setup option was chosen. As we move the setup of test suite out of the
harness the flags that would have told us whether or not we were running
a PE suite are no longer of use. Ideally we would allow the project
being tested to override the host defaults for values, but this that
would be a larger change than is currently scoped. In the mean time this
patch allows setting an environment variable to determine wether or not
this is a PE or FOSS suite run.
```
* Merge pull request #435 from justinstoller/rooted_setup_dirs (d45acade)


```
Merge pull request #435 from justinstoller/rooted_setup_dirs

[#20586] Ensure the assumed "setup" dir is relative to the harness, not CWD
```
* actually include the setup dir in the introduced variable (2073da64)

* (#20651) first pass supporting config file only vm specifications (bb3c19b0)

* Remove setup steps that are PE specific (5359207f)


```
Remove setup steps that are PE specific

Previously we put all of the setup steps for all of Puppetlabs projects
in its test harness. As projects change the maintenance cost should be
shifted to the developers/projects that are changing. They are the best
to understand their particular projects setup/dependencies. We have
moved all of the PE setup tests into a separate repository but the
harness will still try to load these outdated setup steps. This cleans
up the duplicate and/or conflicting setup steps that are better specified in
the PE projects test suite.
```
* [#20586] Ensure the assumed "setup" dir is relative to the harness, not CWD (4ba69848)


```
[#20586] Ensure the assumed "setup" dir is relative to the harness, not CWD

Prior to this the harness assumed that a number of tasks were in it's
setup folder but it loaded them relative to the CWD. This causes issues
when trying to run the harness as a gem executable outside of the
traditional directory structure. This commit fixes that so that all
assumptions around the location of the 'setup' dir is relative to the
harness's root not the CWD.
```
* Merge pull request #377 from justinstoller/maint/master/documentation_test_refactor_hacking (3d510e4b)


```
Merge pull request #377 from justinstoller/maint/master/documentation_test_refactor_hacking

[maint] documentation test refactor hacking
```
* Merge pull request #430 from zaphod42/allow_execute_from_gem (4f33677d)


```
Merge pull request #430 from zaphod42/allow_execute_from_gem

Move systest.rb to bin directory
```
* Merge pull request #433 from anodelman/retry-execute (65b8f5cf)


```
Merge pull request #433 from anodelman/retry-execute

retry command execution after re-connecting to hosts
```
* (fix) retry once and only once (ff398082)

* (maint)  removing dead code (3f739330)

* Merge pull request #431 from branan/remove_dhcp_renew (14051d89)


```
Merge pull request #431 from branan/remove_dhcp_renew

Remove --dhcp-renew
```
* Merge pull request #423 from justinstoller/maint/master/net_not_lan (fc8cee08)


```
Merge pull request #423 from justinstoller/maint/master/net_not_lan

Use proxy.puppetlabs.net, not proxy.puppetlabs.lan
```
* (issue #20483) retry command execution after re-connecting to hosts (bf295990)

* Use new windows 2003r2 box with Ruby 193 (b93805f3)

* typo in fedora config (42f0b09b)

* Add fedora 18 config (c247a03a)

* Remove --dhcp-renew (86f30ad4)


```
Remove --dhcp-renew

This has not been useful/necessary for months, and it has caused at
least a few test failures when the DHCP renew causes open SSH sessions
to be terminated.
```
* Remove domain name component (9d50d09b)


```
Remove domain name component

Remove domain component so that name matches what's in vsphere.
```
* Add Windows Acceptance VM for testing ruby 193 (1d5f77d7)


```
Add Windows Acceptance VM for testing ruby 193

See above
```
* Move systest.rb to bin directory (d4fc92e5)


```
Move systest.rb to bin directory

Without this change you could install the puppet-acceptance code from
the git repo as a gem (via bundler), but could not run the systest.rb
program. This moves systest.rb to the bin directory, leaves a stub
behind, and drops the .rb extension (just 'cuz).
```
* Merge pull request #429 from anodelman/bug_20094 (a2f23306)


```
Merge pull request #429 from anodelman/bug_20094

removed default value for confine -> criteria (bug 20094)
```
* removed default value for confine -> criteria (bug 20094) (02263a3a)

* Finalize Documentation for this pass (8b339ae8)

* Add documentation tasks (dc991c32)

* Improve .gitignore with documentation and bundler artifacts (86b76dd1)

* Use proxy.puppetlabs.net, not proxy.puppetlabs.lan (774f47a8)

* Do not install markdown by default on 1.8 (Regression) (54f0311d)

* Improve `require`s for use as a library (c311c0f9)

* Add Documenting guide (68f888dd)

* Split PuppetCommands into Helpers and Wrappers (28b2510f)


```
Split PuppetCommands into Helpers and Wrappers

Move much of TestCase into Helpers

Refactor Command

Document and test Helpers,Wrappers,TestCase,Command
```
* Document and test DSL/Roles (dbf9a63b)

* Document and test DSL/Outcomes (7f5ff69c)

* Document and test DSL/InstallUtils (85900021)

* Test DSL/Assertions (1c66257e)

* Use SimpleCov if not on Ruby 1.8 & update Rakefile (b04e1a42)

* outline how we should be requiring subsystems (d02b8a0e)

* Move helpers for the dsl into a DSL namespace (161767ce)

* Use YARD better (04d982f4)

* Specify the behavior we want in tests and documentation (db742875)


```
Specify the behavior we want in tests and documentation

whitespace fixup
```
### <a name = "pe2.8.1">pe2.8.1 - 15 Apr, 2013 (7f527ff2)

* Merge pull request #427 from joshcooper/minitar (7f527ff2)


```
Merge pull request #427 from joshcooper/minitar

Minitar
```
* (#11276) Install GeoTrust Global CA on Windows (ae5814db)


```
(#11276) Install GeoTrust Global CA on Windows

In my local Windows VM, it was not able to connect to the production or
pmtacceptance forge due to the GeoTrust Global CA cert not being present
in my Root certificate store.

This commit adds a `git` setup step that installs the certificate on
Windows. When executed, the step installs the following cert:

  CN=GeoTrust Global CA, O=GeoTrust Inc., C=US

If the cert is already present, the `certutil` command still returns 0,
so no special `acceptable_exit_code` logic is required.
```
* (#11276) Add minitar for Windows (090284c9)


```
(#11276) Add minitar for Windows

This commit adds minitar so that the module tool will work on Windows.
```
* Merge pull request #426 from branan/space_race (3b7cebe5)


```
Merge pull request #426 from branan/space_race

Only use space in dashboard password on versions of PE that support it
```
* Revert "Only use space in dashboard password on versions of PE that support it" (a058a341)


```
Revert "Only use space in dashboard password on versions of PE that support it"

This reverts commit b88e28a7a951c0d16b25fdc058fb90169abc70cf.
```
* Merge pull request #425 from branan/space_race (24e4d78f)


```
Merge pull request #425 from branan/space_race

Only use space in dashboard password on versions of PE that support it
```
* Only use space in dashboard password on versions of PE that support it (b88e28a7)

* Only use space in dashboard password on versions of PE that support it (f95b0f22)

* Merge pull request #424 from branan/passwords_in_spaaaaaaace (3e5b9e6d)


```
Merge pull request #424 from branan/passwords_in_spaaaaaaace

Add a space to the console password
```
* Add a space to the console password (1c3a5fa9)


```
Add a space to the console password

Spaces are hard in bash. This makes sure we handle them correctly
```
* Merge pull request #422 from branan/aix_upgrades (398f8672)


```
Merge pull request #422 from branan/aix_upgrades

Fix upgrade job on AIX
```
* Fix upgrade job on AIX (1d1d11ee)


```
Fix upgrade job on AIX

This adds an AIX case when disabling the puppet agent service
post-upgrade.
```
* Create pe_version-2.8.0 (c4bf1d6f)

### <a name = "pe2.8.0">pe2.8.0 - 26 Mar, 2013 (6b79859e)

* Bump console_auth patch version (6b79859e)

* Merge pull request #421 from branan/white_space_is_lame_guys (f0ee2d23)


```
Merge pull request #421 from branan/white_space_is_lame_guys

Fix 32-bit host of EC2 debian6 64mda 32a configuration
```
* Fix 32-bit host of EC2 debian6 64mda 32a configuration (445ef218)


```
Fix 32-bit host of EC2 debian6 64mda 32a configuration

This configuration had a malformed yaml file which caused the puppet
agent to be deployed incorrectly in some cases.
```
* Merge pull request #420 from branan/"cleaner"-cert-regex (d6553666)


```
Merge pull request #420 from branan/"cleaner"-cert-regex

Make quotes optional when verifying agent cert has been signed
```
* Make quotes optional when verifying agent cert has been signed (882cc594)


```
Make quotes optional when verifying agent cert has been signed

The version of puppet included with PE 2.0 does not print quotes
around the certnames in `puppet cert --list`. This prevented the
harness from detecting signed certs on that version. The updated regex
can now handle both PE 2.0 and newer versions.
```
* Merge pull request #419 from branan/verify_cert_is_signed (b11a11ce)


```
Merge pull request #419 from branan/verify_cert_is_signed

Only continue from cert sign step if the cert is actually signed
```
* Only continue from cert sign step if the cert is actually signed (7fa5027c)


```
Only continue from cert sign step if the cert is actually signed

Without this, it was possible for an agent to check in between the
"sign all" step and the "check for the cert" step. In such a case, we
would continue without signing the cert because we could see it is
there. With this change, we now verify that the cert is signed, not
just that it exists.
```
* Merge pull request #418 from djm68/fix_aix_user_list (910fbf69)


```
Merge pull request #418 from djm68/fix_aix_user_list

(maint) fix AIX user_list method
```
* (maint) fix AIX user_list method (e218be9b)


```
(maint) fix AIX user_list method

AUX user_list method listed ALL information about users, when
we only want a list of the users names.
```
* Merge pull request #417 from branan/query_puppet_config_array_syntax (e233b6e8)


```
Merge pull request #417 from branan/query_puppet_config_array_syntax

Add array syntax to Host class for printing puppet config options
```
* Add array syntax to Host class for printing puppet config options (fcfa43d4)


```
Add array syntax to Host class for printing puppet config options

Without this, tests either had to guess at the default values (which
can vary across platforms) or run `puppet --configprint`
manually. This code allows test suites to use the nifty
`host.puppet['option']` syntax.
```
* Merge pull request #416 from kbarber/ticket/master/handle_blimpy_errors_with_retries (d9315443)


```
Merge pull request #416 from kbarber/ticket/master/handle_blimpy_errors_with_retries

Catch generic Fog exceptions for retry when using fleet.start
```
* During fleet.start retry call fleet.destroy and report on sleep (dd866ba7)


```
During fleet.start retry call fleet.destroy and report on sleep

This addition to the fleet.start retry block will add a fleet.destroy call
before fleet.start is retried in case we need to do some cleanup for it
to work again. It is caught inside its own begin/rescue block and has a
timeout to stop it blocking forever.

I've also added reporting on the number of seconds we are sleeping before
retry.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Catch generic Fog exceptions for retry when using fleet.start (a5189e4b)


```
Catch generic Fog exceptions for retry when using fleet.start

Previously we had been seeing multiple exceptions to do with AWS transient
failures:

    #<Fog::Errors::Error: Reload failed, Fog::Compute::AWS::Server i-7b97ba49 went away.>
    #<Fog::Compute::AWS::Error: RequestLimitExceeded => Request limit exceeded.>

This patch wraps the call to fleet.start in a retry wrapper, returning retry
count status each time, a random sleep (to work around API request limits)
and finally the ability to throw the original error if the exception
continues.

I see this as an initial start to adding resiliency to this problematic area,
to at least cater for the majority of our errors for now.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Merge pull request #415 from branan/strip_gid_on_aix (4c3ac9fb)


```
Merge pull request #415 from branan/strip_gid_on_aix

Strip the GID string in the AIX host backend
```
* Strip the GID string in the AIX host backend (ec325961)


```
Strip the GID string in the AIX host backend

on AIX, the GID string will have a newline. It doesn't on other
platforms. This change makes the AIX output match the rest of our
platforms.
```
* Merge pull request #414 from branan/stop_agent_on_aix (9e6ea1b0)


```
Merge pull request #414 from branan/stop_agent_on_aix

Add support for AIX when stopping the pe puppet agent service
```
* Add support for AIX when stopping the pe puppet agent service (82225c85)

* Merge pull request #413 from branan/bump_stomp_version (99335a2f)


```
Merge pull request #413 from branan/bump_stomp_version

Bump STOMP version for next PE release
```
* Bump stomp version for next PE release (8a83085a)

* Merge pull request #412 from branan/query_aix_stomp_ver (90618272)


```
Merge pull request #412 from branan/query_aix_stomp_ver

Use `rpm -q` to check stomp version on AIX
```
* Use `rpm -q` to check stomp version on AIX (5cc6faa8)


```
Use `rpm -q` to check stomp version on AIX

Previously, we used nothing and got a nilptr exception
```
* Merge pull request #411 from branan/retry_connreset (38e6e493)


```
Merge pull request #411 from branan/retry_connreset

Add ECONNRESET to list of retryable exceptions for SSH connections
```
* Add ECONNRESET to list of retryable exceptions for SSH connections (fd16a173)

* Merge pull request #410 from branan/no_more_awful_paths (85f7d5ba)


```
Merge pull request #410 from branan/no_more_awful_paths

Get rid of cfg-specified bindir/libdir on AIX configs
```
* Get rid of cfg-specified bindir/libdir on AIX configs (39f8a9c9)


```
Get rid of cfg-specified bindir/libdir on AIX configs

These were added during attemptes to get AIX acceptance running
continuously. Since that's been shelved for now and these are causing
problems, I'm removing them until continuous acceptance testing is
revisited.
```
* Merge pull request #409 from branan/facter_++ (a51dafdb)


```
Merge pull request #409 from branan/facter_++

Bump Facter version for next PE release
```
* Bump Facter version for next PE release (bb6492fd)

* Merge pull request #408 from branan/split_aix (b4f93f09)


```
Merge pull request #408 from branan/split_aix

Add split configurations for AIX testing
```
* Remove obsolete AIX 7 config file (663e50e7)


```
Remove obsolete AIX 7 config file

This was created during the initial AIX work, but is obsoleted by
recently added cfgs.
```
* Add split configurations for AIX testing (d9596c91)


```
Add split configurations for AIX testing

This allows the very slow AIX revert process to happen in parallel
```
* Merge pull request #407 from branan/update_deps (cab88b9e)


```
Merge pull request #407 from branan/update_deps

Bump dependencies in pe-latest version file to match recent security releases
```
* Bump dependencies in pe-latest version file to match recent security releases (f441c542)

* Merge pull request #406 from branan/puppet_++ (1644cc48)


```
Merge pull request #406 from branan/puppet_++

Bump base puppet version for next PE release
```
* Bump base puppet version for next PE release (4f992d1f)

* Merge pull request #403 from joshcooper/maint/master/kill-cat-hang (20c150f1)


```
Merge pull request #403 from joshcooper/maint/master/kill-cat-hang

Only try to stop the master if we have a pidfile
```
* new solaris config (a0858a92)

* Add Errno::ENETUNREACH to the list of retryable exceptions on ssh connect (2372fff3)


```
Add Errno::ENETUNREACH to the list of retryable exceptions on ssh connect

ENETUNREACH can occur on our infrastructure when resetting a host in
the vsphere.
```
* Merge pull request #405 from branan/aix_on_debian_master (6e906f8c)


```
Merge pull request #405 from branan/aix_on_debian_master

Switch AIX testing to a debian master
```
* Switch AIX testing to a debian master (2681f215)

* add configs for new windows vms (ec320deb)

* Merge pull request #398 from adrienthebo/rescue-ssh-exceptions (6ae8b144)


```
Merge pull request #398 from adrienthebo/rescue-ssh-exceptions

Retry SSH on network exceptions, fail on auth fail
```
* Merge pull request #404 from kbarber/ticket/master/new-el5-x86_64-instance (a99b6404)


```
Merge pull request #404 from kbarber/ticket/master/new-el5-x86_64-instance

Improved Centos 5 x86_64 image
```
* Improved Centos 5 x86_64 image (79bda2d3)


```
Improved Centos 5 x86_64 image

I've taken the old ami (ami-4433bf74) and made 2 improvements:

* /etc/yum.repos.d/Centos-Base.repo now uses a mirror list
* I've installed the yum-fastestmirror package

This is primarily so we aren't just relying on the rightscale mirror. With
this setup we should reduce the transient failures due to that mirror being
unavailable for whatever reason.

Signed-off-by: Ken Barber <ken@bob.sh>
```
* Only try to stop the master if we have a pidfile (0ca0e29c)


```
Only try to stop the master if we have a pidfile

Previously, on rhel6-32-1 I was noticing the test harness hang trying to
execute `bash -c kill $(cat )`, which blocked reading from stdin. The
issue occurred because I reverted the VM and did --no-install. As a
result, the `puppet master --configprint pidfile` command raised an
execption, which flowed through the top-level ensure block.

This commit moves the ensure block so that we only try to stop the
master if we're able to get its pidfile.
```
* add rhel 6.4 config for new foss job (e05b5db8)

* add precise VMs for public foss (eb5fd576)

* Merge pull request #402 from branan/ec2_west_pe_cfgs (75a13759)


```
Merge pull request #402 from branan/ec2_west_pe_cfgs

Ec2 west pe cfgs
```
* version bumps (d561e302)

* (maint) Update Cent6 64 AMI (487df891)


```
(maint) Update Cent6 64 AMI

Cent6 64 AMI has ssh key issues.  Fixed.
```
* Add pe_version file for 2.0.x (e2d84c3c)

* Add old auth_user answer (a342ed40)

* Merge pull request #401 from djm68/fix_sles32_ami (ff4e37be)


```
Merge pull request #401 from djm68/fix_sles32_ami

(maint) Update sles 32 ami
```
* (maint) Update sles 32 ami (eb623ed9)


```
(maint) Update sles 32 ami

SLES11 32 ami was incorrect.
```
* less old badness, more new goodness (1728c766)

* Merge pull request #400 from djm68/fix_more_amis (735db8b0)


```
Merge pull request #400 from djm68/fix_more_amis

(maint) AMI clean-up
```
* (maint) AMI clean-up (f214aa45)


```
(maint) AMI clean-up

(hopefully) last whach and cleaup of ec2 AMIs for Code Orange
and PE2.8.
```
* Merge pull request #399 from branan/more_complete_http_pulls (f8edcb0c)


```
Merge pull request #399 from branan/more_complete_http_pulls

Fetch PE tarballs over http in a wider range of cases
```
* Fetch PE tarballs over http in a wider range of cases (58f7656a)


```
Fetch PE tarballs over http in a wider range of cases

* Fetch 1.x tarballs during install
* Fetch tarballs during upgrade
```
* Always `apt-get update` on debian/ubuntu machines (e781fa07)


```
Always `apt-get update` on debian/ubuntu machines

This was only doing an update when using repos before, but since we
later try to install packages, we need to update beforehand.
```
* Retry SSH on network exceptions, fail on auth fail (54eca7f1)


```
Retry SSH on network exceptions, fail on auth fail

The current behavior of the SshConnection currently swallows all
exceptions when trying to connect and will retry on any failure.  This
means that errors like SSH failures will be masked as network failures.

This commit adds a list of retryable exceptions for timeouts, network
connectivity and so forth, and explicitly rescues these for retry. It
also reraises the Net::SSH::AuthenticationFailed to clearly indicate
auth failures.
```
* Merge pull request #397 from djm68/new_rhel6_amis (f58547a4)


```
Merge pull request #397 from djm68/new_rhel6_amis

(maint) add new RHEL6 AMIs
```
* (maint) add new RHEL6 AMIs (0485f7f2)


```
(maint) add new RHEL6 AMIs

Both RHEL6 AMIs had broken repos.  Rebuilt AMIs, validated
functioning repos.
```
* Merge pull request #396 from djm68/update_west_amis (731f3cc6)


```
Merge pull request #396 from djm68/update_west_amis

(maint) Update EC2 West AMIs
```
* (maint) Update EC2 West AMIs (b6a421af)


```
(maint) Update EC2 West AMIs

AMIs needed to be modified and re-created.
```
* Add ec2-west configs for PE testing in the cloud (02c06ed9)

* Merge pull request #395 from branan/http_dist_dir (3abfc5c5)


```
Merge pull request #395 from branan/http_dist_dir

Add support for pe_dist_dir to be an HTTP server.
```
* Add support for pe_dist_dir to be an HTTP server. (57063385)


```
Add support for pe_dist_dir to be an HTTP server.

Prior to this change, pe_dist_dir is required to be a local filesystem
path. With this code in place, pe_dist_dir can now be pointed to an
HTTP or HTTPS server, and the LATEST file and PE tarballs will be
properly sourced from that server.
```
* Test GUI editing in GH interface (b38365ab)

* Merge pull request #394 from branan/yaml_loves_whitespace (ec77f0ca)


```
Merge pull request #394 from branan/yaml_loves_whitespace

YAML <3s whitespace
```
* YAML <3s whitespace (8ae287be)

* Merge pull request #393 from djm68/add_pe_ami (cffc2079)


```
Merge pull request #393 from djm68/add_pe_ami

(maint) Add major platforms for PE testing
```
* (maint) Add major platforms for PE testing (06c644d7)


```
(maint) Add major platforms for PE testing

As an stop-gap measure we need to scale our testing into EC2; this
commits adds Cent 5 adn 6, Rhel 5 and 6, ubunt 10.04 and 12.04,
Debian 6 and SLES 11.
```
* Merge pull request #392 from branan/add_ip_as_altname (d11052c3)


```
Merge pull request #392 from branan/add_ip_as_altname

(maint) Add host ip field as a DNS altname to the answers file
```
* (maint) Add host ip field as a DNS altname to the answers file (f41f4a54)


```
(maint) Add host ip field as a DNS altname to the answers file

Without this, accessing the puppetmaster via the listed IP will return
an SSL certificate that does not match.
```
* Merge pull request #389 from branan/ec2_west_pe_compat (dc34cd49)


```
Merge pull request #389 from branan/ec2_west_pe_compat

(maint) Make ec2-west ci configs compatible with PE
```
* (maint) Make ec2-west ci configs compatible with PE (9a22f4b2)

* Merge pull request #387 from branan/gen_config_for_preserved_hosts (409cb075)


```
Merge pull request #387 from branan/gen_config_for_preserved_hosts

(maint) Generate configuration files when --preserve-hosts is passed
```
* Update solaris internal mirrors to use delivery subnet (5bb6e86f)

* Merge pull request #388 from adrienthebo/update_forge_acceptance_host (8086e6d8)


```
Merge pull request #388 from adrienthebo/update_forge_acceptance_host

(maint) Update default hostname for forge
```
* (maint) Update default hostname for forge (3b4e75e5)


```
(maint) Update default hostname for forge

The forge acceptance test host was renamed last night to
'vulcan.delivery.puppetlabs.net', but the test harness is still
defaulting to the deprecated hostname. This commit updates the test
harness to use the new name of the forge acceptance host.
```
* (maint) Generate configuration files when --preserve-hosts is passed (0ebc3dd6)


```
(maint) Generate configuration files when --preserve-hosts is passed

Previously, passing --preserve-hosts would keep cloud instances alive,
but would not provide any easy way to access those hosts after systest
ended.

With this change, an updated systest-compatible config file with the
information needed to contact the cloud hosts is created. This file is
stored in tmp/, the same place where generated PE answers files are
stored.
```
* Merge pull request #386 from haus/ticket/19236_verify_homedir_removal (dc9f7954)


```
Merge pull request #386 from haus/ticket/19236_verify_homedir_removal

(#19236) PE-Uninstaller: Verify homedirs are removed when is_purge is true
```
* (#19236) Uninstaller: Verify homedirs are removed when is_purge is true (adc3bfc0)


```
(#19236) Uninstaller: Verify homedirs are removed when is_purge is true

This commit adds /var/lib/peadmin, the peadmin user homedir, to the list of
directories to verify are gone after the uninstaller completes.
```
* deal with vms with vmname (83b913af)

* CI does not run this as a bundled gem like I do locally; require "blah" wont just work (b6118c03)

* Merge pull request #340 from justinstoller/maint/master/improve_vsphere_performance (6ea47793)


```
Merge pull request #340 from justinstoller/maint/master/improve_vsphere_performance

(maint) improve vsphere performance
```
* Documentation update (bf642a4e)

* use Class methods for Class method dependencies (f74dbc70)

* Do not retry failed vSphere connections (8ca5816c)

* resume blimpy working correctly since multi hypervisor support (30eafb89)


```
resume blimpy working correctly since multi hypervisor support

make vsphere cleanup work with multi-hypervisors

disable vsphere until Enterprise jobs are cleaned up
```
* cleanup vsphere_helper (b92729bf)

* retry vsphere connection if failure 5 times (bbad92ae)

* shutdown vms after acceptance test run unless --preserve-hosts is passed (b71c7f44)

* close the vsphere connection when we're done with it (51c46313)

* move loading of config files to vsphere_helper (ba2056ee)

### <a name = "pe2.7.1">pe2.7.1 - 8 Feb, 2013 (9826e1ca)

* Merge pull request #385 from branan/i_can_haz_aix (9826e1ca)


```
Merge pull request #385 from branan/i_can_haz_aix

New config file and a small bugfix for AIX acceptance testing
```
* Add config file for testing all AIX targets simultaneously (a36e48f9)

* Fix timing on AIX host revert (f0b7e300)

* Merge pull request #384 from domcleal/test-unit-assertions (53de3ed9)


```
Merge pull request #384 from domcleal/test-unit-assertions

Add missing require for Test::Unit::Assertions
```
* Add missing require for Test::Unit::Assertions (b059ad12)

* Merge pull request #383 from domcleal/file-urls (fd10ff4f)


```
Merge pull request #383 from domcleal/file-urls

Accept file:// URLs to git repos
```
* Accept file:// URLs to git repos (ccfe6563)

* Merge pull request #382 from cprice-puppet/bug/master/check-for-config-cli-arg-before-using-it (53a5dbbd)


```
Merge pull request #382 from cprice-puppet/bug/master/check-for-config-cli-arg-before-using-it

Check for the --config CLI arg before attempting to use it
```
* Check for the --config CLI arg before attempting to use it (7757ca53)


```
Check for the --config CLI arg before attempting to use it

Prior to this commit we tried to use the value of --config for
something, and then a few lines later we had the code that
would validate the presence of the parameter and fail with
a descriptive error message.  This was giving NPEs; this
commit just re-orders those steps.
```
* Merge pull request #381 from nicklewis/group-gid-method (bbce3679)


```
Merge pull request #381 from nicklewis/group-gid-method

Add a helper method for retrieving a group's gid
```
* Add a helper method for retrieving a group's gid (35d0ba18)


```
Add a helper method for retrieving a group's gid

This uses `getent group` on "unix" systems `lsgroup -a id` on aix
systems. Windows hosts explicitly don't support this method.
```
* Merge pull request #380 from branan/dashboard_debug_log (ef2564b5)


```
Merge pull request #380 from branan/dashboard_debug_log

(maint) Enable verbose logging on dashbaord as well as master.
```
* (maint) Enable verbose logging on dashbaord as well as master. (6da96d75)


```
(maint) Enable verbose logging on dashbaord as well as master.

Prior to this, only the puppetmaster would have debug logging enabled.
In the case of a split master/dashboard, errors with facts storage are
actually logged on the dashboard host. Enabling debug logging on the
dashboard host will help in tracking down errors in that part of
puppet.
```
* (maint) Bump ActiveSplat versions (d8dee354)

* Merge pull request #379 from branan/master_debug_log (b10abc8e)


```
Merge pull request #379 from branan/master_debug_log

(maint) Enable puppet master debug logging if --debug flag is passed
```
* (maint) Enable puppet master debug logging if --debug flag is passed (8cb25a1e)


```
(maint) Enable puppet master debug logging if --debug flag is passed

Normally, the puppet master has minimal logging enabled by
default. However, it is beneficial to have additional logging
information to help track down issues during testing. This patch
enables full puppet master logging when the user requests verbose
output at the harness level.
```
* (maint) Bump console_auth version for 2.7.x (f7741e25)

* Merge pull request #378 from branan/testing_is_hard_lets_go_shopping (22736f4a)


```
Merge pull request #378 from branan/testing_is_hard_lets_go_shopping

(maint) Add old versions of 1.2.x and 2.7.x for upgrade testing
```
* (maint) Add old versions of 1.2.x and 2.7.x for upgrade testing (7487c093)

* Merge pull request #376 from branan/cfg_vsphere (f7c2f0ef)


```
Merge pull request #376 from branan/cfg_vsphere

(maint) Add vmname/snapshot support to vsphere runner
```
* (maint) Add vmname/snapshot support to vsphere runner (2933e290)

* Merge pull request #375 from branan/activerecord_ver_bump (2346ddd9)


```
Merge pull request #375 from branan/activerecord_ver_bump

(maint) Bump activerecord version
```
* (maint) Bump activerecord version (d2ab2ca8)

* Merge pull request #374 from branan/god_dammit_ruby (63a6f45e)


```
Merge pull request #374 from branan/god_dammit_ruby

why. Why Why Why Why Why.
```
* And then the great RUBY appeared. And he said unto the world: Behold, for my syntax is as unknowable as PERL's, and your variables shall from this day forth contain values which you will never again explain. On that day all the developers of the world let out a great cry of agony, for they knew RUBY would keep his terrible promise. (2391b9aa)

* Merge pull request #373 from branan/split_pkg_repo (e6062da1)


```
Merge pull request #373 from branan/split_pkg_repo

(maint) Split configuration of additional package repos and repository proxies
```
* (maint) Split configuration of additional package repos and repository proxies (6fc9f82c)

* Merge pull request #372 from justinstoller/maint/master/quit_spamming_me (4b240a83)


```
Merge pull request #372 from justinstoller/maint/master/quit_spamming_me

[maint] remove the debugging statement and improve the hypervisor notice
```
* remove the debugging statement and improve the hypervisor notice (fcddd8f6)

* Merge pull request #371 from djm68/add_aix_vm_revert (39e67015)


```
Merge pull request #371 from djm68/add_aix_vm_revert

(maint) Add support for AIX reverts
```
* (maint) Add support for AIX reverts (7fb532c0)


```
(maint) Add support for AIX reverts

Adds support for AIX restores via aix 'hypervisor'.
This requies the use our update fog file in:
git@github.com:puppetlabs/puppetlabs-modules.git
An example config here: config/nodes/aix-7.cfg
```
* Merge pull request #370 from branan/bump_epel_release (07bee1f5)


```
Merge pull request #370 from branan/bump_epel_release

(maint) Bump epel-release package version for config_pkg_repo step
```
* (maint) Bump epel-release package version for config_pkg_repo step (4c56221e)

* Merge pull request #369 from djm68/add_aix_platform_support (83914c2e)


```
Merge pull request #369 from djm68/add_aix_platform_support

(maint) Adding support for AIX
```
* (maint) Adding support for AIX (e67e214f)


```
(maint) Adding support for AIX

AIX is coming; quite some changes to integrate into systest
```
* Merge pull request #331 from justinstoller/feature/master/12743-support-ruby-19 (a5387cf8)


```
Merge pull request #331 from justinstoller/feature/master/12743-support-ruby-19

[#12743] support ruby 19
```
* Merge pull request #368 from branan/skip_vmrun_unless_requested (a39228ea)


```
Merge pull request #368 from branan/skip_vmrun_unless_requested

(maint) Skip vm revert step if vmrun option is not specified
```
* (maint) Skip vm revert step if vmrun option is not specified (d997c338)

* handle blocks with an arity of 0 better in test case (4b2d4267)

* confine test/unit usage to versions of ruby that are 1.8 not x.8 (72db3aa8)

* Merge pull request #345 from justinstoller/bug/master/17032-confine_should_take_arrays (41fe2ad8)


```
Merge pull request #345 from justinstoller/bug/master/17032-confine_should_take_arrays

[#17032] allow arrays of properties to be passed to confine
```
* Merge pull request #347 from justinstoller/feature/master/17209-fail_faster_better (1c1e2cd3)


```
Merge pull request #347 from justinstoller/feature/master/17209-fail_faster_better

[#17209] allow failure strategy to be specified at command line
```
* Merge pull request #367 from branan/multi_hypervisor (4a85552b)


```
Merge pull request #367 from branan/multi_hypervisor

(maint) Support running VMs across multiple hypervisors simultaneously
```
* Merge pull request #1 from justinstoller/multi_hypervisor (d13acdc2)


```
Merge pull request #1 from justinstoller/multi_hypervisor

Multi hypervisor
```
* update readme (8cf8709a)

* if we do not connect to a host, say which host it was (dd37d2e5)

* dont use the local variable name vms, its used by the vsphere section (6c6e0da3)

* specs for TestCase#confine (eee3ef07)

* allow blocks to be passed to TestCase#confine (ff0f1451)

* require test/unit in test_case (it needs it) (aa10e2ef)

* return strings from conversion method when < ruby 1.8 (27387b3f)

* (maint) Support running VMs across multiple hypervisors simultaneously (8b58a782)

* Do not purge harness files when running in DEBUG mode (4667ad29)


```
Do not purge harness files when running in DEBUG mode

Previously Logger#pretty_backtrace was purging harness files from debug
stacktraces but not normal stacktraces. The logic was backwards.
```
* Merge pull request #366 from branan/wait_wait_dont_tell_me (7e6adaea)


```
Merge pull request #366 from branan/wait_wait_dont_tell_me

(maint) Wait just a bit longer before giving up talking to a host
```
* (maint) Wait just a bit longer before giving up talking to a host (2d72b45b)


```
(maint) Wait just a bit longer before giving up talking to a host

When using VM targets which are initially in the shutdown state it can
take them a bit longer to be accessible. This extra wait should help
prevent false positives.

The total wait time is now just under 4 minutes
```
* Merge pull request #365 from branan/continue_retrieve_properties (26139d66)


```
Merge pull request #365 from branan/continue_retrieve_properties

(maint) Search ALL THE HOSTS when trying to restore a VMware snapshot
```
* (maint) Search ALL THE HOSTS when trying to restore a VMware snapshot (57fe4dcc)


```
(maint) Search ALL THE HOSTS when trying to restore a VMware snapshot

VMWare servers can limit the number of results returned by a
RetrievePropertiesEx call. This commit adds code that uses
ContinueRetrievePropertiesEx to ensure we search the entire vcenter
for our hosts.
```
* Merge pull request #364 from branan/exterminate (71d85d69)


```
Merge pull request #364 from branan/exterminate

(maint) remove config files for obsolete OSen
```
* (maint) remove config files for obsolete OSen (b22697ed)

* Merge pull request #363 from djm68/update_forge_hostname (067a47ab)


```
Merge pull request #363 from djm68/update_forge_hostname

(maint) Update harness with new forge hostname
```
* (maint) Update harness with new forge hostname (b294df6d)


```
(maint) Update harness with new forge hostname

Post move: the old forge forge-acceptance.puppetlabs.lan is now
deprecated, the new host is
vulcan-acceptance.acctest.dc1.puppetlabs.net
```
* Merge pull request #362 from branan/outside_ntp_server (65ac3c2a)


```
Merge pull request #362 from branan/outside_ntp_server

(maint) ntp.puppetlabs.lan no longer exists
```
* (maint) ntp.puppetlabs.lan no longer exists (574f78ba)

* Merge pull request #361 from cprice-puppet/maint/master/debug-logging-for-master-start (d3a76b35)


```
Merge pull request #361 from cprice-puppet/maint/master/debug-logging-for-master-start

Extra debug logging for master startup
```
* Only do '-v' on curl if we're running with --debug (c9b92f62)

* Extra debug logging for master startup (a21be463)


```
Extra debug logging for master startup

This just adds a bit more verbosity / logging to the output when
the harness is checking to see whether the master is running.  In
cases such as when you have a bad IP address in your hosts file,
this can be tremendously useful in helping to figure out what's
going on.
```
* Merge pull request #360 from sschneid/master (6b996781)


```
Merge pull request #360 from sschneid/master

Adding configs for x86 Solaris testing
```
* Adding links for both sparc and x86 Solaris tests (3bc154b3)

* Renaming to solaris11-sparc.cfg (db8e46a3)

* Adding Solaris 11 i386 config (fe22d9dd)

* Merge pull request #359 from sschneid/master (ddfc0bb4)


```
Merge pull request #359 from sschneid/master

Changing zfs rollback options from '-r' to '-Rf'
```
* Use more forceful, destructive rollbacks for fun and profit (76ed7250)

* Merge pull request #358 from sschneid/master (eea5c96d)


```
Merge pull request #358 from sschneid/master

Repoint ci-solaris11.cfg at new node config
```
* Repoint ci-solaris11.cfg at new node config (102f9ce1)

* Merge pull request #357 from puppetlabs/solaris_hypervisor (aa149363)


```
Merge pull request #357 from puppetlabs/solaris_hypervisor

Solaris hypervisor
```
* Docs for Solaris support, adding Solaris 11 node config file (9f4f1af4)

* Adding support for Solaris hypervisor with '--vmrun solaris' (134e8880)

* Allow config to be read from a hash or file (c4c360b0)

* Merge pull request #356 from cprice-puppet/maint/master/update-el6-ami (709d57c2)


```
Merge pull request #356 from cprice-puppet/maint/master/update-el6-ami

Update AMI for cent6-west
```
* Update AMI for cent6-west (789a7664)


```
Update AMI for cent6-west

The previous AMI had a bad ssh key setup and was hanging.  I
believe this one should fix that particular issue.
```
* Merge pull request #354 from branan/config_file_ordering (d0be2363)


```
Merge pull request #354 from branan/config_file_ordering

(maint) check for .fog file before /etc/plharness/vsphere
```
* (maint) check for .fog file before /etc/plharness/vsphere (f838ffe7)

* Updated AMI for debian6-64-west (26668b6e)

* Updated AMI for ubuntu10.04-64-west (570a3ef6)

* Merge pull request #352 from cprice-puppet/feature/master/uswest2-amis (c885354a)


```
Merge pull request #352 from cprice-puppet/feature/master/uswest2-amis

Add configs for US-West2 AMIs
```
* Fix platform names (91cf98ac)

* Add configs for US-West2 AMIs (f8ff9635)

* allow failure strategy to be specified at command line (7d8d905e)

* allow arrays of properties to be passed to confine (6913eb4e)

* Force Net::SSH output to be normalized on Encoding.default_external (0a4f3aca)


```
Force Net::SSH output to be normalized on Encoding.default_external
if necessary
```
* Use a class level constants instead of instance variables (c0dead99)

* Remove 1.9 incompatible relative require (50b20cf3)

* Remove final instances of "and break" when trying to skip test (e3551fc6)

* Remove old instance of Test::Unit.run within systest (5f0f88c3)

* Force Logger exception parsing segments to strings before combining (65a1c081)

* Set Test::Unit.run when we learn whether or not were using Test::Unit (7f74e85f)

* whitespace fixup (6a8e32e3)

* First pass at 1.9 compatibility (6a3c1cd0)

### <a name = "pe2.7.0">pe2.7.0 - 16 Nov, 2012 (08c2bd19)

* Merge pull request #350 from branan/rename_pkg_verify_answer (08c2bd19)


```
Merge pull request #350 from branan/rename_pkg_verify_answer

(maint) rename q_rpm_verify_gpg answer to q_verify_packages
```
* (maint) rename q_rpm_verify_gpg answer to q_verify_packages (35b4d19c)

* Merge pull request #349 from branan/no_default_rpm_gpg (d7e371ee)


```
Merge pull request #349 from branan/no_default_rpm_gpg

(maint) only set q_rpm_verify_gpg if the env var for it is set
```
* (maint) only set q_rpm_verify_gpg if the env var for it is set (98341409)

* Merge pull request #348 from djm68/fix_no_install_options_parsing (427b44b5)


```
Merge pull request #348 from djm68/fix_no_install_options_parsing

(maint) fix --no-install failing
```
* (maint) fix --no-install failing (10bab3f7)


```
(maint) fix --no-install failing

--no-install fails due to boolean eval of '--no' resulting in false
instead of setting the option to true, as intended.
```
* Merge branch 'amazon_support' of git://github.com/branan/puppet-acceptance (e9bc050a)

* (maint) Add support for running PE builds against amazon linux (82f8e484)

* handle SLES when checking stomp gem version (555d466b)


```
handle SLES when checking stomp gem version

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #346 from justinstoller/maint/master/check_stomp_version (3fac1573)


```
Merge pull request #346 from justinstoller/maint/master/check_stomp_version

(maint) ensure stomp is at 1.1.9
```
* ensure stomp is at 1.1.9 (681a6250)

* Merge pull request #343 from branan/find_pe_for_uninstall (bbbfdb49)


```
Merge pull request #343 from branan/find_pe_for_uninstall

(maint) Use modern method of finding PE installers for uninstall tests
```
* (maint) Use modern method of finding PE installers for uninstall tests (d463f531)

* Merge pull request #342 from branan/blimpy_ports_by_role (665ef223)


```
Merge pull request #342 from branan/blimpy_ports_by_role

(maint) Determine open Blimpy instance ports based on role
```
* (maint) Determine open Blimpy instance ports based on role (071fb7ec)

* Merge pull request #341 from branan/allow_ami_selection (fa0ec8ea)


```
Merge pull request #341 from branan/allow_ami_selection

(maint) Allow specifying VM template name for Blimpy AMIs
```
* (maint) Allow specifying VM template name for Blimpy AMIs (2520740c)

* bump console auth version (b0467b3d)

* Merge pull request #339 from branan/gen_gpg_answer_on_upgrade (b26e10bf)


```
Merge pull request #339 from branan/gen_gpg_answer_on_upgrade

(maint) Answer the GPG verfication on upgrades
```
* (maint) Answer the GPG verfication on upgrades (682847bc)

* Package version bump (c0bf46c0)

* Merge pull request #338 from branan/verify_rpms (9b8fb528)


```
Merge pull request #338 from branan/verify_rpms

(maint) Verify RPMs by default on PE installs
```
* (maint) Verify RPMs by default on PE installs (9ee91305)

* Merge pull request #337 from branan/fix_pe_installer_usage (64bb1dd7)


```
Merge pull request #337 from branan/fix_pe_installer_usage

(maint) Play nice with the installer's working directory handling
```
* (maint) Play nice with the installer's working directory handling (86415f77)

* (maint) Bump console_auth version (8dc192a4)

* (maint) Bump console auth version (4c1ae161)

* Merge pull request #336 from djm68/clean_up_old_setups (2d5c8534)


```
Merge pull request #336 from djm68/clean_up_old_setups

(maint) Cleanup old install types
```
* (maint) Cleanup old install types (376af8b5)


```
(maint) Cleanup old install types

Old install code hanging around -- not needed any longer.
```
* Merge pull request #335 from branan/install_pe_test_packages (5baa5207)


```
Merge pull request #335 from branan/install_pe_test_packages

(maint) Add step to install PE *-test packages
```
* (maint) Add step to install PE *-test packages (4e789c98)


```
(maint) Add step to install PE *-test packages

This adds a setup type to install the PE *-test packages. This
leverages the power of the existing PE installer in order to install
the packages correctly on all platforms.

In order to use this you will need a `config/test_packages.yml` file
listing the packages to install as part of this step.
```
* Merge pull request #334 from branan/use_pe_dir_for_windows (4802b7d7)


```
Merge pull request #334 from branan/use_pe_dir_for_windows

Use the configured PE files directory on windows
```
* Use the configured PE files directory on windows (df0a6f78)

* Merge pull request #333 from justinstoller/maint/master/config_pkg_to_sol_11 (96721533)


```
Merge pull request #333 from justinstoller/maint/master/config_pkg_to_sol_11

confine pkg_repo action for pkg publishers to solaris 11
```
* confine pkg_repo action for pkg publishers to solaris 11 (210cb198)

* Merge pull request #332 from djm68/add_pe27_version_file (f8b71e72)


```
Merge pull request #332 from djm68/add_pe27_version_file

(maint) add PE 2.7 version file
```
* (maint) add PE 2.7 version file (1cd05854)


```
(maint) add PE 2.7 version file

Add new files to track pe2.7 specifc versions
```
* Bump console_auth version to 1.1.9 (d28a91bc)

* the password is a syntax error (6619d328)

* Merge pull request #329 from djm68/add_env_override_console_auth_pass (98cfd3aa)


```
Merge pull request #329 from djm68/add_env_override_console_auth_pass

(maint) Add ENV override for console auth pass
```
* (maint) Add ENV override for console auth pass (614d890e)


```
(maint) Add ENV override for console auth pass

Allow teams to deploy PE build with sensible passwords for easy
logins.
```
* Merge pull request #328 from djm68/add_q_rpm_verify_gpg_answer (6d12ff50)


```
Merge pull request #328 from djm68/add_q_rpm_verify_gpg_answer

(maint) Add answer for gpg pkg verification
```
* (maint) Add answer for gpg pkg verification (2fd25601)


```
(maint) Add answer for gpg pkg verification

q_rpm_verify_gpg is used on PE2.7 to determine if the installer
will attempt to verify packages.  Defeaults to 'n' but can be over-
ridden by setting q_rpm_verify_gpg='y' in the shell.
```
* Merge pull request #327 from justinstoller/maint/master/use_echo_hack_for_win (6cb268bd)


```
Merge pull request #327 from justinstoller/maint/master/use_echo_hack_for_win

force wmic to not use a pty
```
* hack to force wmic to not use a pty (950452dc)


```
hack to force wmic to not use a pty

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #326 from justinstoller/w/t/f/solaris (ca897ee1)


```
Merge pull request #326 from justinstoller/w/t/f/solaris

(maint) solaris 11 uses gnu style ntpdate
```
* I have no idea why this just started failing, but gnu ntpdate is first in path on sol 11 (a29f6029)

* Merge pull request #325 from justinstoller/bug/master/fix_scp (67db720a)


```
Merge pull request #325 from justinstoller/bug/master/fix_scp

(bug) be explicit with results from scp methods
```
* be explicit with results (c003ac7c)

* Merge pull request #322 from justinstoller/bug/master/16985-more-scp-options (0965e984)


```
Merge pull request #322 from justinstoller/bug/master/16985-more-scp-options

(16985) allows passing :recursive => true to scp methods
```
* Merge pull request #324 from joshcooper/maint/master/new-windows-gem (305b938b)


```
Merge pull request #324 from joshcooper/maint/master/new-windows-gem

Maint: Bump win32-security gem version
```
* Merge pull request #310 from justinstoller/feature/master/15455-install-native-packages (a8cd9410)


```
Merge pull request #310 from justinstoller/feature/master/15455-install-native-packages

(maint) unify installing repositories
```
* Maint: Bump win32-security gem version (8040449e)


```
Maint: Bump win32-security gem version

Previously, we were using win32-security version 0.1.2, but we need to
bump this to 0.1.4 for puppet 2.7.x and up. The gem was being installed
as a dependency to one of the others.

This commit bumps the gem version. In the future, we will be able to do
`bundle install` (for 3.0.x and up), but am I don't want to break the
acceptance tests right now, as it would require reording this step (to
do the git clone, to get the Gemfile, and then do bundle install).
```
* add a test (8b169c0c)

* Merge pull request #312 from justinstoller/maint/master/test_the_harness (28c13211)


```
Merge pull request #312 from justinstoller/maint/master/test_the_harness

(maint) add some tests
```
* combine options hashes (5c8854ca)


```
combine options hashes

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #316 from justinstoller/feature/master/12528-break-execution-on-skip (4a405381)


```
Merge pull request #316 from justinstoller/feature/master/12528-break-execution-on-skip

(12528) skip test should break execution when called
```
* Merge pull request #320 from justinstoller/maint/master/restrict_help_output_line_length (cb7be337)


```
Merge pull request #320 from justinstoller/maint/master/restrict_help_output_line_length

(maint) restrict help output line length
```
* Merge pull request #323 from justinstoller/maint/master/ensure_epel (0c65d888)


```
Merge pull request #323 from justinstoller/maint/master/ensure_epel

(maint) ensure epel
```
* simplify and improve --pkg-repo (19029bc6)

* add epel to our hosts when the --pkg-repo option is used (d58bf98d)

* allows passing :recursive => true to scp methods (06b839e6)


```
allows passing :recursive => true to scp methods

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #321 from branan/ancient_pe_upgrade (af681931)


```
Merge pull request #321 from branan/ancient_pe_upgrade

(maint) use the configured pe directory to find tarballs for ugprades
```
* (maint) use the configured pe directory to find tarballs for ugprades (b38bb5c6)

* update booleans to have [no] option (allows overriding option files) (f25bcd63)

* update command line flags for consistency (b1d93c36)

* clean up option parsing (2fcf28e6)

* Merge pull request #319 from branan/pe_12_version_checks (ea621da8)


```
Merge pull request #319 from branan/pe_12_version_checks

(maint) Support version checking on PE 1.2
```
* (maint) Support version checking on PE 1.2 (cf26c89f)

* Merge pull request #318 from djm68/add_pe12_versions_files (70027c63)


```
Merge pull request #318 from djm68/add_pe12_versions_files

(Maint) add version specific PE version files
```
* (Maint) add version specific PE version files (a17e374f)


```
(Maint) add version specific PE version files

To allow multi version PE tests, version specific files
need to be added; only required for major PE versions.
```
* Merge pull request #317 from branan/better_pe_dist_dir (c6b7a3b0)


```
Merge pull request #317 from branan/better_pe_dist_dir

(maint) Improve support for the pe_dist_dir env variable
```
* (maint) Improve support for the pe_dist_dir env variable (affe96ef)

* Merge pull request #314 from justinstoller/maint/master/update-gitignore (51134623)


```
Merge pull request #314 from justinstoller/maint/master/update-gitignore

(maint) update gitignore to allow local testing options and cfg files
```
* Merge pull request #313 from justinstoller/maint/master/install_rb_in_ec2 (af2e7c34)


```
Merge pull request #313 from justinstoller/maint/master/install_rb_in_ec2

install libruby-extras on deb based systems
```
* skip test should break execution when called (cb74c514)


```
skip test should break execution when called

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #315 from branan/old_pe_fixups (b9a94bd1)


```
Merge pull request #315 from branan/old_pe_fixups

Old pe fixups
```
* (maint) gunzip PE 1.2.5 tars (940e28ca)

* (maint) Check config pe_version instead of command-line option to determine answers version generation (06b48dcb)

* normalize parens usage per comment by @branan (ae4f03df)

* Merge pull request #311 from djm68/modify_answerfilegen_pe124 (df765f6d)


```
Merge pull request #311 from djm68/modify_answerfilegen_pe124

(maint) add support for pe1.2.x
```
* (maint) add support for pe1.2.x (32ff8734)


```
(maint) add support for pe1.2.x

We need the current harness to handle PE1.2.x installs; too much
has been added to the harness to revert back to our pe1.2 tag.  This
code allows correct answer file generation for P2.x and PE1.2.x
varients.
```
* I always want to use |result| as if we were (27db98dc)


```
I always want to use |result| as if we were
intentionally yielding something meaningful
```
* install libruby-extras on deb based systems (cdd206d0)


```
install libruby-extras on deb based systems
 to be able to install via install.rb
```
* change option from :package to :install (501e755f)


```
change option from :package to :install

handle option files and multiple -i flags better
```
* add --install flag and allow lists passed to it (0f5a0825)

* pull out bug workarounds into separate file (da4e1c16)

* add tests for added methods in InstallUtils (4d95d90d)

* move more of setup code into install_utils (9455fa6e)

* move to transforming options after parsing option file (d5d43809)

* update gitignore to allow local testing options and cfg files (b1625a49)

* unifying command line install flags -- code spike (4a37cd39)

* basic ssh_connection testing (be4a6a68)

* Basic tests for Hosts (45b4fdf0)


```
Basic tests for Hosts

This provides tests for most of the host's behaviors, save for `exec`
and `do_scp` which are very similar, but `exec` has a lot of knowledge
in it that should probably be elsewhere. So I've decided to hold off on
spec-ing it until I can refactor its friends at the same time.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* begin host testing (7ec3d6ae)

* Test and Refactor Logger class (be80c6e8)


```
Test and Refactor Logger class

This adds rough behavioral specs to puppet_acceptance/logger.rb as well
as refactors the code. Refactors include adding a hierarchy of
log_levels, simple accessors to find log level, pulling out common
color printing code, breaking up `pretty_backtrace` and making
`pretty_backtrace` only print the lines from test files unless in debug
mode.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* bump to rspec 2.11 (16b848a7)

### <a name = "pe2.6.1">pe2.6.1 - 9 Oct, 2012 (58edb963)

* Merge pull request #309 from cprice-puppet/maint/master/add-suite-name-to-summary-output (58edb963)


```
Merge pull request #309 from cprice-puppet/maint/master/add-suite-name-to-summary-output

Add suite name to test case summary
```
* Add suite name to test case summary (25e3e92d)


```
Add suite name to test case summary

When scrolling through log output for a test run with a lot of
test suites, it can be a bit difficult to differentiate them.
This commit simply adds the suite name to the summary log for
a test suite.
```
* Merge pull request #308 from cprice-puppet/feature/master/add-scp-from (b77b85f8)


```
Merge pull request #308 from cprice-puppet/feature/master/add-scp-from

Add an scp_from method, like the existing scp_to
```
* Add an scp_from method, like the existing scp_to (d3eaf99a)


```
Add an scp_from method, like the existing scp_to

This commit adds support for SCP'ing files *from*
hosts, to supplement the existing functionality
for scp'ing files *to* hosts.  This is useful for
collecting log files to archive with the Jenkins
jobs, etc.
```
* Merge pull request #306 from branan/16723_fibonacci_backoff (29fa26ae)


```
Merge pull request #306 from branan/16723_fibonacci_backoff

(#16723) Use a fibonacci backoff sequence for SSH retries
```
* Merge pull request #307 from branan/bump_console_auth_version (f72c34d8)


```
Merge pull request #307 from branan/bump_console_auth_version

Bump console auth version to 1.1.7
```
* Bump console auth version to 1.1.7 (d8c1f95f)

* (#16723) Use a fibonacci backoff sequence for SSH retries (f05c4dc4)


```
(#16723) Use a fibonacci backoff sequence for SSH retries

Previously, all retries would use a 20-second delay. This patch uses a
fibonacci sequence which allows for more immediate results when the
connection issue is resolved quickly.
```
* Merge pull request #305 from branan/remove_dummy_config (0d58b08c)


```
Merge pull request #305 from branan/remove_dummy_config

Remove dummy CONFIG section from Razor cfg file
```
* Remove dummy CONFIG section from Razor cfg file (462e3c11)


```
Remove dummy CONFIG section from Razor cfg file

This section was necessary due to a bug that has since been
resolved. It can now safely be removed.
```
* Merge pull request #304 from branan/16721_roleless_hosts (0f2474a3)


```
Merge pull request #304 from branan/16721_roleless_hosts

(#16721) Allow hosts with no roles set
```
* (#16721) Allow hosts with no roles set (bc1698b7)


```
(#16721) Allow hosts with no roles set

Previously, hosts without any roles set in the config file would cause
nil to be treated as an array. This results in a crash. This change
ensures that the roles configuration is not nil, preventing the crash.
```
* Merge pull request #303 from cprice-puppet/feature/master/update-cent55-openssl (fa6ea396)


```
Merge pull request #303 from cprice-puppet/feature/master/update-cent55-openssl

Update openssl package on cent5 AMI
```
* Update openssl package on cent5 AMI (2eec20d5)


```
Update openssl package on cent5 AMI

Prior to this commit, some of the SSL operations needed for
puppetdb acceptance testing weren't working with our CentOS5
image.  I opened up the old AMI, ran 'yum install openssl' to
get the latest version, and then snapped a new AMI.  This
commit updates the AMI ID in the acceptance config.
```
* Merge pull request #302 from cprice-puppet/feature/master/update-ubuntu-ami-id (d508f80a)


```
Merge pull request #302 from cprice-puppet/feature/master/update-ubuntu-ami-id

Update AMI id for ubuntu

The new AMI now includes the 'unzip' command.
```
* Update AMI id for ubuntu (783c6707)

* Merge pull request #301 from daniel-pittman/master (512b9af9)


```
Merge pull request #301 from daniel-pittman/master

Add Razor test VM configuration to the CI suite.
```
* Add razor CI acceptance test configuration (5479e889)


```
Add razor CI acceptance test configuration

This adds the existing Razor test VM to the CI suite.
```
* Merge pull request #299 from daniel-pittman/better-vsphere-error-handling (9e287753)


```
Merge pull request #299 from daniel-pittman/better-vsphere-error-handling

Better vsphere error handling
```
* Merge pull request #298 from justinstoller/maint/master/doc-update (9f75f7aa)


```
Merge pull request #298 from justinstoller/maint/master/doc-update

update docs for vsphere .fog file
```
* write better (d2f15f68)

* Power on any stopped VM during setup (512ba814)


```
Power on any stopped VM during setup

This detects a powered off VM on the vSphere host, and boots it back up after
the snapshot is restored. It will also wake up a suspended VM.

This change makes the system more robust against sleeping or stopped VMs
or snapshots.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Detect missing VMs and fail the setup process (29356ab6)


```
Detect missing VMs and fail the setup process

Previously the vSphere integration made a "best effort" pass at the VMs: it
would look for them all, and then act only on the machines that it found.

This means that if a VM name was incorrectly specified or otherwise
unavailable the entire process would just silently skip over it, omitting real
and important test targets.

Now this is detected and a failure results: you can't skip over a VM any longer.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Fix more floating point precision vs printf typos (7acb9aac)


```
Fix more floating point precision vs printf typos

More places where precision came after the format, rather than before, leading
to extremely precise numbers - to two decimal sets!

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Use a normal failure in the vsphere helper (984ee68d)


```
Use a normal failure in the vsphere helper

The test suite helpers are not available in this Ruby helper object, so this
failed - but without actually having the helpful error.  Just raising at least
improves this some.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* update docs for vsphere .fog file (9cc9e774)

* Fix printf formatting of floating point... (b3c3b4c4)


```
Fix printf formatting of floating point...

A type meant that instead of setting the output precision we appended
a `.2` to the end of every time output in this file.
```
* Merge pull request #297 from branan/16720_allow_no_ruby (401c971e)


```
Merge pull request #297 from branan/16720_allow_no_ruby

(#16720) Allow systest to run on systems without ruby
```
* (#16720) Allow systest to run on systems without ruby (5e12a7ad)


```
(#16720) Allow systest to run on systems without ruby

Prior to this commit, a ruby version check would cause systest to fail
if run on any system without ruby. This changes it to return the
special value "none" when ruby is not found or is not functional.
```
* Merge pull request #296 from branan/16724_support_empty_config (7b192cf6)


```
Merge pull request #296 from branan/16724_support_empty_config

(#16724) Accept config files without a CONFIG hash
```
* (#16724) Accept config files without a CONFIG hash (b91118f3)


```
(#16724) Accept config files without a CONFIG hash

Previously the code assumed all config files included a CONFIG
section. This would cause a crash when that section was missing.

This commit changes the code to create an empty hash if the CONFIG
section is missing.
```
* Merge pull request #295 from cprice-puppet/feature/master/add-ec2-el6-config (1049fb47)


```
Merge pull request #295 from cprice-puppet/feature/master/add-ec2-el6-config

Add EC2 config file for EL6
```
* Add EC2 config file for EL6 (a31b418a)

* Merge pull request #294 from cprice-puppet/feature/master/blimpy-ports (d4f4b156)


```
Merge pull request #294 from cprice-puppet/feature/master/blimpy-ports

Add missing ports to the security group
```
* Add missing ports to the security group (bca2e36b)


```
Add missing ports to the security group

The puppet and puppetdb ports were not open in the security policy
that blimpy was using prior to this commit.
```
* Merge pull request #293 from cprice-puppet/feature/master/puppetdb-ec2 (6da41370)


```
Merge pull request #293 from cprice-puppet/feature/master/puppetdb-ec2

Feature/master/puppetdb ec2
```
* Update AMI for Ubuntu 10.04 (ca37f997)


```
Update AMI for Ubuntu 10.04

The existing Ubuntu AMI did not contain the Puppet
ssh public keys.  I added them to /etc/rc.local
and made a new AMI.  This commit updates the ec2
config to use the new AMI ID.
```
* Add fqdn to /etc/hosts during startup (f2ca0707)


```
Add fqdn to /etc/hosts during startup

In addition to the short hostname, some tests will definitely
need for the /etc/hosts file to contain the FQDN.  (PuppetDB
does for sure.)  This commit blatantly rips off some code
from Facter to guess the domain name, and then adds it to
the /etc/hosts file during VM runs.
```
* Merge pull request #292 from branan/console_auth_116 (e1f6f783)


```
Merge pull request #292 from branan/console_auth_116

Bump console_auth version to 1.1.6
```
* Bump console_auth version to 1.1.6 (af105d85)

* Merge pull request #291 from branan/add_pe_noop (53903782)


```
Merge pull request #291 from branan/add_pe_noop

Add pe_noop type.
```
* Add pe_noop type. (6743ac5d)


```
Add pe_noop type.

In order to have a 'manual'-stype setup type that is still detected as PE,
a type with the substring 'pe' must be used. This adds that type.
```
* Merge pull request #290 from branan/fix_snapshot_selection (5e37e5f3)


```
Merge pull request #290 from branan/fix_snapshot_selection

Make it possible to override the snapshot for 'gem' and 'manual' types
```
* Make it possible to override the snapshot for 'gem' and 'manual' types (d6a0a9b0)


```
Make it possible to override the snapshot for 'gem' and 'manual' types

Previously, the snapshot-consolidation logic would check the run type
whether or not the user specified a custom snapshot. This would cause
user-specified snapshots to be ignored when using the 'gem' or
'manual' run types.
```
* Merge pull request #289 from MosesMendoza/bump_console_auth_version (857e4704)


```
Merge pull request #289 from MosesMendoza/bump_console_auth_version

bump console-auth check to 1.1.5
```
* bump console-auth check to 1.1.5 (e70905f2)

* Merge pull request #288 from vrthra/ticket/master/16307_fix_solaris (31c261e4)


```
Merge pull request #288 from vrthra/ticket/master/16307_fix_solaris

(#16307) solaris uses the gnu specific mv under /usr/gnu/bin
```
* (#16307) solaris uses the gnu specific mv under /usr/gnu/bin (5878b46a)


```
(#16307) solaris uses the gnu specific mv under /usr/gnu/bin

The manage ssh keys script uses a gnu-ism for mv. This patch adds
the path for gnu binaries in solaris.
```
* Merge pull request #285 from vrthra/ticket/master/16307_fix_solaris (67b8685c)


```
Merge pull request #285 from vrthra/ticket/master/16307_fix_solaris

(#16307) fix ip command for solaris.
```
* Merge pull request #284 from justinstoller/maint/master/multiple_datacenter_support (37ceae20)


```
Merge pull request #284 from justinstoller/maint/master/multiple_datacenter_support

(maint) multiple datacenter support
```
* (#16307) get solaris to use the internal ips repository (2e028c69)


```
(#16307) get solaris to use the internal ips repository

Previously we used the default repository at http://pkg.oracle.com/solaris/release/
which caused zone creation to be very slow. By using internal mirror we hope to reduce
the time, and network load.
```
* (#16307) fix ip command for solaris. (49d71520)


```
(#16307) fix ip command for solaris.

Previously we were usign `ip a` in solaris which is not present. Instead use ifconfig to
get the ip address. We also use /etc/inet/hosts instead of /etc/hosts in solaris.
```
* minor fixups (608479d0)

* rough draft of multiple datacenter support (2fb96091)

### <a name = "pe2.6.0">pe2.6.0 - 17 Sep, 2012 (592ad45d)

* Merge pull request #287 from branan/bump_console_auth_ver (592ad45d)


```
Merge pull request #287 from branan/bump_console_auth_ver

(maint) Bump console_auth_ver to 1.1.4
```
* (maint) Bump console_auth_ver to 1.1.4 (474adcaf)

* Merge pull request #286 from branan/pe_ver_bump (186c9c59)


```
Merge pull request #286 from branan/pe_ver_bump

(maint) Bump console_auth_ver for new PE build
```
* (maint) Bump console_auth_ver for new PE build (f98c8e69)

* (maint) update symlink to config file (d3eb7dd1)

* (maint) fix config file typo (a339cb74)

* Bump console-auth version to match the future reality. (fd3836b8)

* Merge pull request #283 from haus/console_version_bump (cd1d2c01)


```
Merge pull request #283 from haus/console_version_bump

Bump console-auth version to match the future reality.
```
* fix solaris cfg (fbcde046)

* Merge pull request #282 from justinstoller/maint/master/use-short-names (dd085453)


```
Merge pull request #282 from justinstoller/maint/master/use-short-names

use the shortname for the host in cfg files
```
* use the shortname for the host in cfg files (9edbd2dc)

* Merge pull request #281 from vrthra/ticket/master/16307_fix_solaris (423ec5d0)


```
Merge pull request #281 from vrthra/ticket/master/16307_fix_solaris

(#16307) handle solaris specially for bin and sbindir
```
* Merge pull request #280 from justinstoller/ticket/master/16307_fix_solaris (030cb0c0)


```
Merge pull request #280 from justinstoller/ticket/master/16307_fix_solaris

Ticket/master/16307 fix solaris
```
* windows doesnt like unix paths (ce895baf)

* Bumping console auth expected version to 1.1.1 (def1557d)

* Merge pull request #279 from haus/console_auth_bump (9fdd4842)


```
Merge pull request #279 from haus/console_auth_bump

Bumping console auth expected version to 1.1.1
```
* Merge pull request #278 from djm68/move_ec2_steps_to_early (821eb7ac)


```
Merge pull request #278 from djm68/move_ec2_steps_to_early

(maint) Move ec2 config to setup/early
```
* (maint) Move ec2 config to setup/early (f75515e0)


```
(maint) Move ec2 config to setup/early

Not pretty, but need a simple, low impact way to perform small
amount of pre-test setup on ec2 nodes.  Only runs when calling
--vmrun blimpy and not a PE build.
```
* Merge pull request #277 from djm68/ec2_setup_steps (4879dad9)


```
Merge pull request #277 from djm68/ec2_setup_steps

(maint) adding setup steps for ec2 hosts
```
* (maint) adding setup steps for ec2 hosts (99f1b11c)


```
(maint) adding setup steps for ec2 hosts

EC2 nodes require a bit of extra setup; this allows node config
before code install/testing.
```
* Merge pull request #276 from djm68/update_ec2_configs (91e26f3d)


```
Merge pull request #276 from djm68/update_ec2_configs

(maint) update ec2 configs for EL5
```
* (maint) update ec2 configs for EL5 (20818621)


```
(maint) update ec2 configs for EL5

Use two el5 32bit amis until we build out sane 64 bit and el6 based
systems.
```
* Merge pull request #275 from djm68/add_configurable_ami_size (578a8bd1)


```
Merge pull request #275 from djm68/add_configurable_ami_size

(Maint) Add support for per host ami sizing
```
* (Maint) Add support for per host ami sizing (9970f5b1)


```
(Maint) Add support for per host ami sizing

Blimpy implementation used ami type 't1.micro' as default; not
useful for real work.  Adds 'amisize' to the config:

HOSTS:
  ubuntu-1004-32-1:
    roles:
      - master
      - database
      - agent
    platform: ubuntu-10.04-i386
    amisize: m1.small
```
* Merge pull request #274 from djm68/add_foss_ec2_amis (6f75a83e)


```
Merge pull request #274 from djm68/add_foss_ec2_amis

(Maint) Add entries for FOSS AMIs
```
* (Maint) Add entries for FOSS AMIs (8014eb82)


```
(Maint) Add entries for FOSS AMIs

Using the PE AMIs, will need to add some pre-test code to install
Ruby and git.
```
* Merge pull request #273 from branan/maint/master/bump-pe-26-versions (f536ff30)


```
Merge pull request #273 from branan/maint/master/bump-pe-26-versions

bump versions for PE 2.6
```
* (acceptance) we dont want master to be an agent. (e8ddd559)


```
(acceptance) we dont want master to be an agent.

Remove the master hostname from the agent list.
```
* Merge pull request #272 from djm68/add_ec2_configs_puppetdb (e34206a9)


```
Merge pull request #272 from djm68/add_ec2_configs_puppetdb

Add ec2 configs puppetdb
```
* (maint) Add links to configs for easy CI integration (df88a9cc)

* (maint) Add ec2 specfic acceptance test configs (242cbb2f)

* bump versions for PE 2.6 (632a3477)

* Merge pull request #270 from justinstoller/feature/master/14158-line-endings (28711819)


```
Merge pull request #270 from justinstoller/feature/master/14158-line-endings

[14158] normalize line endings to unix newline
```
* normalize line endings to unix newline and saw raw versions of stdout,stderr,output (a731b396)

* (#16307) handle solaris specially for bin and sbindir (12294c0b)


```
(#16307) handle solaris specially for bin and sbindir

This is specific to the pkg://solaris/runtime/ruby-18@1.8.7.334,5.11
package available from pkg.oracle.com and available from a full system installation of
solaris11.

The ruby available from the above has Config::CONFIG['bindir'] compiled in to /usr/ruby18/bin
unlike in other platforms and packages which has it set to the system directory /usr/bin
The same issue is present for sbin directory too.

Since puppet and facter need to be delivered to /usr/bin we can not rely on the compiled
in directory for this purpose when using the above package.

This fix updates the invocation of install.rb to pass the directories directly rather than
depend on the compiled in directories. (A better fix would be to rely on the native package
managers to deilver the puppet and facter binaries correctly to the system, so this is a
temporary fix until atleast that happens, or the upstream changes the ruby compiled in
settings in a future version).
```
* Merge pull request #268 from djm68/readme_updates (b24b0838)


```
Merge pull request #268 from djm68/readme_updates

(maint) Significant re-write of README
```
* Merge pull request #266 from zaphod42/maint/master/host-in-ssh-is-a-string (50ff96fe)


```
Merge pull request #266 from zaphod42/maint/master/host-in-ssh-is-a-string

Fix using :pty in tests
```
* (maint) Significant re-write of README (ebc73d39)


```
(maint) Significant re-write of README

README was stale and hard to follow.  Added new provisioning info
and reorganized for easier flow.
```
* (Maint) Better express value of variable in its name (d62293bd)


```
(Maint) Better express value of variable in its name

The @host variable didn't contain a Host instance, it actually contained
the name of the host and so is renamed to @hostname.
```
* (Maint) @host is actually a string (bdee604d)


```
(Maint) @host is actually a string

There must have been a change at some point from @host being an instance
of Host to being just the name of the host. This removes a few calls to
@host methods that assume that it is a Host object.
```
* (acceptance) machines: add solaris hosts (85d8ae47)


```
(acceptance) machines: add solaris hosts

Adds the solaris acceptance machines
```
* (#16307) acceptance: fix up to test cases for making them run on solaris. (3777ec37)


```
(#16307) acceptance: fix up to test cases for making them run on solaris.

- dont do apt-get on solaris
- readlink is present in opensolaris.
- fix solaris specific commadns in master run.
```
* Merge pull request #265 from djm68/extend_ec2_amis (386a1122)


```
Merge pull request #265 from djm68/extend_ec2_amis

(maint) Improve ec2 support
```
* (maint) Improve ec2 support (20a0b945)


```
(maint) Improve ec2 support

Move ec2 configs to external file:
  config/image_templates/ec2.yaml

Populate ec2.yaml with 'production' PE AMIs.
```
* Merge pull request #264 from praxxis/feature/apply_manifest_on_catch_failures (1bb2a2e0)


```
Merge pull request #264 from praxxis/feature/apply_manifest_on_catch_failures

Add an option to apply_manifest_on that allows raising of test failures when manifests fail to apply
```
* Add an option to apply_manifest_on that allows raising of test failures when manifests fail to apply. (31ea306c)

* Merge pull request #263 from branan/remove_virsh_vmrun (bda7bcb1)


```
Merge pull request #263 from branan/remove_virsh_vmrun

Remove obsolete virsh support from vmrun
```
* Remove obsolete virsh support from vmrun (cb12f3dc)

* Merge pull request #262 from branan/blimpy_vmrun (104532a4)


```
Merge pull request #262 from branan/blimpy_vmrun

Blimpy vmrun
```
* Merge pull request #256 from branan/scp_modules (b7c97923)


```
Merge pull request #256 from branan/scp_modules

Add support for installing a module via scp from the test controller
```
* Add an option to preserve test instances. (a80a74fe)


```
Add an option to preserve test instances.

Current test machines are snapshot based and don't require any sort
of deletion or preservation. This support is needed to allow debugging
and instance re-use for cloud-based acceptance testing
```
* Add blimpy support for creating AWS instances for acceptance (b8fad5b6)


```
Add blimpy support for creating AWS instances for acceptance

This adds a new cleanup step. Cleanup is run if *any* step fails.
This ensure that ec2 instances are cleaned up even if another
setup, pre, or post step fails.
```
* Merge pull request #260 from kbarber/ticket/master/15699-forge_role (40360cdb)


```
Merge pull request #260 from kbarber/ticket/master/15699-forge_role

(#15699) Add methods for resolving and more adequately stubbing the forge host
```
* (#15699) Add methods for resolving and more adequately stubbing the forge host (d0976992)


```
(#15699) Add methods for resolving and more adequately stubbing the forge host

This patch includes the new 'forge' method which looks up the host using the
following mechanisms:

* return the host with the 'forge' role assigned to it
* return the value of 'forge_host' in the CONFIG hash
* default to returning 'forge-acceptance.puppetlabs.lan'

This allows us multiple mechanisms to override the forge host, with a fall back
to the static 'forge-acceptance.puppetlabs.lan' host.

It also provides wrapper methodology for stubbing a host in general
`stub_hosts_on` and provides a forge specific wrapper `stub_forge_on`
so we can make our acceptance code more DRY.

To facilitate proper 'unstubbing' this patch also introduces the capability to
declare a teardown code block, that will always be called at the end of a test
case. This is a generic method, and can now be used by anyone for purposes
beyond the initial goal of this patch.
```
* Add support for installing a module via scp from the test controller (88e44c05)

### <a name = "pe2.5.3">pe2.5.3 - 23 Jul, 2012 (0eb96550)

* (maint) Add a case statement for Debian (0eb96550)


```
(maint) Add a case statement for Debian

Debian OSes need only to run apt-get update; no need to modify
the repo cofiguration as with Ubuntu.
```
* Merge pull request #259 from cprice-puppet/feature/master/allow-options-file (13f72dc5)


```
Merge pull request #259 from cprice-puppet/feature/master/allow-options-file

Add support for loading harness options from a file
```
* Merge pull request #258 from cprice-puppet/refactor/master/make-git-install-more-accessible (4b2bae5a)


```
Merge pull request #258 from cprice-puppet/refactor/master/make-git-install-more-accessible

Move install_from_git to reusable location
```
* Add support for loading harness options from a file (be80e274)


```
Add support for loading harness options from a file

This commit introduces a new command-line argument,
"--options-file".  If specified, this file will be
treated as a ruby file to be evaluated, and is
expected to return a hash.  The hash may contain
any of the "normal" options that the framework
supports.  It may also contain extra options
that are specific to the project that is being tested.

Any options passed to the harness on the command
line will be given precedence over the ones found
in the file.
```
* Move install_from_git to reusable location (2dc8d0f5)


```
Move install_from_git to reusable location

This commit introduces an InstallUtils module (which will likely
become a class, eventually) to house the "install_from_git" method
that used to live in setup/git/01_TestSetup.rb.  By moving this method
to a location under 'lib' instead of 'setup', it can be used during
the custom setup lifecycle phases of individual projects.  Previously
it could only be used implicitly via, e.g., --yagr option, and only
if the --type was set to 'git'.
```
### <a name = "pe2.5.2">pe2.5.2 - 9 Jul, 2012 (eaa93833)

* Merge pull request #257 from justinstoller/maint/master/changing_cert_list (eaa93833)


```
Merge pull request #257 from justinstoller/maint/master/changing_cert_list

(maint) the puppet cert --list --all output has changed
```
* the puppet cert --list --all output has changed (20a6b701)

* (maint) Add clean-up /tmp to upgrade step (43d932f1)


```
(maint) Add clean-up /tmp to upgrade step

/tmp is at a premium on some nodes -- remove old tar balls before
copying up new tar file.
```
* Merge pull request #255 from justinstoller/maint/master/pin_win_dir (00eb38b3)


```
Merge pull request #255 from justinstoller/maint/master/pin_win_dir

(maint) pessimistically pin windows gem versions
```
* pessimistically pin windows gem versions (92569137)

* Merge pull request #254 from cprice-puppet/bug/master/vmrun-plus-manual-install (cabe61d0)


```
Merge pull request #254 from cprice-puppet/bug/master/vmrun-plus-manual-install

Fix a bug in support for "--type manual"
```
* Merge pull request #253 from grimradical/require-pathname (84c16870)


```
Merge pull request #253 from grimradical/require-pathname

Require pathname in git TestSetup script
```
* Require pathname in git TestSetup script (ae452af4)


```
Require pathname in git TestSetup script

Depending on load-order odditites, 'pathname' may not be loaded when that
script is loaded.

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Merge pull request #252 from branan/allow_manual_ip (c3439eb4)


```
Merge pull request #252 from branan/allow_manual_ip

Allow manual specification of host IP address
```
* Merge pull request #250 from grimradical/fission-loop-until-ready (98f04c95)


```
Merge pull request #250 from grimradical/fission-loop-until-ready

Wait until fission VMs are actually ready before proceeding
```
* Fix a bug in support for "--type manual" (c7437205)


```
Fix a bug in support for "--type manual"

The vmrun option looks for a vmsnapshot named "manual" if you
specify "--type manual".  We want it to just use the normal
"git" snapshot.  This is kind of a hack, unfortunately... but
as you can see in the line above, we weren't the first ones
to have this problem.
```
* Allow manual specification of host IP address (829d840c)


```
Allow manual specification of host IP address

This allows the acceptance module to still track real hostnames without
it being necessary to add all the hosts to the controller's /etc/hosts
file.
```
* Merge pull request #251 from cprice-puppet/feature/master/allow-manual-installation-type (191ce940)


```
Merge pull request #251 from cprice-puppet/feature/master/allow-manual-installation-type

Allow projects to specify manual installation
```
* Allow projects to specify manual installation (f8f4be90)


```
Allow projects to specify manual installation

This commit allows you to specify "--type manual",
if your project will be responsible for managing
installation of the test subject code and does
not need the framework to do anything during that
phase.
```
* Wait until fission VMs are actually ready before proceeding (c40994e2)


```
Wait until fission VMs are actually ready before proceeding

Sometimes fission will return from a call to `start` prior to it actually being
registered as `running` in VMWware.

This patch adds some basic sanity-checking; we'll wait until the VM is actually
in the state we'd like before proceeding. Better safe than sorry.

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Merge pull request #247 from cprice-puppet/feature/master/allow-project-setup-suites (d1fbcd7b)


```
Merge pull request #247 from cprice-puppet/feature/master/allow-project-setup-suites

Feature/master/allow project setup suites
```
* Merge pull request #248 from cprice-puppet/feature/master/node-name-method-for-hosts (9ff0c009)


```
Merge pull request #248 from cprice-puppet/feature/master/node-name-method-for-hosts

Add "node_name" method to Host class
```
* Merge pull request #249 from grimradical/typo-in-vmrun (a8130619)


```
Merge pull request #249 from grimradical/typo-in-vmrun

Fix typo in comparison statement
```
* Merge pull request #246 from cprice-puppet/feature/master/allow-extra-git-clones (d573e48f)


```
Merge pull request #246 from cprice-puppet/feature/master/allow-extra-git-clones

Add support for cloning additional git repos
```
* Fix typo in comparison statement (8b3ba517)


```
Fix typo in comparison statement

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Merge pull request #245 from grimradical/9989_fission_support (c9a91b51)


```
Merge pull request #245 from grimradical/9989_fission_support

Support for VMWare Fusion when using --vmrun
```
* Add "node_name" method to Host class (c1886954)


```
Add "node_name" method to Host class

In certain tests it is very important for us to use
an agent's node_name_value rather than relying
on the hostname from the test config file (or
other possible values that may successfully
resolve in DNS).  For example, when testing
node activation and de-activation for puppetdb,
we *must* use the node_name_value or things
can go awry.

This commit adds a method to the host object
that allows us to retrieve the node_name_value
without having to hard-code the command for
acquiring it into all of the tests.  We might
want to consider similar methods for a few other
things such as FQDN.
```
* Move vmname option from fission-level to host-level (bcabafe4)


```
Move vmname option from fission-level to host-level

vmname is a generic attribute of a host, thus the option can be useful in
contexts outside of fission. This patch moves that option out of the fission
subsection and into the parent host section.

"I've been wanting to make explicit the distinction between name used by the
harness, hostname, and vmname for awhile. This is something we're going to need
in vSphere soon and I'd like to see 'vmname' as a key in the host hash above
the fission specific section (since I'll probably be using it in vSphere as
well before Lance ships)." -- Justin Stoller

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Add fission dependency to gemspec (fddeedb8)


```
Add fission dependency to gemspec

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Allow projects to define their own setup suites (452e5e3a)


```
Allow projects to define their own setup suites

This introduces the "--setup-dir" option, which
allows a project to specify a path to a
project-specific setup directory.  This directory
may contain subdirectories like "early", "pre-suite",
and "post-suite".  Ruby files inside of these
directories will be run at the appropriate phase
in the testing lifecycle.
```
* Use headless mode for Fusion VM's (f325bf76)


```
Use headless mode for Fusion VM's

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Support for VMWare Fusion when using --vmrun (71873184)


```
Support for VMWare Fusion when using --vmrun

This provides support for reverting a VMWare Fusion machine to a particular
snapshot prior to executing tests.

Additional requirements on the Test Driver:
- Must have the 'fission' gem (including all its dependencies) installed
- Must have a ~/.fissionrc that points to the `vmrun` executable and where VMs
  can be found

You can then use the following arguments to systest:
- `--vmrun fusion` tells us to enable this feature. This is required.
- `--snapshot <name>`, where <name> is the snapshot name to revert to. This
  applies across *all* VMs, so it only makes sense if you want to use the same
  snapshot name for all VMs. This is optional.

For each host, you can (optionally) have a "fission" section with the following
(also optional) settings inside:

- `vmname`: This is useful if the hostname of the VM doesn't match the name of
  the .VMX file on disk. The alias should be something fission can load.
- `snapshot`: This is useful if you'd like to use different snapshots for each
  host. The value should be a valid snapshot name for the VM.

Signed-off-by: Deepak Giridharagopal <deepak@puppetlabs.com>
```
* Add support for cloning additional git repos (174a2465)


```
Add support for cloning additional git repos

This adds a "--yagr" option to the acceptance framework: "Yet Another
Git Repo".  You can pass as many occurrences of this as you like,
and the framework will clone each repo so that you'll have it available
for your project's tests.
```
* (maint) Much needed cleanup on README (df545ed4)


```
(maint) Much needed cleanup on README

Much info was out of date; removed references to private PE test
repository.  Converted to markdown format.
```
* Merge pull request #244 from djm68/add_agent_test_pe_upgrade (ac15b338)


```
Merge pull request #244 from djm68/add_agent_test_pe_upgrade

(maint) Add agent --test step
```
* (maint) Add agent --test step (935f5af0)


```
(maint) Add agent --test step

Running 'puppet agent --test' after installation and upgrades
sets up the newly installed agents for testing.  Thi step was
ommitted on pe upgrade testing.
```
* Merge pull request #243 from justinstoller/maint/master/instance_not_class (ab254dc7)


```
Merge pull request #243 from justinstoller/maint/master/instance_not_class

(maint) move from TestConfig.is_pe? to host.is_pe?
```
* move from TestConfig.is_pe? to host.is_pe? (4e0bcf9b)

* Merge pull request #242 from justinstoller/maint/master/hosts_clean_up (93dceaf2)


```
Merge pull request #242 from justinstoller/maint/master/hosts_clean_up

Host initialization/defaults cleanup
```
* clean up host initialization (99ccff97)

* properly load windows defaults for opensource (4187bccd)

* Merge pull request #241 from justinstoller/maint/master/move_logger_initialization (f3fe932b)


```
Merge pull request #241 from justinstoller/maint/master/move_logger_initialization

Logging Refactor
```
* variable names != method names (0ff2f20e)

* break the cli class into some sensical methods (d9c709c0)

* re-enable stdout only behavior (df08dcef)

* refactor logging configuration out of TestSuite and into CLI (855faf4b)

* TestConfig#is_pe -- changed away from !! syntax because the match returns 0 (first character in string) which ! believes is false (c67fec4a)

* Merge pull request #240 from nicklewis/database-role (e463b8ba)


```
Merge pull request #240 from nicklewis/database-role

Add "database" role to CI configs
```
* Merge pull request #237 from nicklewis/command-refactors (45a14a2b)


```
Merge pull request #237 from nicklewis/command-refactors

Command refactors
```
* Merge pull request #239 from nicklewis/preserve-ssl (d6940bf9)


```
Merge pull request #239 from nicklewis/preserve-ssl

Fix preserve_ssl to actually preserve ssl..
```
* Specify depth correctly when removing vardir children (23d4e492)


```
Specify depth correctly when removing vardir children

It turns out `-depth n` is a BSD option only, so we'll use -mindepth and
-maxdepth to get the same effect.
```
* Merge pull request #238 from justinstoller/maint/master/require_json (4582a9c0)


```
Merge pull request #238 from justinstoller/maint/master/require_json

(maint) require json gem as harness dependency
```
* Add "database" role to CI configs (88a0e03c)


```
Add "database" role to CI configs

This doesn't currently having any meaning to the test harness, but will
be used by at least PuppetDB. All the databases live on the same node as
the master.
```
* Use standard file naming convention for Logger (f7231672)

* Fix preserve_ssl to actually preserve ssl.. (28f2d175)


```
Fix preserve_ssl to actually preserve ssl..

This option prevented the explicit removal of the ssl directory, but
didn't prevent the case where the ssldir is inside the vardir and gets
removed that way.
```
* require json gem as harness dependency (73beda73)

* Respect the --no-color option (80c5fe8c)

* Merge pull request #236 from nicklewis/options-for-puppet-master (2738d4a5)


```
Merge pull request #236 from nicklewis/options-for-puppet-master

Allow options for with_master_running_on
```
* Allow options for with_master_running_on (08b69404)


```
Allow options for with_master_running_on

This method now takes an optional final argument, an options hash. The
only current use is to specify the :preserve_ssl option, which dictates
whether or not to leave the ssl directories of the hosts alone. The
default behavior is to remove them, as the master is considered to be a
new puppet instance. However, sometimes a master needs to exist in a
long-running system, so this option can be used to maintain ssl.
```
* Merge pull request #235 from kelseyhightower/feature/master/add_hiera_puppet_support (5aebc4d1)


```
Merge pull request #235 from kelseyhightower/feature/master/add_hiera_puppet_support

(maint) Add hiera-puppet support + code clean up
```
* Don't automatically install hiera and hiera-puppet (364f67f2)

* (maint) Add hiera-puppet support + code clean up (f28b35ca)


```
(maint) Add hiera-puppet support + code clean up

This patch adds support for hiera-puppet plus some code clean up.
```
* Merge pull request #234 from kelseyhightower/master (525e7081)


```
Merge pull request #234 from kelseyhightower/master

(maint) Quote sources in Hiera hierarchy
```
* (maint) Quote sources in Hiera hierarchy (1c6ea5a4)


```
(maint) Quote sources in Hiera hierarchy

Without this patch the YAML parser can fail when parsing the
`/etc/puppet/hiera.yaml` configuration file. This results in the
following error:

    Error 400 on SERVER: (/etc/puppet/hiera.yaml): found character that
    cannot start any token while scanning for the next token at line 5
    column 5
```
* Merge pull request #233 from justinstoller/maint/master/bump_console_version (b4975548)


```
Merge pull request #233 from justinstoller/maint/master/bump_console_version

(maint) bump console version to 1.0.12
```
* bump console version to 1.0.12 (11ed5110)

* Clean-up and stream command output (983c337c)


```
Clean-up and stream command output

This merges stdout and stderr, as we've never actually cared much for
the distinction (and this way, they come out in the proper order). Also
reformatted the way output is done to look like a standard shell
session. Command exit codes are only logged if they are non-zero.
Finally, output is now printed as it's received, rather than being
delayed until the command is finished. This provides better insight into
what the test is doing and why it's held up.
```
* Merge pull request #232 from justinstoller/maint/master/only_change_old_aptconf (34ae12c7)


```
Merge pull request #232 from justinstoller/maint/master/only_change_old_aptconf

(maint) dont backup non-existent files
```
* dont backup non-existent files (fb85b8b0)

* Stop using a global logger (8e271361)


```
Stop using a global logger

Now, the test suite will create an instance of Logger and pass it around
to the other objects that need it. This makes it easier to encapsulate
and change the properties of the logger, or to use a different logger
when necessary (for instance, for summary logging).
```
* Robustify puppet master start/stop (693c380a)


```
Robustify puppet master start/stop

This was using curl to check if the master was stopped, when `kill -0`
will suffice. Also, it was overly permissive in the exit codes it
accepted, and would just wait the full duration for the master to
start/stop in the case where curl wasn't even installed.

Also reduced the timeouts to wait for start/stop, as 30 seconds was a
bit unrealistically long, and just slowed down results when something
really was broken.
```
* Reorder some options for better help output (49f5caa8)


```
Reorder some options for better help output

This moves commonly used (and required) options to the beginning of the
help output to make it easier to get started.
```
* Extract command execution and SCP to SshConnection (e0ce5589)


```
Extract command execution and SCP to SshConnection

This handles the responsibility of actually running a command on the
remote machine, whereas Host has the job of checking that it was
successful (by the given definition of success). The TestCase#on method
is now a thin DSL wrapper around Host#exec.
```
* Remove superfluous do_action method (05f0e290)

* Shift responsibility for executing commands (a6c465fc)


```
Shift responsibility for executing commands

Previously the logic had been in Command, but that only represents
something to execute, and shouldn't be executing it or checking whether
it succeeded.  Now the "on" method of TestCase takes care of this.
```
* (maint) add apt-get update to --pkg-repo (4ef4a8c5)


```
(maint) add apt-get update to --pkg-repo

Some VMs have stale apt caches, this will update the caches
before attemting to install Puppet.
```
* (maint) EL package configs removal (4b1f8d5c)


```
(maint) EL package configs removal

EL platforms have very complex package configs: different names
on each platform, different repo urls, etc.  Removing EL specific
steps for now.
```
* Merge pull request #231 from justinstoller/feature/master/12783-virsh_never_do_it (512e2107)


```
Merge pull request #231 from justinstoller/feature/master/12783-virsh_never_do_it

(#12783) virsh, never do it
```
* add rbvmomi to gemspec (8e431173)


```
add rbvmomi to gemspec

warn of virsh deprecation
```
* alow revert vm step to use RbVmomi if appropriate (9bbf59c7)

* Merge pull request #230 from branan/14694_log_directory (ac00544f)


```
Merge pull request #230 from branan/14694_log_directory

(#14694) use mkdir_p for log output directory
```
* (#14694) use mkdir_p for log output directory (270bdf1d)

* Merge pull request #229 from justinstoller/maint/master/lib_layout (b346b3bf)


```
Merge pull request #229 from justinstoller/maint/master/lib_layout

(maint) move and modify lib to be a true gem
```
* move and modify lib to be a true gem (71f26976)

* Merge pull request #228 from justinstoller/ruby_layout (a7467579)


```
Merge pull request #228 from justinstoller/ruby_layout

(maint) ruby layout
```
* ensure stub tests are passing (b6ae0de9)

* Merge pull request #227 from jeffmccune/maint/master/fix_ntp_for_win2008r2 (8a82c129)


```
Merge pull request #227 from jeffmccune/maint/master/fix_ntp_for_win2008r2

Fix false positive error synchronizing win2008r2 Time
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (12b08e17)

* (maint) No default install of Hiera (2f5c3668)


```
(maint) No default install of Hiera

Hiera was being installed even when not specified on the command line.
Seeting options[:hiera] to nil prevents silent, unintended installs.
```
* (maint) Remove leading white space (c36728bb)


```
(maint) Remove leading white space

Leading white space is breaks repo config
```
* Merge pull request #226 from djm68/add_el6__repo_update (c96f040b)


```
Merge pull request #226 from djm68/add_el6__repo_update

(maint) Dynamic repo cofig for EL6 platforms
```
* (maint) Dynamic repo cofig for EL6 platforms (0a5d4361)


```
(maint) Dynamic repo cofig for EL6 platforms

Our packing reposities are rather dynamic...VM images not so much.
Adding EL6 pkg repo updates.
```
* Merge pull request #224 from cprice-puppet/feature/master/add-helper-file-option (afb5cb80)


```
Merge pull request #224 from cprice-puppet/feature/master/add-helper-file-option

Add a --helper option
```
* Merge pull request #225 from kelseyhightower/ticket/master/14554_add_hiera_command_support (104070a3)


```
Merge pull request #225 from kelseyhightower/ticket/master/14554_add_hiera_command_support

(maint) Fix Hiera setup step
```
* (maint) Fix Hiera setup step (5ab2a98e)


```
(maint) Fix Hiera setup step

Without this patch the `/etc/puppet/hiera.yaml` configuration file has the
wrong permissions which causes the following error:

    Error 400 on SERVER: Permission denied - /etc/puppet/hiera.yaml at
    /tmp/databinding.Z16mln/site.pp:2

This patch also adds the missing configuration option for the YAML
backend's datadir.

    # hiera.yaml
    :yaml:
      :datadir: #{dest_path}/hieradata

The Hiera setup step now creates the YAML backend datadir:

    /etc/puppet/hieradata
```
* Fix false positive error synchronizing win2008r2 Time (8fe23ec5)


```
Fix false positive error synchronizing win2008r2 Time

Without this patch the acceptance tests fail running against Windows
2008 hosts because the w32tm /register command always returns
"Permission Denied."  Even with UAC completely disabled.

The command is not actually required in Windows 2008.  The commands
following the register command are adequate to synchronize the system
clock after a revert of the VM snapshot.

This change should only affect Windows hosts and the command should
still complete on Windows 2003 hosts where Josh thinks it's required.
```
* Add a --helper option (b9fc2717)


```
Add a --helper option

This new option allows tests to pass a path to a "helper"
file, somewhat akin to a spec_helper file, which will
simply be "require"d by the framework.  This allows
tests to rely on library code that lives in their own
project rather than in the framework.
```
* Merge pull request #223 from joshcooper/maint/master/fix-hiera-path (aa5b1732)


```
Merge pull request #223 from joshcooper/maint/master/fix-hiera-path

(Maint) Always use POSIX-style paths for PATH
```
* (Maint) Always use POSIX-style paths for PATH (da54bcc8)


```
(Maint) Always use POSIX-style paths for PATH

Previously, we were setting the PATH environment variable as:

  env PATH="C:\foo;$PATH" cmd.exe /c <command>

However, cygwin handles the PATH environment variable differently than
RUBYLIB. It splits the value of PATH on colons, and converts each path
component to Windows style paths. So `C:\foo` becomes `C;C:\foo`

This commit changes the test harness to generate commands of the form:

  env PATH="/opt/hiera/bin:$PATH" cmd.exe /c <command>

Which becomes `C:\cygwin\opt\hiera\bin;%PATH%`
```
* Merge pull request #222 from jeffmccune/maint/master/win2008_ci_config (e540e00b)


```
Merge pull request #222 from jeffmccune/maint/master/win2008_ci_config

Add ci-windows2008-64a config for CI Acceptance
```
* Add ci-windows2008-64a config for CI Acceptance (22f6995e)


```
Add ci-windows2008-64a config for CI Acceptance

Without this patch we don't have any configurations suitable for
acceptance testing using a Windows 2008 R2 x64 agent system.

This patch fixes the problem by providing a configuration targeting
win2008r2-64-1.puppetlabs.lan as an agent platform.
```
* Merge pull request #221 from kelseyhightower/ticket/master/14554_add_hiera_command_support (471cf80c)


```
Merge pull request #221 from kelseyhightower/ticket/master/14554_add_hiera_command_support

(#14554) Add hiera command support
```
* (#14554) Add hiera command support (18b4b951)


```
(#14554) Add hiera command support

This patch adds support for running hiera commands to the test harness.  You
can execute Hiera commands like this:

    on master, hiera(""), :acceptable_exit_codes => [1] do
      assert_output <<-OUTPUT
        STDERR> Please supply a data item to look up
      OUTPUT
    end
```
* try to ensure backwards compatibility while we change job formats (a0909efe)

* Merge pull request #220 from cprice-puppet/feature/master/allow-trace-for-apply (f243ae82)


```
Merge pull request #220 from cprice-puppet/feature/master/allow-trace-for-apply

Add ability to pass "--trace" when calling apply
```
* Add ability to pass "--trace" when calling apply (076e494b)

* Merge pull request #219 from djm68/add_host_based_path_separator (284b2988)


```
Merge pull request #219 from djm68/add_host_based_path_separator

(maint) Add correct path separator for Windows hosts
```
* (maint) Add correct path separator for Windows hosts (4ae58ba7)


```
(maint) Add correct path separator for Windows hosts

Windows hosts require a ';' vs a ':'.  Added a new entry
'pathseparator' to host/unix.rb host/windows.rb
```
* Merge pull request #218 from justinstoller/maint/master/bump_console_auth (6f606879)


```
Merge pull request #218 from justinstoller/maint/master/bump_console_auth

(maint) bump console auth version
```
* bump console auth version (f3f0fdae)

* (maint) Add append hiera/lib to RUBYLIB, Win (564dee99)


```
(maint) Add append hiera/lib to RUBYLIB, Win

Windows needs its own entry for RUBYLIB; adding hiera/lib to
get Hiera into the path.
```
* Merge pull request #217 from kbarber/ticket/master/14397-win32console_v1.3.2 (9b7519a4)


```
Merge pull request #217 from kbarber/ticket/master/14397-win32console_v1.3.2

(#14397) Use win32console v1.3.2 now, with pipe fixes
```
* Merge pull request #216 from djm68/fix_heira_windows_path (ab9bf37c)


```
Merge pull request #216 from djm68/fix_heira_windows_path

(maint) Fix puppet conf dir path extraction for Win
```
* (maint) Fix puppet conf dir path extraction for Win (6f7c44ac)


```
(maint) Fix puppet conf dir path extraction for Win

I feel dirty.  Terribly ugly hack to retreive a normalized cygpath
path for $confdir.  This needs to be address in the lib/windows.rb
at a later date, but this will un-stick the hiera tests on Win.
```
* Merge pull request #215 from jeffmccune/maint/master/add_modules_to_config_key_summary (159c8e14)


```
Merge pull request #215 from jeffmccune/maint/master/add_modules_to_config_key_summary

Add modules to Host Configuration Summary
```
* Add modules to Host Configuration Summary (edf329d2)


```
Add modules to Host Configuration Summary

Without this patch the set of modules installed into the puppet master
modulepath is not displayed in the Host Configuration Summary.  This is
a problem because I sometimes forget to switch the branch I'm working on
and I end up running the test suite against a branch that fails the
tests I'm currently working on.

This patch simply adds the array created by --modules to the config hash
object displayed by the summary.

The new summary looks like:

      - Host Configuration Summary -
    Platform for win2003sat windows-2003-amd64
    Platform for qa-ubuntu-lucid ubuntu-10.04-i386
    Role for win2003sat agent
    Role for qa-ubuntu-lucid master
    Role for qa-ubuntu-lucid agent
    Ruby version for win2003sat ruby 1.8.7 (2011-12-28 patchlevel 357) [i386-mingw32]
    Ruby version for qa-ubuntu-lucid ruby 1.8.7 (2010-01-10 patchlevel 249) [i486-linux]
    Config Key|Val: modules ["git@github.com:jeffmccune/puppetlabs-registry.git#maint/master/add_acceptance_tests", "git://github.com/puppetlabs/puppetlabs-stdlib.git#master"]
    Config Key|Val: filecount 12
    Config Key|Val: puppet_ver "git://github.com/puppetlabs/puppet.git#2.7.x"
    Config Key|Val: consoleport 443
```
* Merge pull request #214 from justinstoller/maint/master/end_test_when_no_hosts (2881fbd3)


```
Merge pull request #214 from justinstoller/maint/master/end_test_when_no_hosts

(maint) end test when no hosts
```
* skip test when no valid hosts remain (6316af07)

* end test if no valid hosts remain (3ca8c5d6)

* Merge pull request #213 from djm68/install_hiera_all_hosts (1213880a)


```
Merge pull request #213 from djm68/install_hiera_all_hosts

(maint) Install Hiera on all hosts
```
* (maint) Install Hiera on all hosts (56df1b75)


```
(maint) Install Hiera on all hosts

Minor change to instal Hiera on all hosts vs. just the Puppet
Master host.
```
* (#14397) Use win32console v1.3.2 now, with pipe fixes (2ff30a1a)


```
(#14397) Use win32console v1.3.2 now, with pipe fixes

Previously win32console was throwing errors in the acceptances tests due to a
bug in the code which was causing any redirected output to throw an exception:

https://github.com/luislavena/win32console/issues/14

This issue has now been solved, and subsequently win32console version 1.3.2 is
now safe to use.
```
* Merge pull request #212 from justinstoller/maint/master/install_specific_version_of_gem (eb8c5a09)


```
Merge pull request #212 from justinstoller/maint/master/install_specific_version_of_gem

(maint) install gems individually so specific versions can easily be specified
```
* install gems individually so specific versions can easily be specified (8b685832)

* Merge pull request #211 from justinstoller/maint/master/dont_break_junit (bc34da81)


```
Merge pull request #211 from justinstoller/maint/master/dont_break_junit

(maint) escape the escape character, dont use regexes that dont do anything
```
* escape the escape character, dont use regexes that dont do anything (e6ebd364)

* Merge pull request #210 from jeffmccune/fix/master/hard_reset_modules (bc5a8e2f)


```
Merge pull request #210 from jeffmccune/fix/master/hard_reset_modules

Perform a hard reset to get module changes
```
* Perform a hard reset to get module changes (26dc1aae)


```
Perform a hard reset to get module changes

Without this patch the --modules command line option results in the
behavior of using git checkout -f on the puppet master systems using the
local branch.

This is a problem because I frequently re-write history in my topic
branches and the upstream branch will no longer be fast-forward-able
relative to the local branch reference.

The end result is that my changes aren't actually tested if I rewrite
history.

This patch fixes the problem by doing a hard reset of the local topic
branch against the upstream reference.  This ensures the local branch is
the exact same as the upstream reference.

The end result is that my changes are tested.  =)
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (83a00b87)

* (maint) add acceptance test config for jmccune (dd5f9154)


```
(maint) add acceptance test config for jmccune

Jmccune and I are investigating what we need to spin up an
acceptence testing setup a-la-jenkins_pod
```
* Merge pull request #209 from jeffmccune/fix/master/modules_option (721bb668)


```
Merge pull request #209 from jeffmccune/fix/master/modules_option

Fix missing comma in --modules option
```
* Fix missing comma in --modules option (675aa6aa)


```
Fix missing comma in --modules option

I forgot a comma so the -m and --modules string were being combined
together yielding this error:

    $ ./test_registry
    + ./systest.rb --config jeff_win2003.yaml --type git2 --puppet git://github.com/jeffmccune/puppet.git#2.7.x --modules git@github.com:jeffmccune/puppetlabs-registry.git#maint/refactor_type_and_provider_helper_methods/add_acceptance_tests --modules git://github.com/puppetlabs/puppetlabs-stdlib.git#master --debug --tests ./acceptance-registry/tests/resource/registry/should_create_key.rb
    /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1450:in `complete': invalid option: --modules (OptionParser::InvalidOption)
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1448:in `catch'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1448:in `complete'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1261:in `parse_in_order'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1254:in `catch'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1254:in `parse_in_order'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1248:in `order!'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1339:in `permute!'
            from /Users/jeff/.rvm/rubies/ruby-1.8.7-p334/lib/ruby/1.8/optparse.rb:1360:in `parse!'
            from ./lib/options_parsing.rb:202:in `parse_args'
            from ./systest.rb:25

This patch adds in the missing comma and fixes the error.
```
* Merge pull request #206 from jeffmccune/feature/master/registry_acceptance (d20d52b8)


```
Merge pull request #206 from jeffmccune/feature/master/registry_acceptance

Add --modules command line option to test modules
```
* Merge pull request #208 from djm68/add_hiera_lib_dir (dda48e26)


```
Merge pull request #208 from djm68/add_hiera_lib_dir

(maint) Add Hiera lib dir for Linux hosts
```
* (maint) Add Hiera lib dir for Linux hosts (298dfc85)


```
(maint) Add Hiera lib dir for Linux hosts

Add Hiera lib dir: /opt/puppet-git-repos/hiera/lib to $RUBYLIB.
This is very specific to how we install FOSS Puppet via the test
harness, and will not work if Hiera is installed in a different path.
```
* Merge pull request #207 from justinstoller/maint/master/move_required_env_before_install (39cace5d)


```
Merge pull request #207 from justinstoller/maint/master/move_required_env_before_install

(maint) move EnvSetup to before we actually try to install
```
* Add --modules command line option to test modules (e37a7829)


```
Add --modules command line option to test modules

Without this patch the git acceptance type has no way to install
arbitrary Puppet modules.  We need this functionality to properly test
the Registry puppet module.

This patch fixes the problem by providing a --modules command line
option.  This option takes a list of URI's to Puppet module
repositories.  Each listed URI will be cloned into /opt/puppet-git-repos
on each master system using the 04_InstallModules setup step when using
--type git.

Individual test cases may then configure a modulepath directory that
symlinks in the modules we're testing are "installed" on the puppet
master systems.
```
* move EnvSetup to before we actually try to install (677cff33)

* Merge pull request #205 from djm68/add_hiera_install_option (cb22cb78)


```
Merge pull request #205 from djm68/add_hiera_install_option

(maint) Add Hiera install option
```
* (maint) Add Hiera install option (a13eba8b)


```
(maint) Add Hiera install option

Add -h and --hiera + URI to install Hiera.  Creates a default
hiera.yaml file as well.
TODO: add Windows install option as well.
```
* (maint) Debian will require different setup (213e56ef)


```
(maint) Debian will require different setup

Debian needs a seperate config step vs. ubuntu.
```
* Merge pull request #204 from djm68/setup_pkg_repo (35396dfc)


```
Merge pull request #204 from djm68/setup_pkg_repo

(maint) Add step for dynamic pkg repo cfg
```
* (maint) Add step for dynamic pkg repo cfg (ded9366a)


```
(maint) Add step for dynamic pkg repo cfg

Our package repos change occassionally, causing grief for our
VMs that are snap shotted with stale configs.
```
* Merge pull request #187 from mkincaid/windows_bindir_fix (a3c5e890)


```
Merge pull request #187 from mkincaid/windows_bindir_fix

Use cygpath to get the Puppet Enterprise binary directory instead of har...
```
* Merge pull request #203 from haus/bump_console_auth_version (875e3db3)


```
Merge pull request #203 from haus/bump_console_auth_version

Bump expected console-auth version to 1.0.10
```
* Bump expected console-auth version to 1.0.10 (5ad72308)

* Merge pull request #202 from justinstoller/maint/master/missing_colon (ea132fd4)


```
Merge pull request #202 from justinstoller/maint/master/missing_colon

(maint) fix missing colon
```
* fix missing colon (76d314ca)

* Merge pull request #201 from justinstoller/maint/master/round_robin_hosts (6900f5e5)


```
Merge pull request #201 from justinstoller/maint/master/round_robin_hosts

(maint) adds multi-platform test networks
```
* adds multi-platform test networks (63058867)

* Merge pull request #200 from justinstoller/maint/master/add_win32console_gem (ccfccfd7)


```
Merge pull request #200 from justinstoller/maint/master/add_win32console_gem

(maint) add the win32console gem to windows agents during testing
```
* add the win32console gem to windows agents during testing (bbc8a87b)

* Merge pull request #199 from justinstoller/maint/master/consolidate_agent_tests (ba3040c1)


```
Merge pull request #199 from justinstoller/maint/master/consolidate_agent_tests

(maint) consolidate our agent tests
```
* consolidate our agent tests (d7294b5b)

* Merge pull request #198 from justinstoller/maint/master/rename_precise_64 (f1b37d2c)


```
Merge pull request #198 from justinstoller/maint/master/rename_precise_64

(maint) use precise-64-2 instead of precise-64-1
```
* use precise-64-2 instead of precise-64-1 (af2825ce)

* Merge pull request #197 from justinstoller/maint/master/bump_console_auth_ver (24079aca)


```
Merge pull request #197 from justinstoller/maint/master/bump_console_auth_ver

(maint) bump console auth version
```
* bump console auth version (a14e4588)

* Merge pull request #196 from justinstoller/maint/master/add_sles11.2_support (bba77e74)


```
Merge pull request #196 from justinstoller/maint/master/add_sles11.2_support

(maint) support latest sles service pack
```
* support latest sles service pack (59e43de3)

* Merge pull request #195 from justinstoller/maint/master/add_precise_config (5b0f56cc)


```
Merge pull request #195 from justinstoller/maint/master/add_precise_config

(maint) full precise support in testing
```
* full precise support in testing (11084db3)

* Merge pull request #194 from justinstoller/maint/master/add_precise_config (b8c34a49)


```
Merge pull request #194 from justinstoller/maint/master/add_precise_config

(maint) add precise config for mono install tests
```
* add precise config for mono install tests (7c0dabae)

* Merge pull request #193 from joshcooper/rename-64-32 (34720321)


```
Merge pull request #193 from joshcooper/rename-64-32

Rename 64 to 32
```
* (Maint) Rename 64 to 32 (6e55d451)


```
(Maint) Rename 64 to 32

Update the hostname
```
* (Maint) Rename from 64 to 32 (97ee9cba)


```
(Maint) Rename from 64 to 32

Will the real windows 2003R2 VM stand up.
```
* Merge pull request #188 from joshcooper/master (d5faaadc)


```
Merge pull request #188 from joshcooper/master

Install gem dependencies
```
* Merge pull request #192 from justinstoller/maint/master/ensure_vm_reversion_before_pre_script (69040c88)


```
Merge pull request #192 from justinstoller/maint/master/ensure_vm_reversion_before_pre_script

(maint) ensure the setup/early phase has passed so that vms have been reverted
```
* ensure the setup/early phase has passed so that vms have been reverted (431b8423)

* Merge pull request #191 from justinstoller/maint/master/add_config_for_old_agents (ea734d57)


```
Merge pull request #191 from justinstoller/maint/master/add_config_for_old_agents

(maint) add simple config for testing against agents in older versions
```
* add simple config for testing against agents in older versions (a800b1b1)

* Merge pull request #190 from justinstoller/maint/master/allow_consoleport_set_from_env_vars (1401b752)


```
Merge pull request #190 from justinstoller/maint/master/allow_consoleport_set_from_env_vars

(maint) allow console port to be set thru env vars
```
* make the env var override the config value (ead732c9)

* allow console port to be set thru env vars (bdf5f41b)

* Merge pull request #189 from justinstoller/maint/master/add_configs (d7d70182)


```
Merge pull request #189 from justinstoller/maint/master/add_configs

(maint) update the configs
```
* add new configs to allow more split master/dash setups (51c23907)


```
add new configs to allow more split master/dash setups

copy the windows cfg to a standard PE spot
```
* (Maint) Add step for installing necessary gems (c1382235)


```
(Maint) Add step for installing necessary gems

The FOSS version of Puppet on Windows requires several gems to run. Up
until now, the necessary gems were part of the 'git' snapshot. However,
as we add more features, additional gems will be required. Rather than
update the snapshot each time, this commit adds a setup step that
installs/updates the gems we require. It is written fairly generically
so that platform-specific gems and behavior can be added.

Note this step only occurs in 'git' but not 'pe' because in the latter
case, the gems should be part of the installer itself.
```
* Use cygpath to get the Puppet Enterprise binary directory instead of hard-coding. (03361413)


```
Use cygpath to get the Puppet Enterprise binary directory instead of hard-coding.

This fixes 64-bit Windows, where it is "Program Files (x86)".
```
* our foss snapshots are essentially on foss only machines (671a7220)

* give the test harness a valid gem structure (939e33ad)


```
give the test harness a valid gem structure

ignore gem paraphanelia in git
```
* rename ci -> config, and centralize configs and their examples in it (ab28bb5d)

* combine configs, use as many common ones as possible (39603206)

* remove unused dist dir (21fc70b1)

* someone left .sh tests around (23cda0c6)

* remove vmutil -- replaced by fission and vagrant (83957b08)

### <a name = "pe2.5.0">pe2.5.0 - 27 Mar, 2012 (232e21a5)

* Merge pull request #186 from justinstoller/maint/master/generated_upgrade_a (232e21a5)


```
Merge pull request #186 from justinstoller/maint/master/generated_upgrade_a

(maint) we are generating the upgrade answers now
```
* we are generating the upgrade answers now, forgot in haste and lack of sleep (70ad1845)

* Merge pull request #185 from justinstoller/maint/master/update_upgrade_a (ddc76f7e)


```
Merge pull request #185 from justinstoller/maint/master/update_upgrade_a

(maint) we are finally enforcing the eight chars in upgrades as well...
```
* we are finally enforcing the eight chars in upgrades as well... (a377e5f0)

* Merge pull request #184 from joshcooper/maint/master/fix-cert-race-condition (c321962c)


```
Merge pull request #184 from joshcooper/maint/master/fix-cert-race-condition

(Maint) Ensure agent certs are signed before proceeding
```
* Merge pull request #183 from justinstoller/maint/master/bump_facter_dash_and_auth (aee24412)


```
Merge pull request #183 from justinstoller/maint/master/bump_facter_dash_and_auth

(maint) bump dashboard, facter and add console_auth to version checks
```
* (Maint) Ensure agent certs are signed before proceeding (ca678d7f)


```
(Maint) Ensure agent certs are signed before proceeding

Previously, there was a race condition whereby "slow agents" may not
submit their CSR before `03_PE-SignCerts` tries to sign them. As a
result, we might not sign anything (since exit code 24 is acceptable for
situations where the master is also an agent and its cert is always
autosigned). We would then get a failure later on in `05_Agent_test`
when validating that the agents could connect to the master.

This commit changes the test to validate that all of the agents'
certificates have been issued before proceeding. Note we only do this
for hosts that are only agents, because the master's cert is autosigned.
```
* bump dashboard, facter and add console_auth to version checks (e586fce1)

* Merge pull request #182 from joshcooper/maint/master/stop-pe-agent-while-running (297d246f)


```
Merge pull request #182 from joshcooper/maint/master/stop-pe-agent-while-running

(Maint) Don't run puppet agent in the background during test run
```
* Merge pull request #181 from justinstoller/maint/master/skip_dhcp_on_windows (8b1ebc54)


```
Merge pull request #181 from justinstoller/maint/master/skip_dhcp_on_windows

(maint) dont renew dhcp on windows
```
* dont renew dhcp on windows (676e5887)

* (Maint) Don't run puppet agent in the background during test run (406ceb4e)


```
(Maint) Don't run puppet agent in the background during test run

Previously, the `setup/pe/01_PE-InstallPuppet.rb` and
`02_PE-InstallWindows.rb` tests would install the PE agent, and cause
the agent to run in the background every `runinterval` seconds.

Meanwhile, `setup/pe/05_Agent_test.rb` would try to run `puppet agent
--test` to verify that the agent could connect to the master, retrieve
its SSL certificate, etc.

This causes a second puppet process to start up and contend for the
puppet lock file.  Most of the time the first puppet process releases
the lock file and sleeps for 30 minutes, before the 05_Agent_test runs.
But sometimes the the first process still has the file locked, e.g.
because it's pluginsync'ing from the master. If so, 05_Agent_test fails
with `notice: Run of Puppet configuration client already in progress;
skipping`

Since none of the PE acceptance tests rely on having a puppet agent
running in the background, this commit stops all agents before
proceeding. The logic for how to stop the agent was copied from
`setup/pe_co/05_Agent_test.rb`.
```
* Merge pull request #180 from joshcooper/maint/master/fix-ntp (76540ff6)


```
Merge pull request #180 from joshcooper/maint/master/fix-ntp

(Maint) Fix intermittent ssl errors
```
* (Maint) Fix intermittent ssl errors (42a6eb62)


```
(Maint) Fix intermittent ssl errors

Previously, when running windows acceptance tests, the ntp step was
sometimes not updating the clock. As a result, the SSL sanity test would
fail due to mismatched clocks.

It turns out the `/update` flag does not necessarily update the client's
time. It just applies the configuration changes, e.g. ntp server IP
address, so that the Windows service can see them. An explicit /resync
is required to force an immediate ntp update. Also the resync occurs
sychronously, because we're not using the `/nowait` switch.
```
* Merge pull request #179 from joshcooper/maint/master/pe-windows-env (11a89104)


```
Merge pull request #179 from joshcooper/maint/master/pe-windows-env

(Maint): Undo prior changes puppet and facter bin dir
```
* (Maint): Undo prior changes puppet and facter bin dir (508649f2)


```
(Maint): Undo prior changes puppet and facter bin dir

We now pass the puppetbindir in the env command so that it is not
necessary to specify the fully qualified path to puppet.bat and
facter.bat
```
* Merge pull request #178 from justinstoller/maint/master/pe_windows (c9ee0e73)


```
Merge pull request #178 from justinstoller/maint/master/pe_windows

(maint) Allow PE Windows Agents to be installed through the harness
```
* Merge pull request #177 from pcarlisle/fix_silent (885567e3)


```
Merge pull request #177 from pcarlisle/fix_silent

Put back silent option in lib/command
```
* change the way puppet and facter are called to allow for '.bat' ext in (a30c1bbe)


```
change the way puppet and facter are called to allow for '.bat' ext in
PE Windows
```
* skip innappropriate checks for windows (42ea2fe5)

* wait for slow agents to sign in (windows) (b79de8b3)

* strip different line endings from version strings (57e5cff2)

* Put back silent option in lib/command (55136df2)


```
Put back silent option in lib/command

I misinterpreted the meaning of this option since it does not appear elsewhere
in the framework. It is used by some tests to intentionally ignore command
failures.
```
* add a dashboard role to the windows cfg for pe testing (ce3f4f99)

* (Maint) Create PE test to install Windows msi (b0fca167)


```
(Maint) Create PE test to install Windows msi

TBD
```
* Merge pull request #175 from pcarlisle/report_output (a01e8b8f)


```
Merge pull request #175 from pcarlisle/report_output

Include failed command output in exceptions
```
* Include failed command output in exceptions (6480074f)


```
Include failed command output in exceptions

If a command doesn't exit with an expected exit code, include the last ten
lines of its output in the exception formatted for display at the end of the
test run.

This also removes the useless "false is not true" errors.
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (1e92e158)

* (maint) Change host name for win2003 box (74df810a)


```
(maint) Change host name for win2003 box

Win2003 box is now: win2003r2-64-1
```
* Merge pull request #174 from pcarlisle/remove_silent (e89d747b)


```
Merge pull request #174 from pcarlisle/remove_silent

Remove unused silent switch
```
* Remove unused silent switch (4f8199ed)


```
Remove unused silent switch

Command#exec was not checking exit codes if the silent option was turned on.
It turned out that this option isn't recognized anyway, so I'm removing the
code.
```
* (maint) Mods for EC2 answer files (5e0b398d)


```
(maint) Mods for EC2 answer files

Now use port 443 as default for console
change quoting on console answers
```
* Merge pull request #172 from djm68/update_answers_ec2 (ca8414df)


```
Merge pull request #172 from djm68/update_answers_ec2

(maint) Update EC2 answers
```
* (maint) Update EC2 answers (4c531e75)


```
(maint) Update EC2 answers

EC2 answer generation has not been updated since PE2.0 -- many new
configuration options need to be updated.
```
* Merge pull request #171 from djm68/change_auth_user_to_auth_email (5c52b3bd)


```
Merge pull request #171 from djm68/change_auth_user_to_auth_email

(maint) modify answer file generation for auth_email
```
* (maint) modify answer file generation for auth_email (9d5f804f)


```
(maint) modify answer file generation for auth_email

change q_puppet_enterpriseconsole_auth_user  to
q_puppet_enterpriseconsole_auth_user_email
```
* Merge pull request #169 from justinstoller/maint/master/update_upgrade_answers (d9b8e8af)


```
Merge pull request #169 from justinstoller/maint/master/update_upgrade_answers

(maint) missed a question for console
```
* missed a question for console (333b6c1c)

* Merge pull request #168 from justinstoller/maint/master/update_upgrade_answers (f82cec0d)


```
Merge pull request #168 from justinstoller/maint/master/update_upgrade_answers

(maint) first pass at better upgrade answers
```
* first pass at better upgrade answers (0fabc51b)

* Merge pull request #167 from justinstoller/maint/master/no_more_module_tool (c34b5c1e)


```
Merge pull request #167 from justinstoller/maint/master/no_more_module_tool

(maint) remove version check for module tool
```
* we no longer have a separate binary for the module tool, removing version check for it (c2a45efe)

* Merge pull request #163 from joshcooper/maint/master/remove-windows-cfg (26a90a14)


```
Merge pull request #163 from joshcooper/maint/master/remove-windows-cfg

(Maint): Remove orphaned windows configuration
```
* Merge pull request #166 from justinstoller/maint/master/use_env_for_dmv (34c1c21c)


```
Merge pull request #166 from justinstoller/maint/master/use_env_for_dmv

(maint) use env vars for dmv options
```
* use env vars for dmv options (e99e1e22)

* Merge pull request #164 from justinstoller/maint/master/use_actual_email_for_answer (0bd564cc)


```
Merge pull request #164 from justinstoller/maint/master/use_actual_email_for_answer

(maint) use a valid email address instead of "console"
```
* use a valid email address instead of "console" (c5a24f0b)

* (Maint): Remove orphaned windows configuration (43dc2a70)


```
(Maint): Remove orphaned windows configuration

The windows configuration was renamed to have a `ci-` prefix, but the
old version was left behind and is no longer used. Deleting it so we
don't confuse ourselves.
```
* Merge pull request #162 from djm68/add_console_auth_db_name_answer (91740bfe)


```
Merge pull request #162 from djm68/add_console_auth_db_name_answer

(maint) adding answer for _auth_database_name
```
* (maint) adding answer for _auth_database_name (be66debc)


```
(maint) adding answer for _auth_database_name

q_puppet_enterpriseconsole_auth_database_name is a new entry for
the PE installer.
```
* Merge pull request #161 from justinstoller/bump_puppet_ver_for_25 (bc02c136)


```
Merge pull request #161 from justinstoller/bump_puppet_ver_for_25

(maint) bump puppet version to 2.7.12
```
* well *probably* be using 2.7.12 for the next PE (c63a3269)

* Merge pull request #160 from pvande/assertions/assert_output (a10de183)


```
Merge pull request #160 from pvande/assertions/assert_output

Factoring out custom assertions, and adding assert_output.
```
* Factoring out custom assertions, and adding assert_output. (5f4b4c39)

* Merge pull request #159 from mykhyggz/master (cf36e501)


```
Merge pull request #159 from mykhyggz/master

bump dashbord to 1.2.6
```
* (maint) bump Dashboard version to 1.2.6 from 1.2.4 (eab51805)

* Merge pull request #158 from mykhyggz/master (08bcf8f2)


```
Merge pull request #158 from mykhyggz/master

(maint) bump facter version to 1.6.6 from 1.6.4
```
* (maint) Bump facter verstion to 1.6.6 from 1.6.4 (ff7c62cd)

* Merge pull request #157 from justinstoller/dont_duplicate_db_users (ffaacc9d)


```
Merge pull request #157 from justinstoller/dont_duplicate_db_users

(maint) slight tweaks to new answers
```
* slight tweaks to new answers (18240dc2)

* Merge pull request #156 from djm68/add_dmv_answers (36080cb0)


```
Merge pull request #156 from djm68/add_dmv_answers

(maint) add new answers for DMV
```
* (maint) add new answers for DMV (3da76f51)


```
(maint) add new answers for DMV

DMV requires new answers for installation.  First pass at adding
this to answer file generation.
```
* Merge pull request #155 from justinstoller/wrong_line_endings (12ac0d1e)


```
Merge pull request #155 from justinstoller/wrong_line_endings

(maint) fix windows cfg
```
* I believe the line endings for the windows cfg were incorrect, they now load properly with YAML.load_file (0e9364ee)

* Merge pull request #154 from justinstoller/maint_same_win_naming (f215b0ff)


```
Merge pull request #154 from justinstoller/maint_same_win_naming

(maint) Same windows naming
```
* Previously the windows config for FOSS was 'windows2003-64a.cfg' every (d432e19e)


```
Previously the windows config for FOSS was 'windows2003-64a.cfg' every
other config is 'ci-...'. This gives the windows config the same naming
as other configs.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (848aaef3)

* (maint) add cfg file for win2003 acceptance testing (d15d3ca2)

* Merge pull request #153 from justinstoller/maint_fix_xml_output (7dd504e7)


```
Merge pull request #153 from justinstoller/maint_fix_xml_output

(maint) fix xml output
```
* s/skipped_test/skipped_tests/ (3dd6b685)

* s/errored_test/errored_tests/ (4750ef65)

* Merge pull request #150 from justinstoller/feature/master/12672-add_confine_method_to_dsl (74b05302)


```
Merge pull request #150 from justinstoller/feature/master/12672-add_confine_method_to_dsl

(#12672) add confine method to dsl
```
* Merge pull request #149 from justinstoller/bug/master/12613-pending_test_method (67d23871)


```
Merge pull request #149 from justinstoller/bug/master/12613-pending_test_method

(#12613) Add Pending Test Method
```
* Merge pull request #147 from justinstoller/feature/master/12673-add_result.output (3be93a6e)


```
Merge pull request #147 from justinstoller/feature/master/12673-add_result.output

(#12673) Add a Result#output member that combines stdout and stderr
```
* add `confine` method to dsl (ba4e19ce)

* show elapsed and average times on summary (3a7af04a)

* cache test status counts, removed unneeded error checking, factor out useful error checking (1c83b26b)

* add pending tests to summaries (52856520)


```
add pending tests to summaries

always use the same methods to retrieve state counts
```
* add pending_test to TestCase (bfc3a651)

* whitespace clean up and dragon notes (acb6ed4b)

* move puppet commands into separate file (bfe1c431)


```
move puppet commands into separate file

additional whitespace
```
* move methods for clarity (4cfc56aa)


```
move methods for clarity

with_standard_output_to_logs taks a block
```
* whitespace clean up (c6af544b)

* clean up syntax in host for Result#output (7f09e4b1)

* rough pass on adding Result#output (f7275248)

### <a name = "pe2.0.3">pe2.0.3 - 21 Feb, 2012 (492ff756)

* Merge pull request #151 from justinstoller/additional_release_version_check (492ff756)


```
Merge pull request #151 from justinstoller/additional_release_version_check

(maint) add a check for the pe-puppet-enterprise-release
```
* add a check for the pe-puppet-enterprise-release (eed56e5f)

* Merge pull request #148 from justinstoller/revert/master/quarantine-tempfiles (3b758e93)


```
Merge pull request #148 from justinstoller/revert/master/quarantine-tempfiles

(maint) revert temp dir changes
```
* revert temp dir changes, they depend on mkdirs which will not be implemented now (f069fbd4)

* Merge pull request #143 from justinstoller/really_nice_etc_hosts (f335b81a)


```
Merge pull request #143 from justinstoller/really_nice_etc_hosts

Previously the add master to /etc/hosts step would move all lines
```
* Merge pull request #139 from cprice-puppet/quarantine-tempfiles (02cb1996)


```
Merge pull request #139 from cprice-puppet/quarantine-tempfiles

Add "puppet-acceptance" to base tmp dir path
```
* Merge pull request #146 from justinstoller/bug/master/12665-dont_hard_code_paths (e4cf3647)


```
Merge pull request #146 from justinstoller/bug/master/12665-dont_hard_code_paths

(#12665) allow dist dir and version file to be overridden by env vars
```
* allow dist dir and version file to be overridden by env vars (f78adf6b)

* Merge pull request #145 from joshcooper/maint/master/vardir-not-getting-deleted (b478e4c1)


```
Merge pull request #145 from joshcooper/maint/master/vardir-not-getting-deleted

Maint: Ensure cached catalogs get deleted before starting agent/master test cases
```
* Maint: Use short, unquoted paths on Windows (3382f9c6)


```
Maint: Use short, unquoted paths on Windows

Previously, we quoted the puppetpath and puppetvardir host properties
on Windows because they often contain spaces, e.g. C:\Documents and
Settings. However, when these properties are used in bash commands, it
can result in expected consequences. For example,

   if [ -d "#{agent['puppetpath']}" ]

checks if a directory named \"C:\Documents and Settings\...\" exists,
where the quotes are interpreted as part of the path. This was causing
the `with_master_running_on` method to fail to delete Windows agents
vardir contents.

This commit changes the puppetpath and puppetvardir to always return
short versions of Windows paths with forward slashes, e.g.

    C:/DOCUME~1/ALLUSE~1/APPLIC~1/PuppetLabs/puppet/var/client_data

This eliminates the need for these paths to be quoted, and makes it
easier for bash commands to do what you expect in a cross-platform
way.
```
* Maint: Agent vardir sometimes not deleted between test cases (12f45cf2)


```
Maint: Agent vardir sometimes not deleted between test cases

The `with_master_running_on` method was recently updated to delete the
contents of each agents' vardir so that cached catalogs from previous
runs don't pollute subsequent runs, and cause the agent to return 0
exit code, when it shouldn't, for example.

However, commit `ba57ee5c` refactored this code and caused a
regression, as it was only deleting the agent's vardir if the
directory existed on the host driving the tests, not the system under
test. It also removed the `-f` flag.

This commit reinstates the `-f` flag and moves the `File.exists?`
check so that it is executed on the agent. This is necessary because
calling `for f in /foo/*` returns the literal string '/foo/*' if the
directory foo does not exist.
```
* Merge pull request #144 from justinstoller/more_robust_agents (aab8cb10)


```
Merge pull request #144 from justinstoller/more_robust_agents

Allow multiple exitcodes for initial puppet agent run
```
* Merge pull request #142 from justinstoller/pre_and_help (695b87e1)


```
Merge pull request #142 from justinstoller/pre_and_help

(#12565 & #12566) `--pre SCRIPT` and help usage
```
* Previously the add master to /etc/hosts step would move all lines (a252d761)


```
Previously the add master to /etc/hosts step would move all lines
except for those that contained the hostname of the master. If
someone had an /etc/hosts file like this:

127.0.0.1   localhost localhost.localdomain ubuntu-alpha
...snip...

It would filter out the localhost line and cause odd errors later
on. This changes the early step to filter out only the lines that
we add (#{ip} #{hostname})

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* Merge pull request #141 from cprice-puppet/default-args-for-with-master (0d86568b)


```
Merge pull request #141 from cprice-puppet/default-args-for-with-master

remove autosign default from with_master_running_on
```
* Allow multiple exitcodes for initial puppet agent run (10cb4650)


```
Allow multiple exitcodes for initial puppet agent run

Prior to this (a change I made to not effectively bounce
the agent service) only accepted an exit code of 0.

This worked for my testing because of conditions that caused
the agent to check in once before the test was actually ran.
The issue is when (and this is the typical case in CI) the test
is the first agent run to check in there will usually be
successful changes applied and puppet will exit with 2.

This adds 2 as an acceptable exit code.

Signed-off-by: Justin Stoller <justin@puppetlabs.com>
```
* add --pre option (79d9d399)

* print usage banner when no args are given (14479924)

* remove autosign default (56ef289b)


```
remove autosign default

This removes "--autosign" as a default from with_master_running_on.

Also reverts commit 2e7f69a6e75c76ab44cdd49794dbac4fa02d960c :
Revert "alter 03_ValidateSignCert to use new with_master defaults"
```
* Merge pull request #140 from justinstoller/tweak_sign_cert_for_foss (5c1e1719)


```
Merge pull request #140 from justinstoller/tweak_sign_cert_for_foss

(maint) alter 03_ValidateSignCert to use new with_master defaults
```
* alter 03_ValidateSignCert to use new with_master defaults (2e7f69a6)

* Add "puppet-acceptance" to base tmp dir path (13098599)


```
Add "puppet-acceptance" to base tmp dir path

This commit just changes the default "root" temp dir for acceptance
tests from "/tmp" to "/tmp/puppet-acceptance". The goal here is to
quarantine acceptance test temp files into one easily-identifiable
directory that can be cleaned up.

This would only affect tests that were calling the *::File.tmpdir
methods, and should have no effect on the success or failure of any
tests.
```
* Merge pull request #138 from cprice-puppet/default-args-for-with-master (8bb6c4da)


```
Merge pull request #138 from cprice-puppet/default-args-for-with-master

Confirmed on a PE install run, worked fine, merging
```
* This commit includes the following: (ba57ee5c)


```
This commit includes the following:

* New defaults for with_master_running_on:
   * will automatically add "--daemonize" if you haven't specified either
      that or --no-daemonize
   * will automatically add "--logdest=/log/puppetmaster.log" if you don't
      specify a logdest; sending acceptance framework log messages to syslog
      didn't seem very useful
   * will automatically add "--dns_alt_names" if you don't specify it
   * will automatically add "--autosign" if you don't specify it
   * no longer deletes log dir between executions of master
* Log a readable version of the backtrace if a test calls "flunk"
```
* Merge branch 'maint/master/tidy_up' (726475cc)


```
Merge branch 'maint/master/tidy_up'

* maint/master/tidy_up:
  (maint) Ignore /acceptance-tests in version control
  (maint) Add Jeff's local vm configuration "example"

Reviewed By: Pinocchio
```
* (maint) Ignore /acceptance-tests in version control (8ce98afc)


```
(maint) Ignore /acceptance-tests in version control

This patch does not touch the code.

Without this patch my prompt still always says dirty.  The documentation
[1] mentions to link the Puppet acceptance tests into this working
directory so we may as well ignore the link.  This patch makes my prompt
say "clean"

[1] https://sites.google.com/a/puppetlabs.com/main/home/technical/system-acceptance-testing
```
* (maint) Add Jeff's local vm configuration "example" (79f62e39)


```
(maint) Add Jeff's local vm configuration "example"

This patch does not touch the code.

Without this patch my prompt always says dirty.  This annoys me.  This
patch fixes the problem by adding the config I use straight into the
repository.  No harm no foul I say.
```
* Merge branch 'pe2.0.x' (47c7dc79)

* Merge pull request #137 from djm68/sane_cmd_line_defaults_happier_devs (e31811ac)


```
Merge pull request #137 from djm68/sane_cmd_line_defaults_happier_devs

(maint)  Set some sane cmd line defaults
```
* (maint)  Set some sane cmd line defaults (6627412b)


```
(maint)  Set some sane cmd line defaults

Watching some devs run the harness was a little painful: too
many args being passed to stop running step that are geared
to provisoning CI VMs.  Setting this opts to not run unless
specified.
```
* Merge pull request #136 from jeffmccune/maint/master/windows_setup_test_fixes (8b9ff34d)


```
Merge pull request #136 from jeffmccune/maint/master/windows_setup_test_fixes

(maint) Fix Test Setup failure on clean windows vm
```
* (maint) Fix Test Setup failure on clean windows vm (3270f64d)


```
(maint) Fix Test Setup failure on clean windows vm

Without this patch applied the acceptance test harness fails to setup
the win2003sat VM I've constructed because it cannot create the
/opt/puppet-git-repos directory.  It cannot do so because /opt does not
exist on a default cygwin installation.

This patch fixes the problem by using `mkdir -p` instead of `mkdir`
```
* Merge branch 'pe2.0.x' (240949b8)

* Merge branch 'pe2.0.x' of github.com:puppetlabs/puppet-acceptance into pe2.0.x (7586ee20)

* Merge pull request #130 from justinstoller/dont_kill_the_agents (621aec31)


```
Merge pull request #130 from justinstoller/dont_kill_the_agents

(maint) killing the agents could disguise issues with PE
```
* Merge pull request #134 from justinstoller/stop_repeating_version_info (7b006f12)


```
Merge pull request #134 from justinstoller/stop_repeating_version_info

(12456) Stop repeating version info
```
* use TestConfig.is_pe? instead of TestConfig.puppet_enterprise_version (3fd0519a)

* move the check for whether or not this is PE or FOSS to its own method (12f123be)


```
move the check for whether or not this is PE or FOSS to its own method

only load the version file once
```
* Merge pull request #126 from joshcooper/ticket/master/11944-separate-host-logic (f9cb52b2)


```
Merge pull request #126 from joshcooper/ticket/master/11944-separate-host-logic

(#11944) Separate native command logic from acceptance tests
```
* (#11944) Add default group (64e33301)


```
(#11944) Add default group

This commit just adds a default group for test cases performed on
Windows hosts, e.g. when setting a file's group.
```
* killing the agents could disguise issues with PE not being in a sane state after install (a6ca3580)

* (#11944) Add Unix and Windows exec commands (461df99e)


```
(#11944) Add Unix and Windows exec commands

This commit defines a set of methods for executing common commands on
Unix and Windows, e.g. touch, echo. This way all of logic for
performing exec commands is in one place, rather than scattered
throughout each exec test case.

On Windows, echo is a shell built-in, but there isn't a shell exec
provider, so it has to be wrapped within a cmd.exe shell. Touch is not
a built-in, but it can be faked using echo. Also, we have to use
backslashes when referencing the absolute path to cmd.exe and trying
to invoke it via ssh/cygwin. I'm not entirely sure why, but I can
reproduce the error when running a bash shell on the local Windows
box. The fix is to use backslashes for the absolute path.

This commit assumes the windows directory is in c:/windows, which
isn't ideal. It could be made more robust by querying the remote
system for its ENV['windir'] and ENV['COMSPEC'], or allowing them to
be configured, but that's more than I want to do right now.
```
* (#11944) Add Unix and Windows file commands (54b807f9)


```
(#11944) Add Unix and Windows file commands

This commit defines a set of native commands for validating file
resources on Unix and Windows. This way all of logic for performing
file commands is in one place, rather than scattered throughout each
file test case.

Note the Windows implementation uses cygpath to translate from a posix
path, e.g. /tmp, to a "mixed" windows path, e.g. C:/cygwin/tmp, so
that the latter can be passed to puppet and still be a valid fully
qualified path on Windows.
```
* (#11944) Print the time taken to run each test (65e63076)


```
(#11944) Print the time taken to run each test

This commit adds the time taken to run each test case.
```
* (#11944) Refactor default user logic (132d1f99)


```
(#11944) Refactor default user logic

Previously, the logic for determining the default user for a Unix host
was in the host class when making an ssh connection.

This commit just makes the default explicit for Unix hosts. The
Windows hosts already specified the default user (Administrator).
```
* (#11944) Create a CommandFactory module (359e3219)


```
(#11944) Create a CommandFactory module

The CommandFactory module is responsible for creating an instance of a
Command for a specific Host, executing it, and yielding the results to
the block, if one was supplied.
```
* (#11944) Refactor command execution logic (2b91045c)


```
(#11944) Refactor command execution logic

Previously, the `TestCase#on` method knew about the inner workings of
the Command class, e.g. that 0 was the default successful exit
code. However, that behavior would only occur if you called the `on`
method, but not if you called the `Command#exec` method directly.

This commit moves the logic into the Command class to ensure the logic
is always applied regardless of how the command is executed.
```
* (#11944) Add Unix user and group commands (3ae407c0)


```
(#11944) Add Unix user and group commands

This commit defines a set of native commands for validating user and
group resources on Unix. This way all of the logic for performing user
and group commands on Unix is in one place, rather than scattered
throughout each user and group test case.
```
* (#11944) Add Windows user and group commands (02b55b86)


```
(#11944) Add Windows user and group commands

This commit defines a set of native commands for validating user and
group resources on Windows. This way all of the logic for performing
user and group commands on Windows is in one place, rather than
scattered throughout each user and group test case.
```
* (#11944) Refactor Unix and Windows hosts into separate namespaces (d974a149)


```
(#11944) Refactor Unix and Windows hosts into separate namespaces

This commit just moves the Unix and Windows Host classes into their
own namespaces. This is being in done in preparation for future
commits.
```
* (#11944) Refactor Host classes out of the TestCase namespace (8901fb89)


```
(#11944) Refactor Host classes out of the TestCase namespace

Previously, the Host, WindowsHost, and UnixHost classes were contained
in the TestCase namespace. This commit moves them out to the top-level
as the lifetime of a Host spans multiple TestCases.
```
### <a name = "pe2.0.2">pe2.0.2 - 3 Feb, 2012 (e36f0d22)

* Merge branch 'pe2.0.x' (e36f0d22)

* Merge pull request #133 from justinstoller/ci_upgrade_12 (fef0b7fa)


```
Merge pull request #133 from justinstoller/ci_upgrade_12

(maint) add gunzip for solaris
```
* Merge branch 'pe2.0.x' of github.com:puppetlabs/puppet-acceptance into ci_upgrade_12 (6b6befac)

* gunzip for solaris (cb4dca12)

* Merge pull request #131 from justinstoller/ci_upgrade_12 (e418c076)


```
Merge pull request #131 from justinstoller/ci_upgrade_12

(maint) re-sign dashboard properly after upgrade
```
* update upgrader answers (fbff0efe)

* resign dashboard properly after upgrade (04cc9887)

* Merge branch 'pe2.0.x' (a2b32d29)

* Merge pull request #128 from justinstoller/sledgehammer (d5f13ebd)


```
Merge pull request #128 from justinstoller/sledgehammer

This comments out all but the UpgradePuppet step in the pe_upgrade dir
```
* This comments out all but the UpgradePuppet step in the pe_upgrade dir (2adbf86e)


```
This comments out all but the UpgradePuppet step in the pe_upgrade dir

This is totally a sledge hammer kind of fix, but the issue is:
CI will be run with snapshots that are ensured to have known good
setups, skipping based on the --vmrun option would be the best for CI

Locally many will be able to use this as is if they also have known
good snapshots.

I also try to automate as much as I can locally testing PE pre-2.0.
The changes that I'd like to introduce to automate those builds are
not trivial and keeping these files is helpful for my work in that area.

NOTE: This works for me locally with a similar (but not exact) workflow
to CI. It *should* work in CI.
```
### <a name = "pe2.0.1">pe2.0.1 - 31 Jan, 2012 (3a118201)

* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (3a118201)

* (maint) remove version checking for --pe-version option (ba53fc10)


```
(maint) remove version checking for --pe-version option

Checking for a specific PE version serves no real purpose; if
an invalid version is passed the hassness will halt with an
apporiate error indicating the vesrion needed is not found.
```
* Merge pull request #125 from pcarlisle/show-error (acffff6a)


```
Merge pull request #125 from pcarlisle/show-error

On error print the exception message in addition to the backtrace
```
* On error print the exception message in addition to the backtrace (59dcd703)

* Merge pull request #124 from daniel-pittman/avoid-eternally-growing-puppet.conf (571916cb)


```
Merge pull request #124 from daniel-pittman/avoid-eternally-growing-puppet.conf

Empty puppet.conf before adding the server definition.
```
* Merge pull request #123 from cprice-puppet/allow_extra_env_vars_to_puppet_commands (2c01ecef)


```
Merge pull request #123 from cprice-puppet/allow_extra_env_vars_to_puppet_commands

allow extra environment vars for puppet commands
```
* Merge remote branch 'origin/pe2.0.x' (f813bd39)

* (maint)  Update all configs for cloudpro (df7916ab)


```
(maint)  Update all configs for cloudpro

Adding cloud provisioner to all test configs.
```
* (maint) adding cloudpro role to configs (8ffe51c7)


```
(maint) adding cloudpro role to configs

Adding cloudpro role to install only configs -- test install of
cloudpro with each install only test.
```
* Empty puppet.conf before adding the server definition. (ed6dab8b)


```
Empty puppet.conf before adding the server definition.

Previously `/etc/puppet/puppet.conf` would grow without bounds, because this
setup script appended to the configuration but never removed anything.  Now,
instead, it ensures that only the expected content is in place.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* allow extra environment vars for puppet commands (6c02f8c3)


```
allow extra environment vars for puppet commands

When working on some tickets relating to setting system locales (Facter #12012, Puppet #11860), I came across a situation where I needed to be able to set some environment variables before running puppet commands in my acceptance tests.  This changeset adds the ability to pass in an optional ":environment" hash when calling "apply_manifest_on"; the key/value pairs in this hash will be set as environment variables for the duration of the execution of the "puppet apply" operation.

This implementation isn't ideal, but the implementation details are not very visible in the actual acceptance test syntax.  We might want to re-work the implementation later, but for now this was the only reasonably easy way to pull it off.

Also--this logic could very easily be extended to work for other puppet commands besides "apply", but hasn't at this point in time.
```
* Merge pull request #122 from cprice-puppet/allow-no-certs-for-single-node (31e61a1c)


```
Merge pull request #122 from cprice-puppet/allow-no-certs-for-single-node

Allow ValidateSignCert to pass in a single-node setup
```
* Merge pull request #121 from daniel-pittman/handle-machine-that-is-master-and-agent (d96a8d61)


```
Merge pull request #121 from daniel-pittman/handle-machine-that-is-master-and-agent

Handle a machine that is both master *and* agent in git tests.
```
* Allow ValidateSignCert to pass in a single-node setup (c94cce99)


```
Allow ValidateSignCert to pass in a single-node setup

In the case where you are running acceptance tests against a single node (which is serving as both master and agent), the puppet cert --sign-all needs to accept an exit code of 24 (which means that there were no certs to sign).
```
* Handle a machine that is both master *and* agent in git tests. (54985a34)


```
Handle a machine that is both master *and* agent in git tests.

The master signs it's own agent certificate implicitly, which was breaking a
test that validated that *all* agents didn't have a certificate.

This skips over the master, although not the validation that the certificate
works, which keeps things running as expected.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Merge pull request #119 from daniel-pittman/faster-rerun-through-checkout-reuse (99238dd0)


```
Merge pull request #119 from daniel-pittman/faster-rerun-through-checkout-reuse

Better handling of both new and old git checkouts.
```
* Merge pull request #120 from joshcooper/ticket/master/11743-delete-vardir-contents (3ede70ac)


```
Merge pull request #120 from joshcooper/ticket/master/11743-delete-vardir-contents

(#11743) Delete contents of agent var directory in agent/master tests
```
* (#11743) Delete contents of agent var directory in agent/master tests (2d37c6f0)


```
(#11743) Delete contents of agent var directory in agent/master tests

Previously, the
`helpful_error_message_when_hostname_not_match_server_certificate`
test would correctly report that the server's hostname didn't match
its certificate, however, the test would attempt to use a cached
catalog. If one was present, for example, the 03_ValidateSignCert step
causes the agent to retrieve an empty catalog, then the agent would
apply the catalog and return exit code 0, causing the test to fail.

This commit deletes the contents of the agents' vardir, but not the
vardir itself. This change will only affect tests that use the
`with_master_running_on` method which does not include PE.
```
* Better handling of both new and old git checkouts. (3a7284a9)


```
Better handling of both new and old git checkouts.

This has flapped some, because we try to do too many clever things with remote
execution.  Now, it should work robustly in all cases.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* (maint) --force not supported on old git verions (e1bb15fc)


```
(maint) --force not supported on old git verions

Older versions of git (like on cent5.5) do not support --force
but -f instead.
```
* Merge pull request #118 from djm68/fix_pathing_problem_git_TestSetup (b7faeee7)


```
Merge pull request #118 from djm68/fix_pathing_problem_git_TestSetup

(maint) Create source path
```
* (maint) Create source path (e6e4c07f)


```
(maint) Create source path

In same cases the source path is not created, breaking the git
checkout.  Verify the path first, create if needed.
```
* Merge pull request #117 from djm68/fix_git_TestSetup_install (6073db28)


```
Merge pull request #117 from djm68/fix_git_TestSetup_install

(maint) Small fix to dpittmans installer update
```
* (maint) Small fix to dpittmans installer update (c2869752)


```
(maint) Small fix to dpittmans installer update

If existing repo path is not found, factor was cloned into
/root vs.  /opt/puppet-git-repos; rest of installer expects to
find  /opt/puppet-git-repos/facter.
```
* Merge pull request #116 from daniel-pittman/faster-rerun-through-checkout-reuse (798da835)


```
Merge pull request #116 from daniel-pittman/faster-rerun-through-checkout-reuse

Faster rerun through checkout reuse
```
* Checking in one SSH operation rather than one per git command (990a0823)


```
Checking in one SSH operation rather than one per git command

When we started reusing the repository we needed to do a lot of remote
operations.  While the cost of starting a new process is fairly low, it is at
least a couple of RTTs, which will slow down cloud based testing.

This just rewrites the step to collect the operations and glue them together
into a single operation, cutting that overhead dramatically.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Clean and forcibly change branch during git setup. (e939f80b)


```
Clean and forcibly change branch during git setup.

Previously we deleted the entire git repo, which would ensure that we had a
clean, pristine, untouched repository for the next test.

Once we started to reuse the existing checkout we can't assume that - if
someone was to fiddle a file in there, it could break everything.

So, we forcibly clean and checkout now, to restore the repository and checkout
to a pristine state before we proceed through the testing.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Revert incorrect change to acceptable exit codes for agent. (58661065)


```
Revert incorrect change to acceptable exit codes for agent.

Part of another, incomplete change to the harness slipped into my git checkout
improvements; the exit codes for the agent during validation of the cert
should not have been changed.  (This made the test useless, but not actually
break)

This reverts that targeted bit of the change.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Merge pull request #113 from daniel-pittman/faster-rerun-through-checkout-reuse (a9388e28)


```
Merge pull request #113 from daniel-pittman/faster-rerun-through-checkout-reuse

Support reuse of an existing git repository checkout.
```
* Merge pull request #115 from daniel-pittman/support-pty-request-on-ssh-channel (233eca85)


```
Merge pull request #115 from daniel-pittman/support-pty-request-on-ssh-channel

Support PTY allocation on SSH channel.
```
* Merge pull request #114 from daniel-pittman/nicer-handling-of-etc-hosts (92ba0922)


```
Merge pull request #114 from daniel-pittman/nicer-handling-of-etc-hosts

Nicer handling of /etc/hosts.
```
* Support PTY allocation on SSH channel. (4c38c4fd)


```
Support PTY allocation on SSH channel.

Previously all remote commands were run without a PTY allocated.  This almost
always delivers the same results as running them with a PTY - but not in every
case.

This adds the ability to request a PTY for a specific test, which will cause
one to be allocated - or a hard failure to occur.

This is not made the default for two reasons:

1. It changes behaviour around which scripts are run on exec.
2. It potentially changes logging behaviour.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Nicer handling of /etc/hosts. (32b63643)


```
Nicer handling of /etc/hosts.

Previously the updates to /etc/hosts would lead to trouble when the machine
wasn't reverted to a snapshot between each test, or if there was already a
hosts entry for that machine.

Now, instead, we carefully clean out the file to get the content we want, and
nothing but, in place for the test suite run.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Support reuse of an existing git repository checkout. (1bae816e)


```
Support reuse of an existing git repository checkout.

Previously the suite would delete the entire git source checkouts, then fetch
them from scratch.  This would ensure that the content was clean, but wasn't
actually terribly efficient since almost all content was identical each time.

Now, we clone if the repository is missing, but otherwise update the `origin`
remote to whatever we are targeted at, then fetch that.  This has the same net
effect but avoids fetching 36+MB every time the suite runs.

Signed-off-by: Daniel Pittman <daniel@rimspace.net>
```
* Merge pull request #112 from djm68/update_pe_setup_steps_new_host_hash (f1cdf8ee)


```
Merge pull request #112 from djm68/update_pe_setup_steps_new_host_hash

(maint) Update PE setup steps to support host hash
```
* (maint) Update PE setup steps to support host hash (aefcb053)


```
(maint) Update PE setup steps to support host hash

Formally, host config data was stored in the config hash; with
the addition of windows host support, we need to support
per host config data (ie paths).  This change requies updating
tests that were using congig to use host hash instead.
```
* Merge pull request #111 from joshcooper/ticket/master/11767-fix-deprecated-certdnsnames (f525fb48)


```
Merge pull request #111 from joshcooper/ticket/master/11767-fix-deprecated-certdnsnames

(#11767) Use newer --dns_alt_names option
```
* (#11767) Use newer --dns_alt_names option (4fdfbc2d)


```
(#11767) Use newer --dns_alt_names option

Previously, the git setup steps were using the old deprecated
--certdnsnames option when generating the master's csr. It was also
using a colon-delimited list instead of a comma-separated list. As a
result, the puppetmasters certificate generated during
03_ValidateSignCert.rb contained bogus X509 Subject Alt Names:

  X509v3 Subject Alternative Name:
    DNS:centos-55-64-1.puppetlabs.lan,
    DNS:puppet:centos-55-64-1:centos-55-64-1

This was not noticed earlier, because the agent never retrieved its
ssl certificate in the setup steps, which is something I recently
changed so that we'd validate that the agent can connect via SSL to
the master in the setup steps, rather than later during the acceptance
tests.

Previously, when running the first acceptance tests from the puppet
repo, the test would delete all of the hosts ssl directories, and
regenerate the certs, but this time using the correct --dns_alt_names
option.

This commit just updates the setup steps to also use the
--dns_alt_names option with a comma delimited list of names to include
in the puppet master's certificate.
```
* Merge pull request #110 from joshcooper/ticket/master/11767-windows-acceptance-tests (071e945c)


```
Merge pull request #110 from joshcooper/ticket/master/11767-windows-acceptance-tests

(#11767) Support Windows agents in acceptance test framework
```
* (#11767) Update README for Windows (ed60071e)


```
(#11767) Update README for Windows

This commit updates the README to describe prequisites for running the
acceptance tests on Windows agents.
```
* (#11767) Always delete ssl directories with_master_running_on (089334af)


```
(#11767) Always delete ssl directories with_master_running_on

Previously, each test case that used `with_master_running_on` had to
remember to delete the ssl directory from each host.

This commit moves that knowledge into `with_master_running_on` and
removes it from the individual test cases.
```
* (#11767) Add the ability to lazily evaluate a command (8cf8fc32)


```
(#11767) Add the ability to lazily evaluate a command

Previously, the command_string for a Command was evaluated at command
creation time. As a result, it wasn't possible to specify a command
like:

    on hosts, 'rm -rf #{host["puppetpath"]/ssl}'

and have the command be evaluated in the context of each host.

This commit adds a generic HostCommand that lazily evaluates its
command string, in the `Kernel.eval` sense, with a binding containing
the `host` variable. So now it is possible to do:

    on hosts, host_command('rm -rf #{host["puppetpath"]/ssl')

which will remove the ssl directory from each host using each hosts'
`puppetpath` configuration. Note that we're using single quotes to
avoid string interpolation.
```
* Merge pull request #109 from djm68/update_agent_cfgs (9813e848)


```
Merge pull request #109 from djm68/update_agent_cfgs

(maint) Modifying configs to use our dedicated master
```
* (maint) Modifying configs to use our dedicated master (3f868614)


```
(maint) Modifying configs to use our dedicated master

Need an isolated Master node for our agent only tests.
```
* (#11767) Default user to Administrator on Windows (467789e5)


```
(#11767) Default user to Administrator on Windows

Previously, the acceptance tests would ssh as `root` to the remote host.
This commit changes the default user to be `Administrator` on Windows so
that each Jenkins node does not need a 'root' user added to it.
```
* (#11767) Don't assume host['puppetpath'] is /etc/puppet (c34c2fb7)


```
(#11767) Don't assume host['puppetpath'] is /etc/puppet

Previously, the acceptance tests failed on Windows because puppet.conf
does not live in /etc/puppet on Windows.

This commit changes the default value of `puppetpath` for Windows
hosts relative to the CommonAppData folder. Sadly, the location of
this folder is different between 2003 and 2008, and the folder usually
contains spaces, e.g. C:\Documents and Settings\All Users\Application
Data.

This commit uses the Cygwin utility `cygpath` to lookup the
CommonAppData folder, whose id is 35 (0x23). See the following for
known-folder ids:

  http://source.winehq.org/source/include/shlobj.h

It also updates the acceptance tests to use the `puppetpath` value when
appending the `server` property to the `agent` section of the hosts'
`puppet.conf`. And since the CommonAppData folder contain spaces, the
value of `puppetpath` is quoted on Windows.
```
* Merge pull request #108 from justinstoller/uninstaller_support (9778f654)


```
Merge pull request #108 from justinstoller/uninstaller_support

(maint) better solaris output
```
* better solaris output (23cafce6)


```
better solaris output

fix hardcoded paths
```
* (#11767) Make RemoteExec commands work on Windows (9e6c7103)


```
(#11767) Make RemoteExec commands work on Windows

Previously, the acceptance tests could not launch puppet and facter via
SSH and Cygwin on the Windows side, due to Cygwin's bash shell
attempting to invoke ruby.exe on `C:\Ruby187\bin\puppet` and failing,
because that file contains Windows-style paths that confuse bash.

This commit simply wraps the puppet and facter commands within a
`cmd.exe` shell to escape from the bash shell (though the environment
is inherited).
```
* (#11767) Don't create a new SSH connection for each TestCase (f5da078f)


```
(#11767) Don't create a new SSH connection for each TestCase

Previously, a new Host instance was being created for each combination
of TestSuite, TestCase, and Host. As a result, multiple SSH
connections, including SSH authentication, were being performed
unnecessarily. This was actually a regression introduced in
b62f8056f0b5499ad9341487c1fca6f328c0830b.

Given a sufficiently large number of TestCases, the test driver and/or
system under test could run out of file descriptors.

This commit moves the creation of hosts to the top-level, so that the
same SSH connection can be reused across multiple TestSuites and
TestCases. In other words, the acceptance tests will make at most one
SSH connection per host.

This commit also adds a method for closing the SSH connection (if one
was created) and explicitly closes the connection when the tests are
done.
```
* (#11767) Move defaults into type-specific hosts (40689070)


```
(#11767) Move defaults into type-specific hosts

Previously, the acceptance tests were adding POSIX default paths to
the PATH environment variable passed to Windows hosts, e.g. /usr/bin,
which happens to correspond to the location of the Cygwin utilities
that we don't want the tests to use on Windows.

This commit creates host subclasses that contain the default paths that
are applicable for that platform. It also adds a `Host.create` factory
method that knows how to create the appropriate type of `Host` instance
based on the platform specified in the configuration file.

If we need to support PE-specific install locations on Windows, then it
will be easy to change (in one place).
```
* Merge pull request #107 from djm68/more_robust_early_setup (6939ec18)


```
Merge pull request #107 from djm68/more_robust_early_setup

(maint) Make common setup steps for robust
```
* (maint) Make common setup steps for robust (9f95ad56)


```
(maint) Make common setup steps for robust

Some setup steps either did not log when skipping execution, while
some less critical steps, like key syncing, could fail and cause the
tests to halt -- failures during setup are considered fatal and test
execution will halt.
```
* (maint) Trim el4 test config (42497ec9)


```
(maint) Trim el4 test config

Trimming sol10 for the el4 config.  Tried pushing the sol test
into the same run as el4s (all are agent only) but the additonal
load is a bit much for the VM server.  Will run Sol seperately.
```
* (#11767) Skip creating puppet user and group on Windows (9bdff8a2)


```
(#11767) Skip creating puppet user and group on Windows

The `getent`, `useradd`, and `groupadd` commands do not exist on
Windows (nor Cygwin), so we skip creating the puppet user and group on
Windows.

Ideally, we should only create the puppet user and group in a `master`
role (when we need to switch uid). However, due to bug #9862 the puppet
group is required on Unix, even for `puppet agent` and `puppet apply`.

Since #9862 doesn't apply on Windows, we can safely skip creating the
puppet user and group on Windows.
```
* (maint) Add addition el4 configs (70c8ece3)


```
(maint) Add addition el4 configs

More build optimization: splitting EL4 + solaris into :q
```
* (#11767) Sync ntp on Windows (ed95ce31)


```
(#11767) Sync ntp on Windows

By default, the acceptance tests perform an ntp sync. On Windows 2003
and up, this can be done using the time service `w32time`, not to be
confused with the command line utility `w32tm.exe` that interacts with
the service.

If the w32time service is already running, then `net start` will
return exit code 2.
```
* (#11892) Add all agents config for install tests (2598a68d)


```
(#11892) Add all agents config for install tests

Trying to parallelize tests -- running all agents at once
with a single master should prove faster, but with more
system load.
```
* Merge pull request #105 from justinstoller/uninstaller_support (6554bf91)


```
Merge pull request #105 from justinstoller/uninstaller_support

(maint) fix solaris service error
```
* Merge pull request #106 from justinstoller/retry_ssh (dd6070e1)


```
Merge pull request #106 from justinstoller/retry_ssh

(maint) attempt to catch Unreachable Hosts and retry
```
* dont run -d on installs without a db (c96c5b2b)

* attempt to catch Unreachable Hosts and retry (b09fbf9b)

* fix solaris service error (1ca44051)

* Merge pull request #104 from justinstoller/uninstaller_support (ae55e4ce)


```
Merge pull request #104 from justinstoller/uninstaller_support

(maint & 11812) Uninstaller support
```
* Merge pull request #103 from djm68/increase_netssh_timeout (416ae4ef)


```
Merge pull request #103 from djm68/increase_netssh_timeout

(maint) Increase net::ssh timeout
```
* (maint) Increase net::ssh timeout (dd0b7b33)


```
(maint) Increase net::ssh timeout

Make the harness more robust, especially just post VM reversion;
harness was timing out trying to reach VMs that were not done
reverting.
```
* Merge pull request #102 from djm68/ntpdate_fault_tolerant (cf17c76d)


```
Merge pull request #102 from djm68/ntpdate_fault_tolerant

(manint) toughen ntpdate step
```
* (manint) toughen ntpdate step (7ca6c176)


```
(manint) toughen ntpdate step

Force NTPdate to run until it gets a responce  If we bail out
after one fail ntpdate attempt, we falsely fail a PE build.
```
* skip dashboard-workers in /etc/rc* (77aae2a6)


```
skip dashboard-workers in /etc/rc*

fix typo in rpm syntax
```
* Merge pull request #101 from djm68/update_agent_only_configs_dedicated_master (9c2b6c17)


```
Merge pull request #101 from djm68/update_agent_only_configs_dedicated_master

(maint) Modifiy agent only config for dedicated master
```
* (maint) Modifiy agent only config for dedicated master (f1622a61)


```
(maint) Modifiy agent only config for dedicated master

Have a new dedicated master to use for agent only platforms.
Updating configs for new host.
```
* tweak acceptable exit codes (d06de7b2)

* fix stopping of puppet agent in noop test -- previously the local variable was named the same as a test harness helper method (706d8f65)

* ticket 11812 remove cronjobs (45298251)

* better sh support, remove ! and use test instead of [ (d855c033)

* Merge pull request #100 from justinstoller/bump_dash_ver (4ccb99a3)


```
Merge pull request #100 from justinstoller/bump_dash_ver

(maint) fix typo yml key name
```
* fix typo yml key name (4b756a85)

* Merge pull request #99 from djm68/ticket_11622_print_test_before_execution (2f2fcf07)


```
Merge pull request #99 from djm68/ticket_11622_print_test_before_execution

(#11622)  Log test file names before evaluation
```
* (#11622)  Log test file names before evaluation (91a3864d)


```
(#11622)  Log test file names before evaluation

Currently, the test harness evals a test case (test file), then
logs the results.  If the tests hangs, you will not tests was
being run.  This patch annouces the test file before it even evals
the code.  This will greatly ease debugging.
```
* Merge pull request #95 from justinstoller/uninstaller_support (00d70d0b)


```
Merge pull request #95 from justinstoller/uninstaller_support

(maint) the uninstaller does not need to check versions...
```
* Merge pull request #96 from pcarlisle/ticket/11764-handle-blocks (a9304da7)


```
Merge pull request #96 from pcarlisle/ticket/11764-handle-blocks

(#11764) Handle blocks in all test case methods of the form run_X_on
```
* Merge pull request #98 from justinstoller/bump_dash_ver (5e241f10)


```
Merge pull request #98 from justinstoller/bump_dash_ver

(#11638) add test for dashboard version -- 1.2.4
```
* add test for dashboard version -- 1.2.4 (54aa7a7c)

* Merge pull request #97 from justinstoller/bump_puppet_ver (2a6185b0)


```
Merge pull request #97 from justinstoller/bump_puppet_ver

(#11636) bump puppet version from 2.7.6 to 2.7.9
```
* bump puppet version from 2.7.6 to 2.7.9 (8e8c2391)

* the uninstaller does not need to check versions of packages before uninstalling (7c2a332e)

* (#11764) Handle blocks in all test case methods of the form run_X_on (b8cda1db)


```
(#11764) Handle blocks in all test case methods of the form run_X_on

Before this, some of these methods took blocks and some didn't. Since ruby
doesn't complain when you pass a block to a method that doesn't handle it
there was no feedback if you weren't using these methods correctly.
```
* Merge pull request #94 from justinstoller/bump_rack_ver (60221235)


```
Merge pull request #94 from justinstoller/bump_rack_ver

(#11735) bump rack version to 1.1.3
```
* bump rack version to 1.1.3 (dde6e127)

* Merge pull request #93 from justinstoller/uninstaller_support (dc669280)


```
Merge pull request #93 from justinstoller/uninstaller_support

(maint) blank strings are not false
```
* blank strings are not false (04305dc7)

* Merge pull request #92 from justinstoller/bump_facter_ver (edf4be78)


```
Merge pull request #92 from justinstoller/bump_facter_ver

(maint) bump facter version to 1.6.4
```
* Merge pull request #91 from justinstoller/uninstaller_support (0c141b8e)


```
Merge pull request #91 from justinstoller/uninstaller_support

(#5338) test uninstaller
```
* bump facter version to 1.6.4 (a6089238)

* add test for `-h` option (455463eb)

* break standard and full uninstall tests into separate suites (56c27ed9)

* update options and systest for standard or full uninstalls (cbc6723c)

* merge `-d`, `-p`, and `-a` checks (c7cc49e2)

* comment out purge and db for sanity check (de58d22e)

* update solaris pkging check (d532f2db)

* Merge pull request #90 from justinstoller/package_version_checks (ac9ed8e1)


```
Merge pull request #90 from justinstoller/package_version_checks

(#8659 & #7541) add checks for ruby-augeas, activerecord, and activesupport
```
* add database check (4336e258)


```
add database check

add purge check
```
* add comments for clarity (1227e5fe)


```
add comments for clarity

add checks for pids and lockfiles

add solaris pkging check
```
* add checks for ruby-augeas, activerecord, and activesupport (5430ff9c)

* add package check for deb, el, and hopefully sles (fef78ef5)


```
add package check for deb, el, and hopefully sles

add check that services are not enabled at boot
```
* Merge pull request #88 from jeffmccune/feature/master/11618_setup_ssh_access (a9993939)


```
Merge pull request #88 from jeffmccune/feature/master/11618_setup_ssh_access

Feature/master/11618 setup ssh access
```
* Merge pull request #89 from djm68/allow_alternate_PE_versions_installs (8185cb1d)


```
Merge pull request #89 from djm68/allow_alternate_PE_versions_installs

(maint) Add support to install alt versions of PE
```
* (maint) Add support to install alt versions of PE (a2d557b1)


```
(maint) Add support to install alt versions of PE

Need the ability to install more than just the LASTEST tarball
of PE; passing --pe-version 2.0.0 will install PE 2.0.0 from
/opt/enterptise/dists/pe2.0.0
If --pe-version is ommited, version is derived from LATEST and
/opt/enterprise/dist is used for the path.
```
* (maint) Fix program name in help output (2a3e2a02)


```
(maint) Fix program name in help output

Without this patch the name "harness.rb" is hard coded in the output of
--help.  This is incorrect, the program has been renamed to systest.rb.

This patch fixes the problem by using the process name from the process
table to determine the name of the program.

The help now looks like:

    % ./systest.rb --help
    Usage: systest.rb [options...]

Reviewed-by: Dominic Maraglia
```
* (#11621) Add --dhcp-renew option to enable lease renewal (d75a22df)


```
(#11621) Add --dhcp-renew option to enable lease renewal

Without this patch the DHCP lease renewal step of the early setup phase
is always executed.

This is a problem on my CentOS 6 VMware Fusion VM because the interface
is brought down, disconnecting the SUT from the network before the ifup
command can be issued.  This leaves the target system offline and
subsequent steps timeout.

This patch works around the problem by providing and documenting the
--dhcp-renew option to disable renewals.

Reviewed-by: Dominic Maraglia
```
* (#11618) Add root SSH key synchronization setup step (fbac0bc5)


```
(#11618) Add root SSH key synchronization setup step

Without this patch the target systems under test may have out of date
authorized key files since they're usually VM snapshots.  This is
problem if there is a test problem requiring investigating by technical
staff.

This patch fixes the problem by synchronizing the
~root/.ssh/authorized_keys file in the setup early phase.  The behavior
happens by default on all systems.  We assume it will work and intended
to come back and filter out target nodes that are known not to work.

A command line option, --no-root-keys is provided to disable this change
in behavior.

Reviewed-by: Dominic Maraglia
```
* basic uninstaller test (e2108e0f)

* fix typo (980623cc)

* plumbing for allowing Uninstaller testing (c5a6a898)

* Merge pull request #87 from djm68/ticket_11107_alternate_umask (8ff2eee4)


```
Merge pull request #87 from djm68/ticket_11107_alternate_umask

(#11107) Test alternate usmask when installing
```
* (#11107) Test alternate usmask when installing (28eb6e69)


```
(#11107) Test alternate usmask when installing

When selecting --install-only the test harness will switch
umask to 0027 during the install phase.
```
* (#11310) Add master to hosts files -- IPV4 (9cf41682)


```
(#11310) Add master to hosts files -- IPV4

In some cases the ip command will return IPV4 and IPV6; only want
the IPV4 entries.  Add "head -1" to only return IPV4.
```
* (maint) cruft clean-up (13178d80)


```
(maint) cruft clean-up

cleaning up a bunch of old cfg files no longer used.
```
* Merge pull request #85 from djm68/update_docs (a10760f7)


```
Merge pull request #85 from djm68/update_docs

(maint) Update README and config examples
```
* (maint) Update README and config examples (b5e1834b)


```
(maint) Update README and config examples

Harness has grown in functionality and docs need updating to
reflect the changes.
```
* Merge pull request #84 from mykhyggz/nodhclient_solaris (c382fce9)


```
Merge pull request #84 from mykhyggz/nodhclient_solaris

solaris machine isn't using dhcp, fixing test
```
* solaris machine isn't using dhcp, fixing test (7b793182)


```
solaris machine isn't using dhcp, fixing test

Test renews dhcp lease, but solaris vm isn't using dhcp anyway
```
* Merge pull request #83 from mykhyggz/typo (cd2d07ef)


```
Merge pull request #83 from mykhyggz/typo

Typo with missing the second 'c' in dhcpcd
```
* Typo with missing the second 'c' in dhcpcd (101aca61)


```
Typo with missing the second 'c' in dhcpcd

One character change to command, adding second 'c' in 'dhcpcd'
```
* Merge pull request #82 from mykhyggz/dhcp_renew (beede68f)


```
Merge pull request #82 from mykhyggz/dhcp_renew

effect a dhcp lease renewal after ntpdate is run
```
* effect a dhcp lease renewal after ntpdate is run (fb2ed0de)


```
effect a dhcp lease renewal after ntpdate is run

Some VMs, after reverting to snapshot, are renewing their dhcp lease after our tests are running, causing apparent network errors. This test will renew the lease early so it's good for a day (or whatever is configured at the dhcp server), rather than just a few seconds.
```
### <a name = "pe2.0">pe2.0 - 11 Nov, 2011 (4d7b65b6)

* Merge pull request #81 from djm68/add_cert_sign_master_dashboard (4d7b65b6)


```
Merge pull request #81 from djm68/add_cert_sign_master_dashboard

(maint)  Add modified cert signing step to install
```
* (maint)  Add modified cert signing step to install (1ee7d5db)


```
(maint)  Add modified cert signing step to install

Only need to sign certs when master/dash are on the same node;
when master and dashboard are seprate, autosign will be used.
```
* Merge pull request #80 from mykhyggz/deprecated_certsign (97d32745)


```
Merge pull request #80 from mykhyggz/deprecated_certsign

Move sign dashboard certs test out of the way
```
* Move sign dashboard certs test out of the way (255f3de6)


```
Move sign dashboard certs test out of the way

Certs are already signed, this just generates a '400' rake abort error now. Moving to setup/deprecated/
```
* Merge pull request #78 from justinstoller/remove_mco_q_in_upgrader (fb5dd065)


```
Merge pull request #78 from justinstoller/remove_mco_q_in_upgrader

(maint) updated upgrader answers for removing mco
```
* Merge pull request #79 from mykhyggz/signcert_deprecated (07030a84)


```
Merge pull request #79 from mykhyggz/signcert_deprecated

Move pe_sign_certs to new folder 'deprecated'
```
* Move pe_sign_certs to new folder 'deprecated' (d124d441)


```
Move pe_sign_certs to new folder 'deprecated'

Certs are autosigned earlier in the install process. This test is no longer valid, so moving to a new folder 'deprecated'
```
* (maint) minor yaml error in cfg file (717e5583)


```
(maint) minor yaml error in cfg file

Cfg file was missing indentations
```
* updated upgrader answers for removing mco (edf883c3)

* (#10437) Add config for OEL 4 (d5515563)


```
(#10437) Add config for OEL 4

Adding CI cfg for Oracle Linux 4
```
* (maint) small tweak to answer file generation (5cf7f3d0)


```
(maint) small tweak to answer file generation

q_puppet_enterpriseconsole_master_hostname might not be set in all
cases, fixed this for master/dashboard.
```
* (maint)  Adding consoleport option to CI configs (d684dd85)


```
(maint)  Adding consoleport option to CI configs

Set configs to use port 443 for dashboard connections.
```
* (maint) Minor tweak to cfg file (b802bda2)

* Merge pull request #77 from justinstoller/saved_tmp (9fbcf0eb)


```
Merge pull request #77 from justinstoller/saved_tmp

(maint) Saved tmp
```
* only remove if needed (04844272)

* dont blow away all files in tmp (f688efa2)

* Merge pull request #75 from djm68/clean_up_answer_file_code (b03d593e)


```
Merge pull request #75 from djm68/clean_up_answer_file_code

(maint) Clean up answer file code
```
* (maint) Clean up answer file code (5cd2b583)


```
(maint) Clean up answer file code

De-crufting the answer file generation code.
```
* Merge pull request #74 from djm68/console_portno_configurable (a69ae448)


```
Merge pull request #74 from djm68/console_portno_configurable

(maint) Allow alt portno for PE console
```
* (maint) Allow alt portno for PE console (7492b5b6)


```
(maint) Allow alt portno for PE console

PE console will have the option to run on alt portno's, adding
the ability to define an alt portno in the config file.  Still
default to port 3000.  In the cfg files, add:
CONFIG:
  - consoleport: 1234
```
* Merge pull request #73 from djm68/add_puppet_enterpriseconsole_inventory_certname (c9d351f6)


```
Merge pull request #73 from djm68/add_puppet_enterpriseconsole_inventory_certname

(maint) Fix puppet_enterpriseconsole_inventory_certname
```
* (maint) Fix puppet_enterpriseconsole_inventory_certname (5ef34c4f)


```
(maint) Fix puppet_enterpriseconsole_inventory_certname

puppet_enterpriseconsole_inventory_certname was using Master
but requires this entry to be the hostname of the node running
Console.
```
* Merge pull request #72 from djm68/add_puppet_enterpriseconsole_inventory_certname (1362cad1)


```
Merge pull request #72 from djm68/add_puppet_enterpriseconsole_inventory_certname

(maint) more tweaks to answer file: seperate console
```
* (maint) more tweaks to answer file: seperate console (8027a657)


```
(maint) more tweaks to answer file: seperate console

Adding entries for the case when console is on a non-master
node.
```
* Merge pull request #71 from djm68/add_master_entry_to_etc_hosts (637b5d9c)


```
Merge pull request #71 from djm68/add_master_entry_to_etc_hosts

(maint) Add Master entry to hosts file
```
* (maint) Add Master entry to hosts file (8c4dbcf5)


```
(maint) Add Master entry to hosts file

Try to reduce 400 errors by adding entry to /etc/hosts
```
* Merge pull request #70 from djm68/more_answer_file_fixes (b8156ba3)


```
Merge pull request #70 from djm68/more_answer_file_fixes

(maint) More mods to tweak new answer files
```
* (maint) More mods to tweak new answer files (bd113762)

* (maint) Fix platform strings in config files (d8b266fc)


```
(maint) Fix platform strings in config files

x86_64 needed, not 386
```
* Merge pull request #69 from djm68/update_answer_files (48c09cf1)


```
Merge pull request #69 from djm68/update_answer_files

(maint) answer files have changed significantly
```
* (maint) answer files have changed significantly (e74b7b50)


```
(maint) answer files have changed significantly

Time to bring answer files upto date with latest PE format.
```
* Merge pull request #68 from djm68/10375_disallow_install_with_no_dashboard (331d0f19)


```
Merge pull request #68 from djm68/10375_disallow_install_with_no_dashboard

(#10375) If the no dashboard is specified, we halt
```
* (#10375) If the no dashboard is specified, we halt (dbeb660a)


```
(#10375) If the no dashboard is specified, we halt

PE requires a Dashboard to be configured.  Added code to raise
and exception during answer file generation.  Added a new
option to TestSuite "stop_on_error" that will halt test execution
when this is set and an error is raised.
```
* Merge pull request #67 from mykhyggz/answers_auth (8479a144)


```
Merge pull request #67 from mykhyggz/answers_auth

(maint) add answers for auth_user and auth_name
```
* (maint) add answers for auth_user and auth_name (9081daf5)


```
(maint) add answers for auth_user and auth_name

New questions are causing tests to fail before install. This should address the failure.
```
* (maint) Add cloud provisioner entry to answer file generation (417c8986)


```
(maint) Add cloud provisioner entry to answer file generation

Agents only installs in ec2 did not have an entry for
cloud provisioner.
```
* (maint) Clean out old OE Linux configs (25e4a1b2)

* (maint) Adding sles single node test configs (58d53d52)


```
(maint) Adding sles single node test configs

Adding sles11 single node configs for install testing.
```
* (maint) add Ubuntu single node configs (6377fdaa)


```
(maint) add Ubuntu single node configs

Adding Ubuntu single node configs for install testing.
```
* (maint) Adding single node debian configs (b93c90c7)


```
(maint) Adding single node debian configs

Adding single node debian configs for our install only tests.
```
* (maint) add single node configs for el5 (0ea8131d)


```
(maint) add single node configs for el5

Single node configs for installer only tests
```
* (maint) adding some single node test configs (d2db361d)


```
(maint) adding some single node test configs

For install only tests, setup single node configs for our
many platforms.
```
* (maint) Remove old configs (3a356180)

* (maint) More config file sanitizing (d692695d)


```
(maint) More config file sanitizing

Rename agent cfgs to match new naming schema.
```
* Merge pull request #66 from djm68/sanitize_cfgs (081a2abb)


```
Merge pull request #66 from djm68/sanitize_cfgs

(maint) Improve cfg file names, add test cgs
```
* (maint) Improve cfg file names, add test cgs (320275a5)


```
(maint) Improve cfg file names, add test cgs

Acceptance tests are configuration driven, so adding more cfgs
which will improve our test coverage.  Modifying cfg file names
format to platform_ver-64mda-32a.cfg

platform_ver: OS platform and version
64mda: 64 bit node running Master, Dashboard, Agent
32a:   32 bit node running Agent
```
* (maint) Adding dashboard role to Master in cfg file (d339388b)

* Merge pull request #65 from djm68/merge_pe-version_installer_fixes (7154f12b)


```
Merge pull request #65 from djm68/merge_pe-version_installer_fixes

(maint) Install PE versions 1.0 - 1.2.4
```
* (maint) Install PE versions 1.0 - 1.2.4 (f716f152)


```
(maint) Install PE versions 1.0 - 1.2.4

Installing is ever more complex with so many versions, tar ball
names, and varied installing semantics.  Adding ability
to install any of the 1.x series of PE without the need to check
out older versions of the harness.  This might not be perfect as
version checks (facter, module tool etc) will fail; however, install
will run and is sufficient to bootstrap old PE versions.
```
* Merge pull request #64 from djm68/add_non_console_cfg (3780f593)


```
Merge pull request #64 from djm68/add_non_console_cfg

(#10276) Add harness config files sans dashboard
```
* (#10276) Add harness config files sans dashboard (55ed338d)


```
(#10276) Add harness config files sans dashboard

Need to test some basic install without dashboard to be sure
console questions do not leak over into non-dashboard installs.
```
* Merge pull request #62 from djm68/prep_for_cloud_provisioner_CI (6a91a318)


```
Merge pull request #62 from djm68/prep_for_cloud_provisioner_CI

(maint) added test config for new CP tests on VMware
```
* (maint) added test config for new CP tests on VMware (c8faf25e)


```
(maint) added test config for new CP tests on VMware

Config is a template only -- will update when real hosts are
provisioned.
```
* Merge pull request #58 from justinstoller/update_valid_pe (fa8d0b32)


```
Merge pull request #58 from justinstoller/update_valid_pe

(maint) Update valid pe
```
* Merge pull request #56 from justinstoller/updater_updates (fb9c58d0)


```
Merge pull request #56 from justinstoller/updater_updates

(maint) Updater updates
```
* Merge pull request #61 from djm68/update_4_new_answers (4570b94d)


```
Merge pull request #61 from djm68/update_4_new_answers

(#10276) Add fixes for additional PE answers
```
* (#10276) Add fixes for additional PE answers (10fd653a)


```
(#10276) Add fixes for additional PE answers

Even more PE answers need to be added.
```
* Merge pull request #60 from djm68/answers_for_apache_ssl (fed70d0f)


```
Merge pull request #60 from djm68/answers_for_apache_ssl

(maint) New question for setup of apache ssl
```
* (maint) New question for setup of apache ssl (dabd6fbf)


```
(maint) New question for setup of apache ssl

Update answer file generation to include new apache ssl options.
```
* Merge pull request #59 from djm68/ticket_10255_add_q_puppet_enterpriseconsole_auth (cf6fd887)


```
Merge pull request #59 from djm68/ticket_10255_add_q_puppet_enterpriseconsole_auth

(10255) add support for new answer file question
```
* added question and answer for upgrading modules (f1663831)

* (10255) add support for new answer file question (6bbd2bce)


```
(10255) add support for new answer file question

New quesiton for authenticating access to dashboard
```
* 1.2.4 is now a valid pe version (b3d1c631)

* dont guess the extensions of old versions of puppet; use whatevers there (89953af3)

* (maint) Add guthub sig to known_hosts (30e452a6)


```
(maint) Add guthub sig to known_hosts

Allow access to private git repos w/out prompting
```
* Merge branch 'master' of github.com:puppetlabs/puppet-acceptance (9ea440bc)

* (maint) allow install from private git repos (72085439)


```
(maint) allow install from private git repos

Harness was hanging up on git@github repos.
```
* Merge pull request #57 from justinstoller/spelling_correction (b7a6ead8)


```
Merge pull request #57 from justinstoller/spelling_correction

(maint) fixed small spelling mistake
```
* fixed small spelling mistake (d2f6f105)

* we use .gz tars for most recent version now (0dfbecb3)

* add files for signing multiple nodes for pe 1.2 and above (ac3d31fc)

* fix regex (13233c19)

* update upgrade answers for cloud_pro and system_packages (2fedfc42)

* handle tar & tar.gz according to how its currently setup (49739b73)

* Merge pull request #55 from djm68/mod_pe_co_setup_for_pe123 (6336f57c)


```
Merge pull request #55 from djm68/mod_pe_co_setup_for_pe123

(maint) add path to dist dir for pe123
```
* (maint) add path to dist dir for pe123 (0ef5897a)


```
(maint) add path to dist dir for pe123

Need to pull pe123 tarballs from pe123/; add code to append
pe123 path to dist tar source path
```
* Merge pull request #54 from djm68/mod_setup_to_install_old_pe_versions (05d37f6b)


```
Merge pull request #54 from djm68/mod_setup_to_install_old_pe_versions

(maint) Mod installers to handle old pe versions
```
* (maint) Mod installers to handle old pe versions (8376b841)


```
(maint) Mod installers to handle old pe versions

Required mods to install pe1.1 and 1.0 using test harness.  Many
change in platform naming, tar balls etc require ugly hacks...
```
* Merge pull request #53 from djm68/add_pe_setup_for_CO (3cff05dd)


```
Merge pull request #53 from djm68/add_pe_setup_for_CO

(maint) add special setup type for pe CO tests
```
* (maint) add special setup type for pe CO tests (44857df7)


```
(maint) add special setup type for pe CO tests

Need a special setup type to deal with major PE changes from
1.0 1.1 1.2 etc.
```
* Merge pull request #52 from djm68/add_pe_version_option (a490b5ad)


```
Merge pull request #52 from djm68/add_pe_version_option

(maint) Add --pe-version to test harness
```
* (maint) Add --pe-version to test harness (b2b8e74d)


```
(maint) Add --pe-version to test harness

With the need to test many versions of PE (old and new) it is no
longer feasible to only use the string from LATEST.  By adding
this option we can easily specify a PE version in CI and not
modfiy LATEST.  Omitting --pe-version simply falls back to using
LATEST.
```
* Merge pull request #49 from djm68/10070_sign_dashboard_certs_update_new_cert_name (fe4c52f5)


```
Merge pull request #49 from djm68/10070_sign_dashboard_certs_update_new_cert_name

10070 sign dashboard certs update new cert name
```
* (maint) use the new method "puppet" vs "on" (0712c766)


```
(maint) use the new method "puppet" vs "on"

Use the new puppet method to call "sign" which improves
portability to non-Linux OSes.
```
* (#10070) SignDashboardCerts fails wrong cert name (216025b6)


```
(#10070) SignDashboardCerts fails wrong cert name

Certnames have been changed to pe-internal-*; update the test to
use the new format for signing the dashboard cert.
```
* Merge pull request #48 from justinstoller/ticket_10032_update_parseonly_test (95df108f)


```
Merge pull request #48 from justinstoller/ticket_10032_update_parseonly_test

(#10032) adds TestCase#puppet macro to aid fixing ticket 10032
```
* adds TestCase#puppet macro to aid fixing ticket 10032 (c385ab53)

* Merge pull request #47 from bodepd/update_test_vm (0eac448b)


```
Merge pull request #47 from bodepd/update_test_vm

(maint) updated host used for cloud prov testing
```
* (maint) updated host used for cloud prov testing (a817dc30)


```
(maint) updated host used for cloud prov testing

The previous host had some conflicts with other tests.

The updated host is not currently used before 10pm.
```
* Merge pull request #46 from djm68/10038_update_answer_file_generation_cloud_provisioner (55b053c1)


```
Merge pull request #46 from djm68/10038_update_answer_file_generation_cloud_provisioner

(#10038) Update answer file generation for CP optional
```
* Merge pull request #45 from djm68/10036_update_example_cfgs (c4f36732)


```
Merge pull request #45 from djm68/10036_update_example_cfgs

(#10036) Update test config and README
```
* (#10038) Update answer file generation for CP optional (5edf0bcf)


```
(#10038) Update answer file generation for CP optional

Clould provisioner is now an optional install requiring an
additional question in the installer.  Update answer file generation to
add the new question.
```
* (#10036) Update test config and README (a496c7e8)


```
(#10036) Update test config and README

Exmaple configs and the README were woefully out of date.
```
* Merge pull request #44 from bodepd/upate_ami_os (47ee8756)


```
Merge pull request #44 from bodepd/upate_ami_os

(maint) update to use valid AMI.
```
* (maint) update to use valid AMI. (6caf819a)


```
(maint) update to use valid AMI.

Previously it was using now deprecated
el-5 AMI.

This commit updates the cloud pack test setup to
use the new centos56 AMI.
```
* Merge pull request #43 from djm68/change_config_for_master_dashboard_agent_one_host (ca2f4c39)


```
Merge pull request #43 from djm68/change_config_for_master_dashboard_agent_one_host

(#9991) Update harness config to trigger license tests
```
* Merge pull request #42 from djm68/ticket_10015_ntp_server_option (1d5ee20d)


```
Merge pull request #42 from djm68/ticket_10015_ntp_server_option

(#10015) add ntp server option to test harness
```
* (#9991) Update harness config to trigger license tests (686755e7)


```
(#9991) Update harness config to trigger license tests

Modified many test configs to have agent, master, dashboard on a
single host as this will test a different code path for the license
module.  RHEL config still have dashboard on a seperate host.
```
* (#10015) add ntp server option to test harness (54bcb49a)


```
(#10015) add ntp server option to test harness

The ntpdate server is currently hard coded into the test harness. It
uses a ntpdate server on the lan for reliability, but this removes the
option for testing while working from home.  Added --ntp-server option
to the test harness, defaults to ntp.puppetlabs.lan.
```
* Merge pull request #41 from mykhyggz/version_update (702164cb)


```
Merge pull request #41 from mykhyggz/version_update

new facter version
```
* new facter version (dea50907)

* Merge pull request #40 from djm68/simplify_vmrun_code (dc57e585)


```
Merge pull request #40 from djm68/simplify_vmrun_code

(#9981) Clean up extra commands to vrsh in test harness
```
* (#9981) Clean up extra commands to vrsh in test harness (6752f461)


```
(#9981) Clean up extra commands to vrsh in test harness

Test harness includes additional step to extract host names
from the VMware server; this step is no longer required and
removing this code removes a somewhat expensive call to the
ESX server.
```
* Merge pull request #39 from djm68/increase_ntp_timeout (45f94537)


```
Merge pull request #39 from djm68/increase_ntp_timeout

(#9980) Using internal ntp server vs. external
```
* (#9980) Using internal ntp server vs. external (d811c01d)


```
(#9980) Using internal ntp server vs. external

OPs have added an internal NTP server saving us from having to
go to the external pool.ntp.otrg system.  This will prevents the
many failures we have in setting time on our VMs post revert.
```
* Merge pull request #37 from djm68/master_dashboard_on_single_host (a0e72358)


```
Merge pull request #37 from djm68/master_dashboard_on_single_host

(maint) Need answer file for single master/dashboard cfg
```
* (maint) Need answer file for single master/dashboard cfg (822c1ab0)


```
(maint) Need answer file for single master/dashboard cfg

This is essentially a one off scenario for for installing one ec2;
need to modify the answer file generation for single host
master/dashboard/agent.  Only affects ec2 work.
```
* Merge pull request #36 from djm68/change_installer_for_tar_gz_files (c639b236)


```
Merge pull request #36 from djm68/change_installer_for_tar_gz_files

(maint) Installer support for tar.gz vs. plain tar
```
* (maint) Installer support for tar.gz vs. plain tar (b3fb8b23)


```
(maint) Installer support for tar.gz vs. plain tar

Change to handle tar.gz vs. plain tar files.  We now move lots of
files around, including in ec2.  Much more efficient to use tar.gz
vs plain tar files.
```
* Merge pull request #35 from mykhyggz/version_strings (29ce4ba6)


```
Merge pull request #35 from mykhyggz/version_strings

change puppet version string to match current
```
* change puppet version string to match current (8b541cdd)

* Merge pull request #10 from haus/add-trace (b9a7c683)


```
Merge pull request #10 from haus/add-trace

Add --trace to dashboard rake tasks so that when they fail, more verbose
```
* Merge pull request #32 from justinstoller/master (000023c8)


```
Merge pull request #32 from justinstoller/master

(#9668) add check for rack version
```
* Merge pull request #34 from mykhyggz/yaml_error (7dc30209)


```
Merge pull request #34 from mykhyggz/yaml_error

YAML Error: Inconsistent indentation level
```
* YAML Error: Inconsistent indentation level (a13daaff)

* Merge pull request #33 from haus/ticket/9494 (af089e27)


```
Merge pull request #33 from haus/ticket/9494

Removing dirty chmod hack to expose potential failure.
```
* Removing dirty chmod hack to expose potential failure. (2fa97ca9)


```
Removing dirty chmod hack to expose potential failure.

Signed-off-by: Matthaus Litteken <matthaus@puppetlabs.com>
```
* properly specified packages (67bba35b)

* fixed typo: host['role'] > host['roles'] (d0a82a20)

* check rack version (85688086)

* Merge pull request #31 from djm68/ec2_mods (b4f5c2fd)


```
Merge pull request #31 from djm68/ec2_mods

(maint) modify harness to complete AWS PE installs
```
* (maint) Tweaks to answer file generation for aws installs (09a0498a)

* (maint) modify harness to complete AWS PE installs (13ce3b73)

* Merge pull request #30 from djm68/modify_answer_generation_for_aws (1cbbc69b)


```
Merge pull request #30 from djm68/modify_answer_generation_for_aws

(maint) Mods answer file generation for AWS installs
```
* (maint) Mods answer file generation for AWS installs (58f13e71)


```
(maint) Mods answer file generation for AWS installs

Due to the difference in AWS hostname scheme, need to query
http://169.254.169.254/2008-02-01/meta-data/public-hostname
for the corect cert name.
```
* Merge pull request #29 from djm68/add_aws_install_method (7627d852)


```
Merge pull request #29 from djm68/add_aws_install_method

(maint) Add ec2 install method
```
* (maint) Add ec2 install method (9b313486)


```
(maint) Add ec2 install method

For scale testing, we need the ability to install PE on ec2
instances.  New install type "pe_aws" installs PE on nodes,
and works in conjunction with pe-builder to actually provision
the nodes.
```
* Merge pull request #27 from djm68/another_try_to_fix_agent_test (b835b42c)


```
Merge pull request #27 from djm68/another_try_to_fix_agent_test

(9140) puppet agent test fails
```
* (9140) puppet agent test fails (a6210a2a)


```
(9140) puppet agent test fails

Puppet agent --test fails in an unpredictable manner.  Add an
addition sleep step to assist in debugging problem
```
* Merge pull request #26 from djm68/simplify_pe_checking (c4fe00b3)


```
Merge pull request #26 from djm68/simplify_pe_checking

(maint) More cleanup for PE type checking
```
* (maint) More cleanup for PE type checking (ad04f60a)

* Merge pull request #25 from djm68/cleanup_vmrun_code (9d8ee04a)


```
Merge pull request #25 from djm68/cleanup_vmrun_code

(maint) cleanup PE type checking
```
* (maint) cleanup PE type checking (6e346971)


```
(maint) cleanup PE type checking

several places in the test environment check for install type
"pe" and "pe_ro"; need only check for "pe".
```
* Merge pull request #24 from bodepd/dashboard_warning (64318770)


```
Merge pull request #24 from bodepd/dashboard_warning

(#9556) Dashboard should not be required for PE test
```
* (#9556) Dashboard should not be required for PE test (da38f63c)


```
(#9556) Dashboard should not be required for PE test

You should be able to request the hostname of the dashboard
host without making dashboard a required host for a test.
```
* Merge pull request #23 from bodepd/add_silent_option_back (4ba35eb3)


```
Merge pull request #23 from bodepd/add_silent_option_back

(maint) Add silent option back to on method
```
* (maint) Add silent option back to on method (bdcd4079)


```
(maint) Add silent option back to on method

We had unwittenly deprecated this option
and it turns out is used so this caused test
failures.
```
* Merge pull request #22 from bodepd/9538_skip_answers_generation_for_non-pe_tests (f1b2797f)


```
Merge pull request #22 from bodepd/9538_skip_answers_generation_for_non-pe_tests

(#9538) Do not generate PE answers arrays on non-PE tests
```
* (#9538) Do not generate PE answers arrays on non-PE tests (3020c1ca)


```
(#9538) Do not generate PE answers arrays on non-PE tests

Previously, the answers files templates were being generated on
non-PE tests. This makes it hard to make changes to the
answers generation and understand the tests that it may imact.
```
* Merge pull request #20 from djm68/fix_answerfile_generation (81a9444f)


```
Merge pull request #20 from djm68/fix_answerfile_generation

(maint) fix answer file gen -- breaking non PE tests
```
* (maint) fix answer file gen -- breaking non PE tests (f95db60c)


```
(maint) fix answer file gen -- breaking non PE tests

Answer file gen was using "dashboard" which is actually a method call
which checks for the validity of dashboard config; in this case, a
FOSS test has not dashboard and then fails
```
* (maint) add support for CP for vm reversion (7c5564f6)


```
(maint) add support for CP for vm reversion

The setup type pe_cp needed to be added to vmrun as supported setup
type.
```
* Merge pull request #19 from bodepd/update_vm_name (2cf66dfe)


```
Merge pull request #19 from bodepd/update_vm_name

(maint) update name of vm to use for tests
```
* (maint) update name of vm to use for tests (a16128b6)

* Merge pull request #18 from djm68/fix_stdout_logging (af74349d)


```
Merge pull request #18 from djm68/fix_stdout_logging

Fix stdout logging
```
* (maint) Improve logging (a99f4d08)


```
(maint) Improve logging

Adding hostname to output for stdout, stderr, exit code.
```
* (maint) Crust removal (2cbf842d)

* Merge pull request #17 from bodepd/cp_work (35ad88d9)


```
Merge pull request #17 from bodepd/cp_work

Cp work
```
* (#9519) Add config file for rhel 5 CP tests (821251df)


```
(#9519) Add config file for rhel 5 CP tests

Adds a config file for rhel5-latest i386.
```
* (#9494) document that chown line needs to be removed (ebcf55a1)


```
(#9494) document that chown line needs to be removed

it is actually masking a potential bug and needs to
be removed
```
* Merge pull request #16 from bodepd/9515_use_key_options (46352807)


```
Merge pull request #16 from bodepd/9515_use_key_options

(#9515) Use key options
```
* (#9515) Use key options (576c7784)


```
(#9515) Use key options

Need to update the CP setup script to use the new
key params.
```
* Merge pull request #15 from djm68/add_ssh_config_opts (9c6e010a)


```
Merge pull request #15 from djm68/add_ssh_config_opts

(maint) Adding support to pass sshkey and cloud ID as arg
```
* (maint) Adding support to pass sshkey and cloud ID as arg (b91ebfcb)


```
(maint) Adding support to pass sshkey and cloud ID as arg

Need ability to use alternate sshkeys and cloud provider ID keys
to allow provisioning and testing in clouds
```
* Merge pull request #14 from bodepd/ec2_support (194112bf)


```
Merge pull request #14 from bodepd/ec2_support

Ec2 support
```
* Only use one ec2 node. (08ffc23c)


```
Only use one ec2 node.

FOr performance, we only need one node from ec2.

This node can serve as both the dashboard and master.
```
* (#9494) chown reports dir on master (30a2c740)


```
(#9494) chown reports dir on master

This is a work-around for #9494. we fix the
permissions on the reports dir for the master after
installation. This should be removed when #9494 is
really fixed.
```
* (#9504) Add specified hostname as certdnsname (b992b147)


```
(#9504) Add specified hostname as certdnsname

To support ec2 where the hostname used is not the
same as what is returned by `hostname`

This patch adds the hostname from the config file
as a certdnsname.
```
* (maint) Add PE specific check for ruby (3eb4bd61)


```
(maint) Add PE specific check for ruby

Checking the version on ruby was blindly looking for Ruby in the
search path, else in the puppet bin dir.  Made the test specific,
checking specifically for PE or non-PE installs.
```
* Add setup type for cp_pe (35819b56)


```
Add setup type for cp_pe

Adds a type that can be used to take a host config
file that does not have a master, create a new
node to serve as the master and generate a new
config file.
```
* Add ability to retrieve test config as a hash (9ddcee4e)


```
Add ability to retrieve test config as a hash

This can be used to save the current state of
tests so that hosts can be programmatically added
to existing configurations.
```
* Merge pull request #11 from djm68/cleanup_configs (9c0e9ca5)


```
Merge pull request #11 from djm68/cleanup_configs

(maint) clean up configs
```
* Merge pull request #13 from bodepd/9449_forward_agents (fab014ef)


```
Merge pull request #13 from bodepd/9449_forward_agents

(#9449) forward agents by default.
```
* (#9449) forward agents by default. (634a371b)


```
(#9449) forward agents by default.

Updates the test harness to forward ssh agent
by default.

This is a requirement of the acceptance tests for
the cloud provisioner.
```
* (maint)  Modify harness to allow alternate ssh key (7763c47c)


```
(maint)  Modify harness to allow alternate ssh key

To allow the use of alternate ssh credentials for use with such
things as EC2, we need the ability to used arbitrary ssh keys.
Added -k and --key
```
* (maint) Increment puppet version for CmdrKeith (c5008cc0)

* Add --trace to dashboard rake tasks so that when they fail, more verbose output is available. (23947b4d)


```
Add --trace to dashboard rake tasks so that when they fail, more verbose output is available.

Signed-off-by: Matthaus Litteken <matthaus@puppetlabs.com>
```
### <a name = "pe1.2">pe1.2 - 6 Sep, 2011 (ba3dadd2)

* Initial release.
