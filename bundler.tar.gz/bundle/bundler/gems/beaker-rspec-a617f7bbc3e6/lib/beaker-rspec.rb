module BeakerRSpec
  require 'beaker'

  require 'beaker-rspec/beaker_shim'
  require 'beaker-rspec/spec_helper'
  require 'beaker-rspec/version'

end
