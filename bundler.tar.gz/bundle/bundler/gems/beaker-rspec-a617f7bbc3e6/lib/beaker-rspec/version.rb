module BeakerRSpec
  module Version
    STRING = '5.3.0'
  end
end
