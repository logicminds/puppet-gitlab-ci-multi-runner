ENV['RS_SETFILE'] ||= 'sample.cfg'

require "beaker-rspec"
